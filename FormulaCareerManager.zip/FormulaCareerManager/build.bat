@echo off
rem Builds dist\FormulaCareerManager\ (portable folder with FormulaCareerManager.exe) and dist\FormulaCareerManager.zip.
rem No Python/Node needed on the target PC.
rem Requirements on the BUILD machine only: Python 3.10+ and Node.js 18+.
setlocal
cd /d "%~dp0"

echo [1/4] Frontend dependencies...
pushd frontend
if not exist node_modules call npm install --no-audit --no-fund || goto :fail
echo [2/4] Building frontend...
call npm run build || goto :fail
popd

echo [3/4] Python build tools...
python -m pip install --quiet --upgrade pyinstaller pytest || goto :fail

echo [4/4] Running tests and packaging...
python -m pytest -q backend\tests || goto :fail
python -m PyInstaller --noconfirm --clean FormulaCareerManager.spec || goto :fail
copy /y README.md dist\FormulaCareerManager\LEEME.md >nul
if exist dist\FormulaCareerManager.zip del dist\FormulaCareerManager.zip
timeout /t 3 /nobreak >nul
pushd dist
tar -a -c -f FormulaCareerManager.zip FormulaCareerManager || (popd & goto :fail)
popd

echo.
echo OK: dist\FormulaCareerManager\FormulaCareerManager.exe  (and dist\FormulaCareerManager.zip)
echo Copy the folder (or unzip the zip) on any Windows 10/11 PC and run FormulaCareerManager.exe.
exit /b 0

:fail
echo BUILD FAILED
exit /b 1
