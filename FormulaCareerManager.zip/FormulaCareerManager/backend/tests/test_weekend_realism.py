"""Real grid, Q1/Q2/Q3, race lengths (305 km rule), pre-season sprint choice, strategies, conditions,
market value, summer-break transfers, career start modes, personality test."""
import pytest

from fcm.ac_integration import race_ini
from fcm.career_engine import editor, personality, progression, repo, sessions, weekend
from fcm.career_engine.store import store
from fcm.career_engine.world_builder import create_career, load_template
from fcm.management import market, transfers
from fcm.management.common import player_team_id, team_drivers


def _career(cats=('F1',), rounds=None, player=None, settings=None, seed=12):
    store.init_app_db()
    w = load_template()
    if rounds: w['calendar'] = [r for i, r in enumerate(w['calendar']) if i in rounds]
    create_career({'name': f'WR {seed}', 'seed': seed, 'world': w, 'categories': list(cats), 'settings': settings or {'race_length': 25},
                   'player': player or {'first_name': 'Nuevo', 'last_name': 'Piloto', 'team_index': 5, 'rating': 82}})
    return store.require()


def _session(db, code, round_no=1, cat='F1'):
    return db.one('SELECT s.* FROM sessions s JOIN calendar_rounds cr ON cr.id = s.round_id JOIN championships ch ON ch.id = s.championship_id JOIN categories c ON c.id = ch.category_id '
                  'WHERE s.code = ? AND cr.round_no = ? AND c.code = ? AND cr.season_id = (SELECT current_season_id FROM career)', (code, round_no, cat))


def _run_round(db):
    rnd = weekend.current_round(db)
    while True:
        rows = weekend.pending_sessions(db, rnd['id'])
        if not rows: break
        (sessions.skip if rows[0]['type'] == 'practice' else sessions.simulate)(db, rows[0]['id'])
    return rnd


def test_real_grid_and_existing_driver_mode():
    db = _career(cats=('F1', 'F2', 'F3'), rounds=[0], player={'mode': 'existing', 'category': 'F1', 'team_index': 9, 'slot': 0})
    season = repo.current_season(db)
    sizes = {c['category_code']: len(repo.entries(db, c['id'])) for c in repo.championships(db, season['id'])}
    assert sizes == {'F1': 22, 'F2': 22, 'F3': 30}
    p = db.one('SELECT first_name, last_name FROM drivers WHERE is_player = 1')
    assert (p['first_name'], p['last_name']) == ('Fernando', 'Alonso')
    ver = db.one("SELECT a.base_rating, a.pace FROM drivers d JOIN driver_attributes a ON a.driver_id = d.id WHERE d.last_name = 'Verstappen'")
    assert abs(ver['base_rating'] - 95) < 0.5 and ver['pace'] == 96
    assert db.value("SELECT COUNT(*) FROM drivers WHERE is_generated = 1") == 0      # no invented drivers at the start


def test_race_length_modes_follow_305km_rule():
    db = _career(rounds=[0, 5, 12], settings={'race_length': 100})
    assert sessions.session_format(db, sessions.get(db, _session(db, 'R', 1)['id']))['laps'] == 58     # Albert Park
    assert sessions.session_format(db, sessions.get(db, _session(db, 'R', 2)['id']))['laps'] == 78     # Monaco (260 km)
    assert sessions.session_format(db, sessions.get(db, _session(db, 'R', 3)['id']))['laps'] == 53     # Monza
    repo.update_career(db, settings={**repo.career(db)['settings'], 'race_length': 'laps5'})
    assert sessions.session_format(db, sessions.get(db, _session(db, 'R', 3)['id']))['laps'] == 5
    repo.update_career(db, settings={**repo.career(db)['settings'], 'race_length': 25})
    assert sessions.session_format(db, sessions.get(db, _session(db, 'R', 1)['id']))['laps'] == 15     # 76.25 km


def test_f2_half_distance():
    db = _career(cats=('F1', 'F2'), rounds=[0], settings={'race_length': 100})
    assert sessions.session_format(db, sessions.get(db, _session(db, 'R', 1, 'F2')['id']))['laps'] == 29       # 152.5 km


def test_knockout_qualifying_and_grid():
    db = _career(rounds=[0])
    q = _session(db, 'Q')
    fp = _session(db, 'FP1')
    sessions.skip(db, fp['id'])
    sessions.simulate(db, q['id'])
    res = sessions.summary(db, q['id'])
    stage_sizes = [len([x for x in res['stages'] if x['stage'] == k]) for k in (1, 2, 3)]
    assert stage_sizes == [22, 16, 10]
    top10 = res['results'][:10]
    assert all(r['q_stage'] == 3 and r['q3_ms'] for r in top10) and all(r['q_stage'] == 1 for r in res['results'][16:])
    race = sessions.get(db, _session(db, 'R')['id'])
    field, _ = sessions.build_field(db, race)
    assert field[0]['driver_id'] == res['results'][0]['driver_id']


def test_sprint_weekend_choice_only_before_season():
    db = _career(rounds=[0, 2])
    r1 = db.one('SELECT * FROM calendar_rounds WHERE round_no = 1')
    editor.update_round(db, r1['id'], {'sprint': True})
    codes = [s['code'] for s in db.all('SELECT code FROM sessions WHERE round_id = ? ORDER BY order_no', (r1['id'],))]
    assert codes == ['FP1', 'SQ', 'S', 'Q', 'R']
    sp = sessions.get(db, _session(db, 'S')['id'])
    assert sp['points_system'] == 'f1_sprint'
    _run_round(db)
    r2 = db.one('SELECT * FROM calendar_rounds WHERE round_no = 2')
    with pytest.raises(ValueError): editor.update_round(db, r2['id'], {'sprint': True})
    res = sessions.summary(db, sp['id'])['results']
    assert [r['points'] for r in res[:9]] == [8, 7, 6, 5, 4, 3, 2, 1, 0]


def test_player_strategy_validation_and_use():
    db = _career(rounds=[0], settings={'race_length': 50})
    r = _session(db, 'R')
    with pytest.raises(sessions.SessionError): sessions.set_strategy(db, r['id'], {'compounds': ['M'], 'pit_laps': []})      # F1 needs two compounds
    laps = sessions.session_format(db, sessions.get(db, r['id']))['laps']
    sessions.set_strategy(db, r['id'], {'compounds': ['S', 'M', 'H'], 'pit_laps': [laps // 3, 2 * laps // 3]})
    _run_round(db)
    pid = repo.career(db)['player_driver_id']
    row = db.one('SELECT strategy, pit_stops, status FROM results WHERE session_id = ? AND driver_id = ?', (r['id'], pid))
    assert row['status'] != 'FIN' or (row['strategy'] == 'S-M-H' and row['pit_stops'] == 2)


def test_conditions_night_race_and_unclamped_sun():
    db = _career(rounds=[16])    # Singapore
    s = sessions.get(db, _session(db, 'R')['id'])
    cond = sessions.conditions(db, s)
    assert cond['time'] == '20:00' and cond['night'] and cond['weather']
    assert race_ini.sun_angle('20:00') == 80 and race_ini.sun_angle('20:00', clamp=False) == 112


def test_market_value_is_dynamic():
    db = _career(rounds=[0, 1])
    _run_round(db)
    mv = {r['last_name']: r['market_value'] for r in db.all('SELECT last_name, market_value FROM drivers')}
    assert mv['Verstappen'] > mv['Stroll'] > 0 and mv['Lindblad'] > mv['Stroll'] * 0.5


def test_summer_break_transfer_moves_player_and_fills_seats():
    db = _career(rounds=[9, 10, 11])   # Belgium, Hungary (summer break after), Netherlands
    season = repo.current_season(db)
    old_team = player_team_id(db)
    target = next(t for t in market.overview(db)['teams'] if t['tier'] == 1 and t['team_id'] != old_team)
    oid = db.insert('offers', {'season_id': season['id'], 'driver_id': repo.career(db)['player_driver_id'], 'team_id': target['team_id'], 'category_code': 'F1',
                               'role': 'D1', 'salary': 5, 'years': 2, 'origin': 'ai', 'status': 'open', 'reason_json': '{}', 'create_ts': 'x'})
    assert market.accept_offer(db, oid)['effective'] == 'summer'
    _run_round(db)
    assert player_team_id(db) == old_team            # still at the old team before the break
    _run_round(db)                                     # Hungary -> summer window
    assert player_team_id(db) == target['team_id']
    for t in db.all('SELECT DISTINCT team_id FROM championship_entries WHERE championship_id = (SELECT id FROM championships WHERE season_id = ? AND category_id = 1)', (season['id'],)):
        assert len(team_drivers(db, season['id'], t['team_id'])) == 2
    assert db.value("SELECT COUNT(*) FROM domain_events WHERE type = 'MIDSEASON_TRANSFER'") >= 2   # player + replacement
    _run_round(db)
    progression.finish_season(db)
    ents = repo.entries(db, repo.championships(db, repo.current_season(db)['id'])[0]['id'])
    assert len(ents) == 22 and len({e['driver_id'] for e in ents}) == 22
    nxt = db.all('SELECT * FROM calendar_rounds WHERE season_id = ? ORDER BY round_no', (repo.current_season(db)['id'],))
    assert all(r['start_time'] and r['official_length_m'] and r['climate'] and r['circuit'] for r in nxt)   # real data carried to the next season
    assert [r['summer_break_after'] for r in nxt] == [0, 1, 0]


def test_rookies_only_created_in_lowest_category():
    db = _career(cats=('F1', 'F2', 'F3'), rounds=[0])
    weekend.simulate_rest_of_season(db)
    progression.finish_season(db)
    tiers = [db.value('SELECT c.tier FROM teams t JOIN categories c ON c.id = t.category_id WHERE t.id = ?', (eval(e['payload_json'].replace('null', 'None'))['team_id'],))
             for e in db.all("SELECT payload_json FROM domain_events WHERE type = 'ROOKIE_GENERATED'")]
    assert all(t == 3 for t in tiers)
    s = repo.current_season(db)
    sizes = {c['category_code']: len(repo.entries(db, c['id'])) for c in repo.championships(db, s['id'])}
    assert sizes == {'F1': 22, 'F2': 22, 'F3': 30}


def test_personality_test_recommendation():
    w = load_template()
    rookie = personality.evaluate({'background': 'f4', 'style': 'attacker', 'talent': 'generational', 'ambition': 'mid'}, w)
    assert rookie['category'] == 'F3' and rookie['potential'] > rookie['rating'] + 8 and rookie['teams']
    pro = personality.evaluate({'background': 'ready', 'ambition': 'top'}, w)
    assert pro['category'] == 'F1' and pro['teams'][0]['car_rank'] == 1
