"""Rating model tests - scenarios from sections 73, 97, 98, 99 and 100 of the spec."""
import random

from conftest import evidence_for, make_state

from fcm.career_engine.rating import season_end_update, weekend_update


def weekend(pcfg, state, q_exp, q_act, r_exp, r_act, **kw):
    ev = evidence_for(pcfg, 'qualifying', q_exp, q_act) + evidence_for(pcfg, 'race', r_exp, r_act, **kw)
    return weekend_update(state, ev, pcfg)


def test_exceptional_weekend_example_97(pcfg):
    s = make_state(pcfg, base=86.40, form=0.2, potential=89)
    s2, rec = weekend(pcfg, s, 8, 3, 7, 2)
    assert 0 < rec['delta'] <= 0.08            # 86.40 -> ~86.45, never 86 -> 89
    assert 0.6 <= s2['form'] <= 1.6           # form reacts strongly (~+1.1)
    assert rec['reasons']


def test_ten_excellent_races_example_98(pcfg):
    s = make_state(pcfg, base=86.40, potential=90)
    for _ in range(10): s, rec = weekend(pcfg, s, 8, 3, 7, 2)
    gain = s['base'] - 86.40
    assert 0.35 <= gain <= 1.0                  # noticeable permanent improvement (~+0.65)


def test_bad_streak_example_99(pcfg):
    s = make_state(pcfg, base=90.0, potential=91)
    s, _ = weekend(pcfg, s, 4, 5, 4, 22, status='DNF', dnf_reason='incident')
    s, _ = weekend(pcfg, s, 4, 9, 4, 11)
    s, _ = weekend(pcfg, s, 4, 10, 4, 13)
    assert 89.75 <= s['base'] < 90.0            # ~89.92, never 90 -> 86
    assert -3.0 <= s['form'] <= -1.0            # ~-1.7


def test_one_terrible_race_is_mostly_form(pcfg):
    s = make_state(pcfg, base=85.0)
    s2, rec = weekend(pcfg, s, 5, 18, 5, 20)
    assert abs(rec['delta']) <= 0.08
    assert s2['form'] < -0.8


def test_form_regresses_to_zero_without_base_gain(pcfg):
    s = make_state(pcfg, base=85.0)
    s, _ = weekend(pcfg, s, 5, 18, 5, 20)
    s, _ = weekend(pcfg, s, 5, 18, 5, 20)
    low_form = s['form']
    base_after_bad = s['base']
    for _ in range(6): s, _ = weekend(pcfg, s, 5, 5, 5, 5)
    assert abs(s['form']) < abs(low_form) * 0.25     # effective performance recovers
    assert abs(s['base'] - base_after_bad) < 0.15    # ...without needing a rating jump


def test_mechanical_dnf_is_not_evidence(pcfg):
    s = make_state(pcfg, base=85.0)
    ev = evidence_for(pcfg, 'race', 5, 22, status='DNF', dnf_reason='mechanical')
    s2, rec = weekend_update(s, ev, pcfg)
    assert rec['delta'] == 0 and rec['confidence'] == 0


def test_rookie_outperforming_for_season_develops(pcfg):
    s = make_state(pcfg, base=78.0, age=19, potential=90)
    for _ in range(22): s, _ = weekend(pcfg, s, 12, 8, 12, 7)
    assert 0.8 <= s['base'] - 78.0 <= 2.2


def test_veteran_slightly_outperforming_little_growth(pcfg):
    s = make_state(pcfg, base=86.0, age=35, potential=86.5)
    for _ in range(22): s, _ = weekend(pcfg, s, 8, 7, 8, 7)
    assert 0 <= s['base'] - 86.0 <= 0.25


def test_per_race_and_window_caps(pcfg):
    s = make_state(pcfg, base=70.0, age=18, potential=97)
    deltas = []
    for _ in range(12):
        s, rec = weekend(pcfg, s, 20, 1, 20, 1)
        deltas.append(rec['delta'])
    assert max(deltas) <= pcfg['base']['max_per_race'] + 1e-6
    for i in range(len(deltas) - 4): assert sum(deltas[i:i + 5]) <= pcfg['base']['max_per_window'] + 1e-6


def test_season_end_bounded_and_ages(pcfg):
    rng = random.Random(1)
    young = make_state(pcfg, base=78.0, age=19, potential=90)
    old = make_state(pcfg, base=88.0, age=38, potential=88.0)
    mid = make_state(pcfg, base=88.0, age=34, potential=89.0)
    ys = [season_end_update(young, 0.0, pcfg, rng)[1]['delta'] for _ in range(300)]
    os_ = [season_end_update(old, 0.0, pcfg, rng)[1]['delta'] for _ in range(300)]
    ms = [season_end_update(mid, 0.0, pcfg, rng)[1]['delta'] for _ in range(300)]
    assert all(abs(d) <= pcfg['season_end']['max_change'] + 0.05 for d in ys + os_ + ms)
    assert sum(ys) / len(ys) > 0.3        # young drivers tend to improve
    assert sum(os_) / len(os_) < -0.5     # veterans tend to decline...
    assert sum(ms) / len(ms) < 0
    assert max(ms) > 0                    # ...but not deterministically (some age well)
