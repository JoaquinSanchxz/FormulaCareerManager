"""Test fixture: builds a fake Assetto Corsa install and a fake acs.exe (python script) that
reads the generated race.ini and writes race_out.json exactly like AC does. TEST USE ONLY."""
import json
import sys
from pathlib import Path


def build_install(root: Path, skins=11, csp=False):
    root.mkdir(parents=True, exist_ok=True)
    if csp:   # CSP with WeatherFX + RainFX (what detect.csp_capabilities checks)
        cfg = root / 'extension/config'
        cfg.mkdir(parents=True)
        (root / 'dwrite.dll').write_bytes(b'')
        (cfg / 'data_manifest.ini').write_text('[VERSION]\nSHADERS_PATCH=0.2.9\n[FEATURES]\nWEATHERFX_LAUNCHER_CONTROLLED=1\nCONDITIONS_24H=1\n')
        for n in ('general.ini', 'weather_fx.ini', 'rain_fx.ini'): (cfg / n).write_text('[BASIC]\nENABLED=1\n')
    (root / 'acs.exe').write_bytes(b'')
    car = root / 'content/cars/fcm_test_f1'
    (car / 'ui').mkdir(parents=True)
    (car / 'data.acd').write_bytes(b'x')
    # deliberately malformed like many mods: BOM, raw newline inside a string, trailing comma
    (car / 'ui/ui_car.json').write_bytes('﻿{"name": "Test F1 2026", "brand": "Test", "class": "race", "tags": ["open wheel", "f1",],\n "description": "line1\nline2", "year": "2026", "specs": {"bhp": "1000bhp"},}'.encode('utf-8'))
    for i in range(skins):
        sk = car / 'skins' / f'team_{i:02d}'
        sk.mkdir(parents=True)
        (sk / 'ui_skin.json').write_text(json.dumps({'skinname': f'Team {i}', 'team': f'Team {i}', 'number': str(i + 1)}))
        (sk / 'preview.jpg').write_bytes(b'\xff\xd8\xff')
    t = root / 'content/tracks/fcm_ring'
    (t / 'ui').mkdir(parents=True)
    (t / 'data').mkdir()
    (t / 'ui/ui_track.json').write_text(json.dumps({'name': 'FCM Ring', 'country': 'Spain', 'length': '4.6 km', 'pitboxes': '30', 'tags': ['circuit']}))
    m = root / 'content/tracks/fcm_multi'
    for lay, ln in (('gp', '5200m'), ('short', '3100 m')):
        (m / 'ui' / lay).mkdir(parents=True)
        (m / lay / 'data').mkdir(parents=True)
        (m / 'ui' / lay / 'ui_track.json').write_text(json.dumps({'name': f'FCM Multi {lay.upper()}', 'length': ln, 'pitboxes': 24}))
    w = root / 'content/weather/3_clear'
    w.mkdir(parents=True)
    (w / 'weather.ini').write_text('[LAUNCHER]\nNAME=Clear\n')
    return root


def _ini(text):
    out, cur = {}, None
    for line in text.splitlines():
        line = line.strip()
        if line.startswith('['): cur = line[1:-1]; out[cur] = {}
        elif '=' in line and cur: k, v = line.split('=', 1); out[cur][k] = v
    return out


def run_fake_acs(docs: Path, player_finish=None):
    ini = _ini((docs / 'cfg/race.ini').read_text(encoding='utf-8'))
    n = int(ini['RACE']['CARS'])
    stype = int(ini['SESSION_0']['TYPE'])
    laps = int(ini['SESSION_0'].get('LAPS') or 0) or 3
    players = [{'name': ini[f'CAR_{i}']['DRIVER_NAME'], 'car': ini['RACE']['MODEL'] if i == 0 else ini[f'CAR_{i}']['MODEL'], 'skin': ini[f'CAR_{i}']['SKIN']} for i in range(n)]
    speed = [100.0 if i == 0 else float(ini[f'CAR_{i}'].get('AI_LEVEL', 90)) for i in range(n)]
    lap_list, totals = [], [0] * n
    for lap in range(laps):
        for i in range(n):
            t = int(90000 - speed[i] * 50 + i * 7)
            if i == 0 and player_finish == 'dnf' and lap >= 1: continue
            lap_list.append({'car': i, 'lap': lap, 'time': t, 'sectors': [t // 3, t // 3, t - 2 * (t // 3)], 'cuts': 0, 'tyre': 'M'})
            totals[i] += t
    lapstotal = [sum(1 for l in lap_list if l['car'] == i) for i in range(n)]
    order = sorted(range(n), key=lambda i: (-lapstotal[i], totals[i]))
    session = {'event': 0, 'name': ini['SESSION_0']['NAME'], 'type': stype, 'lapsCount': laps if stype == 3 else 0, 'duration': 0,
               'laps': lap_list, 'lapstotal': lapstotal, 'bestLaps': [], 'raceResult': order if stype == 3 else []}
    (docs / 'out').mkdir(parents=True, exist_ok=True)
    (docs / 'out/race_out.json').write_text(json.dumps({'track': ini['RACE']['TRACK'], 'number_of_sessions': 1, 'players': players, 'sessions': [session], 'extras': []}))


if __name__ == '__main__':
    import os
    run_fake_acs(Path(os.environ['FCM_AC_DOCUMENTS']), sys.argv[1] if len(sys.argv) > 1 else None)
