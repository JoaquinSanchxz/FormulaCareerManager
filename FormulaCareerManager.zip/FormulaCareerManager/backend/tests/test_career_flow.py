"""Championship core: career creation, full simulated season, standings, stats, season rollover, save/reopen."""
from fcm.career_engine import championship as champ, progression, repo, weekend
from fcm.career_engine.store import store
from fcm.career_engine.world_builder import create_career, load_template


def small_world():
    w = load_template()
    w['calendar'] = w['calendar'][:3]
    w['calendar'][0]['categories'] = ['F1', 'F2']
    return w


def test_full_season_and_rollover():
    store.init_app_db()
    cid = create_career({'name': 'Flow Test', 'seed': 42, 'categories': ['F1', 'F2'], 'world': small_world(),
                         'player': {'first_name': 'Test', 'last_name': 'Driver', 'nationality': 'ESP', 'category': 'F1', 'team_index': 10, 'rating': 82}})
    db = store.require()
    season = repo.current_season(db)
    f1 = next(c for c in repo.championships(db, season['id']) if c['category_code'] == 'F1')
    assert len(repo.entries(db, f1['id'])) == 22
    # advance stops at the player's first session
    r = weekend.advance(db)
    assert r['stopped_at'] is not None
    n = weekend.simulate_rest_of_season(db)
    assert n > 0
    st = champ.driver_standings(db, f1['id'])
    assert len(st) == 22 and st[0]['points'] >= st[-1]['points']
    assert sum(d['wins'] for d in st) == 3
    cons = champ.constructor_standings(db, f1['id'])
    assert abs(sum(t['points'] for t in cons) - sum(d['points'] for d in st)) < 1e-6
    hist = db.value("SELECT COUNT(*) FROM driver_rating_history WHERE kind = 'race'")
    assert hist >= 22 * 3
    deltas = [r['delta'] for r in db.all("SELECT delta FROM driver_rating_history WHERE kind = 'race'")]
    assert max(abs(d) for d in deltas) <= 0.08 + 1e-6
    stats = champ.driver_stats(db, st[0]['driver_id'])
    assert stats['F1']['starts'] == 3
    res = progression.finish_season(db)
    assert res['new_season'] == season['year'] + 1
    new = repo.current_season(db)
    f1n = next(c for c in repo.championships(db, new['id']) if c['category_code'] == 'F1')
    ents = repo.entries(db, f1n['id'])
    assert len(ents) == 22
    assert any(e['is_player'] for e in ents)
    assert len({e['number'] for e in ents}) == 22
    assert db.value('SELECT COUNT(*) FROM calendar_rounds WHERE season_id = ?', (new['id'],)) == 3
    # close + reopen = same state
    points_before = champ.driver_standings(db, f1['id'])[0]['points']
    store.close()
    db2 = store.open(cid)
    assert champ.driver_standings(db2, f1['id'])[0]['points'] == points_before
    assert repo.current_season(db2)['year'] == season['year'] + 1
