"""Mandatory long-run test (spec section 74): 100 fictional seasons with the real simulator,
rating evidence, weekend updates, season-end development, retirements and rookies.
Prints a metrics report (pytest -s) and asserts the world stays sane."""
import random
import statistics

from fcm.career_engine.rating import (generate_rookie_attributes, retirement_probability, season_end_update, session_scores,
                                      weekend_update)
from fcm.career_engine.world_builder import attrs_around, make_car
from fcm.shared import config
from fcm.simulation import engine
from fcm.simulation.model import base_rating

SEASONS, RACES, LAPS = 100, 22, 12


def new_driver(rng, pcfg, level=None, age=None):
    if level is None:
        r = generate_rookie_attributes(rng, pcfg)
        attrs, pot, age, dev = r['attrs'], r['potential'], r['age'], r['development_rate']
    else:
        attrs = attrs_around(level, rng)
        b = base_rating(attrs, pcfg['attribute_weights'])
        pot, dev = b + max(0.5, (27 - age) * 0.9), 1.0
    b = base_rating(attrs, pcfg['attribute_weights'])
    return {'attrs': attrs, 'base': b, 'form': 0.0, 'morale': 60.0, 'potential': max(pot, b), 'age': age, 'development_rate': dev, 'progress': {},
            'seasons': 0, 'start_base': b}


def test_hundred_seasons_stay_sane(pcfg):
    rng = random.Random(2026)
    scfg, car_cfg = config.load('simulation'), config.load('car_model')
    profiles = list(config.load('track_archetypes').values())
    strengths = [94.5, 94, 93.6, 93.2, 91.8, 91.2, 90.9, 90.6, 90.2, 89.5, 88.6]
    cars = [make_car(s, rng) for s in strengths]
    drivers = [new_driver(rng, pcfg, level=rng.uniform(78, 90), age=rng.randint(20, 35)) for _ in range(22)]
    season_means, season_max, per_race_max, rookie_first_season, form_abs, veteran_drops = [], [], 0.0, [], [], []
    for season in range(SEASONS):
        for race in range(RACES):
            prof = profiles[race % len(profiles)]
            field = [{'driver_id': i, 'team_id': i // 2, 'attrs': d['attrs'], 'form': d['form'], 'morale': d['morale'], 'car': cars[i // 2]}
                     for i, d in enumerate(drivers)]
            ctx = {'scfg': scfg, 'pcfg': pcfg, 'car_cfg': car_cfg, 'profile': prof, 'base_lap_s': 80.0, 'laps': LAPS, 'wet': rng.random() < 0.1}
            evidence = {i: [] for i in range(22)}
            q = engine.simulate(field, 'qualifying', ctx, rng)
            grid = {r['driver_id']: r['position'] for r in q}
            for f in field: f['grid_position'] = grid[f['driver_id']]
            r = engine.simulate(field, 'race', ctx, rng)
            for stype, rows in (('qualifying', q), ('race', r)):
                ev_rows = [{**x, 'strength': engine.expected_perf(field[x['driver_id']], stype, ctx), 'source_confidence': 0.8} for x in rows]
                for e in session_scores(stype, ev_rows, pcfg, scfg['laptime_per_point'] * 100): evidence[e['driver_id']].append(e)
            for i, d in enumerate(drivers):
                new, rec = weekend_update(d, evidence[i], pcfg)
                per_race_max = max(per_race_max, abs(rec['delta']))
                form_abs.append(abs(new['form']))
                drivers[i] = {**d, **new}
        # season end
        for i, d in enumerate(drivers):
            d['age'] += 1
            new, _ = season_end_update(d, 0.0, pcfg, rng)
            new['seasons'] = d['seasons'] + 1
            if d['seasons'] == 0 and d.get('rookie'): rookie_first_season.append(new['base'] - d['start_base'])
            if d['age'] >= 33: veteran_drops.append(new['base'] - d.get('season_start_base', d['start_base']))
            drivers[i] = {**d, **new, 'season_start_base': new['base']}
        for i, d in enumerate(drivers):
            if rng.random() < retirement_probability(d['age'], d['base'], pcfg['retirement']):
                drivers[i] = {**new_driver(rng, pcfg, level=rng.gauss(80, 2.5), age=rng.randint(20, 23)), 'rookie': True}  # F2 graduate
        cars = [{k: v + (statistics.mean(c[k] for c in cars) - v) * 0.3 + rng.gauss(0, 0.8) for k, v in car.items()} for car in cars]
        bases = [d['base'] for d in drivers]
        season_means.append(statistics.mean(bases))
        season_max.append(max(bases))
    elite_share = sum(1 for d in drivers if d['base'] >= 95) / len(drivers)
    report = {'mean_first10': round(statistics.mean(season_means[:10]), 2), 'mean_last10': round(statistics.mean(season_means[-10:]), 2),
              'max_ever': round(max(season_max), 2), 'min_mean': round(min(season_means), 2), 'max_mean': round(max(season_means), 2),
              'per_race_max_delta': round(per_race_max, 4), 'elite_share_end': elite_share,
              'rookie_first_season_mean': round(statistics.mean(rookie_first_season), 3) if rookie_first_season else None,
              'rookie_first_season_max': round(max(rookie_first_season), 3) if rookie_first_season else None,
              'mean_abs_form': round(statistics.mean(form_abs), 3), 'worst_veteran_season': round(min(veteran_drops), 3),
              'mean_veteran_season': round(statistics.mean(veteran_drops), 3)}
    print('\n100-season metrics:', report)
    assert per_race_max <= pcfg['base']['max_per_race'] + 1e-6          # one race never moves skill much
    assert 72 <= min(season_means) and max(season_means) <= 90         # average grid talent stays reasonable
    assert abs(report['mean_last10'] - report['mean_first10']) < 4        # no long-run drift
    assert max(season_max) < 99.5                                        # ratings do not explode
    assert elite_share < 0.25                                            # not everybody ends 95+
    assert rookie_first_season and max(rookie_first_season) < 3.5        # rookies do not rocket
    assert 0.1 < report['mean_abs_form'] < 2.0                           # form does respond short-term
    assert min(veteran_drops) > -3.5                                     # veterans do not collapse absurdly
