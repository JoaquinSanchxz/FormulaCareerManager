"""AC integration: detection/validation, content scanner, lenient JSON, race.ini, race_out parser, safe paths."""
import json

import pytest
from fake_ac import build_install

from fcm.ac_integration import detect, race_ini, results, scanner
from fcm.shared import lenient_json
from fcm.shared.safefs import UnsafePathError, atomic_write_text, ensure_within, safe_id


def test_validate_and_scan(tmp_path):
    root = build_install(tmp_path / 'assettocorsa')
    assert detect.validate_install(root)['valid']
    assert not detect.validate_install(tmp_path)['valid']
    data = scanner.scan_content(root)
    car = next(c for c in data['cars'] if c['id'] == 'fcm_test_f1')
    assert car['name'] == 'Test F1 2026' and car['year'] == 2026 and car['has_data_acd'] and len(car['skins']) == 11
    assert 'line1\nline2' == car['description']
    tracks = {t['id']: t for t in data['tracks']}
    assert tracks['fcm_ring']['layouts'][0]['id'] == '' and tracks['fcm_ring']['layouts'][0]['length_m'] == 4600
    assert tracks['fcm_ring']['layouts'][0]['pitboxes'] == 30
    assert sorted(l['id'] for l in tracks['fcm_multi']['layouts']) == ['gp', 'short']
    assert [w['id'] for w in data['weathers']] == ['3_clear']


def test_library_folders_vdf():
    vdf = '"libraryfolders"\n{\n "0"\n {\n  "path"\t\t"C:\\\\Program Files (x86)\\\\Steam"\n  "apps" { "244210" "123" }\n }\n "1"\n {\n  "path"\t\t"D:\\\\SteamLibrary"\n }\n}'
    libs = [str(p) for p in detect.parse_library_folders(vdf)]
    assert 'D:\\SteamLibrary' in libs and len(libs) == 2


@pytest.mark.parametrize('value,expected', [('5.3 km', 5300), ('5793m', 5793), ('3,6 km', 3600), ('2 mi', 3218.7), (4200, 4200), ('bad', None)])
def test_length_parse(value, expected):
    assert scanner.parse_length_m(value) == expected


def test_lenient_json():
    assert lenient_json.loads('{"a": [1, 2,], // c\n "b": "x\ny",}') == {'a': [1, 2], 'b': 'x\ny'}


def test_safe_paths(tmp_path):
    with pytest.raises(UnsafePathError): ensure_within(tmp_path, '../x')
    with pytest.raises(UnsafePathError): safe_id('..')
    with pytest.raises(UnsafePathError): safe_id('a/b')
    atomic_write_text(tmp_path / 'f.ini', 'A=1\n')
    assert (tmp_path / 'f.ini').read_text() == 'A=1\n'


def test_race_ini_build():
    spec = race_ini.SessionSpec(track='fcm_ring', layout='', session_type='race', name='GP', laps=5,
                                player=race_ini.CarEntry(model='fcm_test_f1', skin='team_00', driver_name='Me', ballast=5),
                                opponents=[race_ini.CarEntry(model='fcm_test_f1', skin='team_01', driver_name='AI [1]', ai_level=93.4, ai_aggression=25)],
                                player_grid_position=2, time_of_day='15:00')
    ini = race_ini.parse(race_ini.build(spec))
    assert ini['RACE']['CARS'] == '2' and ini['RACE']['TRACK'] == 'fcm_ring' and ini['RACE']['RACE_LAPS'] == '5'
    assert ini['CAR_0']['MODEL'] == '-' and ini['CAR_0']['BALLAST'] == '5'
    assert ini['CAR_1']['AI_LEVEL'] == '93.4' and ini['CAR_1']['DRIVER_NAME'] == 'AI (1)'
    assert ini['SESSION_0']['TYPE'] == '3' and ini['SESSION_0']['SPAWN_SET'] == 'START' and ini['SESSION_0']['STARTING_POSITION'] == '2'
    assert ini['LIGHTING']['SUN_ANGLE'] == '32'  # 16 deg per hour after 13:00
    with pytest.raises(UnsafePathError):
        race_ini.build(race_ini.SessionSpec(track='../x', layout='', session_type='race', name='x', player=race_ini.CarEntry(model='a')))


def _race_out(laps_by_car, race_result=None, stype=3, laps=3):
    lap_list = []
    for car, times in enumerate(laps_by_car):
        for i, t in enumerate(times): lap_list.append({'car': car, 'lap': i, 'time': t, 'sectors': [1, 2, 3], 'cuts': 0, 'tyre': 'M'})
    return {'track': 't', 'players': [{'name': f'D{i}', 'car': 'c', 'skin': 's'} for i in range(len(laps_by_car))],
            'sessions': [{'name': 'R', 'type': stype, 'lapsCount': laps, 'laps': lap_list, 'lapstotal': [len(x) for x in laps_by_car],
                          'bestLaps': [], 'raceResult': race_result or []}]}


def test_results_race_with_dnf_and_lapped():
    raw = _race_out([[90000] * 3, [91000] * 3, [95000, 95000], [89000]], race_result=[0, 1, 2, 3])
    p = results.parse(raw, 'race', ['D0', 'D1', 'D2', 'D3'])
    cars = p['cars']
    assert [cars[i]['position'] for i in range(4)] == [1, 2, 3, 4]
    assert cars[0]['status'] == 'FIN' and cars[1]['gap_ms'] == 3000
    assert cars[2]['status'] == 'FIN' and cars[2]['laps_down'] == 1     # lapped but running at the end
    assert cars[3]['status'] == 'DNF'                                    # stopped after 1 lap
    assert p['fastest_lap_car'] == 3 and p['complete']


def test_results_qualifying_and_mismatch():
    raw = _race_out([[91000, 90500], [90000], []], stype=2)
    p = results.parse(raw, 'qualifying', ['D0', 'X', 'D2'])
    assert p['order'] == [1, 0, 2] and p['warnings']
    with pytest.raises(results.ResultParseError): results.parse(raw, 'qualifying', ['D0'])


def test_results_file_roundtrip(tmp_path):
    f = tmp_path / 'race_out.json'
    f.write_text(json.dumps(_race_out([[1000]])))
    assert results.load(f)['players'][0]['name'] == 'D0'
