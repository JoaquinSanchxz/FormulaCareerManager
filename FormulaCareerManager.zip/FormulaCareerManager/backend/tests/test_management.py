"""Phases 5-8: finances/ledger/cost cap, R&D -> manufacturing -> per-driver installation, facilities,
power-unit allocation + grid penalties, market/negotiation, events, regulations, records, no car inflation."""
import pytest

from fcm.career_engine import championship as champ, progression, repo, sessions, weekend
from fcm.career_engine.store import store
from fcm.career_engine.world_builder import create_career, load_template
from fcm.management import components, development, events, finance, market, records, regulations, team_view
from fcm.management.common import player_team_id, team_drivers
from fcm.shared import config
from fcm.simulation.model import overall_strength


def _career(rounds=4, seed=77, **kw):
    store.init_app_db()
    w = load_template()
    w['calendar'] = w['calendar'][:rounds]
    create_career({'name': f'Mgmt {seed}', 'seed': seed, 'world': w, 'categories': ['F1', 'F2'],
                   'player': {'first_name': 'Mia', 'last_name': 'Tester', 'team_index': 4, 'rating': 86, 'age': 24}, **kw})
    return store.require()


def _complete_round(db):
    rnd = weekend.current_round(db)
    for row in weekend.pending_sessions(db, rnd['id']):
        (sessions.skip if row['type'] == 'practice' else sessions.simulate)(db, row['id'])
    return rnd


def test_ledger_is_consistent_and_cost_cap_excludes():
    db = _career()
    season = repo.current_season(db)
    tid = player_team_id(db)
    f0 = finance.row(db, season['id'], tid)
    _complete_round(db)
    f1 = finance.row(db, season['id'], tid)
    txs = db.all('SELECT * FROM transactions WHERE team_id = ? AND season_id = ?', (tid, season['id']))
    assert {'owner_funding', 'sponsor', 'operating', 'staff', 'driver_salary'} <= {t['type'] for t in txs}
    start_cash = f0['season_budget'] * config.load('finance')['starting_cash_share']
    assert abs(round(start_cash, 2) + sum(t['amount'] for t in txs) - f1['cash']) < 1e-6
    capped = sum(-t['amount'] for t in txs if t['cost_cap'])
    assert abs(capped - f1['cost_cap_spent']) < 1e-6
    assert all(not t['cost_cap'] for t in txs if t['type'] in ('driver_salary', 'sponsor', 'facility_upkeep'))
    assert f0['season_budget'] > 0


def test_development_pipeline_and_teammate_difference():
    db = _career(rounds=8)
    season = repo.current_season(db)
    s, tid = team_view.require_player_team(db)
    pv = development.preview(db, season['id'], tid, 'floor', 'minor', season['year'])
    assert pv['can_start'] and pv['expected_gain'] > 0 and pv['rounds'] >= 1
    rnd = weekend.current_round(db)
    pid = development.start_project(db, season['id'], rnd['id'], tid, 'floor', 'minor', season['year'])
    for _ in range(pv['rounds']): _complete_round(db)
    pr = db.one('SELECT * FROM development_projects WHERE id = ?', (pid,))
    assert pr['status'] in ('completed', 'failed') and pr['outcome'] in ('underperformed', 'expected', 'overperformed', 'failed')
    if pr['status'] == 'failed': pytest.skip('project failed by design (seeded risk)')
    part = db.one('SELECT * FROM parts WHERE project_id = ?', (pid,))
    development.manufacture(db, season['id'], None, part['id'], 1)
    for _ in range(part['manufacture_rounds']): _complete_round(db)
    assert db.one('SELECT available FROM parts WHERE id = ?', (part['id'],))['available'] == 1
    d1, d2 = team_drivers(db, season['id'], tid)
    development.install(db, season['id'], part['id'], d1['driver_id'])
    c1 = development.driver_car(db, season['id'], tid, d1['driver_id'])
    c2 = development.driver_car(db, season['id'], tid, d2['driver_id'])
    assert c1['high_speed_downforce'] > c2['high_speed_downforce']
    with pytest.raises(ValueError): development.install(db, season['id'], part['id'], d2['driver_id'])


def test_capacity_and_affordability_limits():
    db = _career()
    season = repo.current_season(db)
    s, tid = team_view.require_player_team(db)
    for _ in range(development.capacity(db, tid)): development.start_project(db, season['id'], None, tid, 'brakes', 'minor', season['year'])
    assert not development.preview(db, season['id'], tid, 'brakes', 'minor', season['year'])['can_start']


def test_power_unit_allocation_and_grid_penalty():
    db = _career()
    season = repo.current_season(db)
    tid = player_team_id(db)
    d = team_drivers(db, season['id'], tid)[0]['driver_id']
    limit = components.regulation(db, season['id'], db.value("SELECT id FROM categories WHERE code = 'F1'"))['component_limits']['ICE']
    res = None
    for _ in range(limit): res = components.fit_new(db, season['id'], d, 'ICE')
    assert res['penalty'] == 10
    assert components.fit_new(db, season['id'], d, 'ICE')['penalty'] == 5
    rnd = weekend.current_round(db)
    race = db.one("SELECT * FROM sessions WHERE round_id = ? AND type = 'race' AND championship_id = (SELECT e.championship_id FROM championship_entries e WHERE e.driver_id = ? LIMIT 1)", (rnd['id'], d))
    s = sessions.get(db, race['id'])
    ids = [e['driver_id'] for e in repo.entries(db, s['championship_id'])]
    ids.remove(d)
    order = components.apply_grid_penalties(db, s, [d] + ids)
    assert order.index(d) == 15                # 10 + 5 places from pole
    assert db.value('SELECT COUNT(*) FROM penalties WHERE driver_id = ? AND applied = 1', (d,)) == 2


def test_wear_increases_with_racing():
    db = _career()
    season = repo.current_season(db)
    tid = player_team_id(db)
    d = team_drivers(db, season['id'], tid)[0]['driver_id']
    _complete_round(db)
    assert components.fitted(db, season['id'], d)['ICE']['wear'] > 0.05


def test_salary_and_negotiation_rules():
    assert market.salary_for(1, 90, 80) > market.salary_for(1, 82, 50) > market.salary_for(2, 82, 50)
    db = _career()
    season = repo.current_season(db)
    teams = [t for t in market.overview(db)['teams'] if t['tier'] == 1]
    out = market.negotiate(db, teams[0]['team_id'], 'D1', 999.0, 9)
    assert out['status'] in ('rejected', 'countered') and out['reasons']
    own = player_team_id(db)
    ok = market.negotiate(db, own, 'D2', market.salary_for(1, 70, 30), 2)
    assert ok['status'] in ('accepted', 'countered', 'rejected') and ok['reasons']


def test_signed_future_contract_moves_player_next_season():
    db = _career(rounds=2)
    season = repo.current_season(db)
    target = next(t for t in market.overview(db)['teams'] if t['tier'] == 1 and t['team_id'] != player_team_id(db))
    oid = db.insert('offers', {'season_id': season['id'], 'driver_id': repo.career(db)['player_driver_id'], 'team_id': target['team_id'], 'category_code': 'F1', 'role': 'D1',
                               'salary': 5, 'years': 2, 'origin': 'ai', 'status': 'open', 'reason_json': '{}', 'create_ts': 'x'})
    market.accept_offer(db, oid)
    weekend.simulate_rest_of_season(db)
    progression.finish_season(db)
    assert player_team_id(db) == target['team_id']
    ents = repo.entries(db, repo.championships(db, repo.current_season(db)['id'])[0]['id'])
    assert len(ents) == 22 and len({e['driver_id'] for e in ents}) == 22


def test_event_resolution_effects():
    db = _career()
    season = repo.current_season(db)
    tid = player_team_id(db)
    pid = development.start_project(db, season['id'], None, tid, 'floor', 'standard', season['year'])
    rnd = weekend.current_round(db)
    import json
    ev = next(e for e in config.load('events')['events'] if e['key'] == 'correlation_issue')
    gid = db.insert('game_events', {'event_key': ev['key'], 'type': ev['type'], 'season_id': season['id'], 'round_id': rnd['id'], 'team_id': tid, 'project_id': pid,
                                    'title': ev['title'], 'body': 'x', 'choices_json': json.dumps(ev['choices']), 'status': 'pending', 'result_json': '{}', 'create_ts': 'x'})
    before = db.one('SELECT rounds_left FROM development_projects WHERE id = ?', (pid,))['rounds_left']
    events.resolve(db, gid, 1)
    p = db.one('SELECT * FROM development_projects WHERE id = ?', (pid,))
    assert p['rounds_left'] == before + 2 and abs(p['gain_mult'] - 0.85) < 1e-9
    with pytest.raises(ValueError): events.resolve(db, gid, 0)


def test_multi_season_no_inflation_regulations_and_records():
    db = _career(rounds=3, seed=91)
    cm = config.load('car_model')
    cat = db.value("SELECT id FROM categories WHERE code = 'F1'")

    def field_mean(season_id):
        rows = db.all('SELECT cp.* FROM car_performance cp JOIN teams t ON t.id = cp.team_id WHERE cp.season_id = ? AND t.category_id = ?', (season_id, cat))
        return sum(overall_strength({k: r[k] for k in repo.CAR_FIELDS}, cm) for r in rows) / len(rows)

    first = field_mean(repo.current_season(db)['id'])
    majors = []
    for _ in range(4):
        weekend.simulate_rest_of_season(db)
        progression.finish_season(db)
        s = repo.current_season(db)
        majors.append(regulations.current(db, s['id'])['this_year_major'])
        assert abs(field_mean(s['id']) - first) < 0.25
    assert any(majors)   # first major change after 3 seasons
    rec = records.records(db)
    assert len(rec['F1']['champions']) == 4 and rec['F1']['wins'][0]['wins'] >= 1
    assert db.value("SELECT COUNT(*) FROM domain_events WHERE type = 'MILESTONE'") > 0
