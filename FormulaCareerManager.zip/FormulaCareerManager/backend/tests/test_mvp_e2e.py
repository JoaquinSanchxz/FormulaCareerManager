"""MVP flow (spec section 86) end-to-end through the real launcher, with a fake acs.exe:
detect -> scan -> career -> car + track mapping -> race.ini -> launch -> result import -> points -> save -> reopen."""
import json
import os
import sys
import time
from pathlib import Path

from fake_ac import build_install

from fcm.ac_integration import catalog, race_ini
from fcm.ac_integration.launcher import launcher
from fcm.career_engine import championship as champ, editor, repo, sessions, weekend
from fcm.career_engine.store import store
from fcm.career_engine.world_builder import create_career, load_template


def _wait_launcher(timeout=30):
    t0 = time.time()
    while launcher.is_busy() and time.time() - t0 < timeout: time.sleep(0.1)
    return launcher.status()


def test_mvp_flow(tmp_path, monkeypatch):
    ac = build_install(tmp_path / 'assettocorsa', csp=True)
    docs = tmp_path / 'Documents' / 'Assetto Corsa'
    (docs / 'cfg').mkdir(parents=True)
    (docs / 'cfg' / 'race.ini').write_text('[ORIGINAL]\nUSER=1\n')
    monkeypatch.setenv('FCM_AC_DOCUMENTS', str(docs))
    monkeypatch.setenv('FCM_ACS_COMMAND', json.dumps([sys.executable, str(Path(__file__).parent / 'fake_ac.py')]))
    store.init_app_db()
    catalog.set_root(store, str(ac))                        # 1. detect/validate
    st = catalog.scan(store)                                # 2. scan
    assert st['last_scan']['cars'] == 1 and st['last_scan']['tracks'] == 2
    w = load_template()
    w['calendar'] = w['calendar'][:2]
    cid = create_career({'name': 'MVP', 'seed': 5, 'world': w, 'settings': {'race_length_pct': 5},     # 3-4. championship + career
                         'player': {'first_name': 'Ana', 'last_name': 'Tester', 'nationality': 'ESP', 'team_index': 3, 'rating': 84}})
    db = store.require()
    season = repo.current_season(db)
    f1 = repo.championships(db, season['id'])[0]
    editor.set_championship_car(db, f1['id'], 'fcm_test_f1')                                            # 5. F1 car
    assert len({e['skin'] for e in repo.entries(db, f1['id'])}) == 11                                    # 6. 22 drivers, team skins
    r1 = db.one('SELECT * FROM calendar_rounds WHERE season_id = ? AND round_no = 1', (season['id'],))
    editor.update_round(db, r1['id'], {'ac_track_id': 'fcm_ring', 'ac_layout_id': ''})
    # simulate practice until the player's qualifying, simulate Q, stop at race
    stop = weekend.advance(db)['stopped_at']
    while sessions.get(db, stop)['type'] != 'race':
        s = sessions.get(db, stop)
        (sessions.skip if s['type'] == 'practice' else sessions.simulate)(db, stop)
        stop = weekend.advance(db)['stopped_at']
    prep = sessions.prepare_play(db, stop)                                                               # 7. generate race
    assert not prep['errors'], prep['errors']
    ini = race_ini.parse(prep['race_ini'])
    assert ini['RACE']['CARS'] == '22' and ini['CAR_0']['DRIVER_NAME'] == 'Ana Tester'
    assert all(70 <= float(ini[f'CAR_{i}']['AI_LEVEL']) <= 100 for i in range(1, 22))
    sessions.play(db, stop)                                                                              # 8. launch
    assert ini['LIGHTING']['__CM_WEATHER_CONTROLLER'] == 'fcm' and 'PLAN = {' in (ac / 'extension/weather-controllers/fcm/controller.lua').read_text()
    status = _wait_launcher()                                                                            # 9-10. finish + import
    assert status['status'] == 'finished', status
    assert (docs / 'cfg' / 'race.ini').read_text().startswith('[ORIGINAL]')                              # user's race.ini restored
    res = sessions.summary(db, stop)['results']
    assert len(res) == 22 and res[0]['points'] == 25 and all(r['source'] == 'played' for r in res)       # 11. points
    assert db.value('SELECT COUNT(*) FROM laps WHERE session_id = ?', (stop,)) > 0
    assert db.value('SELECT COUNT(*) FROM raw_results WHERE session_id = ?', (stop,)) == 1
    st1 = champ.driver_standings(db, f1['id'])                                                           # 12. championship
    assert st1[0]['points'] >= 25
    player_row = next(d for d in st1 if d['is_player'])
    store.close()                                                                                        # 13-14. save + close
    db = store.open(cid)                                                                                 # 15. reopen
    st2 = champ.driver_standings(db, f1['id'])                                                           # 16. same state
    assert [(d['driver_id'], d['points']) for d in st2] == [(d['driver_id'], d['points']) for d in st1]
    assert next(d for d in st2 if d['is_player'])['points'] == player_row['points']
    assert db.one('SELECT status FROM calendar_rounds WHERE id = ?', (r1['id'],))['status'] == 'completed'
    assert os.listdir(tmp_path / 'Documents' / 'Assetto Corsa' / 'out') == ['race_out.json']


def test_play_blocked_without_mapping(tmp_path):
    store.init_app_db()
    w = load_template()
    w['calendar'] = w['calendar'][:1]
    create_career({'name': 'Unmapped', 'seed': 9, 'world': w, 'player': {'team_index': 0}})
    db = store.require()
    stop = weekend.advance(db)['stopped_at']
    prep = sessions.prepare_play(db, stop)
    assert any('coche' in e.lower() for e in prep['errors']) and any('circuito' in e.lower() for e in prep['errors'])
