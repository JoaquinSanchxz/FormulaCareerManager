"""Newsroom: varied Spanish press-style news, only real facts, no internal numbers, no fake milestones for real drivers."""
import re

from fcm.career_engine import newsroom, weekend
from fcm.career_engine.store import store
from fcm.career_engine.world_builder import create_career, load_template


def test_news_are_varied_spanish_and_clean():
    store.init_app_db()
    w = load_template()
    w['calendar'] = w['calendar'][:6]
    create_career({'name': 'Prensa', 'seed': 31, 'world': w, 'categories': ['F1', 'F2', 'F3'], 'settings': {'race_length': 25},
                   'player': {'mode': 'existing', 'category': 'F1', 'team_index': 2, 'slot': 0}})
    db = store.require()
    weekend.advance(db, stop_at_player=False, max_rounds=6)
    news = db.all('SELECT kind, headline, body FROM news')
    text = ' '.join(f"{n['headline']} {n['body'] or ''}" for n in news)
    assert not re.search(r'(?<!ART )Grand Prix|\bspec\b|cost cap|rating|\bP\d+\b', text)
    races = [n for n in news if n['kind'] == 'carrera' and not n['headline'].startswith(('F2', 'F3'))]
    assert len(races) >= 6 and all(n['body'] for n in races)
    shapes = {re.sub(r'[A-ZÁÉÍÓÚÑ][\wáéíóúñü-]+', 'X', n['headline']) for n in races}
    assert len(shapes) >= 3                                               # not the same sentence every weekend
    assert {'clasificacion', 'carrera', 'temporada'} <= {n['kind'] for n in news}
    assert db.value("SELECT COUNT(*) FROM news WHERE kind = 'hito'") == 0  # real drivers had careers before the game: no fake 'first win'


def test_helpers():
    assert newsroom.place('Gran Premio de los Países Bajos') == 'Países Bajos'
    assert newsroom.part_name('suspension') == 'una nueva suspensión' and newsroom.part_name('sidepods', 'el') == 'los nuevos pontones'
    assert newsroom.gap(4321) == '4,3 s' and newsroom.ordinal(3) == 'tercero'
