"""Dynamic weather: plans by climate, wetness curve, rain races with tyre changes, CSP required to play, CSP weather controller."""
import random

from fake_ac import build_install

from fcm.ac_integration import catalog, csp_weather, detect
from fcm.career_engine import repo, sessions, weekend
from fcm.career_engine.store import store
from fcm.career_engine.world_builder import create_career, load_template
from fcm.database.db import jdump
from fcm.shared import config
from fcm.simulation import weather


def _cfg():
    a = config.load('ac_session')
    return a['weather_states'], a['weather'], a['climates']


def test_plan_by_climate_and_wetness_curve():
    states, wcfg, clim = _cfg()
    rainy = lambda c, unstable_p: sum(weather.is_wet(weather.plan(random.Random(i), clim[c], wcfg, random.Random(i + 7).random() < unstable_p), states)
                                      for i in range(400)) / 400
    assert rainy('desert', 0) == 0                                   # stable sessions never rain
    assert rainy('temperate', 1) > 0.5                               # rain system -> rain most of the time
    pl = [{'at': 0.0, 'state': 'scattered'}, {'at': 0.3, 'state': 'rain'}, {'at': 0.6, 'state': 'broken'}]
    assert weather.plan(random.Random(3), clim['cool'], wcfg, True) == weather.plan(random.Random(3), clim['cool'], wcfg, True)
    curve = weather.wetness_curve(pl, 50, states, wcfg)
    assert curve[5] == 0 and curve[25] > 0.6 and 0.05 < curve[40] < curve[30] and curve[-1] < curve[35]   # rises fast, dries slowly
    assert weather.forecast(pl, states) == 'Nubes dispersas → Lluvia (30 %) → Nuboso (60 %)'


def _career(seed=21):
    store.init_app_db()
    w = load_template()
    w['calendar'] = w['calendar'][:1]
    create_career({'name': f'WX {seed}', 'seed': seed, 'world': w, 'categories': ['F1'], 'settings': {'race_length': 50},
                   'player': {'first_name': 'Llu', 'last_name': 'Via', 'team_index': 4, 'rating': 82}})
    return store.require()


def _set_plan(db, code, plan):
    s = db.one('SELECT * FROM sessions WHERE code = ?', (code,))
    states = config.load('ac_session')['weather_states']
    db.update('sessions', s['id'], {'conditions_json': jdump({'time': '15:00', 'night': False, 'weather': plan[0]['state'], 'ambient': 18, 'road': 22,
                                                                'plan': plan, 'forecast': weather.forecast(plan, states), 'wet_sim': weather.is_wet(plan, states)})})
    return s['id']


def test_rain_mid_race_drivers_switch_tyres():
    db = _career()
    rid = _set_plan(db, 'R', [{'at': 0.0, 'state': 'broken'}, {'at': 0.25, 'state': 'heavy_rain'}, {'at': 0.5, 'state': 'scattered'}])
    rnd = weekend.current_round(db)
    for s in weekend.pending_sessions(db, rnd['id']):
        (sessions.skip if s['type'] == 'practice' else sessions.simulate)(db, s['id'])
    res = sessions.summary(db, rid)['results']
    fin = [r for r in res if r['status'] == 'FIN']
    assert sum(('I' in r['strategy'] or 'W' in r['strategy']) for r in fin) >= len(fin) * 0.8      # everybody goes to wet tyres
    assert sum(r['strategy'].split('-')[-1] in ('S', 'M', 'H') for r in fin) >= len(fin) * 0.6      # and back to slicks when it dries
    assert db.value('SELECT weather FROM sessions WHERE id = ?', (rid,)) == 'wet'
    laps = sessions.session_format(db, sessions.get(db, rid))['laps']
    dry_best = min(r['best_lap_ms'] for r in fin)
    assert all(r['pit_stops'] >= 2 for r in fin[:10]) and laps > 10 and dry_best > 0


def test_wet_start_strategy_suggestion_and_validation():
    db = _career(22)
    rid = _set_plan(db, 'R', [{'at': 0.0, 'state': 'rain'}])
    view = sessions.strategy_view(db, rid)
    assert view['suggestion']['compounds'][0] in ('I', 'W') and not view['two_compounds_required'] and 'W' in view['tyres']
    sessions.set_strategy(db, rid, {'compounds': ['W'], 'pit_laps': []})           # one compound allowed in the wet


def test_play_requires_csp_and_writes_weather_controller(tmp_path, monkeypatch):
    docs = tmp_path / 'Documents' / 'Assetto Corsa'
    (docs / 'cfg').mkdir(parents=True)
    monkeypatch.setenv('FCM_AC_DOCUMENTS', str(docs))
    db = _career(23)
    ac = build_install(tmp_path / 'ac')
    catalog.set_root(store, str(ac))
    catalog.scan(store)
    ch = repo.championships(db, repo.current_season(db)['id'])[0]
    db.update('championships', ch['id'], {'ac_car_id': 'fcm_test_f1'})
    db.execute("UPDATE calendar_rounds SET ac_track_id = 'fcm_ring', ac_layout_id = ''")
    rid = db.one("SELECT id FROM sessions WHERE code = 'R'")['id']
    for s in weekend.pending_sessions(db, weekend.current_round(db)['id'])[:-1]:
        (sessions.skip if s['type'] == 'practice' else sessions.simulate)(db, s['id'])
    assert any('Custom Shaders Patch' in e for e in sessions.prepare_play(db, rid)['errors'])
    ac2 = build_install(tmp_path / 'ac2', csp=True)
    catalog.set_root(store, str(ac2))
    catalog.scan(store)
    assert detect.detect_extras(ac2)['csp']['weather'] and detect.detect_extras(ac2)['csp']['rain']
    _set_plan(db, 'R', [{'at': 0.0, 'state': 'overcast'}, {'at': 0.5, 'state': 'rain'}])
    prep = sessions.prepare_play(db, rid)
    assert not prep['errors'], prep['errors']
    assert '__CM_WEATHER_CONTROLLER=fcm' in prep['race_ini'] and '__CM_WEATHER_TYPE=19' in prep['race_ini']
    d = csp_weather.write_controller(ac2, prep['_weather_plan'], config.load('ac_session')['weather_states'], laps=prep['format']['laps'])
    lua = (d / 'controller.lua').read_text()
    assert '{ at = 0.0, type = 19' in lua and '{ at = 0.5, type = 7' in lua and f"LAPS, DURATION, TRANSITION = {prep['format']['laps']}, 0" in lua


def test_knockout_stage_gets_its_slice_of_the_plan():
    pl = [{'at': 0.0, 'state': 'clear'}, {'at': 0.5, 'state': 'rain'}, {'at': 0.9, 'state': 'broken'}]
    assert csp_weather.local_plan(pl, 1 / 3, 2 / 3) == [{'at': 0.0, 'state': 'clear'}, {'at': 0.5, 'state': 'rain'}]
    assert csp_weather.local_plan(pl, 2 / 3, 1.0) == [{'at': 0.0, 'state': 'rain'}, {'at': 0.7, 'state': 'broken'}]
