"""Advanced physics module: original untouched, BASE + modifiers (never cumulative), packed cars refused, safe cleanup."""
import pytest
from fake_ac import build_install

from fcm.ac_integration import physics, scanner


def _unpacked_car(root):
    car = root / 'content/cars/fcm_test_f1'
    (car / 'data.acd').unlink()
    d = car / 'data'
    d.mkdir()
    (d / 'car.ini').write_text('[BASIC]\nGRAPHICS_OFFSET=0,0,0\nTOTALMASS=800\n')
    (d / 'aero.ini').write_text('[WING_0]\nNAME=BODY\nCL_GAIN=1.0\nCD_GAIN=1.0\n[WING_1]\nNAME=REAR\nCL_GAIN=2.0\nCD_GAIN=0.5\n')
    (d / 'engine.ini').write_text('[HEADER]\nVERSION=1\nPOWER_CURVE=power.lut\n')
    (d / 'power.lut').write_text('1000|300\n10000|500\n')
    (d / 'suspensions.ini').write_text('[X]\nA=1\n')
    return car


def test_managed_copy_base_plus_modifiers(tmp_path):
    root = build_install(tmp_path / 'ac')
    with pytest.raises(ValueError): physics.build(root, 'fcm_test_f1', 'AUR1', 'AUR #1', {'power': 0, 'downforce': 0, 'drag': 0, 'weight_kg': 0})
    car = _unpacked_car(root)
    original = (car / 'data/power.lut').read_text()
    mods = physics.modifiers({k: 92.0 for k in ('power', 'energy_recovery', 'high_speed_downforce', 'medium_speed_downforce', 'low_speed_downforce', 'drag_efficiency', 'weight')},
                             {k: 90.0 for k in ('power', 'energy_recovery', 'high_speed_downforce', 'medium_speed_downforce', 'low_speed_downforce', 'drag_efficiency', 'weight')})
    assert mods['power'] == pytest.approx(0.008) and mods['drag'] < 0 and mods['weight_kg'] < 0
    mid = physics.build(root, 'fcm_test_f1', 'AUR1', 'AUR #1', mods)
    dest = root / 'content/cars' / mid
    assert '1000|302.400' in (dest / 'data/power.lut').read_text()
    assert 'CL_GAIN=2.0160' in (dest / 'data/aero.ini').read_text()
    assert 'TOTALMASS=797.0000' in (dest / 'data/car.ini').read_text()
    assert (dest / 'data/suspensions.ini').exists() and (dest / 'skins/team_00/ui_skin.json').exists()
    # rebuild with other modifiers: recomputed from BASE, not cumulative
    physics.build(root, 'fcm_test_f1', 'AUR1', 'AUR #1', {'power': -0.01, 'downforce': 0, 'drag': 0, 'weight_kg': 0})
    assert '1000|297.000' in (dest / 'data/power.lut').read_text()
    assert (car / 'data/power.lut').read_text() == original           # user's car never modified
    assert [c['id'] for c in scanner.scan_content(root)['cars']] == ['fcm_test_f1']   # managed copies hidden from catalog
    (root / 'content/cars/fcm_user_owned').mkdir()
    assert physics.remove_all(root) == 1 and (root / 'content/cars/fcm_user_owned').exists() and not dest.exists()
