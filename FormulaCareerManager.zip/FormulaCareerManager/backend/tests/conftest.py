import os
import sys
import tempfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
os.environ.setdefault('FCM_DATA_DIR', tempfile.mkdtemp(prefix='fcm_test_'))

import pytest  # noqa: E402

from fcm.shared import config  # noqa: E402
from fcm.simulation.model import ATTRIBUTES, base_rating  # noqa: E402


@pytest.fixture
def pcfg():
    return config.load('progression')


def make_state(pcfg, base=86.4, age=27, potential=None, form=0.0, morale=60):
    attrs = {a: base for a in ATTRIBUTES}
    return {'attrs': attrs, 'base': base_rating(attrs, pcfg['attribute_weights']), 'form': form, 'morale': morale,
            'potential': potential if potential is not None else base + 2, 'age': age, 'development_rate': 1.0, 'progress': {}}


def field_rows(me_expected_pos, me_actual_pos, n=22, status='FIN', dnf_reason=None, conf=1.0, session_type='race'):
    """Synthetic field where driver 1 has strength so that expected position ~= me_expected_pos."""
    rows = []
    strengths = [100 - i * 0.9 for i in range(n)]
    my_strength = strengths[me_expected_pos - 1] - 0.001
    others = [s for i, s in enumerate(strengths) if i != me_expected_pos - 1]
    positions = [p for p in range(1, n + 1) if p != me_actual_pos]
    for k, (s, p) in enumerate(zip(others, positions)):
        rows.append({'driver_id': 100 + k, 'team_id': 200 + k, 'strength': s, 'position': p, 'status': 'FIN', 'best_lap_ms': 80000 + p * 100,
                     'source_confidence': conf})
    rows.append({'driver_id': 1, 'team_id': 1, 'strength': my_strength, 'position': me_actual_pos, 'status': status,
                 'dnf_reason': dnf_reason, 'best_lap_ms': 80000 + me_actual_pos * 100, 'source_confidence': conf})
    return rows


def evidence_for(pcfg, session_type, exp_pos, act_pos, **kw):
    from fcm.career_engine.rating import session_scores
    ev = session_scores(session_type, field_rows(exp_pos, act_pos, **kw), pcfg)
    return [e for e in ev if e['driver_id'] == 1]
