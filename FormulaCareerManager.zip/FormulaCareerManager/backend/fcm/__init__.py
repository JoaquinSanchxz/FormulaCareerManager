"""Formula Career Manager - career mode manager for Assetto Corsa."""

__version__ = '0.1.0'
APP_NAME = 'FormulaCareerManager'
