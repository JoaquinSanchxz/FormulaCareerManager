"""Read-only access to Assetto Corsa shared memory (Kunos "ACSharedMemory" documentation).

Mappings: Local\\acpmf_physics, Local\\acpmf_graphics, Local\\acpmf_static (structs packed to 4 bytes).
We open existing mappings with OpenFileMappingW (never create them), so a missing mapping
means AC is not running. Only the fields the Career Manager needs are declared; the leading
layout matches SPageFileGraphic / SPageFileStatic exactly.
"""
import ctypes
import sys

AC_STATUS = {0: 'off', 1: 'replay', 2: 'live', 3: 'pause'}
AC_SESSION = {-1: 'unknown', 0: 'practice', 1: 'qualifying', 2: 'race', 3: 'hotlap', 4: 'time_attack', 5: 'drift', 6: 'drag'}


class SPageFileGraphic(ctypes.Structure):
    _pack_ = 4
    _fields_ = [('packetId', ctypes.c_int), ('status', ctypes.c_int), ('session', ctypes.c_int),
                ('currentTime', ctypes.c_wchar * 15), ('lastTime', ctypes.c_wchar * 15), ('bestTime', ctypes.c_wchar * 15),
                ('split', ctypes.c_wchar * 15), ('completedLaps', ctypes.c_int), ('position', ctypes.c_int),
                ('iCurrentTime', ctypes.c_int), ('iLastTime', ctypes.c_int), ('iBestTime', ctypes.c_int),
                ('sessionTimeLeft', ctypes.c_float), ('distanceTraveled', ctypes.c_float), ('isInPit', ctypes.c_int),
                ('currentSectorIndex', ctypes.c_int), ('lastSectorTime', ctypes.c_int), ('numberOfLaps', ctypes.c_int),
                ('tyreCompound', ctypes.c_wchar * 33)]


class SPageFileStatic(ctypes.Structure):
    _pack_ = 4
    _fields_ = [('smVersion', ctypes.c_wchar * 15), ('acVersion', ctypes.c_wchar * 15), ('numberOfSessions', ctypes.c_int),
                ('numCars', ctypes.c_int), ('carModel', ctypes.c_wchar * 33), ('track', ctypes.c_wchar * 33),
                ('playerName', ctypes.c_wchar * 33), ('playerSurname', ctypes.c_wchar * 33), ('playerNick', ctypes.c_wchar * 33),
                ('sectorCount', ctypes.c_int)]


class SPageFilePhysics(ctypes.Structure):
    """Leading part of SPageFilePhysics (Kunos shared memory documentation), up to carDamage."""
    _pack_ = 4
    _fields_ = [('packetId', ctypes.c_int), ('gas', ctypes.c_float), ('brake', ctypes.c_float), ('fuel', ctypes.c_float), ('gear', ctypes.c_int),
                ('rpms', ctypes.c_int), ('steerAngle', ctypes.c_float), ('speedKmh', ctypes.c_float), ('velocity', ctypes.c_float * 3), ('accG', ctypes.c_float * 3),
                ('wheelSlip', ctypes.c_float * 4), ('wheelLoad', ctypes.c_float * 4), ('wheelsPressure', ctypes.c_float * 4), ('wheelAngularSpeed', ctypes.c_float * 4),
                ('tyreWear', ctypes.c_float * 4), ('tyreDirtyLevel', ctypes.c_float * 4), ('tyreCoreTemperature', ctypes.c_float * 4), ('camberRAD', ctypes.c_float * 4),
                ('suspensionTravel', ctypes.c_float * 4), ('drs', ctypes.c_float), ('tc', ctypes.c_float), ('heading', ctypes.c_float), ('pitch', ctypes.c_float),
                ('roll', ctypes.c_float), ('cgHeight', ctypes.c_float), ('carDamage', ctypes.c_float * 5), ('numberOfTyresOut', ctypes.c_int),
                ('pitLimiterOn', ctypes.c_int), ('abs', ctypes.c_float)]


DAMAGE_ZONES = ('front', 'rear', 'left', 'right', 'centre')
FILE_MAP_READ = 0x0004


def _read(name, struct_type):
    if sys.platform != 'win32': return None
    k32 = ctypes.windll.kernel32
    k32.OpenFileMappingW.restype = ctypes.c_void_p
    k32.MapViewOfFile.restype = ctypes.c_void_p
    k32.MapViewOfFile.argtypes = [ctypes.c_void_p, ctypes.c_uint32, ctypes.c_uint32, ctypes.c_uint32, ctypes.c_size_t]
    k32.UnmapViewOfFile.argtypes = [ctypes.c_void_p]
    k32.CloseHandle.argtypes = [ctypes.c_void_p]
    h = k32.OpenFileMappingW(FILE_MAP_READ, False, name)
    if not h: return None
    try:
        view = k32.MapViewOfFile(h, FILE_MAP_READ, 0, 0, ctypes.sizeof(struct_type))
        if not view: return None
        try:
            return struct_type.from_buffer_copy(ctypes.string_at(view, ctypes.sizeof(struct_type)))
        finally:
            k32.UnmapViewOfFile(view)
    finally:
        k32.CloseHandle(h)


def raw_pages():
    """(physics, graphics) structs or (None, None). Never raises."""
    try:
        return _read('Local\\acpmf_physics', SPageFilePhysics), _read('Local\\acpmf_graphics', SPageFileGraphic)
    except Exception:
        return None, None


def snapshot() -> dict:
    """Current live state or {'available': False}. Never raises."""
    try:
        g = _read('Local\\acpmf_graphics', SPageFileGraphic)
        s = _read('Local\\acpmf_static', SPageFileStatic)
    except Exception as e:
        return {'available': False, 'error': str(e)}
    if g is None: return {'available': False}
    out = {'available': True, 'status': AC_STATUS.get(g.status, str(g.status)), 'session': AC_SESSION.get(g.session, str(g.session)),
           'packet_id': g.packetId, 'completed_laps': g.completedLaps, 'position': g.position, 'current_time': g.currentTime,
           'best_time': g.bestTime, 'number_of_laps': g.numberOfLaps, 'in_pit': bool(g.isInPit), 'session_time_left': g.sessionTimeLeft}
    if s is not None:
        out.update({'sm_version': s.smVersion, 'ac_version': s.acVersion, 'num_cars': s.numCars, 'car_model': s.carModel,
                    'track': s.track, 'player': f'{s.playerName} {s.playerSurname}'.strip()})
    return out
