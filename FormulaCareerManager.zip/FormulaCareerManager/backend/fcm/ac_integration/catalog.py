"""Content catalog service over the app DB (installed AC content)."""
import time

from fcm.ac_integration import detect, scanner
from fcm.database.db import jload


def status(store):
    saved = store.get_setting('ac_root')
    v = detect.validate_install(saved) if saved else None
    scan = store.app_db.one('SELECT * FROM scan_runs ORDER BY id DESC LIMIT 1')
    return {'ac_root': saved, 'valid': bool(v and v['valid']), 'validation': v,
            'last_scan': scan and {**{k: scan[k] for k in ('create_ts', 'cars', 'tracks', 'layouts', 'duration_ms')}, 'warnings': jload(scan['warnings_json'], [])[:100]}}


def auto_detect(store):
    res = detect.detect(store.get_setting('ac_root'))
    if res['found'] and res['path'] != store.get_setting('ac_root'): store.set_setting('ac_root', res['path'])
    return {**res, **status(store)}


def set_root(store, path):
    v = detect.validate_install(path)
    if not v['valid']: raise ValueError(f"No es una carpeta válida de Assetto Corsa (falta: {', '.join(v['missing'])})")
    store.set_setting('ac_root', str(v['path']))
    return status(store)


def scan(store):
    root = store.get_setting('ac_root')
    if not root or not detect.validate_install(root)['valid']: raise ValueError('Carpeta de Assetto Corsa no configurada')
    data = scanner.scan_content(root)
    scanner.store_scan(store.app_db, root, data)
    return {**status(store), 'scanned_ts': time.time()}


def cars(store, q=None):
    sql = 'SELECT id, name, brand, model, year, class, tags_json, skin_count, has_data_acd, has_data_folder, is_kunos, preview_path, badge_path FROM ac_cars'
    params = ()
    if q:
        sql += ' WHERE id LIKE ? OR name LIKE ? OR brand LIKE ? OR tags_json LIKE ?'
        params = tuple(f'%{q}%' for _ in range(4))
    rows = store.app_db.all(sql + ' ORDER BY is_kunos, name', params)
    for r in rows: r['tags'] = jload(r.pop('tags_json'), [])
    return rows


def car(store, car_id):
    c = store.app_db.one('SELECT * FROM ac_cars WHERE id = ?', (car_id,))
    if not c: raise LookupError('Coche no encontrado')
    for k in ('tags', 'specs'): c[k] = jload(c.pop(f'{k}_json'), {})
    c['skins'] = store.app_db.all('SELECT * FROM ac_car_skins WHERE car_id = ? ORDER BY sort_order, id', (car_id,))
    return c


def tracks(store, q=None):
    sql = 'SELECT * FROM ac_tracks'
    params = ()
    if q:
        sql += ' WHERE id LIKE ? OR name LIKE ?'
        params = (f'%{q}%', f'%{q}%')
    rows = store.app_db.all(sql + ' ORDER BY is_kunos, name', params)
    for t in rows:
        t['layouts'] = store.app_db.all('SELECT * FROM ac_track_layouts WHERE track_id = ? ORDER BY id', (t['id'],))
        for l in t['layouts']:
            l['tags'] = jload(l.pop('tags_json'), [])
            l['geotags'] = jload(l.pop('geotags_json'), [])
    return rows


def weathers(store):
    return store.app_db.all('SELECT * FROM ac_weathers ORDER BY id')
