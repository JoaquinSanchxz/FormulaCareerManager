"""Diagnostic mode: environment report + exportable zip (logs, settings, scan summary, race.ini, race_out.json)."""
import io
import json
import platform
import sys
import time
import zipfile
from pathlib import Path

from fcm import __version__
from fcm.ac_integration import detect, shared_memory
from fcm.ac_integration.launcher import launcher
from fcm.shared import log, paths


def report(store):
    root = store.get_setting('ac_root')
    v = detect.validate_install(root) if root else {'valid': False}
    extras = detect.detect_extras(root) if root else {}
    scan = store.app_db.one('SELECT * FROM scan_runs ORDER BY id DESC LIMIT 1')
    return {
        'app_version': __version__, 'python': sys.version.split()[0], 'os': platform.platform(), 'data_dir': str(paths.data_dir()),
        'ac': {'detected': bool(v.get('valid')), 'path': root, 'validation': v, **extras},
        'shared_memory': shared_memory.snapshot(),
        'content': {'cars': store.app_db.value('SELECT COUNT(*) FROM ac_cars'), 'tracks': store.app_db.value('SELECT COUNT(*) FROM ac_tracks'),
                    'layouts': store.app_db.value('SELECT COUNT(*) FROM ac_track_layouts'), 'weathers': store.app_db.value('SELECT COUNT(*) FROM ac_weathers'),
                    'last_scan': scan and {k: scan[k] for k in ('create_ts', 'duration_ms', 'cars', 'tracks', 'layouts')},
                    'scan_warnings': json.loads(scan['warnings_json'])[:50] if scan else []},
        'launcher': launcher.status(),
        'career': {'loaded': store.career_id, 'schema_version': store.db.schema_version() if store.db else None},
        'features': {'race_ini_generation': True, 'launch_acs_exe': bool(v.get('valid')), 'race_out_import': True,
                     'shared_memory_live_status': sys.platform == 'win32', 'per_car_ai_level': True, 'per_car_ai_aggression': 'verify on install',
                     'rain': 'required to play: CSP WeatherFX + RainFX; own weather controller extension/weather-controllers/fcm plays the session plan', 'physics_modification': 'disabled in this version'},
    }


def export_zip(store) -> bytes:
    buf = io.BytesIO()
    rep = report(store)
    with zipfile.ZipFile(buf, 'w', zipfile.ZIP_DEFLATED) as z:
        z.writestr('report.json', json.dumps(rep, indent=2, default=str))
        for f in sorted(paths.logs_dir().glob('fcm.log*')):
            z.write(f, f'logs/{f.name}')
        docs = detect.ac_documents_dir()
        for rel in ('cfg/race.ini', 'out/race_out.json', 'logs/log.txt'):
            p = docs / rel
            if p.exists() and p.stat().st_size < 20_000_000: z.write(p, f'assetto_corsa/{rel}')
        z.writestr('settings.json', json.dumps({r['key']: r['value_json'] for r in store.app_db.all('SELECT key, value_json FROM settings')}, indent=2))
        z.writestr('generated.txt', time.strftime('%Y-%m-%d %H:%M:%S'))
    return buf.getvalue()
