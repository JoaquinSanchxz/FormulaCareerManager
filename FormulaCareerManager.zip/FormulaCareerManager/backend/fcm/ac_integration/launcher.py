"""AC Bridge launcher: writes race.ini, starts acs.exe, waits for exit, locates race_out.json.

Flow (same approach Content Manager uses):
 1. back up the user's current Documents/Assetto Corsa/cfg/race.ini
 2. atomically write the generated race.ini
 3. start <ac_root>/acs.exe with cwd=<ac_root> (Steam must be running)
 4. wait for the process to exit (background thread) while polling shared memory for live status
 5. accept out/race_out.json only if it was written after launch
 6. restore the user's original race.ini
"""
import json
import os
import subprocess
import threading
import time
from pathlib import Path

from fcm.ac_integration import detect, shared_memory, telemetry
from fcm.shared import log, paths
from fcm.shared.safefs import atomic_write_text, backup_file

_log = log.get('AC')


class LaunchError(RuntimeError):
    pass


class ACLauncher:
    def __init__(self):
        self.lock = threading.Lock()
        self.state = {'status': 'idle'}
        self.proc = None

    def is_busy(self):
        return self.state.get('status') in ('launching', 'running', 'importing')

    def status(self):
        st = dict(self.state)
        if st.get('status') == 'running': st['live'] = shared_memory.snapshot()
        return st

    def _command(self, ac_root):
        override = os.environ.get('FCM_ACS_COMMAND')
        if override: return json.loads(override)
        exe = Path(ac_root) / 'acs.exe'
        if not exe.is_file(): raise LaunchError(f'acs.exe no encontrado en {ac_root}')
        return [str(exe)]

    def launch(self, ac_root, race_ini_text, context: dict, on_finished, restore_ini=True):
        with self.lock:
            if self.is_busy(): raise LaunchError('Ya hay una sesión de Assetto Corsa en marcha')
            if not os.environ.get('FCM_ACS_COMMAND') and detect.is_process_running('acs.exe'):
                raise LaunchError('Assetto Corsa (acs.exe) ya está abierto. Ciérralo primero.')
            docs = detect.ac_documents_dir()
            ini_path = docs / 'cfg' / 'race.ini'
            out_path = docs / 'out' / 'race_out.json'
            backup = backup_file(ini_path, paths.backups_dir() / 'race_ini')
            atomic_write_text(ini_path, race_ini_text)
            launch_ts = time.time()
            cmd = self._command(ac_root)
            _log.info('Launching AC: %s (session %s)', cmd, context.get('session_id'))
            try:
                self.proc = subprocess.Popen(cmd, cwd=str(ac_root), creationflags=getattr(subprocess, 'CREATE_NO_WINDOW', 0) if os.environ.get('FCM_ACS_COMMAND') else 0)
            except OSError as e:
                if backup and restore_ini: _restore(backup, ini_path)
                raise LaunchError(f'No se pudo iniciar Assetto Corsa: {e}')
            self.state = {'status': 'running', 'context': context, 'launch_ts': launch_ts, 'pid': self.proc.pid, 'race_ini': str(ini_path)}
            sampler = telemetry.Sampler().start()
        threading.Thread(target=self._wait, args=(self.proc, launch_ts, out_path, ini_path, backup if restore_ini else None, context, on_finished, sampler),
                         daemon=True).start()
        return self.state

    def _wait(self, proc, launch_ts, out_path, ini_path, backup, context, on_finished, sampler=None):
        code = proc.wait()
        tele = sampler.stop() if sampler else {}
        elapsed = time.time() - launch_ts
        _log.info('AC exited with code %s after %.1fs', code, elapsed)
        result_path = None
        for _ in range(20):  # AC writes race_out.json while closing; allow a short grace period
            if out_path.exists() and out_path.stat().st_mtime >= launch_ts - 1:
                result_path = out_path
                break
            time.sleep(0.25)
        if backup: _restore(backup, ini_path)
        info = {'exit_code': code, 'elapsed_s': round(elapsed, 1), 'result_path': str(result_path) if result_path else None, 'telemetry': tele}
        if not result_path:
            info['error'] = ('Assetto Corsa se cerró sin escribir un race_out.json nuevo. '
                             + ('Se cerró muy rápido: ¿está Steam abierto? Revisa Documentos/Assetto Corsa/logs/log.txt.' if elapsed < 15 else 'Puede que la sesión se abortara antes de empezar.'))
        self.state = {'status': 'importing', 'context': context, **{k: v for k, v in info.items() if k != 'telemetry'}}
        try:
            summary = on_finished(result_path, info)
            info.pop('telemetry', None)
            self.state = {'status': 'finished', 'context': context, **info, 'summary': summary}
        except Exception as e:
            _log.exception('Result import failed')
            info.pop('telemetry', None)
            self.state = {'status': 'failed', 'context': context, **info, 'error': str(e)}

    def reset(self):
        if not self.is_busy(): self.state = {'status': 'idle'}


def _restore(backup, ini_path):
    try:
        atomic_write_text(ini_path, Path(backup).read_text(encoding='utf-8', errors='ignore'))
    except OSError as e:
        _log.warning('Could not restore race.ini: %s', e)


launcher = ACLauncher()
