"""Optional telemetry sampler (player car only, via shared memory) while a session runs.

Career-relevant results (pit stops, max damage per zone) are returned to the importer.
Per-lap aggregates (top speed, throttle/brake usage, fuel, tyre wear) go to a SEPARATE
database (saves/telemetry/<career>.sqlite) so the career save stays small (spec section 24)."""
import sqlite3
import threading
import time

from fcm.ac_integration import shared_memory
from fcm.shared import paths


class Sampler:
    def __init__(self, interval=0.25):
        self.interval = interval
        self.stop_evt = threading.Event()
        self.data = {'samples': 0, 'pit_entries': 0, 'max_damage': {}, 'laps': [], 'live': False}
        self._lap = None
        self._acc = None
        self._in_pit = None
        self.thread = threading.Thread(target=self._run, daemon=True)

    def start(self):
        self.thread.start()
        return self

    def stop(self):
        self.stop_evt.set()
        self.thread.join(timeout=2)
        self._close_lap()
        return self.data

    def _run(self):
        while not self.stop_evt.is_set():
            phys, gfx = shared_memory.raw_pages()
            if phys is not None and gfx is not None and gfx.status == 2:  # AC_LIVE
                self._sample(phys, gfx)
            self.stop_evt.wait(self.interval)

    def _sample(self, p, g):
        d = self.data
        d['samples'] += 1
        d['live'] = True
        for i, z in enumerate(shared_memory.DAMAGE_ZONES):
            d['max_damage'][z] = max(d['max_damage'].get(z, 0.0), float(p.carDamage[i]))
        if self._in_pit is not None and g.isInPit and not self._in_pit and g.completedLaps > 0: d['pit_entries'] += 1
        self._in_pit = bool(g.isInPit)
        if self._lap is None or g.completedLaps != self._lap:
            self._close_lap()
            self._lap = g.completedLaps
            self._acc = {'lap': g.completedLaps + 1, 'n': 0, 'max_speed': 0.0, 'gas': 0.0, 'brake': 0.0, 'fuel_start': float(p.fuel), 'fuel_end': float(p.fuel),
                         'tyre_wear': [float(x) for x in p.tyreWear]}
        a = self._acc
        a['n'] += 1
        a['max_speed'] = max(a['max_speed'], float(p.speedKmh))
        a['gas'] += float(p.gas)
        a['brake'] += float(p.brake)
        a['fuel_end'] = float(p.fuel)
        a['tyre_wear_end'] = [float(x) for x in p.tyreWear]

    def _close_lap(self):
        a = self._acc
        if a and a['n'] > 4:
            self.data['laps'].append({'lap': a['lap'], 'max_speed': round(a['max_speed'], 1), 'avg_gas': round(a['gas'] / a['n'], 3), 'avg_brake': round(a['brake'] / a['n'], 3),
                                      'fuel_used': round(a['fuel_start'] - a['fuel_end'], 3), 'tyre_wear': a.get('tyre_wear_end'), 'samples': a['n']})
        self._acc = None


def _db(career_id):
    d = paths.saves_dir() / 'telemetry'
    d.mkdir(parents=True, exist_ok=True)
    con = sqlite3.connect(str(d / f'{career_id}.sqlite'))
    con.execute('CREATE TABLE IF NOT EXISTS laps (id INTEGER PRIMARY KEY AUTOINCREMENT, session_id INTEGER NOT NULL, lap INTEGER NOT NULL, max_speed REAL, avg_gas REAL, '
                'avg_brake REAL, fuel_used REAL, tyre_wear TEXT, samples INTEGER, create_ts TEXT NOT NULL)')
    return con


def store_laps(career_id, session_id, laps):
    if not laps: return
    import json
    con = _db(career_id)
    with con:
        con.execute('DELETE FROM laps WHERE session_id = ?', (session_id,))
        con.executemany('INSERT INTO laps (session_id, lap, max_speed, avg_gas, avg_brake, fuel_used, tyre_wear, samples, create_ts) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)',
                        [(session_id, l['lap'], l['max_speed'], l['avg_gas'], l['avg_brake'], l['fuel_used'], json.dumps(l.get('tyre_wear')), l['samples'],
                          time.strftime('%Y-%m-%dT%H:%M:%S')) for l in laps])
    con.close()


def load_laps(career_id, session_id):
    con = _db(career_id)
    con.row_factory = sqlite3.Row
    rows = [dict(r) for r in con.execute('SELECT * FROM laps WHERE session_id = ? ORDER BY lap', (session_id,))]
    con.close()
    return rows
