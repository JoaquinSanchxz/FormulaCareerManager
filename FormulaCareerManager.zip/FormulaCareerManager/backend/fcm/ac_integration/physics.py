"""Advanced physics module (EXPERIMENTAL, disabled by default - spec sections 16-18, 72, 77).

Managed car versions: content/cars/fcm_<car>__<team>/ built from the user's car WITHOUT touching it:
  - every file is hard-linked (no extra disk space; original never modified), except the physics files we rewrite
  - the original physics is snapshotted once to <data>/physics_base/<car>/ (immutable BASE)
  - physics is ALWAYS recomputed as BASE + CURRENT MODIFIERS (never cumulative -> no drift/corruption)
  - only cars with an unpacked data/ folder and no data.acd are supported (packed data.acd is never touched)
Modified values (standard AC files):
  power.lut (rpm|torque)         torque x (1 + power%)
  aero.ini [WING_n] CL_GAIN      x (1 + downforce%) ; CD_GAIN x (1 + drag%)
  car.ini [BASIC] TOTALMASS      + weight delta (kg)
A marker file fcm_managed.json identifies managed folders; only those can be deleted by the app.
"""
import json
import os
import re
import shutil
from pathlib import Path

from fcm.shared import config, log, paths
from fcm.shared.safefs import atomic_write_text, ensure_within, safe_id

_log = log.get('CAR')
MARKER = 'fcm_managed.json'
PHYSICS_FILES = ('car.ini', 'aero.ini', 'engine.ini')


def cfg():
    return config.load('physics')


def support(ac_root, car_id):
    car = ensure_within(Path(ac_root) / 'content' / 'cars', safe_id(car_id))
    data = car / 'data'
    if (car / 'data.acd').exists(): return {'supported': False, 'reason': 'Coche con data.acd empaquetado: no se modifica (usa lastre/restrictor/IA)'}
    if not data.is_dir(): return {'supported': False, 'reason': 'Sin carpeta data/'}
    missing = [f for f in ('car.ini', 'aero.ini', 'engine.ini') if not (data / f).exists()]
    if missing: return {'supported': False, 'reason': f"Faltan {', '.join(missing)}"}
    return {'supported': True, 'power_lut': _power_lut_name(data / 'engine.ini')}


def _power_lut_name(engine_ini):
    m = re.search(r'^\s*POWER_CURVE\s*=\s*([^\s;]+)', engine_ini.read_text(encoding='utf-8', errors='ignore'), re.M)
    return m.group(1) if m else 'power.lut'


def base_dir(car_id):
    return paths.sub_dir('physics_base') / safe_id(car_id)


def snapshot_base(ac_root, car_id):
    """Copy the original physics once. Never overwritten afterwards (immutable base)."""
    dest = base_dir(car_id)
    if (dest / 'car.ini').exists(): return dest
    src = Path(ac_root) / 'content' / 'cars' / safe_id(car_id) / 'data'
    dest.mkdir(parents=True, exist_ok=True)
    for f in src.iterdir():
        if f.is_file(): shutil.copy2(f, dest / f.name)
    _log.info('Physics base snapshot for %s', car_id)
    return dest


def modifiers(car, field_mean):
    """Car components vs field mean -> % / kg modifiers (clamped)."""
    c = cfg()
    lim = c['max_pct'] / 100

    def pct(keys):
        v = sum(car[k] - field_mean[k] for k in keys) / len(keys)
        return max(-lim, min(lim, v * c['pct_per_point'] / 100))
    return {'power': round(pct(['power', 'energy_recovery']), 5), 'downforce': round(pct(['high_speed_downforce', 'medium_speed_downforce', 'low_speed_downforce']), 5),
            'drag': round(-pct(['drag_efficiency']), 5), 'weight_kg': round(max(-c['max_weight_kg'], min(c['max_weight_kg'], -(car['weight'] - field_mean['weight']) * c['kg_per_point'])), 2)}


def _scale_lut(text, mult):
    out = []
    for line in text.splitlines():
        m = re.match(r'^\s*([-\d.]+)\s*\|\s*([-\d.]+)(.*)$', line)
        out.append(f'{m.group(1)}|{float(m.group(2)) * mult:.3f}{m.group(3)}' if m else line)
    return '\n'.join(out) + '\n'


def _scale_key(text, key, mult=None, add=None):
    def rep(m):
        v = float(m.group(2))
        v = v * mult if mult is not None else v + add
        return f'{m.group(1)}{v:.4f}'
    return re.sub(rf'^(\s*{key}\s*=\s*)([-\d.]+)', rep, text, flags=re.M)


def managed_id(car_id, team_key):
    return safe_id(f"fcm_{car_id}__{re.sub(r'[^a-z0-9]+', '', team_key.lower())[:12]}")


def build(ac_root, car_id, team_key, team_label, mods):
    """Create/refresh a managed car. Physics files = BASE + mods (recomputed from scratch every time)."""
    sup = support(ac_root, car_id)
    if not sup['supported']: raise ValueError(sup['reason'])
    cars_dir = Path(ac_root) / 'content' / 'cars'
    src = ensure_within(cars_dir, safe_id(car_id))
    mid = managed_id(car_id, team_key)
    dest = ensure_within(cars_dir, mid)
    if dest.exists() and not (dest / MARKER).exists(): raise ValueError(f'{dest} existe y no es una copia gestionada: no se toca')
    base = snapshot_base(ac_root, car_id)
    for root, dirs, files in os.walk(src):
        rel = Path(root).relative_to(src)
        (dest / rel).mkdir(parents=True, exist_ok=True)
        for f in files:
            s, d = Path(root) / f, dest / rel / f
            if rel.parts[:1] == ('data',): continue
            if d.exists(): continue
            if s.stat().st_size < 2_000_000:  # small files (json, previews, ini) are copied so nothing can write through to the original
                shutil.copy2(s, d)
                continue
            try:
                os.link(s, d)  # big read-only assets (kn5, dds): hard link, zero extra disk space
            except OSError:
                shutil.copy2(s, d)
    ddir = dest / 'data'
    ddir.mkdir(exist_ok=True)
    for f in base.iterdir():
        if f.name in PHYSICS_FILES or f.name == sup['power_lut']: continue
        shutil.copy2(f, ddir / f.name)
    car_ini = (base / 'car.ini').read_text(encoding='utf-8', errors='ignore')
    atomic_write_text(ddir / 'car.ini', _scale_key(car_ini, 'TOTALMASS', add=mods['weight_kg']))
    aero = (base / 'aero.ini').read_text(encoding='utf-8', errors='ignore')
    aero = _scale_key(_scale_key(aero, 'CL_GAIN', mult=1 + mods['downforce']), 'CD_GAIN', mult=1 + mods['drag'])
    atomic_write_text(ddir / 'aero.ini', aero)
    atomic_write_text(ddir / 'engine.ini', (base / 'engine.ini').read_text(encoding='utf-8', errors='ignore'))
    lut = base / sup['power_lut']
    if lut.exists(): atomic_write_text(ddir / sup['power_lut'], _scale_lut(lut.read_text(encoding='utf-8', errors='ignore'), 1 + mods['power']))
    ui = dest / 'ui' / 'ui_car.json'
    if ui.exists():
        try:
            from fcm.shared import lenient_json
            data = lenient_json.load_file(src / 'ui' / 'ui_car.json') or {}
            data['name'] = f"{data.get('name', car_id)} (FCM {team_label})"
            ui.unlink()
            atomic_write_text(ui, json.dumps(data, ensure_ascii=False, indent=2))
        except OSError:
            pass
    atomic_write_text(dest / MARKER, json.dumps({'source': car_id, 'team': team_label, 'modifiers': mods}, indent=2))
    return mid


def list_managed(ac_root):
    cars_dir = Path(ac_root) / 'content' / 'cars'
    return [json.loads((p / MARKER).read_text(encoding='utf-8')) | {'id': p.name} for p in cars_dir.glob('fcm_*') if (p / MARKER).exists()]


def remove_all(ac_root):
    """Delete only folders created by this app (marker present)."""
    cars_dir = Path(ac_root) / 'content' / 'cars'
    n = 0
    for p in cars_dir.glob('fcm_*'):
        if (p / MARKER).exists():
            shutil.rmtree(ensure_within(cars_dir, p.name))
            n += 1
    return n
