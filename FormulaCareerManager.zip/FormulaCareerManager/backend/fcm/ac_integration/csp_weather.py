"""Own CSP weather controller that plays the session weather plan (fcm/simulation/weather.py) inside Assetto Corsa.

Written to <AC>/extension/weather-controllers/fcm/ (our own folder, nothing of CSP is modified) and selected from race.ini with
[LIGHTING] __CM_WEATHER_CONTROLLER=fcm, the key Content Manager writes for WeatherFX controllers.
Lua API used, verified against the CSP Lua SDK (ac-custom-shaders-patch/acc-lua-sdk: common/ac_weatherconditions.lua, common/ac_enums.lua,
common/ac_state.d.lua) and the stock controller (acc-extension-config/weather-controllers/base/controller.lua):
ac.ConditionsSet(), ac.setConditionsSet2(), ac.getInput*(), refbool(), ac.WeatherType ids, shared/sim/weather.setRainIntensity,
ac.getSim().isPaused / isInMainMenu, ac.getCar.leaderboard(0).lapCount, math.smoothstep, math.saturateN."""
import json
from pathlib import Path

from fcm.shared.safefs import atomic_write_text, ensure_within

NAME = 'fcm'
MANIFEST = """[ABOUT]
NAME = Formula Career Manager
AUTHOR = Formula Career Manager
VERSION = 1.0
DESCRIPTION = Weather plan of the current career session (generated before each launch).
"""
LUA = """--------
-- Formula Career Manager: plays the weather plan of the session (generated file, rewritten before every launch).
-- Progress = leader laps / race laps (races) or driving time / session length (practice, qualifying).
--------
local weatherUtils = require('shared/sim/weather')
local PLAN = __PLAN__
local LAPS, DURATION, TRANSITION = __LAPS__, __DURATION__, __TRANSITION__
local humidityPresent, pressurePresent = refbool(false), refbool(false)
local sim = ac.getSim()
local elapsed, water, timer = 0, PLAN[1].wet, 1

local function progress()
  if LAPS > 0 then
    local leader = ac.getCar.leaderboard(0)
    return leader and math.saturateN(leader.lapCount / LAPS) or 0
  end
  return DURATION > 0 and math.saturateN(elapsed / DURATION) or 0
end

local function build(dt)
  local p = progress()
  local k = 1
  for i = 1, #PLAN do if PLAN[i].at <= p then k = i end end
  local c = ac.ConditionsSet()
  c.currentType = PLAN[k].type
  c.upcomingType = PLAN[k].type
  c.transition = 0
  local nxt = PLAN[k + 1]
  if nxt and p > nxt.at - TRANSITION then
    c.upcomingType = nxt.type
    c.transition = math.smoothstep(math.saturateN((p - (nxt.at - TRANSITION)) / TRANSITION))
  end
  c.variableA, c.variableB, c.variableC = 0, 0, 0
  c.temperatures = ac.getInputTemperatures()
  c.wind = ac.getInputWind()
  c.humidity = ac.getInputHumidity(humidityPresent)
  c.pressure = ac.getInputPressure(pressurePresent)
  c.trackState = ac.getInputTrackState()
  weatherUtils.setRainIntensity(c, false)
  water = water + (c.rainIntensity - water) * math.min(1, dt / 240)
  c.rainWater = water
  return c
end

ac.setConditionsSet2(build(0))

function script.update(dt)
  if not sim.isPaused and not sim.isInMainMenu then elapsed = elapsed + dt end
  timer = timer + dt
  if timer < 0.5 then return end
  ac.setConditionsSet2(build(timer))
  timer = 0
end
"""


def local_plan(plan, p0=0.0, p1=1.0):
    """Slice of the session plan for one AC launch (a knockout stage covers [p0, p1]) remapped to 0..1."""
    from fcm.simulation.weather import state_at
    out = [{'at': 0.0, 'state': state_at(plan, p0)}]
    out += [{'at': round((x['at'] - p0) / (p1 - p0), 3), 'state': x['state']} for x in plan if p0 < x['at'] < p1]
    return out


def write_controller(ac_root, plan, states, laps=0, duration_s=0, transition=0.06):
    d = ensure_within(Path(ac_root) / 'extension' / 'weather-controllers', NAME)
    rows = ', '.join('{ at = %s, type = %d, wet = %s }' % (x['at'], states[x['state']]['csp'], _rain(states, x['state'])) for x in plan)
    lua = LUA.replace('__PLAN__', '{ ' + rows + ' }').replace('__LAPS__', str(int(laps or 0))).replace('__DURATION__', str(int(duration_s or 0))) \
             .replace('__TRANSITION__', json.dumps(transition))
    atomic_write_text(d / 'manifest.ini', MANIFEST)
    atomic_write_text(d / 'controller.lua', lua)
    return d


def _rain(states, state):
    # initial puddles: a session that starts in the rain starts on a wet track
    return round(min(0.5, states[state]['wet'] * 0.2), 3)
