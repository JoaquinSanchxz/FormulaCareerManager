"""Content scanner for content/cars, content/tracks and content/weather.

Car layout (standard AC):
  content/cars/<id>/data.acd | data/        physics (packed or unpacked)
  content/cars/<id>/ui/ui_car.json          name, brand, class, tags, specs, year, country, author...
  content/cars/<id>/ui/badge.png
  content/cars/<id>/skins/<skin>/ui_skin.json, preview.jpg, livery.png
Track layout:
  single layout : content/tracks/<id>/ui/ui_track.json, preview.png, outline.png ; data in <id>/data
  multi layout  : content/tracks/<id>/ui/<layout>/ui_track.json ... ; data in <id>/<layout>/data
Nothing is modified; the scanner is read-only.
"""
import re
import time
from pathlib import Path

from fcm.database.db import jdump, now_ts
from fcm.shared import lenient_json, log

_log = log.get('AC')


def _s(v):
    if v is None: return None
    if isinstance(v, (list, dict)): return jdump(v)
    return str(v).strip() or None


def parse_length_m(value):
    """'5793 m', '5.793 km', '3,6km', '2.4 mi', 5793 -> metres (float) or None."""
    if value is None: return None
    if isinstance(value, (int, float)): return float(value) if value > 100 else float(value) * 1000
    txt = str(value).strip().lower().replace(',', '.')
    m = re.search(r'(\d+(?:\.\d+)?)', txt)
    if not m: return None
    num = float(m.group(1))
    if 'mi' in txt: return round(num * 1609.344, 1)
    if 'km' in txt: return num * 1000
    if num < 100: return num * 1000
    return num


def _int(v):
    try:
        return int(re.search(r'\d+', str(v)).group(0))
    except (AttributeError, TypeError):
        return None


def _is_kunos(folder_id, author):
    return folder_id.startswith('ks_') or (author or '').strip().lower() in ('kunos', 'kunos simulazioni')


def _first_existing(*candidates):
    for c in candidates:
        if c.exists(): return str(c)
    return None


def scan_car(folder: Path) -> dict:
    ui = lenient_json.load_file(folder / 'ui' / 'ui_car.json') or {}
    year = ui.get('year')
    try:
        year = int(year) if year not in (None, '') else None
    except (TypeError, ValueError):
        year = _int(year)
    name = _s(ui.get('name')) or folder.name
    brand = _s(ui.get('brand'))
    model = name[len(brand):].strip() if brand and name.lower().startswith(brand.lower()) else name
    skins = []
    skins_dir = folder / 'skins'
    if skins_dir.is_dir():
        for i, sk in enumerate(sorted(p for p in skins_dir.iterdir() if p.is_dir())):
            sj = lenient_json.load_file(sk / 'ui_skin.json') or {}
            skins.append({'id': sk.name, 'name': _s(sj.get('skinname')) or sk.name, 'driver_name': _s(sj.get('drivername')),
                          'team': _s(sj.get('team')), 'number': _s(sj.get('number')), 'country': _s(sj.get('country')),
                          'preview_path': _first_existing(sk / 'preview.jpg', sk / 'preview.png'),
                          'livery_path': _first_existing(sk / 'livery.png'),
                          'sort_order': _int(sj.get('priority')) if sj.get('priority') is not None else i})
    tags = ui.get('tags') if isinstance(ui.get('tags'), list) else []
    return {
        'id': folder.name, 'name': name, 'brand': brand, 'model': model, 'year': year,
        'class': _s(ui.get('class')), 'country': _s(ui.get('country')), 'author': _s(ui.get('author')),
        'description': _s(ui.get('description')), 'tags': [str(t) for t in tags],
        'specs': ui.get('specs') if isinstance(ui.get('specs'), dict) else {},
        'path': str(folder), 'has_data_acd': (folder / 'data.acd').is_file(), 'has_data_folder': (folder / 'data').is_dir(),
        'has_ui': bool(ui), 'is_kunos': _is_kunos(folder.name, ui.get('author')),
        'preview_path': skins[0]['preview_path'] if skins else None,
        'badge_path': _first_existing(folder / 'ui' / 'badge.png'),
        'skins': skins,
    }


def _layout_from_ui(track_folder: Path, ui_dir: Path, layout_id: str) -> dict:
    ui = lenient_json.load_file(ui_dir / 'ui_track.json') or {}
    data_dir = track_folder / layout_id / 'data' if layout_id else track_folder / 'data'
    tags = ui.get('tags') if isinstance(ui.get('tags'), list) else []
    geotags = ui.get('geotags') if isinstance(ui.get('geotags'), list) else []
    return {
        'id': layout_id, 'name': _s(ui.get('name')) or (f'{track_folder.name} {layout_id}'.strip()),
        'country': _s(ui.get('country')), 'city': _s(ui.get('city')), 'length_m': parse_length_m(ui.get('length')),
        'width': _s(ui.get('width')), 'pitboxes': _int(ui.get('pitboxes')), 'run': _s(ui.get('run')),
        'author': _s(ui.get('author')), 'description': _s(ui.get('description')),
        'tags': [str(t) for t in tags], 'geotags': [str(t) for t in geotags],
        'preview_path': _first_existing(ui_dir / 'preview.png', ui_dir / 'preview.jpg'),
        'outline_path': _first_existing(ui_dir / 'outline.png'),
        'has_data': data_dir.is_dir(),
    }


def scan_track(folder: Path) -> dict:
    ui_root = folder / 'ui'
    layouts = []
    if ui_root.is_dir():
        for sub in sorted(p for p in ui_root.iterdir() if p.is_dir()):
            if (sub / 'ui_track.json').is_file(): layouts.append(_layout_from_ui(folder, sub, sub.name))
        if not layouts and (ui_root / 'ui_track.json').is_file(): layouts.append(_layout_from_ui(folder, ui_root, ''))
    if not layouts:
        # No UI data: infer layouts from models_<layout>.ini or a plain data folder
        for ini in sorted(folder.glob('models_*.ini')):
            lid = ini.stem[len('models_'):]
            if (folder / lid).is_dir(): layouts.append({'id': lid, 'name': f'{folder.name} {lid}', 'has_data': (folder / lid / 'data').is_dir(), 'tags': [], 'geotags': []})
        if not layouts: layouts.append({'id': '', 'name': folder.name, 'has_data': (folder / 'data').is_dir(), 'tags': [], 'geotags': []})
    names = [l['name'] for l in layouts if l.get('name')]
    author = next((l.get('author') for l in layouts if l.get('author')), None)
    return {'id': folder.name, 'name': _common_prefix_name(names) or folder.name, 'path': str(folder),
            'is_kunos': _is_kunos(folder.name, author), 'layouts': layouts}


def _common_prefix_name(names):
    if not names: return None
    if len(names) == 1: return names[0]
    prefix = names[0]
    for n in names[1:]:
        while not n.startswith(prefix) and prefix: prefix = prefix[:-1]
    prefix = prefix.strip(' -_(')
    return prefix if len(prefix) >= 3 else names[0]


def scan_content(ac_root) -> dict:
    t0 = time.time()
    root = Path(ac_root)
    cars, tracks, weathers, warnings = [], [], [], []
    for folder in sorted(p for p in (root / 'content' / 'cars').iterdir() if p.is_dir()):
        if (folder / 'fcm_managed.json').exists(): continue  # managed physics copies are not user content
        try:
            car = scan_car(folder)
            if not car['has_ui']: warnings.append(f'car {folder.name}: missing or invalid ui/ui_car.json')
            if not (car['has_data_acd'] or car['has_data_folder']): warnings.append(f'car {folder.name}: no data.acd nor data folder')
            cars.append(car)
        except Exception as e:
            warnings.append(f'car {folder.name}: {e}')
    for folder in sorted(p for p in (root / 'content' / 'tracks').iterdir() if p.is_dir()):
        try:
            tracks.append(scan_track(folder))
        except Exception as e:
            warnings.append(f'track {folder.name}: {e}')
    wdir = root / 'content' / 'weather'
    if wdir.is_dir():
        for folder in sorted(p for p in wdir.iterdir() if p.is_dir()):
            ini = folder / 'weather.ini'
            name = folder.name
            if ini.exists():
                m = re.search(r'^\s*NAME\s*=\s*(.+)$', ini.read_text(encoding='utf-8', errors='ignore'), re.M)
                if m: name = m.group(1).strip()
            weathers.append({'id': folder.name, 'name': name, 'path': str(folder)})
    ms = int((time.time() - t0) * 1000)
    _log.info('Scanned %d cars, %d tracks, %d weathers in %d ms (%d warnings)', len(cars), len(tracks), len(weathers), ms, len(warnings))
    return {'cars': cars, 'tracks': tracks, 'weathers': weathers, 'warnings': warnings, 'duration_ms': ms}


def store_scan(db, ac_root, scan: dict) -> int:
    """Replace catalog tables with a fresh scan (atomic)."""
    ts = now_ts()
    with db.transaction():
        layouts = sum(len(t['layouts']) for t in scan['tracks'])
        scan_id = db.insert('scan_runs', {'ac_root': str(ac_root), 'cars': len(scan['cars']), 'tracks': len(scan['tracks']), 'layouts': layouts,
                                          'warnings_json': jdump(scan['warnings'][:500]), 'duration_ms': scan['duration_ms'], 'create_ts': ts})
        for t in ('ac_car_skins', 'ac_cars', 'ac_track_layouts', 'ac_tracks', 'ac_weathers'): db.execute(f'DELETE FROM {t}')
        for c in scan['cars']:
            db.insert('ac_cars', {'id': c['id'], 'name': c['name'], 'brand': c['brand'], 'model': c['model'], 'year': c['year'], 'class': c['class'],
                                  'country': c['country'], 'author': c['author'], 'description': c['description'], 'tags_json': jdump(c['tags']),
                                  'specs_json': jdump(c['specs']), 'path': c['path'], 'has_data_acd': int(c['has_data_acd']),
                                  'has_data_folder': int(c['has_data_folder']), 'has_ui': int(c['has_ui']), 'is_kunos': int(c['is_kunos']),
                                  'skin_count': len(c['skins']), 'preview_path': c['preview_path'], 'badge_path': c['badge_path'],
                                  'scan_id': scan_id, 'update_ts': ts})
            for s in c['skins']:
                db.insert('ac_car_skins', {'car_id': c['id'], **{k: s.get(k) for k in ('id', 'name', 'driver_name', 'team', 'number', 'country', 'preview_path', 'livery_path', 'sort_order')}})
        for t in scan['tracks']:
            db.insert('ac_tracks', {'id': t['id'], 'name': t['name'], 'path': t['path'], 'is_kunos': int(t['is_kunos']), 'layout_count': len(t['layouts']), 'scan_id': scan_id, 'update_ts': ts})
            for l in t['layouts']:
                db.insert('ac_track_layouts', {'track_id': t['id'], 'id': l['id'], 'name': l.get('name'), 'country': l.get('country'), 'city': l.get('city'),
                                               'length_m': l.get('length_m'), 'width': l.get('width'), 'pitboxes': l.get('pitboxes'), 'run': l.get('run'),
                                               'author': l.get('author'), 'description': l.get('description'), 'tags_json': jdump(l.get('tags') or []),
                                               'geotags_json': jdump(l.get('geotags') or []), 'preview_path': l.get('preview_path'),
                                               'outline_path': l.get('outline_path'), 'has_data': int(bool(l.get('has_data')))})
        for w in scan['weathers']:
            db.insert('ac_weathers', w)
    return scan_id
