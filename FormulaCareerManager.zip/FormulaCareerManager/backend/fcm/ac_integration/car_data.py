"""Reads tyre compounds and fuel data from an unpacked car (content/cars/<id>/data). Packed data.acd is not decrypted.

tyres.ini: compound index = order of [FRONT], [FRONT_1], [FRONT_2]... (NAME / SHORT_NAME); default [COMPOUND_DEFAULT] INDEX.
car.ini:   [FUEL] FUEL (default litres), MAX_FUEL (capacity).
Setup file (Documents/Assetto Corsa/setups/<car>/<track>/<name>.ini): one section per key with VALUE, e.g. [FUEL] VALUE=45, [TYRES] VALUE=1.
(Format verified against Content Manager: AcManager.Tools/Objects/CarSetupObject.cs, Helpers/Tyres/TyresExtension.cs.)"""
import re
from pathlib import Path

from fcm.ac_integration.race_ini import parse
from fcm.shared.safefs import atomic_write_text, ensure_within, safe_id

COMPOUND_HINTS = {'S': ('soft', 'sm', 's', 'c5', 'c4'), 'M': ('medium', 'm', 'c3'), 'H': ('hard', 'h', 'c2', 'c1'),
                  'I': ('intermediate', 'inter', 'i', 'int'), 'W': ('full wet', 'wet', 'w', 'rain')}


def _data(ac_root, car_id):
    return ensure_within(Path(ac_root) / 'content' / 'cars', safe_id(car_id)) / 'data'


def tyres(ac_root, car_id):
    f = _data(ac_root, car_id) / 'tyres.ini'
    if not f.exists(): return None
    ini = parse(f.read_text(encoding='utf-8', errors='ignore'))
    out = []
    for sec in sorted((k for k in ini if re.fullmatch(r'FRONT(_\d+)?', k)), key=lambda k: int(k.split('_')[1]) if '_' in k else 0):
        idx = int(sec.split('_')[1]) if '_' in sec else 0
        out.append({'index': idx, 'name': ini[sec].get('NAME', sec), 'short': ini[sec].get('SHORT_NAME', '')})
    return {'compounds': out, 'default': int(ini.get('COMPOUND_DEFAULT', {}).get('INDEX', 0) or 0)}


def fuel(ac_root, car_id):
    f = _data(ac_root, car_id) / 'car.ini'
    if not f.exists(): return None
    sec = parse(f.read_text(encoding='utf-8', errors='ignore')).get('FUEL', {})
    try:
        return {'default': float(sec.get('FUEL', 0) or 0), 'max': float(sec.get('MAX_FUEL', 0) or 0)}
    except ValueError:
        return None


def compound_index(tyre_info, code):
    """Our S/M/H/I/W -> the car's compound index (by SHORT_NAME / NAME), or None."""
    if not tyre_info: return None
    hints = COMPOUND_HINTS.get(code, ())
    for c in tyre_info['compounds']:
        short, name = c['short'].strip().lower(), c['name'].strip().lower()
        if short in hints or any(h in name for h in hints if len(h) > 2): return c['index']
    return None


def write_setup(docs_dir, car_id, track_id, values, name='fcm_strategy'):
    """Writes a minimal setup file with the given keys. Only our own file name is ever written."""
    d = Path(docs_dir) / 'setups' / safe_id(car_id) / safe_id(track_id)
    path = d / f'{name}.ini'
    atomic_write_text(path, ''.join(f'[{k}]\nVALUE={int(v) if float(v).is_integer() else v}\n\n' for k, v in values.items()))
    return path
