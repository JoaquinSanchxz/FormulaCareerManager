"""race.ini generation (Documents/Assetto Corsa/cfg/race.ini).

Key set verified against Content Manager's writer (gro-ove/actools,
AcTools/Processes/Game.Properties.cs):
  [RACE]      TRACK, CONFIG_TRACK, MODEL, MODEL_CONFIG, SKIN, CARS, AI_LEVEL, FIXED_SETUP,
              PENALTIES, JUMP_START_PENALTY, DRIFT_MODE, RACE_LAPS
  [CAR_0]     player: MODEL=-, SKIN, SETUP, MODEL_CONFIG, BALLAST, RESTRICTOR, DRIVER_NAME, NATIONALITY, NATION_CODE
  [CAR_n]     AI: MODEL, SKIN, SETUP, MODEL_CONFIG, AI_LEVEL (0-100), AI_AGGRESSION, DRIVER_NAME, BALLAST, RESTRICTOR, ...
  [SESSION_n] NAME, TYPE (1 practice, 2 qualifying, 3 race), DURATION_MINUTES, SPAWN_SET (PIT/START), LAPS, STARTING_POSITION
  [LIGHTING]  SUN_ANGLE = 16 * (seconds - 46800) / 3600 ; TIME_MULT ; CLOUD_SPEED
  [TEMPERATURE] AMBIENT, ROAD ; [WEATHER] NAME ; [WIND] SPEED_KMH_MIN/MAX, DIRECTION_DEG
"""
from dataclasses import dataclass, field
from typing import List

from fcm.shared.safefs import safe_id

SESSION_TYPES = {'practice': 1, 'qualifying': 2, 'race': 3}


@dataclass
class CarEntry:
    model: str
    skin: str = ''
    driver_name: str = ''
    nationality: str = ''
    nation_code: str = ''
    ai_level: float = 100
    ai_aggression: float = 0
    ballast: float = 0
    restrictor: float = 0
    setup: str = ''


@dataclass
class SessionSpec:
    track: str
    layout: str
    session_type: str                 # practice | qualifying | race
    name: str
    player: CarEntry
    opponents: List[CarEntry] = field(default_factory=list)   # in grid order (excluding player)
    laps: int = 0
    duration_min: int = 0
    player_grid_position: int = 1     # 1-based slot of the player on the grid
    time_of_day: str = '14:00'
    weather: str = '3_clear'
    ambient: float = 24
    road: float = 30
    race_ai_level: float = 90
    options: dict = field(default_factory=dict)
    unclamped_time: bool = False        # CSP CONDITIONS_24H: night races
    extra_lighting: dict = field(default_factory=dict)   # CSP WeatherFX keys (__CM_WEATHER_TYPE, __CM_WEATHER_CONTROLLER)
    player_setup_file: str = ''         # CSP: [CAR_0] _EXT_SETUP_FILENAME


def sun_angle(time_of_day: str, clamp=True) -> float:
    """16 degrees per hour around 13:00 (Content Manager formula). Vanilla AC accepts 08:00-18:00 (-80..80);
    with CSP CONDITIONS_24H the unclamped value is written (e.g. 20:00 -> 112)."""
    h, m = (time_of_day or '14:00').split(':')[:2]
    seconds = int(h) * 3600 + int(m) * 60
    angle = 16.0 * (seconds - 46800.0) / 3600.0
    return round(max(-80.0, min(80.0, angle)) if clamp else angle, 2)


def _fmt(v):
    if isinstance(v, bool): return '1' if v else '0'
    if isinstance(v, float): return f'{v:.2f}'.rstrip('0').rstrip('.') if v != int(v) else str(int(v))
    return '' if v is None else str(v)


def _clean(text):
    return str(text or '').replace('\r', ' ').replace('\n', ' ').replace('[', '(').replace(']', ')')


def build(spec: SessionSpec) -> str:
    safe_id(spec.track)
    if spec.layout: safe_id(spec.layout)
    for c in [spec.player, *spec.opponents]:
        safe_id(c.model)
        if c.skin: safe_id(c.skin)
    if spec.session_type not in SESSION_TYPES: raise ValueError(f'Unsupported session type {spec.session_type}')
    o = {'penalties': 1, 'jump_start_penalty': 0, 'fixed_setup': 0, 'allowed_tyres_out': -1, 'time_mult': 1, 'cloud_speed': 0.2,
         'groove': {'VIRTUAL_LAPS': 10, 'MAX_LAPS': 30, 'STARTING_LAPS': 0},
         'dynamic_track': {'SESSION_START': 95, 'RANDOMNESS': 2, 'LAP_GAIN': 10, 'SESSION_TRANSFER': 90},
         'wind': {'SPEED_KMH_MIN': 0, 'SPEED_KMH_MAX': 0, 'DIRECTION_DEG': 0}}
    o.update(spec.options or {})
    cars = len(spec.opponents) + 1
    is_race = spec.session_type == 'race'
    sections = []

    def sec(name, items):
        sections.append((name, items))

    sec('HEADER', [('VERSION', 2)])
    sec('RACE', [('TRACK', spec.track), ('CONFIG_TRACK', spec.layout or ''), ('MODEL', spec.player.model), ('MODEL_CONFIG', ''),
                 ('SKIN', spec.player.skin), ('CARS', cars), ('AI_LEVEL', spec.race_ai_level), ('FIXED_SETUP', o['fixed_setup']),
                 ('PENALTIES', o['penalties']), ('JUMP_START_PENALTY', o['jump_start_penalty']), ('DRIFT_MODE', 0),
                 ('RACE_LAPS', spec.laps if is_race else 0)])
    sec('OPTIONS', [('USE_MPH', 0)])
    sec('REMOTE', [('ACTIVE', 0)])
    sec('REPLAY', [('ACTIVE', 0)])
    sec('RESTART', [('ACTIVE', 0)])
    sec('BENCHMARK', [('ACTIVE', 0)])
    sec('AUTOSPAWN', [('ACTIVE', 1)])
    sec('LAP_INVALIDATOR', [('ALLOWED_TYRES_OUT', o['allowed_tyres_out'])])
    sec('GHOST_CAR', [('RECORDING', 0), ('PLAYING', 0), ('SECONDS_ADVANTAGE', 0), ('LOAD', 0), ('FILE', ''), ('ENABLED', 0)])
    sec('GROOVE', list(o['groove'].items()))
    sec('DYNAMIC_TRACK', list(o['dynamic_track'].items()))
    sec('LIGHTING', [('SUN_ANGLE', sun_angle(spec.time_of_day, clamp=not spec.unclamped_time)), ('TIME_MULT', o['time_mult']), ('CLOUD_SPEED', o['cloud_speed']),
                     *spec.extra_lighting.items()])
    sec('WEATHER', [('NAME', spec.weather)])
    sec('TEMPERATURE', [('AMBIENT', round(spec.ambient)), ('ROAD', round(spec.road))])
    sec('WIND', list(o['wind'].items()))
    session = [('NAME', _clean(spec.name)), ('TYPE', SESSION_TYPES[spec.session_type]),
               ('DURATION_MINUTES', 0 if is_race else spec.duration_min), ('SPAWN_SET', 'START' if is_race else 'PIT'),
               ('LAPS', spec.laps if is_race else 0)]
    if is_race: session.append(('STARTING_POSITION', max(1, min(cars, spec.player_grid_position))))
    sec('SESSION_0', session)
    p = spec.player
    sec('CAR_0', [('SETUP', p.setup), ('SKIN', p.skin), ('MODEL', '-'), ('MODEL_CONFIG', ''), ('BALLAST', p.ballast),
                  ('RESTRICTOR', p.restrictor), ('DRIVER_NAME', _clean(p.driver_name)), ('NATIONALITY', _clean(p.nationality)),
                  ('NATION_CODE', _clean(p.nation_code)), *([('_EXT_SETUP_FILENAME', spec.player_setup_file)] if spec.player_setup_file else [])])
    for i, c in enumerate(spec.opponents, start=1):
        sec(f'CAR_{i}', [('MODEL', c.model), ('SKIN', c.skin), ('SETUP', c.setup), ('MODEL_CONFIG', ''),
                         ('AI_LEVEL', round(float(c.ai_level), 1)), ('AI_AGGRESSION', round(float(c.ai_aggression), 1)),
                         ('DRIVER_NAME', _clean(c.driver_name)), ('NATIONALITY', _clean(c.nationality)), ('NATION_CODE', _clean(c.nation_code)),
                         ('BALLAST', c.ballast), ('RESTRICTOR', c.restrictor)])
    lines = []
    for name, items in sections:
        lines.append(f'[{name}]')
        lines += [f'{k}={_fmt(v)}' for k, v in items]
        lines.append('')
    return '\n'.join(lines)


def parse(text: str) -> dict:
    """Minimal INI parser (AC ini files are not always ConfigParser-compatible)."""
    out, cur = {}, None
    for raw in text.splitlines():
        line = raw.split(';', 1)[0].strip()
        if not line: continue
        if line.startswith('[') and line.endswith(']'):
            cur = line[1:-1].strip()
            out.setdefault(cur, {})
        elif '=' in line and cur is not None:
            k, v = line.split('=', 1)
            out[cur][k.strip()] = v.strip()
    return out
