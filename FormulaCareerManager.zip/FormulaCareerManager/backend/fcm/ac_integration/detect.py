"""Assetto Corsa installation detection.

Sources (see AC_INTEGRATION.md):
- Steam registry: HKCU\\Software\\Valve\\Steam\\SteamPath and HKLM\\SOFTWARE\\WOW6432Node\\Valve\\Steam\\InstallPath
- <steam>/steamapps/libraryfolders.vdf lists extra Steam libraries ("path" keys)
- AC Steam app id is 244210; installed under <library>/steamapps/common/assettocorsa
- Common manual locations on every drive letter
A folder is valid when it contains acs.exe and content/cars + content/tracks.
"""
import os
import re
import string
import sys
from pathlib import Path

from fcm.shared import log, paths

_log = log.get('AC')
AC_APP_ID = '244210'
AC_FOLDER = 'assettocorsa'


def _registry_steam_paths():
    out = []
    if sys.platform != 'win32': return out
    try:
        import winreg
    except ImportError:
        return out
    keys = [(winreg.HKEY_CURRENT_USER, r'Software\Valve\Steam', 'SteamPath'),
            (winreg.HKEY_LOCAL_MACHINE, r'SOFTWARE\WOW6432Node\Valve\Steam', 'InstallPath'),
            (winreg.HKEY_LOCAL_MACHINE, r'SOFTWARE\Valve\Steam', 'InstallPath')]
    for hive, sub, name in keys:
        try:
            with winreg.OpenKey(hive, sub) as k:
                val, _ = winreg.QueryValueEx(k, name)
                if val: out.append(Path(val))
        except OSError:
            continue
    # Uninstall entry written by Steam for AC itself
    for hive in (winreg.HKEY_LOCAL_MACHINE, winreg.HKEY_CURRENT_USER):
        for sub in (rf'SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall\Steam App {AC_APP_ID}',
                    rf'SOFTWARE\WOW6432Node\Microsoft\Windows\CurrentVersion\Uninstall\Steam App {AC_APP_ID}'):
            try:
                with winreg.OpenKey(hive, sub) as k:
                    val, _ = winreg.QueryValueEx(k, 'InstallLocation')
                    if val: out.append(('AC', Path(val)))
            except OSError:
                continue
    return out


def parse_library_folders(vdf_text: str):
    """Extract library paths from Steam's libraryfolders.vdf (old and new formats)."""
    paths_ = []
    for m in re.finditer(r'"(?:path|\d+)"\s+"([^"]+)"', vdf_text):
        p = m.group(1).replace('\\\\', '\\')
        if ':' in p or p.startswith('/'): paths_.append(Path(p))
    return paths_


def steam_libraries():
    libs = []
    steam_roots = []
    for item in _registry_steam_paths():
        if isinstance(item, tuple): continue
        steam_roots.append(item)
    steam_roots += [Path(r'C:\Program Files (x86)\Steam'), Path(r'C:\Program Files\Steam')]
    for root in steam_roots:
        if root not in libs: libs.append(root)
        vdf = root / 'steamapps' / 'libraryfolders.vdf'
        try:
            for lib in parse_library_folders(vdf.read_text(encoding='utf-8', errors='ignore')):
                if lib not in libs: libs.append(lib)
        except OSError:
            pass
    return libs


def candidate_paths(saved=None):
    cands = []
    if saved: cands.append(Path(saved))
    for item in _registry_steam_paths():
        if isinstance(item, tuple): cands.append(item[1])
    for lib in steam_libraries():
        cands.append(lib / 'steamapps' / 'common' / AC_FOLDER)
    if sys.platform == 'win32':
        for d in string.ascii_uppercase:
            drive = Path(f'{d}:\\')
            if not os.path.exists(f'{d}:\\'): continue
            for rel in ('SteamLibrary/steamapps/common', 'Steam/steamapps/common', 'Games/Steam/steamapps/common',
                        'Program Files (x86)/Steam/steamapps/common', 'Games', ''):
                cands.append(drive / rel / AC_FOLDER)
    seen, out = set(), []
    for c in cands:
        key = str(c).lower()
        if key not in seen:
            seen.add(key)
            out.append(c)
    return out


def validate_install(path) -> dict:
    p = Path(path) if path else None
    checks = {
        'exists': bool(p and p.is_dir()),
        'acs_exe': bool(p and (p / 'acs.exe').is_file()),
        'content_cars': bool(p and (p / 'content' / 'cars').is_dir()),
        'content_tracks': bool(p and (p / 'content' / 'tracks').is_dir()),
    }
    valid = checks['exists'] and checks['content_cars'] and checks['content_tracks'] and checks['acs_exe']
    reasons = [k for k, v in checks.items() if not v]
    return {'path': str(p) if p else None, 'valid': valid, 'checks': checks, 'missing': reasons}


def detect(saved=None) -> dict:
    tried = []
    for c in candidate_paths(saved):
        v = validate_install(c)
        tried.append(str(c))
        if v['valid']:
            _log.info('Assetto Corsa detected at %s', c)
            return {'found': True, 'path': str(c), 'source': 'saved' if saved and str(c) == str(saved) else 'auto', 'tried': len(tried)}
    _log.warning('Assetto Corsa not found automatically (%d candidates)', len(tried))
    return {'found': False, 'path': None, 'tried': len(tried)}


def ac_documents_dir() -> Path:
    """Documents/Assetto Corsa - holds cfg/race.ini, out/race_out.json and logs/log.txt."""
    if os.environ.get('FCM_AC_DOCUMENTS'): return Path(os.environ['FCM_AC_DOCUMENTS'])
    return paths.documents_dir() / 'Assetto Corsa'


def detect_extras(ac_root) -> dict:
    """Detect CSP, Content Manager, Steam process, documents folders. Best effort, never raises."""
    root = Path(ac_root) if ac_root else None
    info = {'csp': {'installed': False}, 'content_manager': {'detected': False}, 'documents': {}}
    try:
        if root:
            manifest = root / 'extension' / 'config' / 'data_manifest.ini'
            info['csp']['installed'] = (root / 'dwrite.dll').exists() and (root / 'extension').is_dir()
            if manifest.exists():
                from fcm.ac_integration.race_ini import parse
                ini = parse(manifest.read_text(encoding='utf-8', errors='ignore'))
                info['csp']['version'] = ini.get('VERSION', {}).get('SHADERS_PATCH')
                info['csp']['build'] = ini.get('VERSION', {}).get('SHADERS_PATCH_BUILD')
                info['csp']['features'] = sorted(k for k, v in ini.get('FEATURES', {}).items() if v.strip() == '1')
            info['csp'].update(csp_capabilities(root, info['csp']))
        local = os.environ.get('LOCALAPPDATA')
        if local and (Path(local) / 'AcTools Content Manager').is_dir(): info['content_manager']['detected'] = True
        docs = ac_documents_dir()
        info['documents'] = {'path': str(docs), 'exists': docs.is_dir(),
                             'race_ini': str(docs / 'cfg' / 'race.ini'), 'race_out': str(docs / 'out' / 'race_out.json')}
    except Exception as e:
        _log.warning('detect_extras failed: %s', e)
    info['steam_running'] = is_process_running('steam.exe')
    info['ac_running'] = is_process_running('acs.exe')
    return info


def _ini_enabled(root, name):
    """CSP module enabled? User config (Documents/.../cfg/extension/<name>) overrides the default (<AC>/extension/config/<name>)."""
    from fcm.ac_integration.race_ini import parse
    val = None
    for p in (Path(root) / 'extension' / 'config' / name, ac_documents_dir() / 'cfg' / 'extension' / name):
        if p.exists():
            v = parse(p.read_text(encoding='utf-8', errors='ignore')).get('BASIC', {}).get('ENABLED')
            if v is not None: val = v.strip()
    return val == '1'


def csp_capabilities(root, csp):
    """Same checks Content Manager does (PatchHelper.IsFeatureSupported): CSP installed + active + feature flag."""
    feats = set(csp.get('features') or [])
    active = bool(csp.get('installed')) and _ini_enabled(root, 'general.ini')
    weather = active and 'WEATHERFX_LAUNCHER_CONTROLLED' in feats and _ini_enabled(root, 'weather_fx.ini')
    return {'active': active, 'night': active and 'CONDITIONS_24H' in feats, 'weather': weather, 'rain': weather and _ini_enabled(root, 'rain_fx.ini')}


def is_process_running(image: str) -> bool:
    if sys.platform != 'win32': return False
    try:
        import subprocess
        out = subprocess.run(['tasklist', '/FI', f'IMAGENAME eq {image}', '/NH', '/FO', 'CSV'], capture_output=True,
                             text=True, timeout=5, creationflags=getattr(subprocess, 'CREATE_NO_WINDOW', 0))
        return image.lower() in out.stdout.lower()
    except Exception:
        return False
