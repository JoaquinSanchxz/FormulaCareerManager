"""Parser for Documents/Assetto Corsa/out/race_out.json (written by AC when a session ends).

Structure (cross-checked with simresults' AssettoCorsa reader):
  track, players[{name, car, skin}], sessions[{name, type, lapsCount, duration,
  laps[{car, lap, time, sectors[], cuts, tyre}], lapstotal[], bestLaps[{car, time, lap}], raceResult[]}]
Car index N in players/laps == [CAR_N] section of race.ini.

Not available in race_out.json (fallbacks, see AC_INTEGRATION.md):
  pit stops, damage, penalties, DNF cause. DNF is inferred from laps and elapsed time.
"""
import statistics

from fcm.shared import lenient_json


class ResultParseError(ValueError):
    pass


def load(path):
    data = lenient_json.load_file(path)
    if not isinstance(data, dict) or 'sessions' not in data: raise ResultParseError(f'Invalid race_out.json at {path}')
    return data


def _pick_session(raw, session_type):
    sessions = raw.get('sessions') or []
    if not sessions: raise ResultParseError('race_out.json contains no sessions')
    want = {'practice': 1, 'qualifying': 2, 'race': 3, 'sprint': 3}.get(session_type)
    for s in reversed(sessions):
        if s.get('type') == want: return s
    return sessions[-1]


def parse(raw: dict, session_type: str, expected_names=None) -> dict:
    players = raw.get('players') or []
    s = _pick_session(raw, session_type)
    n = len(players)
    warnings = []
    if expected_names is not None:
        if len(expected_names) != n: raise ResultParseError(f'Result has {n} cars but session had {len(expected_names)} entries')
        for i, (exp, p) in enumerate(zip(expected_names, players)):
            if exp and (p.get('name') or '').strip() != exp.strip(): warnings.append(f'car {i}: expected driver "{exp}", result says "{p.get("name")}"')
    cars = [{'car_index': i, 'name': p.get('name'), 'car': p.get('car'), 'skin': p.get('skin'), 'laps': [], 'lap_count': 0,
             'total_time_ms': 0, 'best_lap_ms': None, 'cuts': 0} for i, p in enumerate(players)]
    for lap in s.get('laps') or []:
        i = lap.get('car')
        if not isinstance(i, int) or i < 0 or i >= n: continue
        t = int(lap.get('time') or 0)
        if t <= 0: continue
        c = cars[i]
        cuts = int(lap.get('cuts') or 0)
        c['laps'].append({'lap_no': len(c['laps']) + 1, 'time_ms': t, 'sectors': [int(x) for x in (lap.get('sectors') or [])], 'cuts': cuts, 'tyre': lap.get('tyre')})
        c['total_time_ms'] += t
        c['cuts'] += cuts
        if cuts == 0 and (c['best_lap_ms'] is None or t < c['best_lap_ms']): c['best_lap_ms'] = t
    lapstotal = s.get('lapstotal') or []
    for c in cars:
        c['lap_count'] = len(c['laps'])
        if c['lap_count'] == 0 and c['car_index'] < len(lapstotal): c['lap_count'] = int(lapstotal[c['car_index']] or 0)
    for b in s.get('bestLaps') or []:
        i = b.get('car')
        if isinstance(i, int) and 0 <= i < n and cars[i]['best_lap_ms'] is None and (b.get('time') or 0) > 0: cars[i]['best_lap_ms'] = int(b['time'])
    is_race = session_type in ('race', 'sprint')
    session_laps = int(s.get('lapsCount') or 0)
    if is_race:
        order = [i for i in (s.get('raceResult') or []) if isinstance(i, int) and 0 <= i < n]
        order += [c['car_index'] for c in sorted(cars, key=lambda c: (-c['lap_count'], c['total_time_ms'] or 1e18)) if c['car_index'] not in order]
        leader = cars[order[0]] if order else None
        leader_laps = leader['lap_count'] if leader else 0
        leader_time = leader['total_time_ms'] if leader else 0
        for c in cars:
            avg = statistics.median([l['time_ms'] for l in c['laps']]) if c['laps'] else 0
            if c['lap_count'] == 0: c['status'] = 'DNS' if leader_laps else 'DNF'
            elif c['lap_count'] < leader_laps and c['total_time_ms'] + 1.5 * avg < leader_time: c['status'] = 'DNF'
            else: c['status'] = 'FIN'
        # classified finishers first (keeping AC order), then DNF by laps completed
        fin = [i for i in order if cars[i]['status'] == 'FIN']
        rest = sorted((i for i in order if cars[i]['status'] != 'FIN'), key=lambda i: (-cars[i]['lap_count'], -cars[i]['total_time_ms']))
        order = fin + rest
        for c in cars:
            c['gap_ms'] = c['total_time_ms'] - leader_time if c['status'] == 'FIN' and c['lap_count'] == leader_laps else None
            c['laps_down'] = leader_laps - c['lap_count']
        complete = bool(leader_laps) and (session_laps == 0 or leader_laps >= session_laps)
    else:
        order = [c['car_index'] for c in sorted(cars, key=lambda c: (c['best_lap_ms'] is None, c['best_lap_ms'] or 0, c['car_index']))]
        best = cars[order[0]]['best_lap_ms'] if order else None
        for c in cars:
            c['status'] = 'FIN'
            c['gap_ms'] = c['best_lap_ms'] - best if c['best_lap_ms'] and best else None
        complete = any(c['best_lap_ms'] for c in cars)
    for pos, i in enumerate(order, start=1): cars[i]['position'] = pos
    fastest = min((c for c in cars if c['best_lap_ms']), key=lambda c: c['best_lap_ms'], default=None)
    return {'track': raw.get('track'), 'session_name': s.get('name'), 'session_type': session_type, 'session_laps': session_laps,
            'cars': cars, 'order': order, 'fastest_lap_car': fastest['car_index'] if fastest else None,
            'complete': complete, 'warnings': warnings}
