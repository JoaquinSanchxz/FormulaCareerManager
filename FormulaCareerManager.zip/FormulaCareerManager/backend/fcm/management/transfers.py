"""Dynamic market value and mid-season transfers (summer break window).

- Market value (M): talent + youth/potential + current form + recent streak + reputation, per category level.
- Offers accepted before the summer break move the driver AT the break; later ones at season end.
- At the break AI teams may replace clearly underperforming drivers (reserve, free agent or a strong
  driver from a lower category, super licence permitting). Every departure is covered before the driver
  leaves: the team picks a replacement, which can cascade down the categories. Invented rookies are only
  created in the lowest category, and only when nobody real is available."""
import math

from fcm.career_engine import newsroom, repo
from fcm.database.db import jdump, jload, now_ts
from fcm.management import finance
from fcm.management.common import season_teams, team_drivers
from fcm.shared import config
from fcm.shared.rng import rng_for
from fcm.simulation.model import clamp


def cfg():
    return config.load('market')


def market_value(d, tier):
    """d: driver row with base_rating, potential, age, form, reputation, trend."""
    mv = cfg()['market_value']
    youth = max(0.0, (25 - d['age']) / 6)
    w = d['base_rating'] + (d['potential'] - d['base_rating']) * 0.5 * youth + d['form'] * 0.8 + d.get('trend', 0) * 2.0 \
        + (d['reputation'] - 50) * 0.04 - max(0, d['age'] - 33) * 0.8
    t = mv['by_tier'][str(min(3, tier))]
    return round(clamp(t['base'] * math.exp((w - t['pivot']) / mv['scale']), t['min'], t['max']), 3)


def driver_tier(db, season_id, driver_id):
    return db.value("SELECT MIN(c.tier) FROM championship_entries e JOIN championships ch ON ch.id = e.championship_id JOIN categories c ON c.id = ch.category_id "
                    "WHERE ch.season_id = ? AND e.driver_id = ? AND e.active = 1", (season_id, driver_id)) or 3


def update_market_values(db, season):
    for d in db.all('SELECT d.*, a.base_rating FROM drivers d JOIN driver_attributes a ON a.driver_id = d.id WHERE d.retired = 0'):
        d['age'] = repo.age_in(d['birth_date'], season['year'])
        d['trend'] = jload(d['progress_json'], {}).get('trend', 0.0)
        db.update('drivers', d['id'], {'market_value': market_value(d, driver_tier(db, season['id'], d['id']))})


def summer_round(db, season_id):
    return db.one('SELECT * FROM calendar_rounds WHERE season_id = ? AND summer_break_after = 1 ORDER BY round_no LIMIT 1', (season_id,))


def before_summer_break(db, season_id):
    r = summer_round(db, season_id)
    return bool(r and r['status'] != 'completed')


# ------------------------------------------------------------------------------------------
# Moves
# ------------------------------------------------------------------------------------------
def race_entry(db, season_id, driver_id):
    return db.one("SELECT e.*, c.tier, c.code FROM championship_entries e JOIN championships ch ON ch.id = e.championship_id JOIN categories c ON c.id = ch.category_id "
                  "WHERE ch.season_id = ? AND e.driver_id = ? AND e.active = 1 AND e.role IN ('D1', 'D2', 'D3') ORDER BY c.tier LIMIT 1", (season_id, driver_id))


def team_championship(db, season_id, team_id):
    return db.one('SELECT ch.id, c.tier, c.code FROM teams t JOIN categories c ON c.id = t.category_id JOIN championships ch ON ch.category_id = c.id AND ch.season_id = ? WHERE t.id = ?',
                  (season_id, team_id))


def move_driver(db, season, driver_id, to_team_id, reason, rng, depth=0, contract=None):
    """Move a driver into a race seat of to_team mid-season. Covers every vacancy it creates."""
    year = season['year']
    target = team_championship(db, season['id'], to_team_id)
    old = race_entry(db, season['id'], driver_id)
    seats = team_drivers(db, season['id'], to_team_id)
    per_team = repo.cars_per_team(db, target['id'])
    dropped = None
    if len(seats) >= per_team:
        pid = repo.career(db)['player_driver_id']
        cands = [s for s in seats if s['driver_id'] not in (pid, driver_id)]
        dropped = min(cands, key=lambda s: db.value('SELECT base_rating FROM driver_attributes WHERE driver_id = ?', (s['driver_id'],)))
        role = dropped['role']
        _release(db, season, dropped['driver_id'], to_team_id, target['id'], make_reserve=target['tier'] == 1)
    else:
        role = f'D{len(seats) + 1}'
    existing = db.one('SELECT * FROM championship_entries WHERE championship_id = ? AND driver_id = ?', (target['id'], driver_id))
    number = existing['number'] if existing else (old['number'] if old and old['championship_id'] == target['id'] else None)
    used = {r['number'] for r in db.all('SELECT number FROM championship_entries WHERE championship_id = ? AND driver_id != ? AND active = 1', (target['id'], driver_id))}
    if not number or number in used: number = next(n for n in range(2, 100) if n not in used)
    skin = db.value("SELECT skin FROM championship_entries WHERE team_id = ? AND championship_id = ? AND skin IS NOT NULL LIMIT 1", (to_team_id, target['id']))
    if old and old['championship_id'] != target['id']: db.update('championship_entries', old['id'], {'active': 0, 'role': 'left'})
    if existing: db.update('championship_entries', existing['id'], {'team_id': to_team_id, 'role': role, 'active': 1, 'number': number, 'skin': skin})
    else: db.insert('championship_entries', {'championship_id': target['id'], 'driver_id': driver_id, 'team_id': to_team_id, 'number': number, 'skin': skin, 'role': role, 'active': 1})
    db.execute("UPDATE contracts SET status = 'terminated', end_season = ? WHERE driver_id = ? AND status = 'active' AND team_id != ?", (year, driver_id, to_team_id))
    if contract: db.update('contracts', contract['id'], {'status': 'active', 'start_season': year, 'effective': 'summer'})
    elif not db.value("SELECT 1 FROM contracts WHERE driver_id = ? AND team_id = ? AND status = 'active'", (driver_id, to_team_id)):
        from fcm.management.market import salary_for
        d = db.one('SELECT d.reputation, a.base_rating FROM drivers d JOIN driver_attributes a ON a.driver_id = d.id WHERE d.id = ?', (driver_id,))
        sal = salary_for(target['tier'], d['base_rating'], d['reputation'])
        db.insert('contracts', {'driver_id': driver_id, 'team_id': to_team_id, 'start_season': year, 'end_season': year + 1, 'salary': sal, 'role': role,
                                'release_clause': round(sal * 2, 3), 'status': 'active', 'effective': 'summer', 'create_ts': now_ts()})
    dn = db.one('SELECT first_name, last_name FROM drivers WHERE id = ?', (driver_id,))
    tn = db.value('SELECT name FROM teams WHERE id = ?', (to_team_id,))
    ev = repo.emit(db, 'MIDSEASON_TRANSFER', {'driver_id': driver_id, 'to_team_id': to_team_id, 'from_team_id': old and old['team_id'], 'reason': reason,
                                              'dropped': dropped and dropped['driver_id']}, season_id=season['id'])
    newsroom.midseason(db, driver_id, to_team_id, dropped and dropped['driver_id'], season['id'], ev)
    if old and not (old['team_id'] == to_team_id and old['championship_id'] == target['id']) and depth < 4:
        fill_vacancy(db, season, old['team_id'], old['championship_id'], rng, depth + 1, exclude={driver_id})
    return {'dropped': dropped and dropped['driver_id'], 'role': role}


def _release(db, season, driver_id, team_id, championship_id, make_reserve):
    e = db.one('SELECT * FROM championship_entries WHERE championship_id = ? AND driver_id = ?', (championship_id, driver_id))
    if make_reserve and e: db.update('championship_entries', e['id'], {'role': 'reserve', 'active': 1})
    elif e: db.update('championship_entries', e['id'], {'active': 0, 'role': 'left'})
    db.execute("UPDATE contracts SET status = 'terminated', end_season = ? WHERE driver_id = ? AND team_id = ? AND status = 'active'", (season['year'], driver_id, team_id))
    repo.emit(db, 'DRIVER_DROPPED', {'driver_id': driver_id, 'team_id': team_id, 'to_reserve': make_reserve}, season_id=season['id'])


def _candidates(db, season, tier, team_id, exclude):
    """Available replacements: team reserve, free agents, and drivers from LOWER categories (never poaching same-level race seats mid-season)."""
    from fcm.management.market import candidate_score, has_super_license
    out = []
    raced = {r['driver_id']: r for r in db.all("SELECT e.driver_id, c.tier, e.team_id, e.role FROM championship_entries e JOIN championships ch ON ch.id = e.championship_id "
                                               "JOIN categories c ON c.id = ch.category_id WHERE ch.season_id = ? AND e.active = 1", (season['id'],))}
    pid = repo.career(db)['player_driver_id']
    for d in db.all('SELECT d.id, d.first_name, d.last_name, d.birth_date, d.potential, d.reputation, d.form, d.progress_json, a.base_rating FROM drivers d '
                    'JOIN driver_attributes a ON a.driver_id = d.id WHERE d.retired = 0'):
        if d['id'] in exclude or d['id'] == pid: continue
        r = raced.get(d['id'])
        if r and r['role'] in ('D1', 'D2', 'D3') and r['tier'] <= tier: continue
        if r and r['role'] == 'reserve' and r['team_id'] != team_id and r['tier'] == tier: continue
        d.update({'age': repo.age_in(d['birth_date'], season['year']), 'tier': r['tier'] if r else 9})
        if tier == 1 and not has_super_license(db, d['id'], season['year']): continue
        sc = candidate_score(db, d, tier, None, team_id) + (2.0 if r and r['role'] == 'reserve' and r['team_id'] == team_id else 0)
        sc += jload(d['progress_json'], {}).get('trend', 0.0) * 1.5 + d['form'] * 0.4
        out.append((round(sc, 3), d))
    out.sort(key=lambda x: -x[0])
    return out


def fill_vacancy(db, season, team_id, championship_id, rng, depth=0, exclude=frozenset()):
    ch = db.one('SELECT ch.id, c.tier, c.code FROM championships ch JOIN categories c ON c.id = ch.category_id WHERE ch.id = ?', (championship_id,))
    if len(team_drivers(db, season['id'], team_id)) >= repo.cars_per_team(db, championship_id): return None
    pool = _candidates(db, season, ch['tier'], team_id, set(exclude))
    lowest = db.value('SELECT MAX(c.tier) FROM championships ch JOIN categories c ON c.id = ch.category_id WHERE ch.season_id = ?', (season['id'],))
    if pool:
        chosen = pool[0][1]
    elif ch['tier'] == lowest:
        from fcm.career_engine import world_builder
        new_id = world_builder.generate_rookie(db, rng, season['year'])
        chosen = {'id': new_id}
        repo.emit(db, 'ROOKIE_GENERATED', {'driver_id': new_id, 'team_id': team_id, 'midseason': True}, season_id=season['id'])
    else:
        return None
    repo.emit(db, 'MARKET_DECISION', {'team_id': team_id, 'need': 'midseason replacement', 'candidates': [{'driver_id': d['id'], 'score': s} for s, d in pool[:5]],
                                      'chosen': chosen['id']}, season_id=season['id'])
    return move_driver(db, season, chosen['id'], team_id, 'Sustituto a mitad de temporada', rng, depth)


def summer_window(db, rnd):
    """Executed when the round before the summer break is completed."""
    if not repo.career(db)['realism'].get('driver_market', True): return
    season = db.one('SELECT * FROM seasons WHERE id = ?', (rnd['season_id'],))
    rng = rng_for(repo.career(db)['seed'], 'summer', season['year'])
    for c in db.all("SELECT * FROM contracts WHERE status = 'pending' AND effective = 'summer' AND start_season = ?", (season['year'],)):
        move_driver(db, season, c['driver_id'], c['team_id'], 'Traspaso acordado antes del parón', rng, contract=c)
    pid = repo.career(db)['player_driver_id']
    moves = 0
    for t in season_teams(db, season['id']):
        if moves >= cfg()['midseason']['max_moves']: break
        for d in team_drivers(db, season['id'], t['team_id']):
            if d['driver_id'] == pid: continue
            perf = db.one('SELECT AVG(dp.score * dp.confidence) m, COUNT(*) n FROM driver_performance dp JOIN sessions s ON s.id = dp.session_id JOIN calendar_rounds cr ON cr.id = s.round_id '
                          "WHERE cr.season_id = ? AND dp.driver_id = ? AND s.type IN ('race', 'qualifying')", (season['id'], d['driver_id']))
            if not perf['n'] or perf['n'] < cfg()['midseason']['min_sessions'] or perf['m'] > cfg()['midseason']['underperform_score']: continue
            pool = _candidates(db, season, t['tier'], t['team_id'], {d['driver_id']})
            me = db.one('SELECT d.id, d.birth_date, d.potential, d.reputation, a.base_rating FROM drivers d JOIN driver_attributes a ON a.driver_id = d.id WHERE d.id = ?', (d['driver_id'],))
            from fcm.management.market import candidate_score
            me.update({'age': repo.age_in(me['birth_date'], season['year']), 'tier': t['tier']})
            my = candidate_score(db, me, t['tier'], None, t['team_id']) + perf['m'] * 2
            if not pool or pool[0][0] < my + cfg()['midseason']['min_improvement'] or rng.random() > cfg()['midseason']['probability']: continue
            _release(db, season, d['driver_id'], t['team_id'], d['championship_id'], make_reserve=t['tier'] == 1)
            repo.emit(db, 'MARKET_DECISION', {'team_id': t['team_id'], 'dropped': d['driver_id'], 'avg_score': round(perf['m'], 3), 'my_score': round(my, 2),
                                              'candidates': [{'driver_id': x['id'], 'score': s} for s, x in pool[:5]]}, season_id=season['id'])
            move_driver(db, season, pool[0][1]['id'], t['team_id'], f"Sustituye a {d['first_name']} {d['last_name']} por bajo rendimiento", rng)
            moves += 1
            break
