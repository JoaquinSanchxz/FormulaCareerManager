"""Read model for the player's team management screens + permission check for team actions."""
from fcm.career_engine import repo
from fcm.database.db import jload
from fcm.management import components, development, finance, regulations
from fcm.management.common import player_team_id, season_teams
from fcm.shared import config
from fcm.simulation.model import car_track_strength, overall_strength


def require_player_team(db, team_id=None):
    season = repo.current_season(db)
    ptid = player_team_id(db, season['id'])
    if not ptid: raise ValueError('El jugador no tiene equipo esta temporada')
    if team_id is not None and int(team_id) != ptid: raise ValueError('Solo puedes gestionar tu propio equipo')
    return season, ptid


def overview(db, team_id=None):
    season = repo.current_season(db)
    team_id = int(team_id) if team_id else player_team_id(db, season['id'])
    t = next((x for x in season_teams(db, season['id']) if x['team_id'] == team_id), None)
    if not t: raise LookupError('Equipo no encontrado')
    ai = db.one('SELECT * FROM team_ai WHERE team_id = ?', (team_id,))
    notes = jload(ai['notes_json'], {}) if ai else {}
    cm = config.load('car_model')
    base = repo.car(db, season['id'], team_id)
    now = development.team_car_now(db, season['id'], team_id)
    rnd = db.one("SELECT * FROM calendar_rounds WHERE season_id = ? AND status != 'completed' ORDER BY round_no LIMIT 1", (season['id'],))
    field = []
    for x in season_teams(db, season['id']):
        if x['code'] != t['code']: continue
        car = development.team_car_now(db, season['id'], x['team_id'])
        field.append({'team_id': x['team_id'], 'name': x['name'], 'overall': overall_strength(car, cm),
                      'next_track': car_track_strength(car, repo.track_profile(db, rnd['track_profile_id']), cm) if rnd else None})
    field.sort(key=lambda f: -f['overall'])
    return {'team': {**t, 'color': db.value('SELECT color FROM teams WHERE id = ?', (team_id,))}, 'is_player_team': team_id == player_team_id(db, season['id']),
            'delegated': bool(repo.career(db)['settings'].get('delegate_team_management')), 'ai': ai and {k: ai[k] for k in ('risk_tolerance', 'strategy', 'next_season_share')},
            'objective': notes.get('objective'), 'base_car': base, 'current_car': now, 'field': field, 'season': season,
            'finance': finance.summary(db, season['id'], team_id), 'cost_cap_headroom': finance.cost_cap_headroom(db, season['id'], team_id),
            'development': development.overview(db, season['id'], team_id), 'components': components.overview(db, season['id'], team_id),
            'regulations': regulations.current(db, season['id']), 'facility_costs': config.load('development')['facilities']}
