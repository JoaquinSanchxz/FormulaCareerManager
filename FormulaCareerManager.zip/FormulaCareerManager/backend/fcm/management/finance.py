"""FinanceService: per-team ledger (every operation is a transaction), sponsors, prize money, cost cap.
cash is a materialised balance; the transactions table is the source of truth."""
from fcm.career_engine import championship as champ, newsroom, repo
from fcm.database.db import jload, now_ts
from fcm.management.common import rounds_in_championship, season_teams, team_drivers, tier_key
from fcm.shared import config
from fcm.shared.rng import rng_for


def cost_cap_cfg(db, season_id, team_id):
    t = db.one('SELECT c.tier, c.id category_id FROM teams tm JOIN categories c ON c.id = tm.category_id WHERE tm.id = ?', (team_id,))
    cc = dict(config.load('finance')['cost_cap'].get(tier_key(t['tier']), {'enabled': False}))
    reg = db.one('SELECT data_json FROM regulations WHERE season_id = ? AND category_id = ?', (season_id, t['category_id']))
    over = jload(reg['data_json'], {}).get('cost_cap_override') if reg else None
    if over is not None: cc.update({'enabled': True, 'value': over})
    return cc


def tx(db, season_id, round_id, team_id, type_, amount, description, reference=None):
    """Record a transaction and update the team's balance (+ cost cap spending when applicable)."""
    cc = cost_cap_cfg(db, season_id, team_id)
    counts = amount < 0 and cc.get('enabled') and type_ not in cc.get('excluded', [])
    db.insert('transactions', {'season_id': season_id, 'round_id': round_id, 'team_id': team_id, 'type': type_, 'amount': round(amount, 4),
                               'cost_cap': int(bool(counts)), 'description': description, 'reference': reference, 'create_ts': now_ts()})
    db.execute('UPDATE team_finances SET cash = cash + ?, cost_cap_spent = cost_cap_spent + ?, '
               'sponsor_income = sponsor_income + ?, prize_income = prize_income + ?, update_ts = ? WHERE season_id = ? AND team_id = ?',
               (amount, -amount if counts else 0, amount if type_ == 'sponsor' else 0, amount if type_ == 'prize' else 0, now_ts(), season_id, team_id))


def row(db, season_id, team_id):
    return db.one('SELECT * FROM team_finances WHERE season_id = ? AND team_id = ?', (season_id, team_id))


def can_afford(db, season_id, team_id, amount, cost_cap=True):
    f = row(db, season_id, team_id)
    if not f: return True, None
    tier = db.value('SELECT c.tier FROM teams t JOIN categories c ON c.id = t.category_id WHERE t.id = ?', (team_id,))
    reserve = config.load('finance')['minimum_cash_reserve'].get(tier_key(tier), 0)
    if f['cash'] - amount < reserve: return False, 'No hay dinero suficiente en caja'
    cc = cost_cap_cfg(db, season_id, team_id)
    if cost_cap and cc.get('enabled') and f['cost_cap_spent'] + amount > cc['value']:
        return False, 'Se superaría el límite de gasto de la temporada'
    return True, None


def init_season(db, season_id, year, seed):
    """Budgets, starting cash (carried over), sponsors with objectives."""
    fc = config.load('finance')
    prev = db.one('SELECT id FROM seasons WHERE year = ?', (year - 1,))
    teams = season_teams(db, season_id)
    cm = config.load('car_model')
    from fcm.simulation.model import overall_strength
    for code in {t['code'] for t in teams}:
        group = [t for t in teams if t['code'] == code]
        ranked = sorted(group, key=lambda t: -overall_strength(repo.car(db, season_id, t['team_id']), cm))
        for rank, t in enumerate(ranked, start=1):
            if row(db, season_id, t['team_id']): continue
            b = fc['budget_by_tier'][tier_key(t['tier'])]
            from fcm.management.common import difficulty_mult
            budget = round((b['base'] + b['per_reputation'] * t['reputation']) * difficulty_mult(db, 'economy', t['team_id'], season_id), 2)
            old = row(db, prev['id'], t['team_id']) if prev else None
            cash = old['cash'] if old else round(budget * fc['starting_cash_share'], 2)
            db.insert('team_finances', {'season_id': season_id, 'team_id': t['team_id'], 'cash': cash, 'season_budget': budget, 'update_ts': now_ts()})
            tx(db, season_id, None, t['team_id'], 'owner_funding', round(budget * (1 - fc['sponsor_share_of_budget']), 3), f'{year} aportación de accionistas / fabricante')
            rng = rng_for(seed, 'sponsors', year, t['team_id'])
            names = rng.sample(fc['sponsor_names'], 2)
            sponsor_total = budget * fc['sponsor_share_of_budget']
            for i, name in enumerate(names):
                share = 0.65 if i == 0 else 0.35
                db.insert('sponsors', {'season_id': season_id, 'team_id': t['team_id'], 'name': name, 'base_payment': round(sponsor_total * share * 0.85, 3),
                                       'race_bonus': round(sponsor_total * share * 0.15 / 10, 3), 'race_objective': max(1, min(len(group) * 2, rank * 2 + 2)),
                                       'season_bonus': round(sponsor_total * share * 0.1, 3), 'season_objective': rank,
                                       'reputation_requirement': max(0, t['reputation'] - 30), 'status': 'active'})


def round_tick(db, rnd):
    """Per-round income/costs: sponsor payments + objective bonuses, operating, staff, facilities, salaries."""
    fc = config.load('finance')
    season_id = rnd['season_id']
    for t in season_teams(db, season_id):
        if not row(db, season_id, t['team_id']): continue
        tk = tier_key(t['tier'])
        n_rounds = rounds_in_championship(db, t['championship_id'])
        raced = db.value('SELECT 1 FROM sessions WHERE round_id = ? AND championship_id = ?', (rnd['id'], t['championship_id']))
        if not raced: continue
        best = db.value("SELECT MIN(r.position) FROM results r JOIN sessions s ON s.id = r.session_id WHERE s.round_id = ? AND s.type = 'race' AND r.team_id = ? AND r.status = 'FIN'",
                        (rnd['id'], t['team_id']))
        for sp in db.all("SELECT * FROM sponsors WHERE season_id = ? AND team_id = ? AND status = 'active'", (season_id, t['team_id'])):
            tx(db, season_id, rnd['id'], t['team_id'], 'sponsor', round(sp['base_payment'] / n_rounds, 4), f"{sp['name']} pago base", f"sponsor:{sp['id']}")
            if best and sp['race_objective'] and best <= sp['race_objective'] and sp['race_bonus']:
                tx(db, season_id, rnd['id'], t['team_id'], 'sponsor', sp['race_bonus'], f"{sp['name']} objetivo de carrera (P{sp['race_objective']}) cumplido", f"sponsor:{sp['id']}")
        tx(db, season_id, rnd['id'], t['team_id'], 'operating', -fc['operating_cost_per_round'][tk], f"Costes operativos R{rnd['round_no']}")
        tx(db, season_id, rnd['id'], t['team_id'], 'staff', -fc['staff_cost_per_round'][tk], f"Costes de personal R{rnd['round_no']}")
        levels = db.value('SELECT SUM(level) FROM facilities WHERE team_id = ?', (t['team_id'],)) or 0
        if levels: tx(db, season_id, rnd['id'], t['team_id'], 'facility_upkeep', -round(levels * fc['facility_upkeep_per_level_round'][tk], 4), 'Mantenimiento de instalaciones')
        for d in team_drivers(db, season_id, t['team_id'], ('D1', 'D2', 'D3', 'reserve')):
            c = db.one("SELECT salary FROM contracts WHERE driver_id = ? AND team_id = ? AND status = 'active' ORDER BY id DESC LIMIT 1", (d['driver_id'], t['team_id']))
            if c and c['salary']:
                tx(db, season_id, rnd['id'], t['team_id'], 'driver_salary', -round(c['salary'] / n_rounds, 4), f"Salario {d['first_name']} {d['last_name']}", f"driver:{d['driver_id']}")
        _sponsor_challenge(db, rnd, t, best)


def _sponsor_challenge(db, rnd, t, best):
    ai = db.one('SELECT notes_json FROM team_ai WHERE team_id = ?', (t['team_id'],))
    notes = jload(ai['notes_json'], {}) if ai else {}
    ch = notes.get('sponsor_challenge')
    if not ch or ch.get('round_no') != rnd['round_no']: return
    if best and best <= ch['position']:
        tx(db, rnd['season_id'], rnd['id'], t['team_id'], 'sponsor', ch['bonus'], f"Reto de patrocinador cumplido (top {ch['position']})")
        newsroom.sponsor(db, t['team_id'], rnd['season_id'], rnd['id'])
    notes.pop('sponsor_challenge')
    from fcm.database.db import jdump
    db.update('team_ai', t['team_id'], {'notes_json': jdump(notes)}, key='team_id')


def damage_cost(db, season_id, round_id, team_id, part, severity, label):
    fc = config.load('finance')
    tier = db.value('SELECT c.tier FROM teams t JOIN categories c ON c.id = t.category_id WHERE t.id = ?', (team_id,))
    cost = round(fc['damage_costs'].get(part, {}).get(tier_key(tier), 0.1) * severity, 4)
    if cost and row(db, season_id, team_id): tx(db, season_id, round_id, team_id, 'damage', -cost, f'Reparación de daños: {part} ({label})')
    return cost


def season_end(db, season):
    """Prize money, sponsor season objectives, cost-cap breaches."""
    fc = config.load('finance')
    for ch in repo.championships(db, season['id']):
        pool = fc['prize_pool_by_position'].get(tier_key(ch['tier']), [])
        for t in champ.constructor_standings(db, ch['id']):
            if not row(db, season['id'], t['team_id']): continue
            if t['position'] <= len(pool): tx(db, season['id'], None, t['team_id'], 'prize', pool[t['position'] - 1], f"Premios {season['year']} (P{t['position']})")
            for sp in db.all("SELECT * FROM sponsors WHERE season_id = ? AND team_id = ? AND status = 'active'", (season['id'], t['team_id'])):
                if sp['season_objective'] and t['position'] <= sp['season_objective'] and sp['season_bonus']:
                    tx(db, season['id'], None, t['team_id'], 'sponsor', sp['season_bonus'], f"{sp['name']} objetivo de temporada (P{sp['season_objective']}) cumplido")
            f = row(db, season['id'], t['team_id'])
            cc = cost_cap_cfg(db, season['id'], t['team_id'])
            if cc.get('enabled') and f['cost_cap_spent'] > cc['value']:
                over = f['cost_cap_spent'] - cc['value']
                tx(db, season['id'], None, t['team_id'], 'fine', -round(over * fc['cost_cap_breach']['fine_per_million'], 3), f'Multa por superar el cost cap ({over:.2f}M de exceso)')
                from fcm.database.db import jdump
                ai = db.one('SELECT notes_json FROM team_ai WHERE team_id = ?', (t['team_id'],))
                notes = jload(ai['notes_json'], {}) if ai else {}
                notes['dev_penalty_year'] = season['year'] + 1
                db.update('team_ai', t['team_id'], {'notes_json': jdump(notes)}, key='team_id')
                ev = repo.emit(db, 'COST_CAP_BREACH', {'team_id': t['team_id'], 'over': round(over, 3)}, season_id=season['id'])
                newsroom.cost_cap(db, t['team_id'], over, fc['cost_cap_breach']['next_season_dev_penalty_pct'], season['id'], ev)


def cost_cap_headroom(db, season_id, team_id):
    """Cap minus spent minus projected fixed costs for the remaining rounds (AI planning). None = no cap."""
    cc = cost_cap_cfg(db, season_id, team_id)
    f = row(db, season_id, team_id)
    if not cc.get('enabled') or not f: return None
    fc = config.load('finance')
    t = db.one('SELECT c.tier, ch.id championship_id FROM teams tm JOIN categories c ON c.id = tm.category_id JOIN championships ch ON ch.category_id = c.id AND ch.season_id = ? WHERE tm.id = ?',
               (season_id, team_id))
    from fcm.management.common import completed_rounds
    left = rounds_in_championship(db, t['championship_id']) - completed_rounds(db, t['championship_id'])
    tk = tier_key(t['tier'])
    projected = left * (fc['operating_cost_per_round'][tk] + fc['staff_cost_per_round'][tk]) * 1.08
    return cc['value'] - f['cost_cap_spent'] - projected


def summary(db, season_id, team_id):
    f = row(db, season_id, team_id)
    return {'finance': f, 'cost_cap': cost_cap_cfg(db, season_id, team_id),
            'sponsors': db.all('SELECT * FROM sponsors WHERE season_id = ? AND team_id = ?', (season_id, team_id)),
            'by_type': db.all('SELECT type, SUM(amount) total, COUNT(*) n FROM transactions WHERE season_id = ? AND team_id = ? GROUP BY type ORDER BY total', (season_id, team_id)),
            'ledger': db.all('SELECT t.*, cr.round_no FROM transactions t LEFT JOIN calendar_rounds cr ON cr.id = t.round_id WHERE t.season_id = ? AND t.team_id = ? ORDER BY t.id DESC LIMIT 400', (season_id, team_id))}
