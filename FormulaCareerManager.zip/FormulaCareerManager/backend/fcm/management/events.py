"""Event engine: data-driven events (events.json) with conditions, probability, cooldown, choices, effects.
Player-team events wait for a decision; AI teams resolve automatically. Events never punish without context."""
from fcm.career_engine import newsroom, repo
from fcm.database.db import jdump, jload, now_ts
from fcm.management import finance
from fcm.management.common import player_team_id, realism, season_teams, team_drivers
from fcm.shared import config
from fcm.shared.rng import rng_for


def _defs():
    return config.load('events')


def _last_round_for(db, key, team_id):
    return db.value('SELECT MAX(cr.round_no) FROM game_events g JOIN calendar_rounds cr ON cr.id = g.round_id WHERE g.event_key = ? AND g.team_id = ? AND g.season_id = cr.season_id',
                    (key, team_id))


def roll(db, rnd):
    if not realism(db, 'random_events', False): return []
    cfg = _defs()
    seed = repo.career(db)['seed']
    ptid = player_team_id(db, rnd['season_id'])
    created = []
    for t in season_teams(db, rnd['season_id']):
        is_player = t['team_id'] == ptid
        if is_player:
            pending = db.value("SELECT COUNT(*) FROM game_events WHERE team_id = ? AND status = 'pending'", (t['team_id'],))
            last_any = db.value('SELECT MAX(cr.round_no) FROM game_events g JOIN calendar_rounds cr ON cr.id = g.round_id WHERE g.team_id = ? AND cr.season_id = ?', (t['team_id'], rnd['season_id']))
            if pending >= cfg['max_pending_player'] or (last_any and rnd['round_no'] - last_any < cfg['global_cooldown_rounds']): continue
        rng = rng_for(seed, 'events', rnd['season_id'], rnd['round_no'], t['team_id'])
        for ev in cfg['events']:
            if ev['requires'] == 'player_team' and not is_player: continue
            project = None
            if ev['requires'] == 'project_in_design':
                project = db.one("SELECT * FROM development_projects WHERE team_id = ? AND status = 'design' ORDER BY rounds_left DESC LIMIT 1", (t['team_id'],))
                if not project: continue
            last = _last_round_for(db, ev['key'], t['team_id'])
            if last and rnd['round_no'] - last < ev['cooldown']: continue
            if rng.random() >= ev['probability']: continue
            params = {k: rng.randint(*v) for k, v in ev.get('params', {}).items()}
            if project: params['part'] = newsroom.part_name(project['part'], '')
            body = ev['body'].format(**params) if params else ev['body']
            eid = db.insert('game_events', {'event_key': ev['key'], 'type': ev['type'], 'season_id': rnd['season_id'], 'round_id': rnd['id'], 'team_id': t['team_id'],
                                            'project_id': project['id'] if project else None, 'title': ev['title'], 'body': body,
                                            'choices_json': jdump([{'label': ch['label'], 'effects': ch['effects']} for ch in ev['choices']]),
                                            'status': 'pending', 'result_json': jdump({'params': params}), 'create_ts': now_ts()})
            created.append(eid)
            if not is_player: resolve(db, eid, ev.get('ai_choice', [0])[0], auto=True)
            else: repo.emit(db, 'EVENT_RAISED', {'event_id': eid, 'key': ev['key']}, season_id=rnd['season_id'], round_id=rnd['id'])
            break
    return created


def expire_pending(db, rnd):
    """Player events not answered before the next round are resolved with the team's default choice."""
    cfg = {e['key']: e for e in _defs()['events']}
    for g in db.all("SELECT g.*, cr.round_no FROM game_events g JOIN calendar_rounds cr ON cr.id = g.round_id WHERE g.status = 'pending' AND cr.round_no < ? AND g.season_id = ?",
                    (rnd['round_no'], rnd['season_id'])):
        resolve(db, g['id'], cfg.get(g['event_key'], {}).get('ai_choice', [0])[0], auto=True)


def resolve(db, event_id, choice, auto=False):
    g = db.one('SELECT * FROM game_events WHERE id = ?', (event_id,))
    if not g or g['status'] != 'pending': raise ValueError('El evento ya está resuelto')
    choices = jload(g['choices_json'], [])
    if not 0 <= int(choice) < len(choices): raise ValueError('Opción no válida')
    applied = []
    params = jload(g['result_json'], {}).get('params', {})
    rnd_no = db.value('SELECT round_no FROM calendar_rounds WHERE id = ?', (g['round_id'],))
    for eff in choices[int(choice)]['effects']:
        applied.append(_apply(db, g, eff, params, rnd_no))
    db.update('game_events', event_id, {'status': 'auto' if auto else 'resolved', 'choice': int(choice), 'result_json': jdump({'params': params, 'applied': applied})})
    repo.emit(db, 'EVENT_RESOLVED', {'event_id': event_id, 'key': g['event_key'], 'choice': int(choice), 'auto': auto, 'applied': applied}, season_id=g['season_id'], round_id=g['round_id'])
    return {'ok': True, 'applied': applied}


def _apply(db, g, eff, params, rnd_no):
    t, sid, team = eff['type'], g['season_id'], g['team_id']
    if t == 'cash':
        tier = db.value('SELECT c.tier FROM teams tm JOIN categories c ON c.id = tm.category_id WHERE tm.id = ?', (team,)) or 1
        amount = round(eff['amount'] * config.load('development')['tier_cost_mult'][str(min(3, tier))], 4)
        if finance.row(db, sid, team): finance.tx(db, sid, g['round_id'], team, 'event' if eff.get('cost_cap') else 'event_excluded', amount, g['title'])
        return f"caja {amount:+}M"
    if t in ('project_delay', 'project_gain_mult', 'abandon_project') and g['project_id']:
        p = db.one('SELECT * FROM development_projects WHERE id = ?', (g['project_id'],))
        if not p or p['status'] != 'design': return 'el proyecto ya no está en diseño'
        if t == 'project_delay':
            db.update('development_projects', p['id'], {'rounds_left': p['rounds_left'] + eff['rounds']})
            return f"proyecto retrasado {eff['rounds']} ronda(s)"
        if t == 'project_gain_mult':
            db.update('development_projects', p['id'], {'gain_mult': round(p['gain_mult'] * eff['value'], 4)})
            return f"ganancia esperada x{eff['value']}"
        refund = round(p['cost'] * eff.get('refund', 0), 3)
        db.update('development_projects', p['id'], {'status': 'abandoned', 'rounds_left': 0, 'outcome': 'abandoned'})
        if refund and finance.row(db, sid, team): finance.tx(db, sid, g['round_id'], team, 'refund', refund, f"Proyecto de {newsroom.part_name(p['part'], '')} abandonado (reembolso)")
        return f'proyecto abandonado, reembolso {refund}M'
    if t == 'department_delay':
        db.execute("UPDATE development_projects SET rounds_left = rounds_left + ? WHERE team_id = ? AND department = ? AND status = 'design'", (eff['rounds'], team, eff['department']))
        return f"proyectos de {eff['department']} retrasados"
    if t == 'dev_efficiency':
        db.execute('UPDATE car_performance SET development_efficiency = MAX(40, development_efficiency + ?) WHERE season_id = ? AND team_id = ?', (eff['value'], sid, team))
        return f"eficiencia de desarrollo {eff['value']:+}"
    if t in ('morale', 'reputation'):
        col = 'morale' if t == 'morale' else 'reputation'
        pid = repo.career(db)['player_driver_id']
        ids = [pid] if team == player_team_id(db, sid) else [d['driver_id'] for d in team_drivers(db, sid, team)]
        for i in ids: db.execute(f'UPDATE drivers SET {col} = MIN(100, MAX(1, {col} + ?)) WHERE id = ?', (eff['value'], i))
        return f"{col} {eff['value']:+}"
    if t == 'sponsor_challenge':
        ai = db.one('SELECT notes_json FROM team_ai WHERE team_id = ?', (team,))
        notes = jload(ai['notes_json'], {}) if ai else {}
        notes['sponsor_challenge'] = {'round_no': (rnd_no or 0) + 1, 'position': params.get('position', 10), 'bonus': eff['bonus']}
        db.update('team_ai', team, {'notes_json': jdump(notes)}, key='team_id')
        return f"reto: top {params.get('position')} en la próxima ronda por {eff['bonus']}M"
    return 'sin efecto'


def inbox(db):
    season = repo.current_season(db)
    tid = player_team_id(db, season['id'])
    rows = db.all('SELECT g.*, cr.round_no, cr.event_name FROM game_events g LEFT JOIN calendar_rounds cr ON cr.id = g.round_id WHERE g.team_id = ? ORDER BY g.id DESC LIMIT 60', (tid,))
    for r in rows:
        r['choices'] = jload(r.pop('choices_json'), [])
        r['result'] = jload(r.pop('result_json'), {})
    return rows
