"""MarketService: salaries, reputation, super licence, AI offers to the player, negotiations,
academies, reserves, injuries and the season-end driver market (renewals, promotions, rookies).
Every AI decision stores its inputs (candidate scores) in domain_events for transparency."""
import json

from fcm.career_engine import championship as champ, newsroom, repo
from fcm.database.db import jdump, jload, now_ts
from fcm.management import finance
from fcm.management.common import completed_rounds, realism, rounds_in_championship, season_teams, team_drivers, tier_key
from fcm.shared import config
from fcm.shared.rng import rng_for
from fcm.simulation.model import clamp, overall_strength

MIN_BASE = {1: 76.0, 2: 66.0, 3: 0.0}


def cfg():
    return config.load('market')


def salary_for(tier, base_rating, reputation):
    s = cfg()['salary_by_tier'][tier_key(tier)]
    v = s['base'] + max(0.0, base_rating - s['pivot']) * s['per_point_above']
    v *= 1 + cfg()['reputation_salary_weight'] * (reputation - 50) / 50
    return round(clamp(v, s['base'] * 0.5, s['max']), 3)


def _driver(db, driver_id, year):
    d = db.one('SELECT d.*, a.base_rating FROM drivers d JOIN driver_attributes a ON a.driver_id = d.id WHERE d.id = ?', (driver_id,))
    d['age'] = repo.age_in(d['birth_date'], year)
    return d


def academy_team(db, driver_id):
    return db.value('SELECT a.team_id FROM academy_members m JOIN academies a ON a.id = m.academy_id WHERE m.driver_id = ? AND m.active = 1', (driver_id,))


def candidate_score(db, d, tier, standings_pos, team_id=None):
    youth = max(0.0, (25 - d['age']) / 6)
    score = d['base_rating'] + (d['potential'] - d['base_rating']) * 0.35 * youth + d['reputation'] * 0.03
    if 'form' in d: score += d['form'] * cfg()['form_weight']
    if d.get('progress_json'): score += jload(d['progress_json'], {}).get('trend', 0.0) * cfg()['streak_weight']
    d_tier = d.get('tier', 9)
    if standings_pos:
        if d_tier > tier: score += {1: 2.5, 2: 1.5, 3: 1.0}.get(standings_pos, 0.0)
        elif d_tier == tier: score += max(0.0, (10 - standings_pos) * 0.08)
    if team_id and realism(db, 'academies', False) and academy_team(db, d['id']) == team_id: score += cfg()['academy_bonus']
    return round(score, 3)


# ------------------------------------------------------------------------------------------
# Super licence
# ------------------------------------------------------------------------------------------
def super_license_points(db, driver_id, year):
    sl = cfg()['super_license']
    total = 0
    for s in db.all("SELECT * FROM seasons WHERE status = 'finished' AND year >= ? AND year < ?", (year - sl['window_seasons'], year)):
        for ch in repo.championships(db, s['id']):
            table = sl['points'].get(ch['category_code'], [])
            for row in champ.driver_standings(db, ch['id']):
                if row['driver_id'] == driver_id and row['position'] <= len(table): total += table[row['position'] - 1]
    return total


def has_super_license(db, driver_id, year):
    sl = cfg()['super_license']
    if not sl['enabled'] or not realism(db, 'super_license', True): return True
    if db.value("SELECT 1 FROM results r JOIN sessions s ON s.id = r.session_id JOIN championships ch ON ch.id = s.championship_id JOIN categories c ON c.id = ch.category_id "
                "WHERE r.driver_id = ? AND c.tier = 1 AND s.type = 'race' LIMIT 1", (driver_id,)): return True
    return super_license_points(db, driver_id, year) >= sl['required_points']


# ------------------------------------------------------------------------------------------
# Reputation (separate from rating; consistent drivers in small teams can gain it)
# ------------------------------------------------------------------------------------------
def update_reputation(db, driver_id, score, conf, round_id):
    rc = cfg()['reputation']
    d = db.one('SELECT d.reputation, a.base_rating FROM drivers d JOIN driver_attributes a ON a.driver_id = d.id WHERE d.id = ?', (driver_id,))
    best = db.value("SELECT MIN(r.position) FROM results r JOIN sessions s ON s.id = r.session_id WHERE s.round_id = ? AND r.driver_id = ? AND s.type = 'race' AND r.status = 'FIN'",
                    (round_id, driver_id))
    target = clamp((d['base_rating'] - 55) * 2.2, 5, 95)
    rep = d['reputation'] + rc['gain'] * score * conf + (rc['win_bonus'] if best == 1 else rc['podium_bonus'] if best and best <= 3 else 0) + (target - d['reputation']) * rc['reversion']
    db.update('drivers', driver_id, {'reputation': round(clamp(rep, rc['min'], rc['max']), 2)})


# ------------------------------------------------------------------------------------------
# Offers & negotiation (player)
# ------------------------------------------------------------------------------------------
def _player(db):
    return repo.career(db)['player_driver_id']


def _player_context(db, season):
    pid = _player(db)
    d = _driver(db, pid, season['year'] + 1)
    entry = db.one('SELECT e.*, ch.id championship_id, c.tier, c.code FROM championship_entries e JOIN championships ch ON ch.id = e.championship_id JOIN categories c ON c.id = ch.category_id '
                   'WHERE ch.season_id = ? AND e.driver_id = ? AND e.active = 1', (season['id'], pid))
    pos = None
    if entry:
        st = champ.driver_standings(db, entry['championship_id'])
        pos = next((r['position'] for r in st if r['driver_id'] == pid), None)
    contract = db.one("SELECT * FROM contracts WHERE driver_id = ? AND status = 'active' ORDER BY end_season DESC LIMIT 1", (pid,))
    d['tier'] = entry['tier'] if entry else 9
    return d, entry, pos, contract


def team_interest(db, season, team, d, pos):
    """How much better the player is than the driver the team could replace (expiring first)."""
    year = season['year']
    mates = team_drivers(db, season['id'], team['team_id'])
    mates = [m for m in mates if m['driver_id'] != d['id']]
    scored = []
    for m in mates:
        md = _driver(db, m['driver_id'], year + 1)
        md['tier'] = team['tier']
        c = db.one("SELECT end_season, release_clause FROM contracts WHERE driver_id = ? AND team_id = ? AND status = 'active' ORDER BY id DESC LIMIT 1", (m['driver_id'], team['team_id']))
        expiring = not c or c['end_season'] <= year
        scored.append({'driver_id': m['driver_id'], 'score': candidate_score(db, md, team['tier'], None, team['team_id']) + (cfg()['retention_bonus'] if not expiring else 0),
                       'expiring': expiring})
    my = candidate_score(db, d, team['tier'], pos, team['team_id'])
    if d['id'] == _player(db): my += {'easy': 1.0, 'normal': 0.0, 'hard': -1.0}.get(repo.career(db)['difficulty'].get('career', 'normal'), 0.0)
    if not scored: return my - 70, None, my, None
    weakest = min(scored, key=lambda x: (not x['expiring'], x['score']))
    other = next((x for x in scored if x is not weakest), None)
    return round(my - weakest['score'] - (0 if weakest['expiring'] else 2.0), 3), weakest, my, other


def maybe_generate_offers(db, rnd, force_window=None):
    if not realism(db, 'driver_market') or not realism(db, 'contracts'): return []
    season = db.one('SELECT * FROM seasons WHERE id = ?', (rnd['season_id'],)) if rnd else repo.current_season(db)
    d, entry, pos, contract = _player_context(db, season)
    if not entry: return []
    done, total = completed_rounds(db, entry['championship_id']), rounds_in_championship(db, entry['championship_id'])
    from fcm.management import transfers
    sr = transfers.summer_round(db, season['id'])
    mid_at = max(1, (db.value('SELECT COUNT(DISTINCT s.round_id) FROM sessions s JOIN calendar_rounds cr ON cr.id = s.round_id WHERE s.championship_id = ? AND cr.round_no <= ?',
                              (entry['championship_id'], sr['round_no'])) if sr else round(total * cfg()['offers_round_fraction'])) - cfg()['offer_windows']['mid_rounds_before_break'])
    window = force_window or ('mid' if done == mid_at else 'end' if done == total else None)
    if not window: return []
    if db.value("SELECT 1 FROM offers WHERE season_id = ? AND origin = 'ai' AND reason_json LIKE ?", (season['id'], f'%"window": "{window}"%')): return []
    out = []
    teams = [t for t in season_teams(db, season['id']) if t['tier'] in (entry['tier'], entry['tier'] - 1)]
    for t in teams:
        if t['tier'] == 1 and not has_super_license(db, d['id'], season['year'] + 1): continue
        own = t['team_id'] == entry['team_id']
        if own and contract and contract['end_season'] > season['year']: continue
        interest, weakest, my, other = team_interest(db, season, t, d, pos)
        if interest < (-1.0 if own else cfg()['offer_interest_threshold']): continue
        if not own and contract and contract['end_season'] > season['year'] and interest < 2: continue  # would have to pay the release clause
        role = 'D1' if other is None or my > other['score'] + cfg()['negotiation']['role_d1_margin'] else 'D2'
        sal = round(salary_for(t['tier'], d['base_rating'], d['reputation']) * (1 + 0.08 * max(0.0, interest)), 3)
        ok, _ = finance.can_afford(db, season['id'], t['team_id'], sal, cost_cap=False)
        if not ok: continue
        out.append((interest + (0.5 if own else 0), t, role, sal))
    out.sort(key=lambda x: -x[0])
    made = []
    for interest, t, role, sal in out[:cfg()['max_ai_offers']]:
        years = 1 if d['age'] > 32 else 2 if interest < 2 else 3
        oid = db.insert('offers', {'season_id': season['id'], 'driver_id': d['id'], 'team_id': t['team_id'], 'category_code': t['code'], 'role': role, 'salary': sal,
                                   'years': years, 'bonus_per_win': round(sal * 0.05, 3), 'release_clause': round(max(sal * 2, (d.get('market_value') or 0) * 0.6), 3),
                                   'origin': 'ai', 'status': 'open', 'effective': 'summer' if window == 'mid' else 'season_end',
                                   'reason_json': jdump({'window': window, 'interest': interest}), 'create_ts': now_ts()})
        made.append(oid)
        repo.emit(db, 'OFFER_RECEIVED', {'offer_id': oid, 'team_id': t['team_id'], 'interest': interest, 'role': role, 'salary': sal}, season_id=season['id'])
    if made: newsroom.offers(db, len(made), season['id'], rnd['id'] if rnd else None)
    return made


def negotiate(db, team_id, role, salary, years, bonus_per_win=0.0, release_clause=None):
    """Player proposal to a team for next season. Deterministic evaluation with explicit reasons."""
    season = repo.current_season(db)
    nc = cfg()['negotiation']
    d, entry, pos, contract = _player_context(db, season)
    team = next((t for t in season_teams(db, season['id']) if t['team_id'] == team_id), None)
    if not team: raise ValueError('Equipo no encontrado esta temporada')
    reasons = []
    recent = db.value("SELECT COUNT(*) FROM offers WHERE season_id = ? AND team_id = ? AND origin = 'player' AND status = 'rejected'", (season['id'], team_id))
    if recent >= 2: return _answer(db, season, team, d, role, salary, years, 'rejected', ['El equipo no quiere reabrir negociaciones esta temporada'], None)
    if team['tier'] == 1 and not has_super_license(db, d['id'], season['year'] + 1):
        return _answer(db, season, team, d, role, salary, years, 'rejected', ['Todavía no tienes la superlicencia: necesitas mejores resultados en las categorías inferiores'], None)
    interest, weakest, my, other = team_interest(db, season, team, d, pos)
    reasons.append('El equipo te sigue muy de cerca' if interest > 1.5 else 'El equipo está interesado en ti' if interest > 0.3 else 'El equipo tiene dudas contigo' if interest > -0.5 else 'El equipo no está convencido')
    own = entry and entry['team_id'] == team_id
    if interest < (-1.0 if own else 0):
        reasons.append('Prefieren mantener a sus pilotos actuales')
        return _answer(db, season, team, d, role, salary, years, 'rejected', reasons, None)
    value = salary_for(team['tier'], d['base_rating'], d['reputation']) * (1 + 0.08 * max(0.0, interest))
    max_sal = value * (1 + nc['salary_flex'])
    counter = {}
    if role == 'D1' and other is not None and my < other['score'] + nc['role_d1_margin']:
        counter['role'] = 'D2'
        reasons.append('No te ven todavía como primer piloto por delante de tu compañero')
    if salary > max_sal:
        counter['salary'] = round(max_sal * 0.97, 3)
        reasons.append('Pides más dinero del que están dispuestos a pagar')
    if years > nc['years_max'] or (d['age'] > 33 and years > 1):
        counter['years'] = 1 if d['age'] > 33 else nc['years_max']
        reasons.append('No les convence la duración del contrato')
    ok, why = finance.can_afford(db, season['id'], team_id, min(salary, max_sal), cost_cap=False)
    if not ok:
        reasons.append(why)
        return _answer(db, season, team, d, role, salary, years, 'rejected', reasons, None)
    buyout = None
    if contract and contract['end_season'] > season['year'] and not own:
        buyout = contract['release_clause'] or 0
        if interest < 2 or not finance.can_afford(db, season['id'], team_id, buyout + salary, cost_cap=False)[0]:
            reasons.append(f"Tienes contrato hasta {contract['end_season']} y no quieren pagar tu cláusula de rescisión")
            return _answer(db, season, team, d, role, salary, years, 'rejected', reasons, None)
        reasons.append('Están dispuestos a pagar tu cláusula de rescisión')
    if counter:
        return _answer(db, season, team, d, counter.get('role', role), counter.get('salary', salary), counter.get('years', years), 'countered', reasons, buyout, bonus_per_win)
    reasons.append('¡Hay acuerdo!')
    oid = _answer(db, season, team, d, role, salary, years, 'open', reasons, buyout, bonus_per_win, release_clause)['offer_id']
    accept_offer(db, oid)
    return {'status': 'accepted', 'offer_id': oid, 'reasons': reasons}


def _answer(db, season, team, d, role, salary, years, status, reasons, buyout, bonus=0.0, release=None):
    oid = db.insert('offers', {'season_id': season['id'], 'driver_id': d['id'], 'team_id': team['team_id'], 'category_code': team['code'], 'role': role,
                               'salary': round(salary, 3), 'years': int(years), 'bonus_per_win': round(bonus or 0, 3), 'release_clause': release or round(salary * 2, 3),
                               'origin': 'player', 'status': 'open' if status == 'countered' else status,
                               'reason_json': jdump({'reasons': reasons, 'buyout': buyout, 'countered': status == 'countered'}), 'create_ts': now_ts()})
    if status == 'rejected':
        db.execute('UPDATE drivers SET morale = MAX(5, morale + ?) WHERE id = ?', (cfg()['negotiation']['morale_on_reject'], d['id']))
    repo.emit(db, 'NEGOTIATION', {'team_id': team['team_id'], 'status': status, 'reasons': reasons, 'role': role, 'salary': salary, 'years': years}, season_id=season['id'])
    return {'status': status, 'offer_id': oid, 'reasons': reasons, 'counter': {'role': role, 'salary': round(salary, 3), 'years': years} if status == 'countered' else None}


def accept_offer(db, offer_id):
    season = repo.current_season(db)
    o = db.one('SELECT * FROM offers WHERE id = ?', (offer_id,))
    if not o or o['status'] != 'open': raise ValueError('Oferta no disponible')
    year = season['year']
    pid = o['driver_id']
    reason = jload(o['reason_json'], {})
    cur = db.one("SELECT * FROM contracts WHERE driver_id = ? AND status = 'active' ORDER BY end_season DESC LIMIT 1", (pid,))
    from fcm.management import transfers
    summer = transfers.before_summer_break(db, season['id']) and not (cur and cur['team_id'] == o['team_id'])
    with db.transaction():
        if summer:
            buyout = reason.get('buyout') or (cur['release_clause'] if cur and cur['end_season'] > year else 0) or 0
            if buyout and cur:
                finance.tx(db, season['id'], None, o['team_id'], 'transfer', -buyout, 'Pago de cláusula de rescisión por nuevo piloto', f'driver:{pid}')
                if finance.row(db, season['id'], cur['team_id']): finance.tx(db, season['id'], None, cur['team_id'], 'transfer', buyout, 'Cláusula de rescisión cobrada', f'driver:{pid}')
            db.insert('contracts', {'driver_id': pid, 'team_id': o['team_id'], 'start_season': year, 'end_season': year + o['years'], 'salary': o['salary'], 'role': o['role'],
                                    'bonuses_json': jdump({'per_win': o['bonus_per_win']}), 'release_clause': o['release_clause'], 'status': 'pending', 'effective': 'summer',
                                    'create_ts': now_ts()})
        elif cur and cur['team_id'] == o['team_id']:
            db.update('contracts', cur['id'], {'end_season': year + o['years'], 'salary': o['salary'], 'role': o['role'], 'release_clause': o['release_clause'],
                                              'bonuses_json': jdump({'per_win': o['bonus_per_win']})})
        else:
            if cur and cur['end_season'] > year:
                buyout = reason.get('buyout') or cur['release_clause'] or 0
                if buyout:
                    finance.tx(db, season['id'], None, o['team_id'], 'transfer', -buyout, 'Pago de cláusula de rescisión por nuevo piloto', f'driver:{pid}')
                    if finance.row(db, season['id'], cur['team_id']): finance.tx(db, season['id'], None, cur['team_id'], 'transfer', buyout, 'Cláusula de rescisión cobrada', f'driver:{pid}')
                db.update('contracts', cur['id'], {'end_season': year})
            db.insert('contracts', {'driver_id': pid, 'team_id': o['team_id'], 'start_season': year + 1, 'end_season': year + o['years'], 'salary': o['salary'], 'role': o['role'],
                                    'bonuses_json': jdump({'per_win': o['bonus_per_win']}), 'release_clause': o['release_clause'], 'status': 'active', 'create_ts': now_ts()})
        db.update('offers', offer_id, {'status': 'accepted'})
        db.execute("UPDATE offers SET status = 'expired' WHERE season_id = ? AND driver_id = ? AND status = 'open' AND id != ?", (season['id'], pid, offer_id))
        team = db.one('SELECT name FROM teams WHERE id = ?', (o['team_id'],))
        ev = repo.emit(db, 'CONTRACT_SIGNED', {'driver_id': pid, 'team_id': o['team_id'], 'role': o['role'], 'salary': o['salary'], 'years': o['years'], 'player': True}, season_id=season['id'])
        d = db.one('SELECT first_name, last_name FROM drivers WHERE id = ?', (pid,))
        newsroom.signing(db, pid, o['team_id'], o['role'], o['years'], 'tras el parón de verano' if summer else f'a partir de {year + 1}', season['id'], ev)
    return {'ok': True, 'effective': 'summer' if summer else 'season_end'}


def reject_offer(db, offer_id):
    db.execute("UPDATE offers SET status = 'rejected' WHERE id = ? AND status = 'open'", (offer_id,))
    return {'ok': True}


# ------------------------------------------------------------------------------------------
# Academies
# ------------------------------------------------------------------------------------------
def init_academies(db, season_id, year, seed_members=None):
    """One academy per F1 team; real junior-programme members (from the template) are enrolled first."""
    if db.value('SELECT COUNT(*) FROM academies'): return
    ids = {}
    for t in season_teams(db, season_id):
        if t['tier'] != 1: continue
        ids[t['name']] = db.insert('academies', {'team_id': t['team_id'], 'name': f"Academia {t['name']}", 'cost_per_season': cfg()['academy_cost_per_season']['1']})
    for team_name, members in (seed_members or {}).items():
        aid = ids.get(team_name) or next((v for k, v in ids.items() if team_name.lower() in k.lower() or k.lower() in team_name.lower()), None)
        for did in members:
            if aid and did and not db.value('SELECT 1 FROM academy_members WHERE driver_id = ? AND active = 1', (did,)):
                db.insert('academy_members', {'academy_id': aid, 'driver_id': did, 'since_year': year, 'active': 1})
    refresh_academies(db, season_id, year)


def refresh_academies(db, season_id, year):
    size = cfg()['academy_size']
    for m in db.all('SELECT m.id, d.birth_date, d.retired, m.driver_id FROM academy_members m JOIN drivers d ON d.id = m.driver_id WHERE m.active = 1'):
        in_f1 = db.value('SELECT 1 FROM championship_entries e JOIN championships ch ON ch.id = e.championship_id JOIN categories c ON c.id = ch.category_id '
                         'WHERE ch.season_id = ? AND e.driver_id = ? AND c.tier = 1', (season_id, m['driver_id']))
        if m['retired'] or repo.age_in(m['birth_date'], year) > 24 or in_f1: db.update('academy_members', m['id'], {'active': 0})
    pool = db.all('SELECT d.id, d.potential, d.birth_date, a.base_rating FROM drivers d JOIN driver_attributes a ON a.driver_id = d.id JOIN championship_entries e ON e.driver_id = d.id '
                  'JOIN championships ch ON ch.id = e.championship_id JOIN categories c ON c.id = ch.category_id WHERE ch.season_id = ? AND c.tier > 1 AND d.is_player = 0 '
                  'AND d.id NOT IN (SELECT driver_id FROM academy_members WHERE active = 1)', (season_id,))
    pool = [p for p in pool if repo.age_in(p['birth_date'], year) <= 22]
    pool.sort(key=lambda p: -p['potential'])
    academies = db.all('SELECT a.*, (SELECT COUNT(*) FROM academy_members m WHERE m.academy_id = a.id AND m.active = 1) n FROM academies a')
    academies.sort(key=lambda a: -(db.value('SELECT reputation FROM teams WHERE id = ?', (a['team_id'],)) or 0))
    while pool and any(a['n'] < size for a in academies):
        for a in academies:
            if a['n'] >= size or not pool: continue
            p = pool.pop(0)
            db.insert('academy_members', {'academy_id': a['id'], 'driver_id': p['id'], 'since_year': year, 'active': 1})
            a['n'] += 1
    for a in academies:
        if finance.row(db, season_id, a['team_id']): finance.tx(db, season_id, None, a['team_id'], 'academy', -a['cost_per_season'], f"{a['name']} costes de funcionamiento")


# ------------------------------------------------------------------------------------------
# Injuries (optional)
# ------------------------------------------------------------------------------------------
def maybe_injure(db, s, rows, rng):
    if not realism(db, 'injuries', False): return
    ic = cfg()['injuries']
    pid = _player(db)
    for r in rows:
        if r.get('dnf_reason') != 'incident' or r['driver_id'] == pid: continue
        if rng.random() >= ic['probability_on_incident']: continue
        entry = db.one('SELECT * FROM championship_entries WHERE championship_id = ? AND driver_id = ?', (s['championship_id'], r['driver_id']))
        if not entry or not entry['active']: continue
        rounds = rng.randint(*ic['rounds'])
        reserve = db.one("SELECT * FROM championship_entries WHERE championship_id = ? AND team_id = ? AND role = 'reserve'", (s['championship_id'], entry['team_id']))
        if reserve:
            rep_id = reserve['driver_id']
            db.update('championship_entries', reserve['id'], {'role': entry['role'], 'active': 1})
        else:
            from fcm.career_engine import world_builder
            rep_id = world_builder.generate_rookie(db, rng, db.value('SELECT year FROM seasons WHERE id = ?', (s['season_id'],)))
            used = {x['number'] for x in db.all('SELECT number FROM championship_entries WHERE championship_id = ?', (s['championship_id'],))}
            num = next(n for n in range(2, 100) if n not in used)
            db.insert('championship_entries', {'championship_id': s['championship_id'], 'driver_id': rep_id, 'team_id': entry['team_id'], 'number': num,
                                               'skin': entry['skin'], 'role': entry['role'], 'active': 1})
        db.update('championship_entries', entry['id'], {'active': 0})
        db.insert('injuries', {'driver_id': r['driver_id'], 'season_id': s['season_id'], 'rounds_left': rounds, 'replacement_id': rep_id,
                               'championship_id': s['championship_id'], 'reason': f"Accidente en {s['event_name']}", 'create_ts': now_ts()})
        d = db.one('SELECT first_name, last_name FROM drivers WHERE id = ?', (r['driver_id'],))
        rp = db.one('SELECT first_name, last_name FROM drivers WHERE id = ?', (rep_id,))
        ev = repo.emit(db, 'DRIVER_INJURED', {'driver_id': r['driver_id'], 'rounds': rounds, 'replacement_id': rep_id}, season_id=s['season_id'], round_id=s['round_id'])
        newsroom.injury(db, r['driver_id'], rounds, rep_id, s['season_id'], s['round_id'], ev)


def injuries_tick(db, rnd):
    for inj in db.all('SELECT * FROM injuries WHERE season_id = ? AND rounds_left > 0', (rnd['season_id'],)):
        left = inj['rounds_left'] - 1
        db.update('injuries', inj['id'], {'rounds_left': left})
        if left > 0: continue
        db.execute('UPDATE championship_entries SET active = 1 WHERE championship_id = ? AND driver_id = ?', (inj['championship_id'], inj['driver_id']))
        rep = db.one('SELECT * FROM championship_entries WHERE championship_id = ? AND driver_id = ?', (inj['championship_id'], inj['replacement_id']))
        if rep: db.update('championship_entries', rep['id'], {'role': 'reserve', 'active': 1})
        repo.emit(db, 'DRIVER_RECOVERED', {'driver_id': inj['driver_id']}, season_id=rnd['season_id'], round_id=rnd['id'])


# ------------------------------------------------------------------------------------------
# Season-end market
# ------------------------------------------------------------------------------------------
def run_season_market(db, c, season, new_year, old_champs, champ_by_code, final, rng):
    ts = now_ts()
    tier_of = {ch['category_code']: ch['tier'] for ch in old_champs}
    pos_in = {}
    for code, st in final.items():
        for row in st: pos_in[row['driver_id']] = (tier_of[code], row['position'])
    old_entries = {}
    for ch in old_champs:
        for e in db.all("SELECT e.* FROM championship_entries e WHERE e.championship_id = ? AND e.role IN ('D1', 'D2', 'D3', 'reserve')", (ch['id'],)):
            if e['role'] != 'reserve' or e['driver_id'] not in old_entries: old_entries[e['driver_id']] = (ch, e)
    player_id = c['player_driver_id']
    per_team = {ch['category_code']: repo.cars_per_team(db, ch['id']) for ch in old_champs}
    code_of_team = {e['team_id']: ch['category_code'] for ch, e in old_entries.values()}
    seats = {}
    placed = set()
    # 0. future contracts signed during the season (player moves, pre-agreements)
    for fc in db.all("SELECT * FROM contracts WHERE start_season = ? AND status = 'active'", (new_year,)):
        code = code_of_team.get(fc['team_id'])
        if not code or fc['driver_id'] in placed: continue
        seats.setdefault((code, fc['team_id']), []).append((fc['driver_id'], fc['role'], None))
        placed.add(fc['driver_id'])
    # 1. renewals / expiries for race drivers
    for did, (ch, e) in old_entries.items():
        if did in placed or e['role'] == 'reserve': continue
        d = db.one('SELECT d.*, a.base_rating FROM drivers d JOIN driver_attributes a ON a.driver_id = d.id WHERE d.id = ?', (did,))
        if d['retired']: continue
        key = (ch['category_code'], e['team_id'])
        contract = db.one("SELECT * FROM contracts WHERE driver_id = ? AND team_id = ? AND status = 'active' ORDER BY end_season DESC LIMIT 1", (did, e['team_id']))
        if contract and contract['end_season'] >= new_year:
            if len(seats.get(key, [])) < per_team[ch['category_code']]:
                seats.setdefault(key, []).append((did, e['role'], e['number']))
                placed.add(did)
            continue
        team_level = db.value("SELECT AVG(a.base_rating) FROM championship_entries ce JOIN driver_attributes a ON a.driver_id = ce.driver_id WHERE ce.championship_id = ? AND ce.role IN ('D1','D2','D3')", (ch['id'],))
        age = repo.age_in(d['birth_date'], new_year)
        keep = did == player_id or not realism(db, 'driver_market') or (d['base_rating'] >= (team_level or 0) - 2 + (1.5 if age > 33 else 0) and rng.random() < 0.85)
        if len(seats.get(key, [])) >= per_team[ch['category_code']]: keep = False
        if contract: db.update('contracts', contract['id'], {'status': 'expired'})
        repo.emit(db, 'CONTRACT_DECISION', {'driver_id': did, 'team_id': e['team_id'], 'base_rating': d['base_rating'], 'team_level': round(team_level or 0, 2), 'age': age, 'renewed': keep},
                  season_id=season['id'])
        if keep:
            sal = contract['salary'] if did == player_id and contract else salary_for(ch['tier'], d['base_rating'], d['reputation'])
            db.insert('contracts', {'driver_id': did, 'team_id': e['team_id'], 'start_season': new_year, 'end_season': new_year + rng.randint(0, 2), 'salary': sal,
                                    'role': e['role'], 'release_clause': round(sal * 2, 3), 'status': 'active', 'create_ts': ts})
            seats.setdefault(key, []).append((did, e['role'], e['number']))
            placed.add(did)
    # 2. fill vacancies: top tier first, strongest teams first
    cm = config.load('car_model')
    for ch in sorted(old_champs, key=lambda x: x['tier']):
        code, tier = ch['category_code'], ch['tier']
        teams = db.all('SELECT DISTINCT e.team_id, t.name FROM championship_entries e JOIN teams t ON t.id = e.team_id WHERE e.championship_id = ?', (ch['id'],))
        teams.sort(key=lambda t: -overall_strength(repo.car(db, season['id'], t['team_id']), cm))
        for t in teams:
            key = (code, t['team_id'])
            while len(seats.get(key, [])) < per_team[code]:
                chosen, pool = _pick(db, tier, new_year, placed, pos_in, t['team_id'], rng, c)
                did = chosen['id']
                role = f"D{len(seats.get(key, [])) + 1}"
                seats.setdefault(key, []).append((did, role, None))
                placed.add(did)
                d = db.one('SELECT d.reputation, a.base_rating FROM drivers d JOIN driver_attributes a ON a.driver_id = d.id WHERE d.id = ?', (did,))
                sal = salary_for(tier, d['base_rating'], d['reputation'])
                db.execute("UPDATE contracts SET status = 'expired' WHERE driver_id = ? AND status = 'active'", (did,))
                db.insert('contracts', {'driver_id': did, 'team_id': t['team_id'], 'start_season': new_year, 'end_season': new_year + rng.randint(0, 2), 'salary': sal,
                                        'role': role, 'release_clause': round(sal * 2, 3), 'status': 'active', 'create_ts': ts})
                ev = repo.emit(db, 'CONTRACT_SIGNED', {'driver_id': did, 'team_id': t['team_id'], 'category': code, 'need': role, 'salary': sal,
                                                       'candidates': [{'driver_id': x['id'], 'score': sc} for sc, x in pool[:5]]}, season_id=season['id'])
                if chosen.get('tier', 9) < 9 and chosen['tier'] > tier:
                    repo.emit(db, 'DRIVER_PROMOTED', {'driver_id': did, 'to': code}, season_id=season['id'])
                    newsroom.promotion(db, did, t['team_id'], ch['category_name'], season['id'], ev)
    # 3. entries for the new championships (+ reserves)
    for (code, team_id), lst in seats.items():
        ch_id = champ_by_code.get(code)
        if not ch_id: continue
        used = {r['number'] for r in db.all('SELECT number FROM championship_entries WHERE championship_id = ?', (ch_id,))}
        for i, (did, role, number) in enumerate(lst[:per_team[code]]):
            if not number or number in used: number = next(n for n in (rng.randint(2, 99) for _ in range(500)) if n not in used)
            used.add(number)
            prev_skin = db.value('SELECT skin FROM championship_entries WHERE team_id = ? AND skin IS NOT NULL ORDER BY id DESC LIMIT 1', (team_id,))
            db.insert('championship_entries', {'championship_id': ch_id, 'driver_id': did, 'team_id': team_id, 'number': number, 'skin': prev_skin,
                                               'role': f'D{i + 1}', 'active': 1})
    _sign_reserves(db, season, new_year, champ_by_code, placed, pos_in, rng, c)


def _pick(db, tier, new_year, placed, pos_in, team_id, rng, c):
    pool = []
    for d in db.all('SELECT d.id, d.first_name, d.last_name, d.birth_date, d.potential, d.reputation, d.form, d.progress_json, a.base_rating FROM drivers d '
                    'JOIN driver_attributes a ON a.driver_id = d.id WHERE d.retired = 0 AND d.is_player = 0'):
        if d['id'] in placed: continue
        d_tier, spos = pos_in.get(d['id'], (9, None))
        if d_tier < tier: continue
        d.update({'age': repo.age_in(d['birth_date'], new_year), 'tier': d_tier})
        if d['base_rating'] < MIN_BASE.get(tier, 0) and d_tier > tier: continue
        if tier == 1 and d_tier > 1 and not has_super_license(db, d['id'], new_year): continue
        pool.append((candidate_score(db, d, tier, spos, team_id), d))
    pool.sort(key=lambda x: -x[0])
    lowest = db.value('SELECT MAX(tier) FROM categories')
    if tier < lowest and not pool:  # upper categories promote from below; never invent a driver there
        pool = [(0, d) for d in db.all('SELECT d.id, d.first_name, d.last_name FROM drivers d WHERE d.retired = 0 AND d.is_player = 0 ORDER BY d.id DESC') if d['id'] not in placed][:1]
    if not pool or (tier == lowest and realism(db, 'generated_rookies') and pool[0][0] < 60):
        from fcm.career_engine import world_builder
        new_id = world_builder.generate_rookie(db, rng, new_year)
        repo.emit(db, 'ROOKIE_GENERATED', {'driver_id': new_id, 'team_id': team_id}, season_id=None)
        return {'id': new_id, 'first_name': '', 'last_name': '', 'tier': 9}, pool
    return pool[0][1], pool


def _sign_reserves(db, season, new_year, champ_by_code, placed, pos_in, rng, c):
    """Reserve drivers: free agents first, otherwise drivers racing in a lower category (dual role)."""
    per = cfg()['reserve_per_team']
    reserved = set()
    for code, ch_id in champ_by_code.items():
        tier = db.value('SELECT c.tier FROM championships ch JOIN categories c ON c.id = ch.category_id WHERE ch.id = ?', (ch_id,))
        n = per.get(str(tier), 0)
        if not n: continue
        same_or_higher = {r['driver_id'] for r in db.all('SELECT e.driver_id FROM championship_entries e JOIN championships ch ON ch.id = e.championship_id JOIN categories c ON c.id = ch.category_id '
                                                        'WHERE ch.season_id = (SELECT season_id FROM championships WHERE id = ?) AND c.tier <= ?', (ch_id, tier))}
        for t in db.all('SELECT DISTINCT team_id FROM championship_entries WHERE championship_id = ?', (ch_id,)):
            for _ in range(n):
                cands = []
                for d in db.all('SELECT d.id, d.birth_date, d.potential, d.reputation, a.base_rating FROM drivers d JOIN driver_attributes a ON a.driver_id = d.id WHERE d.retired = 0 AND d.is_player = 0'):
                    if d['id'] in same_or_higher or d['id'] in reserved: continue
                    d_tier, spos = pos_in.get(d['id'], (9, None))
                    d.update({'age': repo.age_in(d['birth_date'], new_year), 'tier': d_tier})
                    cands.append((d['base_rating'] + (3 if d['id'] not in placed else 0) + (2 if d_tier == tier else 0), d))
                if not cands: break
                cands.sort(key=lambda x: -x[0])
                d = cands[0][1]
                reserved.add(d['id'])
                free_agent = d['id'] not in placed
                placed.add(d['id'])
                used = {r['number'] for r in db.all('SELECT number FROM championship_entries WHERE championship_id = ?', (ch_id,))}
                num = next(x for x in (rng.randint(2, 99) for _ in range(500)) if x not in used)
                sal = round(salary_for(tier, d['base_rating'], d['reputation']) * 0.3, 3)
                db.insert('championship_entries', {'championship_id': ch_id, 'driver_id': d['id'], 'team_id': t['team_id'], 'number': num, 'role': 'reserve', 'active': 1})
                if free_agent:
                    db.insert('contracts', {'driver_id': d['id'], 'team_id': t['team_id'], 'start_season': new_year, 'end_season': new_year, 'salary': sal, 'role': 'Reserve',
                                            'status': 'active', 'create_ts': now_ts()})


def overview(db):
    season = repo.current_season(db)
    d, entry, pos, contract = _player_context(db, season)
    teams = []
    for t in season_teams(db, season['id']):
        if entry and t['tier'] not in (entry['tier'], entry['tier'] - 1): continue
        interest, weakest, my, other = team_interest(db, season, t, d, pos)
        teams.append({**t, 'interest': interest, 'valuation': round(salary_for(t['tier'], d['base_rating'], d['reputation']) * (1 + 0.08 * max(0.0, interest)), 3),
                      'drivers': [{'driver_id': m['driver_id'], 'name': f"{m['first_name']} {m['last_name']}", 'role': m['role'],
                                   'contract_end': db.value("SELECT end_season FROM contracts WHERE driver_id = ? AND status = 'active' ORDER BY end_season DESC LIMIT 1", (m['driver_id'],))}
                                  for m in team_drivers(db, season['id'], t['team_id'])]})
    teams.sort(key=lambda t: (t['tier'], -t['interest']))
    offers = db.all('SELECT o.*, t.name team_name, t.color team_color FROM offers o JOIN teams t ON t.id = o.team_id WHERE o.driver_id = ? ORDER BY o.id DESC LIMIT 40', (d['id'],))
    for o in offers: o['reason'] = jload(o.pop('reason_json'), {})
    from fcm.management import transfers
    return {'player': {'id': d['id'], 'base_rating': d['base_rating'], 'reputation': d['reputation'], 'age': d['age'], 'standing': pos, 'market_value': d.get('market_value')},
            'summer_open': transfers.before_summer_break(db, season['id']),
            'contract': contract, 'future_contracts': db.all("SELECT c.*, t.name team_name FROM contracts c JOIN teams t ON t.id = c.team_id WHERE c.driver_id = ? AND c.start_season > ? AND c.status = 'active'",
                                                              (d['id'], season['year'])),
            'super_license': {'points': super_license_points(db, d['id'], season['year'] + 1), 'required': cfg()['super_license']['required_points'],
                              'eligible': has_super_license(db, d['id'], season['year'] + 1)},
            'teams': teams, 'offers': offers,
            'contracts': db.all("SELECT c.*, d.first_name, d.last_name, d.market_value, t.name team_name, a.base_rating FROM contracts c JOIN drivers d ON d.id = c.driver_id JOIN teams t ON t.id = c.team_id "
                                "JOIN driver_attributes a ON a.driver_id = d.id WHERE c.status = 'active' AND c.start_season <= ? ORDER BY t.id, c.role", (season['year'],)),
            'academies': [{**a, 'members': db.all('SELECT m.*, d.first_name, d.last_name, d.potential, x.base_rating FROM academy_members m JOIN drivers d ON d.id = m.driver_id '
                                                  'JOIN driver_attributes x ON x.driver_id = d.id WHERE m.academy_id = ? AND m.active = 1', (a['id'],))}
                          for a in db.all('SELECT a.*, t.name team_name, t.color FROM academies a JOIN teams t ON t.id = a.team_id')]}
