"""DevelopmentService: R&D projects (design) -> parts -> manufacturing -> installation per driver,
facilities, next-season development bank and AI team development decisions.

Car used in a session = season base car (car_performance) + gains of the parts installed on THAT driver.
Gains are small, have diminishing returns near the component ceiling and uncertain outcomes.
AI teams develop because they spend/choose well, never because of the player's position (no rubber-banding)."""
import math

from fcm.career_engine import newsroom, repo
from fcm.database.db import jdump, jload, now_ts
from fcm.management import finance
from fcm.management.common import ai_controls, completed_rounds, difficulty_mult, realism, rounds_in_championship, season_teams, team_drivers, team_info, tier_key, upcoming_rounds
from fcm.shared import config
from fcm.shared.rng import rng_for
from fcm.simulation.model import clamp, overall_strength


OUTCOME_ES = {'underperformed': 'por debajo de lo previsto', 'expected': 'según lo previsto', 'overperformed': 'por encima de lo previsto', 'failed': 'fallido'}


OUTCOME_ES = {'underperformed': 'por debajo de lo previsto', 'expected': 'según lo previsto', 'overperformed': 'por encima de lo previsto', 'failed': 'fallido'}


def cfg():
    return config.load('development')


# ------------------------------------------------------------------------------------------
# Facilities
# ------------------------------------------------------------------------------------------
def init_facilities(db, team_id, strength, rng):
    for kind in cfg()['facilities']['kinds']:
        if db.value('SELECT 1 FROM facilities WHERE team_id = ? AND kind = ?', (team_id, kind)): continue
        level = int(clamp(round((strength - 84) / 3 + rng.uniform(-0.8, 0.8)), 1, cfg()['facilities']['max_level']))
        db.insert('facilities', {'team_id': team_id, 'kind': kind, 'level': level, 'upgrade_rounds_left': 0})


def facilities(db, team_id):
    return {r['kind']: r for r in db.all('SELECT * FROM facilities WHERE team_id = ?', (team_id,))}


def dept_level(db, team_id, department):
    f = facilities(db, team_id)
    kinds = cfg()['facilities']['affects'].get(department, [])
    return sum(f[k]['level'] for k in kinds if k in f) / max(1, len(kinds)) if kinds else 1


def upgrade_facility(db, season_id, round_id, team_id, kind):
    fc = cfg()['facilities']
    f = facilities(db, team_id).get(kind)
    if not f: raise ValueError('Instalación desconocida')
    if f['upgrade_rounds_left']: raise ValueError('Ya hay una mejora en curso')
    if f['level'] >= fc['max_level']: raise ValueError('La instalación ya está al nivel máximo')
    tier = team_info(db, season_id, team_id)['tier']
    cost = fc['upgrade_cost'][tier_key(tier)][f['level']]
    ok, why = finance.can_afford(db, season_id, team_id, cost, cost_cap=False)
    if not ok: raise ValueError(why)
    finance.tx(db, season_id, round_id, team_id, 'facility_upgrade', -cost, f"Mejora de {kind} a nivel {f['level'] + 1}")
    db.update('facilities', f['id'], {'upgrade_rounds_left': fc['upgrade_rounds'][f['level']]})
    repo.emit(db, 'FACILITY_UPGRADE_STARTED', {'team_id': team_id, 'kind': kind, 'to': f['level'] + 1}, season_id=season_id)


# ------------------------------------------------------------------------------------------
# Projects
# ------------------------------------------------------------------------------------------
def _dev_penalty(db, team_id, year):
    ai = db.one('SELECT notes_json FROM team_ai WHERE team_id = ?', (team_id,))
    notes = jload(ai['notes_json'], {}) if ai else {}
    return 1 - config.load('finance')['cost_cap_breach']['next_season_dev_penalty_pct'] / 100 if notes.get('dev_penalty_year') == year else 1.0


def capacity(db, team_id):
    c = cfg()
    pers = facilities(db, team_id).get('personnel', {'level': 1})['level']
    return int(c['base_capacity'] + math.floor(pers * c['capacity_per_personnel_level']))


def active_projects(db, team_id):
    return db.value("SELECT COUNT(*) FROM development_projects WHERE team_id = ? AND status = 'design'", (team_id,))


def preview(db, season_id, team_id, part, size, target_year):
    c = cfg()
    if part not in c['parts'] or size not in c['sizes']: raise ValueError('Pieza o alcance desconocidos')
    p, sz = c['parts'][part], c['sizes'][size]
    season = db.one('SELECT * FROM seasons WHERE id = ?', (season_id,))
    t = team_info(db, season_id, team_id)
    car = repo.car(db, season_id, team_id)
    lvl = dept_level(db, team_id, p['department'])
    fcf = c['facilities']
    rounds = max(1, math.ceil(p['rounds'] * sz['rounds'] * (1 - fcf['speed_per_level'] * (lvl - 1))))
    comps = p['components']
    cur = sum(car[k] * s for k, s in comps.items()) / sum(comps.values())
    dimin = clamp(1 - (cur - c['diminishing_start']) / (c['component_max'] - c['diminishing_start']), c['diminishing_floor'], 1.2) if cur > c['diminishing_start'] else 1.2 if cur < 85 else 1.0
    gain = p['gain'] * sz['gain'] * (car['development_efficiency'] / 80) * (1 + fcf['gain_per_level'] * (lvl - 1)) * dimin * _dev_penalty(db, team_id, season['year'])
    if target_year > season['year']: gain *= c['next_season_efficiency']
    gain *= difficulty_mult(db, 'development', team_id, season_id)
    cost = round(p['cost'] * sz['cost'] * c['tier_cost_mult'][tier_key(t['tier'])], 3)
    reasons = []
    if active_projects(db, team_id) >= capacity(db, team_id): reasons.append(f'Capacidad de diseño completa ({capacity(db, team_id)} proyectos)')
    ok, why = finance.can_afford(db, season_id, team_id, cost)
    if not ok: reasons.append(why)
    if target_year < season['year'] or target_year > season['year'] + 1: reasons.append('El objetivo debe ser esta temporada o la siguiente')
    return {'part': part, 'size': size, 'department': p['department'], 'target_year': target_year, 'cost': cost, 'rounds': rounds,
            'expected_gain': round(gain, 3), 'risk': sz['risk'], 'components': comps, 'facility_level': round(lvl, 2),
            'diminishing': round(dimin, 2), 'can_start': not reasons, 'reasons': reasons}


def start_project(db, season_id, round_id, team_id, part, size, target_year, reason=None):
    pv = preview(db, season_id, team_id, part, size, target_year)
    if not pv['can_start']: raise ValueError('; '.join(pv['reasons']))
    rno = db.value('SELECT round_no FROM calendar_rounds WHERE id = ?', (round_id,)) if round_id else None
    pid = db.insert('development_projects', {'team_id': team_id, 'season_id': season_id, 'target_year': target_year, 'department': pv['department'], 'part': part,
                                             'size': size, 'cost': pv['cost'], 'rounds_total': pv['rounds'], 'rounds_left': pv['rounds'], 'expected_gain': pv['expected_gain'],
                                             'risk': pv['risk'], 'status': 'design', 'start_round': rno, 'reason': reason, 'create_ts': now_ts()})
    finance.tx(db, season_id, round_id, team_id, 'development', -pv['cost'], f"R&D {part} ({size}) for {target_year}", f'project:{pid}')
    repo.emit(db, 'PROJECT_STARTED', {'project_id': pid, 'team_id': team_id, 'part': part, 'size': size, 'target_year': target_year, 'reason': reason}, season_id=season_id, round_id=round_id)
    return pid


def _resolve(db, pr, season, rnd, rng):
    c = cfg()
    ro = dict(c['risk_outcomes'][pr['risk']])
    qc = facilities(db, pr['team_id']).get('quality_control', {'level': 1})['level']
    prec = c['facilities']['precision_per_level'] * (qc - 1)
    ro['failed'] *= max(0.2, 1 - prec)
    ro['under'] *= max(0.3, 1 - prec / 2)
    roll = rng.random()
    if roll < ro['failed']: outcome, mult = 'failed', 0.0
    elif roll < ro['failed'] + ro['under']: outcome, mult = 'underperformed', rng.uniform(0.4, 0.88)
    elif roll < ro['failed'] + ro['under'] + ro['expected']: outcome, mult = 'expected', rng.uniform(0.9, 1.1)
    else: outcome, mult = 'overperformed', rng.uniform(1.12, 1.4)
    mult *= max(0.0, 1 + rng.gauss(0, ro['sd'] * max(0.3, 1 - prec))) if mult else 0
    actual = round(pr['expected_gain'] * pr['gain_mult'] * mult, 4)
    db.update('development_projects', pr['id'], {'status': 'completed' if actual > 0 else 'failed', 'outcome': outcome, 'actual_gain': actual, 'rounds_left': 0})
    comps = c['parts'][pr['part']]['components']
    ev = repo.emit(db, 'UPGRADE_COMPLETED' if actual > 0 else 'UPGRADE_FAILED', {'project_id': pr['id'], 'team_id': pr['team_id'], 'part': pr['part'],
                   'expected': pr['expected_gain'], 'actual': actual, 'outcome': outcome, 'target_year': pr['target_year']}, season_id=season['id'], round_id=rnd['id'])
    if actual <= 0:
        from fcm.management.common import player_team_id
        newsroom.development(db, pr['team_id'], pr['part'], 'failed', pr['team_id'] == player_team_id(db), team_info(db, season['id'], pr['team_id'])['tier'], season['id'], rnd['id'], ev, rng_for(pr['id'], 'news'))
        return
    split = {k: round(actual * s / sum(comps.values()), 4) for k, s in comps.items()}
    if pr['target_year'] > season['year']:  # completed before its target season -> next-season car bank
        for k, g in split.items(): db.insert('next_season_bank', {'team_id': pr['team_id'], 'target_year': pr['target_year'], 'component': k, 'gain': g, 'project_id': pr['id']})
        return
    spec = (db.value('SELECT MAX(spec_no) FROM parts WHERE team_id = ? AND season_id = ? AND part = ?', (pr['team_id'], season['id'], pr['part'])) or 0) + 1
    tier = team_info(db, season['id'], pr['team_id'])['tier']
    p = c['parts'][pr['part']]
    db.insert('parts', {'project_id': pr['id'], 'team_id': pr['team_id'], 'season_id': season['id'], 'part': pr['part'], 'spec_no': spec,
                        'components_json': jdump(split), 'available': 0, 'manufacture_cost': round(p['mf_cost'] * c['tier_cost_mult'][tier_key(tier)], 4),
                        'manufacture_rounds': p['mf_rounds'], 'create_ts': now_ts()})
    nxt = upcoming_rounds(db, season['id'], 1)
    from fcm.management.common import player_team_id
    newsroom.development(db, pr['team_id'], pr['part'], outcome, pr['team_id'] == player_team_id(db), tier, season['id'], nxt[0]['id'] if nxt else rnd['id'], ev, rng_for(pr['id'], 'news'))


def manufacture(db, season_id, round_id, part_id, quantity):
    part = db.one('SELECT * FROM parts WHERE id = ?', (part_id,))
    if not part: raise LookupError('Pieza no encontrada')
    quantity = max(1, min(2, int(quantity)))
    fac = facilities(db, part['team_id']).get('factory', {'level': 1})['level']
    cost = round(part['manufacture_cost'] * quantity * (1 - 0.05 * (fac - 1)), 4)
    ok, why = finance.can_afford(db, season_id, part['team_id'], cost)
    if not ok: raise ValueError(why)
    rounds = max(1, part['manufacture_rounds'] - (1 if fac >= 4 else 0))
    oid = db.insert('manufacturing_orders', {'part_id': part_id, 'team_id': part['team_id'], 'quantity': quantity, 'cost': cost, 'rounds_left': rounds,
                                             'status': 'in_progress', 'create_ts': now_ts()})
    finance.tx(db, season_id, round_id, part['team_id'], 'manufacturing', -cost, f"Fabricación {quantity}x {part['part']} spec {part['spec_no']}", f'order:{oid}')
    return oid


def install(db, season_id, part_id, driver_id):
    part = db.one('SELECT * FROM parts WHERE id = ?', (part_id,))
    if not part or part['available'] < 1: raise ValueError('No hay unidades fabricadas disponibles de esta pieza')
    if not db.value("SELECT 1 FROM championship_entries e JOIN championships ch ON ch.id = e.championship_id WHERE ch.season_id = ? AND e.team_id = ? AND e.driver_id = ?",
                    (season_id, part['team_id'], driver_id)): raise ValueError('El piloto no corre para este equipo')
    old = db.all('SELECT pi.id FROM part_installations pi JOIN parts p ON p.id = pi.part_id WHERE pi.driver_id = ? AND pi.season_id = ? AND p.part = ? AND pi.active = 1',
                 (driver_id, season_id, part['part']))
    for o in old: db.update('part_installations', o['id'], {'active': 0})
    rnd = db.one("SELECT round_no FROM calendar_rounds WHERE season_id = ? AND status != 'completed' ORDER BY round_no LIMIT 1", (season_id,))
    db.insert('part_installations', {'part_id': part_id, 'driver_id': driver_id, 'season_id': season_id, 'round_no': rnd['round_no'] if rnd else None, 'active': 1})
    db.update('parts', part_id, {'available': part['available'] - 1})
    repo.emit(db, 'PART_INSTALLED', {'part_id': part_id, 'driver_id': driver_id, 'part': part['part'], 'spec': part['spec_no']}, season_id=season_id)


def driver_car(db, season_id, team_id, driver_id):
    car = repo.car(db, season_id, team_id)
    if car is None: return None
    for p in db.all('SELECT p.components_json FROM part_installations pi JOIN parts p ON p.id = pi.part_id WHERE pi.driver_id = ? AND pi.season_id = ? AND pi.active = 1 AND p.team_id = ?',
                    (driver_id, season_id, team_id)):
        for k, g in jload(p['components_json'], {}).items(): car[k] = min(cfg()['component_max'], car[k] + g)
    return car


def team_car_now(db, season_id, team_id):
    """Average of the team's race cars (for rankings/history)."""
    ds = team_drivers(db, season_id, team_id)
    cars = [driver_car(db, season_id, team_id, d['driver_id']) for d in ds] or [repo.car(db, season_id, team_id)]
    return {k: sum(c[k] for c in cars) / len(cars) for k in cars[0]}


# ------------------------------------------------------------------------------------------
# Round tick + AI decisions
# ------------------------------------------------------------------------------------------
def round_tick(db, rnd):
    season = db.one('SELECT * FROM seasons WHERE id = ?', (rnd['season_id'],))
    seed = repo.career(db)['seed']
    for pr in db.all("SELECT * FROM development_projects WHERE status = 'design'"):  # projects carry over season boundaries
        left = pr['rounds_left'] - 1
        if left > 0: db.update('development_projects', pr['id'], {'rounds_left': left})
        else: _resolve(db, pr, season, rnd, rng_for(seed, 'project', pr['id']))
    for o in db.all("SELECT * FROM manufacturing_orders WHERE status = 'in_progress'"):
        left = o['rounds_left'] - 1
        if left > 0: db.update('manufacturing_orders', o['id'], {'rounds_left': left})
        else:
            db.update('manufacturing_orders', o['id'], {'rounds_left': 0, 'status': 'done'})
            db.execute('UPDATE parts SET available = available + ? WHERE id = ?', (o['quantity'], o['part_id']))
    for f in db.all('SELECT * FROM facilities WHERE upgrade_rounds_left > 0'):
        left = f['upgrade_rounds_left'] - 1
        db.update('facilities', f['id'], {'upgrade_rounds_left': left, **({'level': f['level'] + 1} if left == 0 else {})})
        if left == 0: repo.emit(db, 'FACILITY_UPGRADED', {'team_id': f['team_id'], 'kind': f['kind'], 'level': f['level'] + 1}, season_id=season['id'], round_id=rnd['id'])
    cm = config.load('car_model')
    for t in season_teams(db, season['id']):
        car = team_car_now(db, season['id'], t['team_id'])
        overall = overall_strength(car, cm)
        last = db.value('SELECT overall FROM team_performance_history WHERE team_id = ? AND season_id = ? ORDER BY id DESC LIMIT 1', (t['team_id'], season['id']))
        if last is None or abs(last - overall) > 0.005:
            db.insert('team_performance_history', {'season_id': season['id'], 'round_id': rnd['id'], 'team_id': t['team_id'], 'overall': overall,
                                                   'components_json': jdump({k: round(v, 3) for k, v in car.items() if k in repo.CAR_FIELDS}), 'reason': 'mejoras instaladas', 'create_ts': now_ts()})


def update_ai_shares(db, season):
    regs_major = db.value('SELECT MAX(major_change) FROM regulations r JOIN seasons s ON s.id = r.season_id WHERE s.year = ?', (season['year'] + 1,))
    rcfg = config.load('regulations')['major_change']
    for t in season_teams(db, season['id']):
        done, total = completed_rounds(db, t['championship_id']), rounds_in_championship(db, t['championship_id'])
        frac = done / total
        share = rcfg['ai_next_season_share'] if regs_major and frac > 0.3 else clamp((frac - 0.4) * 0.6, 0, 0.35)
        db.update('team_ai', t['team_id'], {'next_season_share': round(share, 3)}, key='team_id')


def ai_tick(db, rnd):
    """AI (and delegated player team) development decisions for the next round."""
    if not realism(db, 'development'): return
    season = db.one('SELECT * FROM seasons WHERE id = ?', (rnd['season_id'],))
    seed = repo.career(db)['seed']
    update_ai_shares(db, season)
    ahead = upcoming_rounds(db, season['id'], 3)
    profiles = [repo.track_profile(db, r['track_profile_id']) for r in ahead]
    c = cfg()
    for t in season_teams(db, season['id']):
        if not ai_controls(db, t['team_id'], season['id']): continue
        rng = rng_for(seed, 'ai_dev', season['id'], rnd['round_no'], t['team_id'])
        ai = db.one('SELECT * FROM team_ai WHERE team_id = ?', (t['team_id'],)) or {'risk_tolerance': 0.5, 'next_season_share': 0, 'strategy': 'balanced'}
        # 1) install available parts on both drivers (D1 first)
        for part in db.all('SELECT * FROM parts WHERE team_id = ? AND season_id = ? AND available > 0 ORDER BY id', (t['team_id'], season['id'])):
            for d in team_drivers(db, season['id'], t['team_id']):
                if db.one('SELECT available FROM parts WHERE id = ?', (part['id'],))['available'] < 1: break
                has = db.value('SELECT 1 FROM part_installations WHERE part_id = ? AND driver_id = ? AND active = 1', (part['id'], d['driver_id']))
                if not has: install(db, season['id'], part['id'], d['driver_id'])
        # 2) order manufacturing for newly designed parts
        for part in db.all('SELECT p.* FROM parts p WHERE p.team_id = ? AND p.season_id = ? AND p.available = 0 AND NOT EXISTS (SELECT 1 FROM manufacturing_orders o WHERE o.part_id = p.id) '
                           'AND NOT EXISTS (SELECT 1 FROM part_installations pi WHERE pi.part_id = p.id)', (t['team_id'], season['id'])):
            for qty in (2, 1):
                try:
                    manufacture(db, season['id'], rnd['id'], part['id'], qty)
                    break
                except ValueError:
                    continue
        # 3) start projects while there is capacity and money
        tries = 0
        while active_projects(db, t['team_id']) < capacity(db, t['team_id']) and tries < 3:
            tries += 1
            target = season['year'] + 1 if rng.random() < ai['next_season_share'] else season['year']
            part = _choose_part(db, season['id'], t, profiles, rng)
            size = 'major' if rng.random() < ai['risk_tolerance'] * 0.5 else 'minor' if rng.random() > 0.5 + ai['risk_tolerance'] * 0.3 else 'standard'
            pv = preview(db, season['id'], t['team_id'], part, size, target)
            head = finance.cost_cap_headroom(db, season['id'], t['team_id'])
            if head is not None and pv['cost'] > head: size = 'minor'; pv = preview(db, season['id'], t['team_id'], part, size, target)
            if head is not None and pv['cost'] > head: break
            if not pv['can_start']:
                pv = preview(db, season['id'], t['team_id'], part, 'minor', target)
                if not pv['can_start']: break
                size = 'minor'
            start_project(db, season['id'], rnd['id'], t['team_id'], part, size, target,
                          reason=f"IA: foco en el área más débil ({ai['strategy']}), reparto temporada siguiente {ai['next_season_share']:.2f}")
        # 4) occasionally invest in facilities with spare cash
        f = finance.row(db, season['id'], t['team_id'])
        if f and f['cash'] > f['season_budget'] * 0.6 and rng.random() < 0.25:
            facs = sorted(facilities(db, t['team_id']).values(), key=lambda x: x['level'])
            for fac in facs:
                if fac['level'] < c['facilities']['max_level'] and not fac['upgrade_rounds_left']:
                    try:
                        upgrade_facility(db, season['id'], rnd['id'], t['team_id'], fac['kind'])
                    except ValueError:
                        pass
                    break


def _choose_part(db, season_id, t, profiles, rng):
    """Pick the part addressing the weakest components vs the field, weighted by upcoming track needs."""
    c = cfg()
    cm = config.load('car_model')
    same = [x for x in season_teams(db, season_id) if x['code'] == t['code']]
    cars = [team_car_now(db, season_id, x['team_id']) for x in same]
    mine = team_car_now(db, season_id, t['team_id'])
    need = {}
    for k in repo.CAR_FIELDS:
        mean = sum(cr[k] for cr in cars) / len(cars)
        imp = cm['overall_weights'].get(k, 0.05)
        for prof in profiles:
            for key, comps in cm['track_mapping'].items():
                if k in comps: imp += float(prof.get(key, 0.5)) * comps[k] * 0.05
        need[k] = (mean - mine[k] + 1.5) * imp
    scores = {part: sum(need.get(k, 0) * s for k, s in p['components'].items()) + rng.uniform(0, 0.02) for part, p in c['parts'].items()}
    return max(scores, key=scores.get)


def bank_for(db, team_id, year):
    rows = db.all('SELECT component, SUM(gain) g FROM next_season_bank WHERE team_id = ? AND target_year = ? GROUP BY component', (team_id, year))
    return {r['component']: r['g'] for r in rows}


def overview(db, season_id, team_id):
    return {'projects': db.all('SELECT * FROM development_projects WHERE team_id = ? AND season_id = ? ORDER BY id DESC', (team_id, season_id)),
            'parts': db.all('SELECT p.*, (SELECT COUNT(*) FROM part_installations pi WHERE pi.part_id = p.id AND pi.active = 1) installed, '
                            "(SELECT SUM(quantity) FROM manufacturing_orders o WHERE o.part_id = p.id AND o.status = 'in_progress') in_production, "
                            "(SELECT MIN(rounds_left) FROM manufacturing_orders o WHERE o.part_id = p.id AND o.status = 'in_progress') production_rounds "
                            'FROM parts p WHERE p.team_id = ? AND p.season_id = ? ORDER BY p.id DESC', (team_id, season_id)),
            'installations': db.all('SELECT pi.*, p.part, p.spec_no, p.components_json, d.first_name, d.last_name FROM part_installations pi JOIN parts p ON p.id = pi.part_id '
                                    'JOIN drivers d ON d.id = pi.driver_id WHERE p.team_id = ? AND pi.season_id = ? AND pi.active = 1 ORDER BY d.id, p.part', (team_id, season_id)),
            'facilities': list(facilities(db, team_id).values()), 'capacity': capacity(db, team_id), 'active': active_projects(db, team_id),
            'next_season_bank': bank_for(db, team_id, db.value('SELECT year FROM seasons WHERE id = ?', (season_id,)) + 1),
            'catalog': cfg()['parts'], 'sizes': cfg()['sizes'], 'departments': cfg()['departments']}
