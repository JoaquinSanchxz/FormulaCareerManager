"""All-time records and career milestones (news only for things that really happened)."""
from fcm.career_engine import championship as champ, newsroom, repo

MILESTONES = {'wins': (1, 10, 25, 50, 75, 100), 'podiums': (1, 50, 100), 'poles': (1, 10, 25, 50), 'starts': (100, 200, 300)}


def _counts(db, driver_id, code):
    r = db.one("SELECT SUM(CASE WHEN s.type = 'race' AND r.status = 'FIN' AND r.position = 1 THEN 1 ELSE 0 END) wins, "
               "SUM(CASE WHEN s.type = 'race' AND r.status = 'FIN' AND r.position <= 3 THEN 1 ELSE 0 END) podiums, "
               "SUM(CASE WHEN s.code = 'Q' AND r.position = 1 THEN 1 ELSE 0 END) poles, SUM(CASE WHEN s.type = 'race' THEN 1 ELSE 0 END) starts "
               "FROM results r JOIN sessions s ON s.id = r.session_id JOIN championships ch ON ch.id = s.championship_id JOIN categories c ON c.id = ch.category_id "
               "WHERE r.driver_id = ? AND c.code = ? AND s.status = 'completed'", (driver_id, code))
    return {k: r[k] or 0 for k in ('wins', 'podiums', 'poles', 'starts')}


def milestones(db, s, rows):
    code = db.value('SELECT c.code FROM championships ch JOIN categories c ON c.id = ch.category_id WHERE ch.id = ?', (s['championship_id'],))
    relevant = []
    if s['type'] == 'race':
        relevant = [(r['driver_id'], ('wins', 'podiums', 'starts')) for r in rows if r.get('status') != 'DNS']
    elif s['code'] == 'Q' and rows:
        relevant = [(rows[0]['driver_id'], ('poles',))]
    for did, kinds in relevant:
        # real drivers already had a career before the game starts: their counters here would be wrong, only debutants get milestones
        if not db.value('SELECT is_generated FROM drivers WHERE id = ?', (did,)): continue
        cnt = _counts(db, did, code)
        r = next((x for x in rows if x['driver_id'] == did), {})
        for k in kinds:
            if k == 'wins' and not (r.get('status') == 'FIN' and r.get('position') == 1): continue
            if k == 'podiums' and not (r.get('status') == 'FIN' and r.get('position', 99) <= 3): continue
            if cnt[k] in MILESTONES[k]:
                ev = repo.emit(db, 'MILESTONE', {'driver_id': did, 'kind': k, 'count': cnt[k], 'category': code}, season_id=s['season_id'], round_id=s['round_id'], session_id=s['id'])
                newsroom.milestone(db, s, did, k, cnt[k], code, ev)


def records(db):
    out = {}
    for c in db.all('SELECT * FROM categories ORDER BY tier'):
        rows = db.all("SELECT r.driver_id, d.first_name, d.last_name, "
                      "SUM(CASE WHEN s.type = 'race' AND r.status = 'FIN' AND r.position = 1 THEN 1 ELSE 0 END) wins, "
                      "SUM(CASE WHEN s.type = 'race' AND r.status = 'FIN' AND r.position <= 3 THEN 1 ELSE 0 END) podiums, "
                      "SUM(CASE WHEN s.code = 'Q' AND r.position = 1 THEN 1 ELSE 0 END) poles, SUM(CASE WHEN s.type = 'race' THEN 1 ELSE 0 END) starts, "
                      "SUM(r.points) points, SUM(r.fastest_lap) fastest_laps FROM results r JOIN sessions s ON s.id = r.session_id JOIN championships ch ON ch.id = s.championship_id "
                      "JOIN drivers d ON d.id = r.driver_id WHERE ch.category_id = ? AND s.status = 'completed' GROUP BY r.driver_id", (c['id'],))
        champions = []
        for s in db.all("SELECT * FROM seasons WHERE status = 'finished' ORDER BY year"):
            ch = db.one('SELECT id FROM championships WHERE season_id = ? AND category_id = ?', (s['id'], c['id']))
            if not ch: continue
            st = champ.driver_standings(db, ch['id'])
            cons = champ.constructor_standings(db, ch['id'])
            if st: champions.append({'year': s['year'], 'driver_id': st[0]['driver_id'], 'driver': st[0]['name'], 'points': st[0]['points'],
                                     'team': cons[0]['team_name'] if cons else None})
        titles = {}
        for x in champions: titles[x['driver_id']] = titles.get(x['driver_id'], 0) + 1
        for r in rows: r['titles'] = titles.get(r['driver_id'], 0)
        out[c['code']] = {'champions': champions,
                          **{k: sorted(rows, key=lambda r: -(r[k] or 0))[:10] for k in ('wins', 'poles', 'podiums', 'titles', 'starts', 'points', 'fastest_laps')}}
    return out
