"""Management lifecycle orchestration: season start, per-round tick, season end, next-season cars."""
from fcm.career_engine import championship as champ, newsroom, repo
from fcm.database.db import jdump, jload, now_ts
from fcm.management import components, development, events, finance, market, regulations
from fcm.management.common import player_team_id, realism, season_teams
from fcm.shared import config, log
from fcm.shared.rng import rng_for
from fcm.simulation.model import clamp, overall_strength

_log = log.get('FINANCE')


def init_team_ai(db, season_id, seed):
    for t in season_teams(db, season_id):
        if db.value('SELECT 1 FROM team_ai WHERE team_id = ?', (t['team_id'],)): continue
        rng = rng_for(seed, 'team_ai', t['team_id'])
        strategy = rng.choice(['balanced', 'balanced', 'aggressive', 'conservative'])
        risk = clamp(rng.uniform(0.25, 0.75) + (0.15 if strategy == 'aggressive' else -0.15 if strategy == 'conservative' else 0), 0.05, 0.95)
        db.insert('team_ai', {'team_id': t['team_id'], 'risk_tolerance': round(risk, 3), 'strategy': strategy, 'next_season_share': 0, 'notes_json': '{}'})


def init_season(db, season_id, year, seed, first=False, academy_seed=None):
    init_team_ai(db, season_id, seed)
    cm = config.load('car_model')
    rng = rng_for(seed, 'facilities', year)
    for t in season_teams(db, season_id):
        development.init_facilities(db, t['team_id'], overall_strength(repo.car(db, season_id, t['team_id']), cm) if t['tier'] == 1 else 80 + (3 - t['tier']) * 2, rng)
    regulations.init_season(db, season_id, year)
    if realism(db, 'finances'): finance.init_season(db, season_id, year, seed)
    components.init_season(db, season_id)
    if realism(db, 'academies', False):
        if first: market.init_academies(db, season_id, year, academy_seed)
        else: market.refresh_academies(db, season_id, year)
    _set_objectives(db, season_id, year)


def _set_objectives(db, season_id, year):
    cm = config.load('car_model')
    teams = season_teams(db, season_id)
    for code in {t['code'] for t in teams}:
        group = sorted((t for t in teams if t['code'] == code), key=lambda t: -overall_strength(repo.car(db, season_id, t['team_id']), cm))
        for rank, t in enumerate(group, start=1):
            ai = db.one('SELECT notes_json FROM team_ai WHERE team_id = ?', (t['team_id'],))
            notes = jload(ai['notes_json'], {}) if ai else {}
            notes['objective'] = {'year': year, 'position': rank}
            db.update('team_ai', t['team_id'], {'notes_json': jdump(notes)}, key='team_id')


def round_complete(db, rnd):
    """Called once when a round is completed (all categories)."""
    if realism(db, 'finances'): finance.round_tick(db, rnd)
    if realism(db, 'development'): development.round_tick(db, rnd)
    market.injuries_tick(db, rnd)
    from fcm.management import transfers
    transfers.update_market_values(db, db.one('SELECT * FROM seasons WHERE id = ?', (rnd['season_id'],)))
    if rnd.get('summer_break_after'): transfers.summer_window(db, rnd)
    events.expire_pending(db, rnd)
    nxt = db.one("SELECT * FROM calendar_rounds WHERE season_id = ? AND status != 'completed' ORDER BY round_no LIMIT 1", (rnd['season_id'],))
    if nxt:
        if realism(db, 'failures'): components.ai_tick(db, rnd)
        development.ai_tick(db, rnd)
        events.roll(db, nxt)
    market.maybe_generate_offers(db, rnd)


def season_end(db, season):
    if realism(db, 'finances'): finance.season_end(db, season)
    ptid = player_team_id(db, season['id'])
    pid = repo.career(db)['player_driver_id']
    for ch in repo.championships(db, season['id']):
        for t in champ.constructor_standings(db, ch['id']):
            ai = db.one('SELECT notes_json FROM team_ai WHERE team_id = ?', (t['team_id'],))
            obj = jload(ai['notes_json'], {}).get('objective') if ai else None
            if not obj or obj.get('year') != season['year']: continue
            delta = obj['position'] - t['position']
            db.execute('UPDATE teams SET reputation = MIN(99, MAX(1, reputation + ?)) WHERE id = ?', (clamp(delta * 1.5, -6, 6), t['team_id']))
            if t['team_id'] == ptid:
                db.execute('UPDATE drivers SET morale = MIN(100, MAX(5, morale + ?)) WHERE id = ?', (clamp(delta * 2, -8, 8), pid))
                ev = repo.emit(db, 'TEAM_OBJECTIVE', {'team_id': t['team_id'], 'objective': obj['position'], 'result': t['position']}, season_id=season['id'])
                newsroom.objective(db, t['team_id'], obj['position'], t['position'], season['id'], ev)


def next_season_cars(db, old_season, new_season, seed, new_year):
    """New car = old base + carry-over of installed upgrades + regression to mean + noise + next-season R&D bank.
    Major regulation change: cars converge strongly and next-season R&D counts more."""
    cm = config.load('car_model')
    dc = config.load('development')
    rc = config.load('regulations')['major_change']
    major = regulations.is_major_year(db, new_year)
    ts = now_ts()
    rows = db.all('SELECT * FROM car_performance WHERE season_id = ?', (old_season,))
    by_cat = {}
    for r in rows: by_cat.setdefault(db.value('SELECT category_id FROM teams WHERE id = ?', (r['team_id'],)), []).append(r)
    for cat, cars in by_cat.items():
        means = {k: sum(c[k] for c in cars) / len(cars) for k in repo.CAR_FIELDS}
        # regulation baseline = the category's first-season field mean: winter rule tweaks stop long-run inflation
        first = db.value('SELECT MIN(season_id) FROM car_performance cp JOIN teams t ON t.id = cp.team_id WHERE t.category_id = ?', (cat,))
        base_rows = db.all('SELECT cp.* FROM car_performance cp JOIN teams t ON t.id = cp.team_id WHERE cp.season_id = ? AND t.category_id = ?', (first, cat))
        baseline = {k: sum(c[k] for c in base_rows) / len(base_rows) for k in repo.CAR_FIELDS}
        new_cars = []
        for r in cars:
            rng = rng_for(seed, 'nextcar', new_season, r['team_id'])
            eff = r['development_efficiency']
            now = development.team_car_now(db, old_season, r['team_id'])
            carry = rc['carry_over'] if major else dc['carry_over_current_upgrades']
            bank = development.bank_for(db, r['team_id'], new_year)
            comps = {}
            for k in repo.CAR_FIELDS:
                v = r[k] + (now[k] - r[k]) * carry
                v += (means[k] - v) * 0.3 + rng.gauss(0, 0.8) + (eff - 75) * 0.04
                if major: v = means[k] + (v - means[k]) * rc['reset_factor']
                v += bank.get(k, 0) * (rc['next_season_bank_mult'] if major else 1)
                comps[k] = v
            new_cars.append((r, rng, eff, comps, bank))
        new_means = {k: sum(c[3][k] for c in new_cars) / len(new_cars) for k in repo.CAR_FIELDS}
        for r, rng, eff, comps, bank in new_cars:
            comps = {k: round(clamp(v - (new_means[k] - baseline[k]), 40, dc['component_max']), 3) for k, v in comps.items()}
            db.insert('car_performance', {'season_id': new_season, 'team_id': r['team_id'], **comps,
                                          'development_efficiency': round(clamp(eff + rng.gauss(0, 1.5), 45, 99), 2), 'update_ts': ts})
            db.insert('team_performance_history', {'season_id': new_season, 'team_id': r['team_id'], 'overall': overall_strength(comps, cm), 'components_json': jdump(comps),
                                                   'reason': 'coche de la nueva temporada' + (' (nuevo reglamento)' if major else '') + (f" + I+D temporada siguiente {sum(bank.values()):.2f}" if bank else ''),
                                                   'create_ts': ts})


def after_session(db, s, rows, field, source, rng, telemetry=None):
    """Management consequences of a finished session: wear/failures, damage costs, injuries, bonuses, milestones."""
    from fcm.management import records
    components.after_session(db, s, rows, field, source)
    if source == 'simulated' and s['type'] != 'practice': components.damage_from_sim(db, s, rows, rng)
    if telemetry and telemetry.get('max_damage'):
        pid = repo.career(db)['player_driver_id']
        r = next((x for x in rows if x['driver_id'] == pid), None)
        if r: components.damage_from_telemetry(db, s, pid, r['team_id'], telemetry['max_damage'])
    if source == 'simulated' and s['type'] in ('race', 'sprint'): market.maybe_injure(db, s, rows, rng)
    if s['type'] == 'race' and realism(db, 'finances'):
        for r in rows:
            if r.get('status') == 'FIN' and r.get('position') == 1:
                c = db.one("SELECT bonuses_json FROM contracts WHERE driver_id = ? AND team_id = ? AND status = 'active' ORDER BY id DESC LIMIT 1", (r['driver_id'], r['team_id']))
                bonus = jload(c['bonuses_json'], {}).get('per_win') if c else None
                if bonus and finance.row(db, s['season_id'], r['team_id']):
                    finance.tx(db, s['season_id'], s['round_id'], r['team_id'], 'driver_salary', -bonus, f"Bonus por victoria ({s['event_name']})", f"driver:{r['driver_id']}")
    records.milestones(db, s, rows)
