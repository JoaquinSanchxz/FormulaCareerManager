"""Power-unit elements, wear, reliability failures, grid penalties and damage.

Wear depends on use (session type), the car's reliability and the element's life.
Failure probability grows with wear (not pure RNG): p = base * weight * exp(k * (wear - 0.8)) * (1.15 - reliability/100).
Exceeding the regulation allocation creates grid penalties per the RegulationSet."""
import math

from fcm.career_engine import newsroom, repo
from fcm.database.db import jload, now_ts
from fcm.management import finance
from fcm.management.common import ai_controls, realism, season_teams, team_drivers
from fcm.shared import config
from fcm.shared.rng import rng_for


def cfg():
    return config.load('components')


def regulation(db, season_id, category_id):
    r = db.one('SELECT data_json FROM regulations WHERE season_id = ? AND category_id = ?', (season_id, category_id))
    return jload(r['data_json'], {}) if r else {}


def applies(db, championship_id):
    code = db.value('SELECT c.code FROM championships ch JOIN categories c ON c.id = ch.category_id WHERE ch.id = ?', (championship_id,))
    return code in cfg()['category_codes']


def init_season(db, season_id):
    for t in season_teams(db, season_id):
        if t['code'] not in cfg()['category_codes']: continue
        for d in team_drivers(db, season_id, t['team_id']): ensure_fitted(db, season_id, d['driver_id'], t['team_id'])


def ensure_fitted(db, season_id, driver_id, team_id):
    for kind in cfg()['kinds']:
        if not db.value("SELECT 1 FROM power_components WHERE season_id = ? AND driver_id = ? AND kind = ? AND status = 'fitted'", (season_id, driver_id, kind)):
            serial = (db.value('SELECT MAX(serial) FROM power_components WHERE season_id = ? AND driver_id = ? AND kind = ?', (season_id, driver_id, kind)) or 0) + 1
            db.insert('power_components', {'season_id': season_id, 'driver_id': driver_id, 'team_id': team_id, 'kind': kind, 'serial': serial, 'wear': 0, 'km': 0,
                                           'status': 'fitted', 'create_ts': now_ts()})


def fitted(db, season_id, driver_id):
    return {r['kind']: r for r in db.all("SELECT * FROM power_components WHERE season_id = ? AND driver_id = ? AND status = 'fitted'", (season_id, driver_id))}


def failure_probabilities(db, season_id, driver_id, reliability, session_type):
    c = cfg()
    share = c['wear_session_share'].get(session_type, 0.3)
    out = {}
    for kind, pc in fitted(db, season_id, driver_id).items():
        k = c['kinds'][kind]
        out[kind] = c['failure_base_per_weekend'] * share * k['failure_weight'] * math.exp(c['failure_wear_exponent'] * (pc['wear'] - 0.8)) * max(0.2, 1.15 - reliability / 100)
    return out


def pre_roll_failures(db, s, field, laps, rng):
    """Sim only: decide component failures before the session. Sets forced_dnf_lap/forced_dnf_reason on entries."""
    if not realism(db, 'failures') or s['type'] not in ('race', 'sprint') or not applies(db, s['championship_id']): return
    season_id = s['season_id']
    for f in field:
        for kind, p in failure_probabilities(db, season_id, f['driver_id'], f['car'].get('reliability', 80), s['type']).items():
            if rng.random() < p:
                f['forced_dnf_lap'] = rng.randint(1, max(1, laps))
                f['forced_dnf_reason'] = f'mechanical: {kind}'
                f['failed_component'] = kind
                break


def after_session(db, s, rows, field, source):
    """Wear for everyone, failed elements, component-driven DNF reasons."""
    if not applies(db, s['championship_id']): return
    c = cfg()
    share = c['wear_session_share'].get(s['type'], 0.2)
    by = {f['driver_id']: f for f in field}
    for r in rows:
        if r.get('status') == 'DNS': continue
        f = by.get(r['driver_id'])
        rel = f['car'].get('reliability', 80) if f else 80
        rel_factor = max(0.4, 1 + c['reliability_wear_factor'] * (80 - rel) / 20)
        done_share = share * (min(1.0, r['laps'] / max(1, s.get('laps') or r['laps'] or 1)) if s['type'] in ('race', 'sprint') else 1)
        for kind, pc in fitted(db, s['season_id'], r['driver_id']).items():
            wear = pc['wear'] + done_share / c['kinds'][kind]['life_weekends'] * rel_factor
            db.update('power_components', pc['id'], {'wear': round(wear, 4), 'km': pc['km'] + (r['laps'] or 0) * 5})
        if f and f.get('failed_component') and r['status'] == 'DNF':
            pc = fitted(db, s['season_id'], r['driver_id']).get(f['failed_component'])
            if pc:
                db.update('power_components', pc['id'], {'status': 'failed'})
                repo.emit(db, 'COMPONENT_FAILED', {'driver_id': r['driver_id'], 'kind': f['failed_component'], 'serial': pc['serial']}, season_id=s['season_id'], round_id=s['round_id'], session_id=s['id'])


def fit_new(db, season_id, driver_id, kind, reason='manual'):
    """Fits a new element. Beyond the regulation allocation -> grid penalty for the next race."""
    if kind not in cfg()['kinds']: raise ValueError('Componente desconocido')
    team_id, champ_id, cat_id = _team_of(db, season_id, driver_id)
    old = fitted(db, season_id, driver_id).get(kind)
    if old: db.update('power_components', old['id'], {'status': 'failed' if old['status'] == 'failed' else 'retired'})
    serial = (db.value('SELECT MAX(serial) FROM power_components WHERE season_id = ? AND driver_id = ? AND kind = ?', (season_id, driver_id, kind)) or 0) + 1
    db.insert('power_components', {'season_id': season_id, 'driver_id': driver_id, 'team_id': team_id, 'kind': kind, 'serial': serial, 'wear': 0, 'km': 0,
                                   'status': 'fitted', 'create_ts': now_ts()})
    tier = db.value('SELECT tier FROM categories WHERE id = ?', (cat_id,))
    cost = cfg()['kinds'][kind]['cost'] * (1 if tier == 1 else 0.1)
    if finance.row(db, season_id, team_id): finance.tx(db, season_id, None, team_id, 'components', -cost, f'{kind} nuevo #{serial}', f'driver:{driver_id}')
    reg = regulation(db, season_id, cat_id)
    limit = reg.get('component_limits', {}).get(kind)
    penalty = 0
    if limit and serial > limit:
        penalty = reg['grid_penalty_first'] if serial == limit + 1 else reg['grid_penalty_next']
        rnd = db.one("SELECT * FROM calendar_rounds WHERE season_id = ? AND status != 'completed' ORDER BY round_no LIMIT 1", (season_id,))
        if penalty and rnd:
            db.insert('penalties', {'season_id': season_id, 'round_id': rnd['id'], 'driver_id': driver_id, 'kind': 'grid', 'value': penalty,
                                    'reason': f'{kind} #{serial} supera el cupo ({limit})', 'applied': 0, 'create_ts': now_ts()})
            d = db.one('SELECT first_name, last_name FROM drivers WHERE id = ?', (driver_id,))
            ev = repo.emit(db, 'GRID_PENALTY', {'driver_id': driver_id, 'places': penalty, 'kind': kind}, season_id=season_id, round_id=rnd['id'])
            newsroom.grid_penalty(db, driver_id, penalty, kind, season_id, rnd['id'], ev)
    repo.emit(db, 'COMPONENT_FITTED', {'driver_id': driver_id, 'kind': kind, 'serial': serial, 'penalty': penalty, 'reason': reason}, season_id=season_id)
    return {'serial': serial, 'penalty': penalty}


def _team_of(db, season_id, driver_id):
    r = db.one('SELECT e.team_id, ch.id championship_id, ch.category_id FROM championship_entries e JOIN championships ch ON ch.id = e.championship_id WHERE ch.season_id = ? AND e.driver_id = ?',
               (season_id, driver_id))
    if not r: raise ValueError('El piloto no tiene asiento esta temporada')
    return r['team_id'], r['championship_id'], r['category_id']


def ai_tick(db, rnd):
    """Before each round: replace failed elements (all teams) and worn ones (AI), preferring tracks where overtaking is easy."""
    season_id = rnd['season_id']
    nxt = db.one("SELECT * FROM calendar_rounds WHERE season_id = ? AND status != 'completed' ORDER BY round_no LIMIT 1", (season_id,))
    easy = nxt and repo.track_profile(db, nxt['track_profile_id']).get('overtaking_difficulty', 0.5) < 0.45
    for t in season_teams(db, season_id):
        if t['code'] not in cfg()['category_codes']: continue
        ai = ai_controls(db, t['team_id'], season_id)
        limits = regulation(db, season_id, t['category_id']).get('component_limits', {})
        for d in team_drivers(db, season_id, t['team_id']):
            ensure_fitted_after_failure(db, season_id, d['driver_id'])
            if not ai: continue
            for kind, pc in fitted(db, season_id, d['driver_id']).items():
                within = pc['serial'] < limits.get(kind, 99)
                if pc['wear'] >= cfg()['ai_replace_wear'] and (within or easy or pc['wear'] > 1.05):
                    fit_new(db, season_id, d['driver_id'], kind, 'AI: worn element')


def ensure_fitted_after_failure(db, season_id, driver_id):
    for r in db.all("SELECT * FROM power_components WHERE season_id = ? AND driver_id = ? AND status = 'failed' AND id IN "
                    "(SELECT MAX(id) FROM power_components WHERE season_id = ? AND driver_id = ? GROUP BY kind)", (season_id, driver_id, season_id, driver_id)):
        if not fitted(db, season_id, driver_id).get(r['kind']): fit_new(db, season_id, driver_id, r['kind'], 'replacement after failure')


def apply_grid_penalties(db, s, order):
    """order: driver ids in grid order. Applies unapplied grid penalties of this round (Grand Prix only)."""
    if s['type'] != 'race': return order
    pens = db.all('SELECT * FROM penalties WHERE round_id = ? AND kind = ? AND applied = 0', (s['round_id'], 'grid'))
    if not pens: return order
    reg = regulation(db, s['season_id'], db.value('SELECT category_id FROM championships WHERE id = ?', (s['championship_id'],)))
    total = {}
    for p in pens:
        if p['driver_id'] in order: total[p['driver_id']] = total.get(p['driver_id'], 0) + p['value']
    if not total: return order
    n = len(order)
    moved = []
    for did, places in total.items():
        idx = order.index(did)
        target = n - 1 if places > reg.get('back_of_grid_over', 15) else min(n - 1, idx + places)
        moved.append((target, did))
    base = [d for d in order if d not in total]
    for target, did in sorted(moved):
        base.insert(min(target, len(base)), did)
    for p in pens:
        if p['driver_id'] in total: db.update('penalties', p['id'], {'applied': 1})
    return base


def damage_from_sim(db, s, rows, rng):
    """Sim incidents -> damaged parts with repair costs (mapped to real race components)."""
    out = []
    for r in rows:
        parts = []
        if r.get('status') == 'DNF' and r.get('dnf_reason') == 'incident':
            parts = [(rng.choice(['front_wing', 'floor', 'suspension', 'rear_wing']), rng.uniform(0.6, 1.0))]
            if rng.random() < 0.5: parts.append((rng.choice(['floor', 'suspension', 'gearbox']), rng.uniform(0.3, 0.8)))
        elif (r.get('incidents') or 0) > 0 and rng.random() < 0.3:
            parts = [('front_wing', rng.uniform(0.2, 0.5))]
        for part, sev in parts: out.append(_damage(db, s, r['driver_id'], r['team_id'], part, sev, 'simulated'))
    return out


def damage_from_telemetry(db, s, driver_id, team_id, max_damage):
    """Played sessions: player car damage sampled from shared memory carDamage[5] (front, rear, left, right, centre)."""
    scale = cfg().get('ac_damage_scale', 100.0)
    zones = {'front': 'front_wing', 'rear': 'rear_wing', 'left': 'suspension', 'right': 'suspension', 'centre': 'floor'}
    out = []
    for zone, value in (max_damage or {}).items():
        sev = min(1.0, float(value) / scale)
        if sev >= 0.05 and zone in zones: out.append(_damage(db, s, driver_id, team_id, zones[zone], sev, 'assetto_corsa'))
    return out


def _damage(db, s, driver_id, team_id, part, sev, source):
    cost = finance.damage_cost(db, s['season_id'], s['round_id'], team_id, part, sev, f"{s['event_name']} {s['code']}") if realism(db, 'finances') else 0
    db.insert('damage_reports', {'session_id': s['id'], 'driver_id': driver_id, 'team_id': team_id, 'component': part, 'severity': round(sev, 3), 'cost': cost,
                                 'source': source, 'create_ts': now_ts()})
    return {'driver_id': driver_id, 'part': part, 'severity': round(sev, 3), 'cost': cost}


def overview(db, season_id, team_id):
    t = next((x for x in season_teams(db, season_id) if x['team_id'] == team_id), None)
    limits = regulation(db, season_id, t['category_id']).get('component_limits', {}) if t else {}
    drivers = []
    for d in team_drivers(db, season_id, team_id):
        els = db.all('SELECT * FROM power_components WHERE season_id = ? AND driver_id = ? ORDER BY kind, serial', (season_id, d['driver_id']))
        drivers.append({**d, 'fitted': fitted(db, season_id, d['driver_id']), 'history': els,
                        'used': {k: (db.value('SELECT MAX(serial) FROM power_components WHERE season_id = ? AND driver_id = ? AND kind = ?', (season_id, d['driver_id'], k)) or 0) for k in cfg()['kinds']}})
    return {'limits': limits, 'kinds': cfg()['kinds'], 'drivers': drivers,
            'penalties': db.all('SELECT p.*, cr.round_no, cr.event_name FROM penalties p JOIN calendar_rounds cr ON cr.id = p.round_id WHERE p.season_id = ? AND p.driver_id IN '
                                '(SELECT driver_id FROM championship_entries e JOIN championships ch ON ch.id = e.championship_id WHERE ch.season_id = ? AND e.team_id = ?) ORDER BY p.id DESC', (season_id, season_id, team_id)),
            'damage': db.all('SELECT dr.*, s.code, cr.event_name FROM damage_reports dr JOIN sessions s ON s.id = dr.session_id JOIN calendar_rounds cr ON cr.id = s.round_id '
                             'WHERE dr.team_id = ? AND cr.season_id = ? ORDER BY dr.id DESC LIMIT 60', (team_id, season_id))}
