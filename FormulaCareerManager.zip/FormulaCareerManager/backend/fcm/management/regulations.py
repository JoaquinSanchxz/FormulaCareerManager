"""RegulationSet per season and category; scheduled major changes announced one season ahead."""
import copy

from fcm.career_engine import repo
from fcm.database.db import jdump, jload, now_ts
from fcm.shared import config


def is_major_year(db, year):
    rc = config.load('regulations')
    first = db.value('SELECT MIN(year) FROM seasons')
    if not first or not repo.career(db)['realism'].get('regulation_changes', False): return False
    k = year - first - rc['first_major_change_after']
    return k >= 0 and k % rc['major_change_every'] == 0


def init_season(db, season_id, year):
    rc = config.load('regulations')
    major = is_major_year(db, year)
    for ch in repo.championships(db, season_id):
        if db.value('SELECT 1 FROM regulations WHERE season_id = ? AND category_id = ?', (season_id, ch['category_id'])): continue
        data = copy.deepcopy(rc['default'].get(ch['category_code'], rc['default']['F1']))
        name = f"{year} {data['name']}" + (' (nueva era)' if major else '')
        db.insert('regulations', {'season_id': season_id, 'category_id': ch['category_id'], 'name': name, 'major_change': int(major), 'data_json': jdump(data), 'create_ts': now_ts()})
    if major: repo.emit(db, 'REGULATION_CHANGED', {'year': year}, season_id=season_id)
    if is_major_year(db, year + 1):
        ev = repo.emit(db, 'REGULATION_ANNOUNCED', {'year': year + 1}, season_id=season_id)
        from fcm.career_engine import newsroom
        newsroom.regulation(db, year, season_id, ev)


def current(db, season_id=None):
    season_id = season_id or repo.current_season(db)['id']
    year = db.value('SELECT year FROM seasons WHERE id = ?', (season_id,))
    rows = db.all('SELECT r.*, c.code FROM regulations r JOIN categories c ON c.id = r.category_id WHERE r.season_id = ?', (season_id,))
    for r in rows: r['data'] = jload(r.pop('data_json'), {})
    return {'regulations': rows, 'next_year_major': is_major_year(db, year + 1), 'this_year_major': is_major_year(db, year)}


def points_system_override(db, session):
    r = db.one('SELECT r.data_json FROM regulations r JOIN championships ch ON ch.category_id = r.category_id AND ch.season_id = r.season_id WHERE ch.id = ?', (session['championship_id'],))
    data = jload(r['data_json'], {}) if r else {}
    ov = data.get('points_system')
    if isinstance(ov, dict): return ov.get(session['code']) or session['points_system']
    return session['points_system']
