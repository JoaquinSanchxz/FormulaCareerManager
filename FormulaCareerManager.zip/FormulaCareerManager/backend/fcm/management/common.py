"""Shared lookups for the management layer (teams per season, tiers, player team, realism flags)."""
from fcm.career_engine import repo


def realism(db, key, default=True):
    return bool(repo.career(db)['realism'].get(key, default))


def setting(db, key, default=None):
    return repo.career(db)['settings'].get(key, default)


def season_teams(db, season_id):
    """[{team_id, name, championship_id, category_id, code, tier}] for every team entered this season."""
    return db.all('SELECT DISTINCT e.team_id, t.name, t.reputation, ch.id championship_id, ch.category_id, c.code, c.tier FROM championship_entries e '
                  'JOIN championships ch ON ch.id = e.championship_id JOIN categories c ON c.id = ch.category_id JOIN teams t ON t.id = e.team_id '
                  'WHERE ch.season_id = ? ORDER BY c.tier, e.team_id', (season_id,))


def team_info(db, season_id, team_id):
    return next((t for t in season_teams(db, season_id) if t['team_id'] == team_id), None)


def team_drivers(db, season_id, team_id, roles=('D1', 'D2', 'D3')):
    marks = ','.join('?' for _ in roles)
    return db.all(f'SELECT e.driver_id, e.role, e.championship_id, d.first_name, d.last_name, d.is_player FROM championship_entries e JOIN championships ch ON ch.id = e.championship_id '
                  f'JOIN drivers d ON d.id = e.driver_id WHERE ch.season_id = ? AND e.team_id = ? AND e.active = 1 AND e.role IN ({marks}) ORDER BY e.role', (season_id, team_id, *roles))


def player_team_id(db, season_id=None):
    season_id = season_id or repo.current_season(db)['id']
    pid = repo.career(db)['player_driver_id']
    return db.value('SELECT e.team_id FROM championship_entries e JOIN championships ch ON ch.id = e.championship_id WHERE ch.season_id = ? AND e.driver_id = ? AND e.active = 1',
                    (season_id, pid))


def ai_controls(db, team_id, season_id=None):
    """True when the AI makes this team's decisions (every team except the player's, unless delegated)."""
    return team_id != player_team_id(db, season_id) or bool(setting(db, 'delegate_team_management', False))


def rounds_in_championship(db, championship_id):
    return db.value('SELECT COUNT(DISTINCT round_id) FROM sessions WHERE championship_id = ?', (championship_id,)) or 1


def completed_rounds(db, championship_id):
    return db.value("SELECT COUNT(DISTINCT s.round_id) FROM sessions s JOIN calendar_rounds cr ON cr.id = s.round_id WHERE s.championship_id = ? AND cr.status = 'completed'",
                    (championship_id,)) or 0


def upcoming_rounds(db, season_id, n=3):
    return db.all("SELECT * FROM calendar_rounds WHERE season_id = ? AND status != 'completed' ORDER BY round_no LIMIT ?", (season_id, n))


DIFFICULTY_MULT = {'easy': 1.15, 'normal': 1.0, 'hard': 0.85}


def difficulty_mult(db, system, team_id=None, season_id=None):
    """Player-chosen difficulty per system (career / economy / development). Applies only to the player's team:
    it is a fixed choice made by the player, never a reaction to results (no rubber-banding)."""
    if team_id is not None and team_id != player_team_id(db, season_id): return 1.0
    return DIFFICULTY_MULT.get(repo.career(db)['difficulty'].get(system, 'normal'), 1.0)


def tier_key(tier):
    return str(min(3, max(1, int(tier))))
