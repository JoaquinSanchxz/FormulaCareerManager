"""Dynamic weather. A session gets a plan (weather states over session progress 0..1) drawn from the round climate;
the same plan drives the simulator (track wetness lap by lap) and the CSP weather controller in AC (AC_INTEGRATION.md §7b).
Seeded -> reproducible."""
import math

from fcm.simulation.model import clamp


def plan(rng, clim, wcfg, unstable):
    """Markov chain over the ladder clear..storm. Stable sessions never go past `stable_top`; unstable ones drift into rain and out."""
    ladder = wcfg['ladder']
    weights = wcfg['unstable_start'] if unstable else clim['weathers']
    state = rng.choices(list(weights), weights=list(weights.values()))[0]
    out = [{'at': 0.0, 'state': state}]
    top = len(ladder) - 1 if unstable else ladder.index(wcfg['stable_top'])
    n = wcfg['segments']
    p_change = wcfg['change_probability'] * (wcfg['unstable_change_mult'] if unstable else 1)
    for k in range(1, n):
        if rng.random() >= p_change: continue
        i = ladder.index(state) if state in ladder else ladder.index('broken')      # fog lifts into clouds
        wet_now = i >= ladder.index('drizzle')
        up = (wcfg['worsen_bias_unstable_wet'] if wet_now else wcfg['worsen_bias_unstable_dry']) if unstable else 0.5
        step = rng.choice([1, 1, 1, 2])
        i = int(clamp(i + (step if rng.random() < up else -step), 0, top))
        if ladder[i] == state: continue
        state = ladder[i]
        out.append({'at': round(clamp(k / n + rng.uniform(-0.3, 0.3) / n, 0.02, 0.98), 3), 'state': state})
    return out


def state_at(pl, p):
    cur = pl[0]['state']
    for seg in pl:
        if seg['at'] <= p: cur = seg['state']
    return cur


def wetness_curve(pl, steps, states, wcfg, start=None):
    """Track wetness at the middle of each of `steps` equal slices: rises quickly with rain, dries slowly."""
    w = states[pl[0]['state']]['wet'] if start is None else start
    out = []
    for k in range(steps):
        target = states[state_at(pl, (k + 0.5) / steps)]['wet']
        tau = wcfg['rise_tau'] if target > w else wcfg['dry_tau']
        w += (target - w) * (1 - math.exp(-1 / steps / tau))
        out.append(round(w, 3))
    return out


def wet_at(curve, p):
    return curve[int(clamp(p, 0, 0.9999) * len(curve))] if curve else 0.0


def forecast(pl, states):
    """'Nuboso → Lluvia (35 %) → Cubierto'"""
    return ' → '.join(states[x['state']]['name'] + (f" ({round(x['at'] * 100)} %)" if x['at'] else '') for x in pl)


def is_wet(pl, states):
    return any(states[x['state']]['wet'] >= 0.2 for x in pl)
