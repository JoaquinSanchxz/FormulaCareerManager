"""Lap-by-lap probabilistic session simulator.

Used for sessions the player does not drive and for all other categories. Never sorts by
rating: every lap combines car-at-track strength, driver attributes, form, morale, tyre wear,
noise, mistakes, overtaking difficulty, reliability, incidents, safety cars and pit stops.
Weather: ctx['wet'] is the mean track wetness 0..1; ctx['wet_laps'] / ctx['wet_runs'] give it lap by lap (dynamic weather),
drivers switch slicks / intermediates / wets when the gain pays the pit stop.
Seeded RNG -> reproducible.
"""
from fcm.simulation.model import car_track_strength, clamp, interp, morale_effect, weighted


def _driver_score(e, inputs, wet, pcfg, scfg):
    d = weighted(e['attrs'], inputs) + e.get('form', 0) + morale_effect(e.get('morale', 60), pcfg['morale'])
    if wet: d += 0.35 * float(wet) * (e['attrs']['wet_skill'] - d)
    return d


def _pace(e, inputs, ctx, wet=None):
    scfg = ctx['scfg']
    w = float(ctx['wet'] if wet is None else wet)
    car = car_track_strength(e['car'], ctx['profile'], ctx['car_cfg'])
    drv = _driver_score(e, inputs, w, ctx['pcfg'], scfg)
    perf = scfg['car_weight'] * car + scfg['driver_weight'] * drv
    lap = ctx['base_lap_s'] * (1 + scfg['laptime_per_point'] * (100 - perf)) * _wet_mult(scfg, 'wet_laptime_mult', w)
    return lap, perf, car, drv


def _wet_mult(s, key, w):
    return 1 + (s[key] - 1) * w


SLICKS = ('S', 'M', 'H')


def _family(comp):
    return 'slick' if comp in SLICKS else comp


def _wet_pen(tc, fam, w):
    return interp(tc['wet_penalty'][fam], w) if tc.get('wet_penalty') else 0.0


def _best_family(tc, w):
    return min(('slick', 'I', 'W'), key=lambda k: _wet_pen(tc, k, w)) if tc.get('wet_penalty') else 'slick'


def _slick_for(rem, tc):
    return 'S' if rem <= tc['cliff_laps']['S'] else 'M' if rem <= tc['cliff_laps']['M'] else 'H'


def expected_perf(e, session_type, ctx):
    """Noise-free performance used as the 'expected result' baseline for rating evidence."""
    s = ctx['scfg']
    return _pace(e, s['qualifying_inputs'] if session_type == 'qualifying' else s['race_inputs'], ctx)[1]


def _noise_sd(e, ctx):
    s = ctx['scfg']
    return s['lap_noise_base_pct'] + s['lap_noise_consistency_pct'] * (100 - e['attrs']['consistency']) / 100


def simulate(entries, session_type, ctx, rng):
    """entries: [{driver_id, team_id, attrs, form, morale, car{components}, grid_position?}]
    ctx: {scfg, pcfg, car_cfg, profile, base_lap_s, laps, wet}"""
    if 'day' not in ctx: ctx = dict(ctx, day=day_factors(entries, ctx['scfg'], rng))
    if session_type in ('practice', 'qualifying'): return _simulate_timed(entries, session_type, ctx, rng)
    return _simulate_race(entries, ctx, rng)


def day_factors(entries, scfg, rng):
    """Per-session 'form of the day' (car set-up fit per team + driver day). Shared by all knockout stages."""
    team_fit, out = {}, {}
    for e in entries:
        if e['team_id'] not in team_fit: team_fit[e['team_id']] = rng.gauss(0, scfg.get('team_session_sd_pct', 0))
        out[e['driver_id']] = team_fit[e['team_id']] + rng.gauss(0, scfg.get('driver_session_sd_pct', 0))
    return out


def _simulate_timed(entries, session_type, ctx, rng):
    s = ctx['scfg']
    runs = ctx.get('runs') or (s['qualifying_runs'] if session_type == 'qualifying' else s['practice_laps_equivalent'])
    tc = s.get('tyres') or {}
    wr = ctx.get('wet_runs') or [float(ctx['wet'])] * runs
    out = []
    for e in entries:
        inputs = s['qualifying_inputs'] if session_type == 'qualifying' else s['race_inputs']
        perf = _pace(e, inputs, ctx)[1]
        sd0 = s['qualifying_noise_pct'] * (1 + (100 - e['attrs']['consistency']) / 100)
        best, incidents, laps = None, 0, []
        for k in range(runs):
            w = wr[min(k, len(wr) - 1)]
            pace = _pace(e, inputs, ctx, w)[0] * (1 + ctx['day'][e['driver_id']] - ctx.get('evolution', 0.0))
            if session_type == 'practice': pace *= 1.004  # teams do not show everything in practice
            fam = _best_family(tc, w)
            pace *= 1 + _wet_pen(tc, fam, w) + (tc['S']['pace'] if fam == 'slick' and 'S' in tc else 0)
            t = pace * (1 + rng.gauss(0, sd0 * _wet_mult(s, 'wet_noise_mult', w)))
            if rng.random() < s['mistake_probability'] * (1 + (80 - e['attrs']['awareness']) / 40):
                t += rng.uniform(*s['mistake_cost_s'])
                incidents += 1
            laps.append(int(t * 1000))
            best = t if best is None or t < best else best
        out.append({'driver_id': e['driver_id'], 'team_id': e['team_id'], 'best_lap_ms': int(best * 1000), 'laps': runs,
                    'total_time_ms': None, 'status': 'FIN', 'dnf_reason': None, 'pit_stops': 0, 'incidents': incidents, 'lap_times': laps,
                    'perf': round(perf, 3)})
    out.sort(key=lambda r: r['best_lap_ms'])
    for i, r in enumerate(out, start=1):
        r['position'] = i
        r['gap_ms'] = r['best_lap_ms'] - out[0]['best_lap_ms']
        r['grid_position'] = None
    return out


def _simulate_race(entries, ctx, rng):
    s = ctx['scfg']
    prof = ctx['profile']
    L = max(1, int(ctx['laps']))
    wl = ctx.get('wet_laps') or [float(ctx['wet'])] * L
    tc = s.get('tyres') or {}
    dynamic = bool(tc.get('wet_penalty')) and max(wl) >= 0.12
    n = len(entries)
    order = sorted(range(n), key=lambda i: entries[i].get('grid_position') or 99)
    st = []
    for gi, i in enumerate(order):
        e = entries[i]
        pace, perf, car, drv = _pace(e, s['race_inputs'], ctx, 0.0)
        pace *= 1 + ctx['day'][e['driver_id']]
        strat = e.get('strategy') or default_strategy(L, prof, rng, s, ctx.get('category'), wl[0])
        pit_laps = list(strat['pit_laps'])
        tyre_mult = 1 + s['tyre_mgmt_effect'] * (75 - e['attrs']['tyre_management']) / 25 + (75 - e['car'].get('tyre_usage', 75)) / 50
        st.append({'i': i, 'e': e, 'pace': pace, 'perf': perf, 'cum': gi * 0.25, 'alive': True, 'laps': 0, 'lap_times': [],
                   'tyre_age': 0, 'pit_laps': pit_laps, 'compounds': list(strat['compounds']), 'stint': 0, 'stops': 0, 'incidents': 0, 'dnf_reason': None,
                   'tyre_mult': max(0.3, tyre_mult), 'sd': _noise_sd(e, ctx), 'grid': gi + 1, 'adapted': False,
                   'gamble': rng.uniform(*tc.get('weather_gamble', [1, 1]))})
    # start: reaction/launch spread positions a little
    for c in st:
        a = c['e']['attrs']
        c['cum'] -= (rng.gauss(0, s['start_sd_positions']) + (a['starts'] - 75) * s['start_skill_weight']) * 0.25
    diff = prof.get('overtaking_difficulty', 0.5)
    deg = s['tyre_deg_s_per_lap'] * (0.5 + prof.get('tyre_importance', 0.5))
    for lap in range(1, L + 1):
        running = sorted((c for c in st if c['alive']), key=lambda c: c['cum'])
        incident_this_lap = False
        w = wl[lap - 1]
        for c in running:
            a = c['e']['attrs']
            if w != wl[0] or lap == 1: c['pace'] = _pace(c['e'], s['race_inputs'], ctx, w)[0] * (1 + ctx['day'][c['e']['driver_id']])
            if dynamic: _weather_call(c, lap, L, w, s, tc)
            t = c['pace'] + c['pace'] * rng.gauss(0, c['sd'] * _wet_mult(s, 'wet_noise_mult', w)) + _tyre_time(c, deg, s, w)
            if rng.random() < s['mistake_probability'] * (1 + (80 - a['awareness']) / 40): t += rng.uniform(*s['mistake_cost_s'])
            if lap in c['pit_laps']:
                t += max(15.0, rng.gauss(s['pit_loss_s'], s['pit_loss_sd']))
                c['tyre_age'] = 0
                c['stops'] += 1
                c['stint'] = min(c['stint'] + 1, len(c['compounds']) - 1)
            else:
                c['tyre_age'] += 1
            rel = c['e']['car'].get('reliability', 80)
            p_mech = s['dnf_mechanical_per_lap'] * max(0.2, 1 + (85 - rel) / 15)
            p_inc = s['dnf_incident_per_lap'] * max(0.3, 1 + (80 - a['awareness']) / 20) * _wet_mult(s, 'wet_incident_mult', w)
            if c['compounds'][c['stint']] in SLICKS and w > 0.35: p_inc *= 1 + 4 * (w - 0.35)   # slicks on a wet track
            if lap == 1: p_inc += s['lap1_incident'] * max(0.3, 1 + (80 - a['awareness']) / 20)
            r = rng.random()
            if c['e'].get('forced_dnf_lap') == lap:  # pre-rolled component failure (management layer)
                c['alive'] = False
                c['dnf_reason'] = c['e'].get('forced_dnf_reason', 'mechanical')
                continue
            if r < p_mech or r < p_mech + p_inc:
                c['alive'] = False
                c['dnf_reason'] = 'mechanical' if r < p_mech else 'incident'
                c['incidents'] += 1 if c['dnf_reason'] == 'incident' else 0
                incident_this_lap = incident_this_lap or c['dnf_reason'] == 'incident'
                continue
            c['new_cum'] = c['cum'] + t
            c['last'] = t
        # overtaking resolution front to back
        alive = [c for c in running if c['alive']]
        for k in range(1, len(alive)):
            c, ahead = alive[k], alive[k - 1]
            if c['new_cum'] < ahead['new_cum'] + 0.05:
                gain = ahead['new_cum'] - c['new_cum']
                ac, ad = c['e']['attrs'], ahead['e']['attrs']
                p = s['overtake_base'] * (1 - diff) + s['overtake_pace_scale'] * min(1.0, gain) + (ac['overtaking'] - ad['defending']) / 150
                if rng.random() > clamp(p, 0.03, 0.97):
                    c['new_cum'] = ahead['new_cum'] + s['stuck_gap_s']
                    alive.sort(key=lambda x: x['new_cum'])
        for c in alive:
            c['last'] = c['new_cum'] - (0 if lap == 1 else c['cum'])
            c['cum'] = c['new_cum']
            c['laps'] = lap
            c['lap_times'].append(int(c['last'] * 1000))
        if incident_this_lap and rng.random() < s['safety_car_on_incident'] and lap < L:
            alive.sort(key=lambda x: x['cum'])
            lead = alive[0]['cum'] if alive else 0
            for k, c in enumerate(alive):
                new = min(c['cum'], lead + k * s['safety_car_gap_s'])
                c['lap_times'][-1] += int((new - c['cum']) * 1000)
                c['cum'] = new
    finishers = sorted((c for c in st if c['alive']), key=lambda c: c['cum'])
    out = []
    lead_time = finishers[0]['cum'] if finishers else 0
    for c in finishers:
        avg = c['cum'] / max(1, c['laps'])
        down = max(0, int((c['cum'] - lead_time) / avg)) if avg else 0
        laps_done = L - down
        total = sum(c['lap_times'][:laps_done])
        out.append((c, laps_done, total, 'FIN'))
    for c in sorted((c for c in st if not c['alive']), key=lambda c: (-c['laps'], -c['cum'])):
        out.append((c, c['laps'], sum(c['lap_times']), 'DNF'))
    res = []
    lead_total = out[0][2] if out else 0
    for pos, (c, laps_done, total, status) in enumerate(out, start=1):
        best = min(c['lap_times']) if c['lap_times'] else None
        res.append({'driver_id': c['e']['driver_id'], 'team_id': c['e']['team_id'], 'position': pos, 'grid_position': c['grid'],
                    'laps': laps_done, 'total_time_ms': total, 'best_lap_ms': best,
                    'gap_ms': (total - lead_total) if status == 'FIN' and laps_done == L else None, 'status': status,
                    'dnf_reason': c['dnf_reason'], 'pit_stops': c['stops'], 'incidents': c['incidents'], 'lap_times': c['lap_times'],
                    'perf': round(c['perf'], 3), 'strategy': '-'.join(c['compounds'][:c['stint'] + 1])})
    return res


def _weather_call(c, lap, L, w, s, tc):
    """Switch slicks/inters/wets when the time gained over the next laps pays the pit stop (per-driver gamble factor).
    After a weather stop the planned dry stops are dropped and worn slicks are replaced by the compound that reaches the flag."""
    rem = L - lap
    if rem < 2: return
    cur = c['compounds'][c['stint']]
    fam, best = _family(cur), _best_family(tc, w)
    new = None
    if best != fam:
        gain = (_wet_pen(tc, fam, w) - _wet_pen(tc, best, w)) * c['pace'] * min(rem, tc['weather_lookahead_laps'])
        if gain > s['pit_loss_s'] * c['gamble']: new = best if best != 'slick' else _slick_for(rem, tc)
    elif c['adapted'] and fam == 'slick' and c['tyre_age'] > tc['cliff_laps'].get(cur, 30) + 2 and rem > 4:
        new = _slick_for(rem, tc)
    if new:
        c['compounds'] = c['compounds'][:c['stint'] + 1] + [new]
        c['pit_laps'] = [lap]
        c['adapted'] = True


def _tyre_time(c, deg, s, w=0.0):
    tc = s.get('tyres')
    if not tc: return deg * c['tyre_age'] * c['tyre_mult']
    comp = c['compounds'][c['stint']]
    t = tc.get(comp, tc['M'])
    dm = t['deg'] * (1 + tc.get('dry_overheat', 0) * max(0.0, 0.25 - w)) if comp not in SLICKS else t['deg']
    wear = deg * c['tyre_age'] * c['tyre_mult'] * dm
    cliff = tc['cliff_laps'].get(comp, 30)
    if c['tyre_age'] > cliff: wear += deg * (c['tyre_age'] - cliff) * tc['cliff_age_factor']
    return c['pace'] * (t['pace'] + _wet_pen(tc, _family(comp), w)) + wear


def default_strategy(laps, profile, rng, scfg, category=None, wet=False):
    """Plausible AI strategy: number of stops from tyre importance, compounds, stint lengths by compound life.
    On a wet start: intermediates or wets, stops decided lap by lap by the weather."""
    tc = scfg.get('tyres')
    if tc and tc.get('wet_penalty') and wet and _best_family(tc, float(wet)) != 'slick':
        return {'compounds': [_best_family(tc, float(wet))], 'pit_laps': []}
    if (wet and float(wet) >= 0.2) or not tc:
        stops = int(interp(scfg['stops_by_tyre_importance'], profile.get('tyre_importance', 0.5))) if laps > 6 else 0
        return {'compounds': ['M'] * (stops + 1), 'pit_laps': _even_pits(laps, [1] * (stops + 1), rng)}
    need_two = category in tc.get('mandatory_two_compounds', []) and laps >= 10
    stops = int(interp(scfg['stops_by_tyre_importance'], profile.get('tyre_importance', 0.5))) if laps >= 10 else 0
    if stops == 0:
        comps = [rng.choice(['S', 'M'])] if not need_two else ['M', 'H']
        if need_two: stops = 1
    elif stops == 1:
        comps = rng.choices([['M', 'H'], ['H', 'M'], ['S', 'H'], ['S', 'M']], weights=[5, 2, 3, 1])[0]
    else:
        comps = rng.choices([['S', 'M', 'H'], ['M', 'H', 'M'], ['S', 'H', 'S'], ['M', 'M', 'H']], weights=[4, 3, 1, 2])[0]
    return {'compounds': comps, 'pit_laps': _even_pits(laps, [tc['cliff_laps'].get(x, 25) for x in comps], rng)}


def _even_pits(laps, lives, rng):
    if len(lives) <= 1 or laps < 4: return []
    total = sum(lives)
    out, acc = [], 0
    for life in lives[:-1]:
        acc += life / total * laps
        out.append(int(clamp(round(acc + rng.uniform(-0.06, 0.06) * laps), 2, laps - 1)))
    return sorted(set(out))


def validate_strategy(strategy, laps, category=None, scfg=None, dry=True):
    """Returns (ok, message). Player strategies must be coherent; F1 dry races need two slick compounds."""
    comps, pits = strategy.get('compounds') or [], sorted(strategy.get('pit_laps') or [])
    tc = (scfg or {}).get('tyres', {})
    if not comps or any(c not in ('S', 'M', 'H', 'I', 'W') for c in comps): return False, 'Compuestos no válidos (S, M, H, I, W)'
    if len(pits) != len(comps) - 1: return False, 'Debe haber una parada entre cada stint'
    if any(p < 1 or p >= laps for p in pits) or len(set(pits)) != len(pits): return False, f'Las vueltas de parada deben estar entre 1 y {laps - 1}'
    if dry and all(c in SLICKS for c in comps) and category in tc.get('mandatory_two_compounds', []) and laps >= 10 and len(set(comps)) < 2:
        return False, 'En F1 en seco es obligatorio usar al menos dos compuestos distintos'
    return True, 'ok'
