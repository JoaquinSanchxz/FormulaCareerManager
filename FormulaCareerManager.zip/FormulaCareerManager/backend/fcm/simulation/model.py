"""Pure performance model helpers shared by simulation, rating and AC translation."""
import math

ATTRIBUTES = ('pace', 'qualifying', 'racecraft', 'awareness', 'consistency', 'tyre_management', 'wet_skill', 'starts',
              'defending', 'overtaking', 'adaptability', 'experience')
TRACK_KEYS = ('power_importance', 'drag_importance', 'low_speed_importance', 'medium_speed_importance', 'high_speed_importance',
              'traction_importance', 'braking_importance', 'tyre_importance')


def interp(points, x):
    """Piecewise-linear interpolation over [[x, y], ...] (sorted by x), clamped at the ends."""
    if x <= points[0][0]: return points[0][1]
    for (x0, y0), (x1, y1) in zip(points, points[1:]):
        if x <= x1: return y0 + (y1 - y0) * (x - x0) / (x1 - x0)
    return points[-1][1]


def clamp(v, lo, hi):
    return max(lo, min(hi, v))


def weighted(attrs: dict, weights: dict) -> float:
    total = sum(weights.values())
    return sum(attrs[k] * w for k, w in weights.items()) / total


def base_rating(attrs: dict, weights: dict) -> float:
    return round(weighted(attrs, weights), 4)


def morale_effect(morale, mcfg) -> float:
    return clamp((morale - mcfg['neutral']) / (mcfg['max'] - mcfg['neutral']), -1, 1) * mcfg['max_effect']


def effective_rating(base, form, morale, mcfg) -> float:
    return base + form + morale_effect(morale, mcfg)


def overall_strength(car: dict, car_cfg: dict) -> float:
    return round(weighted(car, car_cfg['overall_weights']), 3)


def car_track_strength(car: dict, profile: dict, car_cfg: dict) -> float:
    """Track-specific car strength: components weighted by the track's importance profile."""
    weights = dict(car_cfg.get('always_weights', {}))
    for key, comps in car_cfg['track_mapping'].items():
        imp = float(profile.get(key, 0.5))
        for comp, share in comps.items(): weights[comp] = weights.get(comp, 0) + imp * share
    return round(weighted(car, weights), 3)


def logistic(x):
    return 1.0 / (1.0 + math.exp(-x))


def expected_positions(strengths: list, sigma: float) -> list:
    """Expected finishing position of each entry = 1 + sum_j P(j beats i)."""
    out = []
    for i, si in enumerate(strengths):
        out.append(1 + sum(logistic((sj - si) / sigma) for j, sj in enumerate(strengths) if j != i))
    return out
