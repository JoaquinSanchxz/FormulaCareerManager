"""SQLite access + versioned migrations.

Two database kinds:
- 'app'    : global settings + installed AC content catalog (one per user).
- 'career' : one file per career save (portable: export/import = copy file).
Migrations are plain SQL files in migrations/<kind>/NNN_name.sql applied in order.
"""
import json
import sqlite3
import threading
from datetime import datetime, timezone
from pathlib import Path

from fcm.shared import log

_log = log.get('DATABASE')
MIGRATIONS_DIR = Path(__file__).parent / 'migrations'


def now_ts() -> str:
    return datetime.now(timezone.utc).strftime('%Y-%m-%dT%H:%M:%SZ')


class Database:
    """Thread-safe wrapper (single connection guarded by a re-entrant lock)."""

    def __init__(self, path, kind):
        self.path = Path(path)
        self.kind = kind
        self.lock = threading.RLock()
        self.conn = sqlite3.connect(str(self.path), check_same_thread=False, isolation_level=None)
        self.conn.row_factory = sqlite3.Row
        self.conn.execute('PRAGMA foreign_keys = ON')
        self.conn.execute('PRAGMA journal_mode = DELETE')
        self.migrate()

    # --- migrations -------------------------------------------------------------------
    def migrate(self):
        with self.lock:
            self.conn.execute('CREATE TABLE IF NOT EXISTS schema_migrations (version INTEGER PRIMARY KEY, name TEXT NOT NULL, applied_ts TEXT NOT NULL)')
            done = {r[0] for r in self.conn.execute('SELECT version FROM schema_migrations')}
            for f in sorted((MIGRATIONS_DIR / self.kind).glob('*.sql')):
                version = int(f.name.split('_', 1)[0])
                if version in done: continue
                _log.info('Applying %s migration %s to %s', self.kind, f.name, self.path.name)
                sql = f.read_text(encoding='utf-8')
                try:
                    self.conn.execute('BEGIN')
                    for stmt in _split_sql(sql):
                        self.conn.execute(stmt)
                    self.conn.execute('INSERT INTO schema_migrations (version, name, applied_ts) VALUES (?, ?, ?)', (version, f.name, now_ts()))
                    self.conn.execute('COMMIT')
                except Exception:
                    self.conn.execute('ROLLBACK')
                    raise

    def schema_version(self):
        r = self.one('SELECT MAX(version) v FROM schema_migrations')
        return r['v'] if r else 0

    # --- helpers ----------------------------------------------------------------------
    def all(self, sql, params=()):
        with self.lock:
            return [dict(r) for r in self.conn.execute(sql, params).fetchall()]

    def one(self, sql, params=()):
        with self.lock:
            r = self.conn.execute(sql, params).fetchone()
            return dict(r) if r else None

    def value(self, sql, params=()):
        with self.lock:
            r = self.conn.execute(sql, params).fetchone()
            return r[0] if r else None

    def execute(self, sql, params=()):
        with self.lock:
            return self.conn.execute(sql, params)

    def insert(self, table, data: dict) -> int:
        cols = ', '.join(data)
        marks = ', '.join('?' for _ in data)
        with self.lock:
            return self.conn.execute(f'INSERT INTO {table} ({cols}) VALUES ({marks})', tuple(data.values())).lastrowid

    def update(self, table, id_, data: dict, key='id'):
        sets = ', '.join(f'{k} = ?' for k in data)
        with self.lock:
            self.conn.execute(f'UPDATE {table} SET {sets} WHERE {key} = ?', (*data.values(), id_))

    def transaction(self):
        return _Tx(self)

    def close(self):
        with self.lock:
            self.conn.close()


class _Tx:
    def __init__(self, db):
        self.db = db
        self.nested = False

    def __enter__(self):
        self.db.lock.acquire()
        self.nested = self.db.conn.in_transaction
        if not self.nested: self.db.conn.execute('BEGIN')
        return self.db

    def __exit__(self, exc_type, exc, tb):
        try:
            if not self.nested: self.db.conn.execute('ROLLBACK' if exc_type else 'COMMIT')
        finally:
            self.db.lock.release()
        return False


def _split_sql(sql):
    """Split on ';' at line ends (migrations do not contain triggers with inner ';')."""
    parts, buf = [], []
    for line in sql.splitlines():
        if line.strip().startswith('--'): continue
        buf.append(line)
        if line.rstrip().endswith(';'):
            stmt = '\n'.join(buf).strip()
            if stmt: parts.append(stmt)
            buf = []
    tail = '\n'.join(buf).strip()
    if tail: parts.append(tail)
    return parts


def jdump(obj) -> str:
    return json.dumps(obj, ensure_ascii=False, separators=(',', ':'))


def jload(text, default=None):
    if text in (None, ''): return default
    try:
        return json.loads(text)
    except ValueError:
        return default
