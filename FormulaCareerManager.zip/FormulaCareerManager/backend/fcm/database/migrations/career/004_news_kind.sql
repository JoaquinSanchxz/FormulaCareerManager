-- News with a section (carrera, mercado, técnica…) and the protagonists, so the UI can show icons, colours and pictures.

ALTER TABLE news ADD COLUMN kind TEXT NOT NULL DEFAULT 'general';
ALTER TABLE news ADD COLUMN team_id INTEGER;
ALTER TABLE news ADD COLUMN driver_id INTEGER;
