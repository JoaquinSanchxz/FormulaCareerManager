-- Career save database (one file per career).

CREATE TABLE career (
  id INTEGER PRIMARY KEY CHECK (id = 1),
  name TEXT NOT NULL,
  seed INTEGER NOT NULL,
  player_driver_id INTEGER,
  current_season_id INTEGER,
  difficulty_json TEXT NOT NULL DEFAULT '{}',
  realism_json TEXT NOT NULL DEFAULT '{}',
  settings_json TEXT NOT NULL DEFAULT '{}',
  app_version TEXT,
  create_ts TEXT NOT NULL,
  update_ts TEXT NOT NULL
);

CREATE TABLE categories (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  code TEXT NOT NULL UNIQUE,
  name TEXT NOT NULL,
  tier INTEGER NOT NULL,
  config_json TEXT NOT NULL
);

CREATE TABLE seasons (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  year INTEGER NOT NULL UNIQUE,
  status TEXT NOT NULL DEFAULT 'active',
  seed INTEGER NOT NULL,
  create_ts TEXT NOT NULL
);

CREATE TABLE championships (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  season_id INTEGER NOT NULL REFERENCES seasons(id),
  category_id INTEGER NOT NULL REFERENCES categories(id),
  ac_car_id TEXT,
  player_mode TEXT NOT NULL DEFAULT 'simulate',
  status TEXT NOT NULL DEFAULT 'active',
  rules_json TEXT NOT NULL DEFAULT '{}',
  UNIQUE (season_id, category_id)
);

CREATE TABLE teams (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  name TEXT NOT NULL,
  short_name TEXT NOT NULL,
  country TEXT,
  color TEXT,
  category_id INTEGER REFERENCES categories(id),
  reputation REAL NOT NULL DEFAULT 50,
  create_ts TEXT NOT NULL
);

CREATE TABLE drivers (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  first_name TEXT NOT NULL,
  last_name TEXT NOT NULL,
  short_name TEXT NOT NULL,
  nationality TEXT,
  birth_date TEXT,
  is_player INTEGER NOT NULL DEFAULT 0,
  is_generated INTEGER NOT NULL DEFAULT 0,
  potential REAL NOT NULL,
  reputation REAL NOT NULL DEFAULT 50,
  experience_races INTEGER NOT NULL DEFAULT 0,
  morale REAL NOT NULL DEFAULT 60,
  form REAL NOT NULL DEFAULT 0,
  development_rate REAL NOT NULL DEFAULT 1,
  personality TEXT,
  market_value REAL NOT NULL DEFAULT 0,
  progress_json TEXT NOT NULL DEFAULT '{}',
  retired INTEGER NOT NULL DEFAULT 0,
  retired_season INTEGER,
  create_ts TEXT NOT NULL,
  update_ts TEXT NOT NULL
);

CREATE TABLE driver_attributes (
  driver_id INTEGER PRIMARY KEY REFERENCES drivers(id) ON DELETE CASCADE,
  pace REAL NOT NULL,
  qualifying REAL NOT NULL,
  racecraft REAL NOT NULL,
  awareness REAL NOT NULL,
  consistency REAL NOT NULL,
  tyre_management REAL NOT NULL,
  wet_skill REAL NOT NULL,
  starts REAL NOT NULL,
  defending REAL NOT NULL,
  overtaking REAL NOT NULL,
  adaptability REAL NOT NULL,
  experience REAL NOT NULL,
  base_rating REAL NOT NULL,
  update_ts TEXT NOT NULL
);

CREATE TABLE driver_rating_history (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  driver_id INTEGER NOT NULL REFERENCES drivers(id) ON DELETE CASCADE,
  season_id INTEGER,
  round_id INTEGER,
  kind TEXT NOT NULL,
  base_before REAL NOT NULL,
  base_after REAL NOT NULL,
  delta REAL NOT NULL,
  form_before REAL,
  form_after REAL,
  morale_after REAL,
  confidence REAL,
  reasons_json TEXT NOT NULL DEFAULT '[]',
  attributes_json TEXT NOT NULL DEFAULT '{}',
  create_ts TEXT NOT NULL
);
CREATE INDEX idx_rating_hist_driver ON driver_rating_history(driver_id, id);

CREATE TABLE contracts (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  driver_id INTEGER NOT NULL REFERENCES drivers(id) ON DELETE CASCADE,
  team_id INTEGER NOT NULL REFERENCES teams(id),
  start_season INTEGER NOT NULL,
  end_season INTEGER NOT NULL,
  salary REAL NOT NULL DEFAULT 0,
  role TEXT NOT NULL DEFAULT 'D1',
  bonuses_json TEXT NOT NULL DEFAULT '{}',
  release_clause REAL,
  extension_option INTEGER NOT NULL DEFAULT 0,
  status TEXT NOT NULL DEFAULT 'active',
  create_ts TEXT NOT NULL
);

CREATE TABLE championship_entries (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  championship_id INTEGER NOT NULL REFERENCES championships(id) ON DELETE CASCADE,
  driver_id INTEGER NOT NULL REFERENCES drivers(id),
  team_id INTEGER NOT NULL REFERENCES teams(id),
  number INTEGER,
  skin TEXT,
  role TEXT NOT NULL DEFAULT 'D1',
  active INTEGER NOT NULL DEFAULT 1,
  UNIQUE (championship_id, driver_id)
);

CREATE TABLE car_performance (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  season_id INTEGER NOT NULL REFERENCES seasons(id),
  team_id INTEGER NOT NULL REFERENCES teams(id),
  power REAL NOT NULL,
  energy_recovery REAL NOT NULL,
  low_speed_downforce REAL NOT NULL,
  medium_speed_downforce REAL NOT NULL,
  high_speed_downforce REAL NOT NULL,
  drag_efficiency REAL NOT NULL,
  traction REAL NOT NULL,
  mechanical_grip REAL NOT NULL,
  braking REAL NOT NULL,
  weight REAL NOT NULL,
  tyre_usage REAL NOT NULL,
  cooling REAL NOT NULL,
  reliability REAL NOT NULL,
  development_efficiency REAL NOT NULL,
  update_ts TEXT NOT NULL,
  UNIQUE (season_id, team_id)
);

CREATE TABLE team_performance_history (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  season_id INTEGER NOT NULL,
  round_id INTEGER,
  team_id INTEGER NOT NULL REFERENCES teams(id),
  overall REAL NOT NULL,
  components_json TEXT NOT NULL,
  reason TEXT,
  create_ts TEXT NOT NULL
);

CREATE TABLE track_profiles (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  name TEXT NOT NULL,
  archetype TEXT,
  power_importance REAL NOT NULL,
  drag_importance REAL NOT NULL,
  low_speed_importance REAL NOT NULL,
  medium_speed_importance REAL NOT NULL,
  high_speed_importance REAL NOT NULL,
  traction_importance REAL NOT NULL,
  braking_importance REAL NOT NULL,
  tyre_importance REAL NOT NULL,
  overtaking_difficulty REAL NOT NULL DEFAULT 0.5,
  wet_probability REAL NOT NULL DEFAULT 0.1,
  length_m REAL
);

CREATE TABLE calendar_rounds (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  season_id INTEGER NOT NULL REFERENCES seasons(id),
  round_no INTEGER NOT NULL,
  event_name TEXT NOT NULL,
  country TEXT,
  ac_track_id TEXT,
  ac_layout_id TEXT,
  track_profile_id INTEGER REFERENCES track_profiles(id),
  date TEXT,
  sprint INTEGER NOT NULL DEFAULT 0,
  status TEXT NOT NULL DEFAULT 'scheduled',
  UNIQUE (season_id, round_no)
);

CREATE TABLE sessions (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  round_id INTEGER NOT NULL REFERENCES calendar_rounds(id) ON DELETE CASCADE,
  championship_id INTEGER NOT NULL REFERENCES championships(id),
  code TEXT NOT NULL,
  type TEXT NOT NULL,
  name TEXT NOT NULL,
  order_no INTEGER NOT NULL,
  laps INTEGER,
  duration_min INTEGER,
  points_system TEXT,
  grid_rule_json TEXT NOT NULL DEFAULT '{}',
  weather TEXT,
  time_of_day TEXT,
  ambient_temp REAL,
  status TEXT NOT NULL DEFAULT 'pending',
  mode TEXT,
  seed INTEGER NOT NULL,
  played_ts TEXT,
  create_ts TEXT NOT NULL
);
CREATE INDEX idx_sessions_round ON sessions(round_id, championship_id, order_no);

CREATE TABLE session_entries (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  session_id INTEGER NOT NULL REFERENCES sessions(id) ON DELETE CASCADE,
  driver_id INTEGER NOT NULL REFERENCES drivers(id),
  team_id INTEGER NOT NULL REFERENCES teams(id),
  car_index INTEGER NOT NULL,
  grid_position INTEGER,
  ai_level REAL,
  ai_aggression REAL,
  ballast REAL NOT NULL DEFAULT 0,
  restrictor REAL NOT NULL DEFAULT 0,
  skin TEXT,
  is_player INTEGER NOT NULL DEFAULT 0,
  translation_json TEXT NOT NULL DEFAULT '{}',
  UNIQUE (session_id, driver_id)
);

CREATE TABLE results (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  session_id INTEGER NOT NULL REFERENCES sessions(id) ON DELETE CASCADE,
  driver_id INTEGER NOT NULL REFERENCES drivers(id),
  team_id INTEGER NOT NULL REFERENCES teams(id),
  position INTEGER,
  grid_position INTEGER,
  laps INTEGER NOT NULL DEFAULT 0,
  total_time_ms INTEGER,
  best_lap_ms INTEGER,
  gap_ms INTEGER,
  status TEXT NOT NULL DEFAULT 'FIN',
  dnf_reason TEXT,
  points REAL NOT NULL DEFAULT 0,
  fastest_lap INTEGER NOT NULL DEFAULT 0,
  pit_stops INTEGER,
  incidents INTEGER,
  source TEXT NOT NULL,
  UNIQUE (session_id, driver_id)
);

CREATE TABLE laps (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  session_id INTEGER NOT NULL REFERENCES sessions(id) ON DELETE CASCADE,
  driver_id INTEGER NOT NULL REFERENCES drivers(id),
  lap_no INTEGER NOT NULL,
  time_ms INTEGER NOT NULL,
  sectors_json TEXT NOT NULL DEFAULT '[]',
  cuts INTEGER NOT NULL DEFAULT 0,
  tyre TEXT
);
CREATE INDEX idx_laps_session ON laps(session_id, driver_id);

CREATE TABLE raw_results (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  session_id INTEGER NOT NULL REFERENCES sessions(id) ON DELETE CASCADE,
  source_path TEXT,
  raw_json TEXT NOT NULL,
  race_ini TEXT,
  imported_ts TEXT NOT NULL
);

CREATE TABLE driver_performance (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  session_id INTEGER NOT NULL REFERENCES sessions(id) ON DELETE CASCADE,
  driver_id INTEGER NOT NULL REFERENCES drivers(id),
  expected_pos REAL,
  actual_pos REAL,
  teammate_delta REAL,
  score REAL NOT NULL,
  confidence REAL NOT NULL,
  source TEXT NOT NULL,
  details_json TEXT NOT NULL DEFAULT '{}',
  UNIQUE (session_id, driver_id)
);

CREATE TABLE standings_snapshots (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  championship_id INTEGER NOT NULL REFERENCES championships(id),
  round_id INTEGER NOT NULL,
  kind TEXT NOT NULL,
  data_json TEXT NOT NULL,
  create_ts TEXT NOT NULL
);

CREATE TABLE snapshots (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  season_id INTEGER NOT NULL,
  round_id INTEGER,
  kind TEXT NOT NULL,
  data_json TEXT NOT NULL,
  create_ts TEXT NOT NULL
);

CREATE TABLE domain_events (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  type TEXT NOT NULL,
  season_id INTEGER,
  round_id INTEGER,
  session_id INTEGER,
  payload_json TEXT NOT NULL DEFAULT '{}',
  create_ts TEXT NOT NULL
);
CREATE INDEX idx_events_type ON domain_events(type, id);

CREATE TABLE news (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  season_id INTEGER,
  round_id INTEGER,
  event_id INTEGER REFERENCES domain_events(id),
  headline TEXT NOT NULL,
  body TEXT,
  create_ts TEXT NOT NULL
);
