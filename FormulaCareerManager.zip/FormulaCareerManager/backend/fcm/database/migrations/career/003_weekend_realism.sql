-- Knockout qualifying (Q1/Q2/Q3), session conditions + strategy, official circuit data,
-- mid-season transfer window, market value.

ALTER TABLE sessions ADD COLUMN stage INTEGER NOT NULL DEFAULT 0;
ALTER TABLE sessions ADD COLUMN conditions_json TEXT NOT NULL DEFAULT '{}';
ALTER TABLE sessions ADD COLUMN strategy_json TEXT NOT NULL DEFAULT '{}';

ALTER TABLE results ADD COLUMN q1_ms INTEGER;
ALTER TABLE results ADD COLUMN q2_ms INTEGER;
ALTER TABLE results ADD COLUMN q3_ms INTEGER;
ALTER TABLE results ADD COLUMN q_stage INTEGER;
ALTER TABLE results ADD COLUMN strategy TEXT;

CREATE TABLE session_stage_results (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  session_id INTEGER NOT NULL REFERENCES sessions(id) ON DELETE CASCADE,
  stage INTEGER NOT NULL,
  driver_id INTEGER NOT NULL REFERENCES drivers(id),
  team_id INTEGER NOT NULL REFERENCES teams(id),
  position INTEGER NOT NULL,
  best_lap_ms INTEGER,
  laps INTEGER NOT NULL DEFAULT 0,
  source TEXT NOT NULL,
  UNIQUE (session_id, stage, driver_id)
);

ALTER TABLE calendar_rounds ADD COLUMN circuit TEXT;
ALTER TABLE calendar_rounds ADD COLUMN official_length_m REAL;
ALTER TABLE calendar_rounds ADD COLUMN length_override_m REAL;
ALTER TABLE calendar_rounds ADD COLUMN race_distance_km REAL;
ALTER TABLE calendar_rounds ADD COLUMN start_time TEXT;
ALTER TABLE calendar_rounds ADD COLUMN night INTEGER NOT NULL DEFAULT 0;
ALTER TABLE calendar_rounds ADD COLUMN climate TEXT;
ALTER TABLE calendar_rounds ADD COLUMN summer_break_after INTEGER NOT NULL DEFAULT 0;

ALTER TABLE contracts ADD COLUMN effective TEXT NOT NULL DEFAULT 'season_start';
ALTER TABLE offers ADD COLUMN effective TEXT NOT NULL DEFAULT 'season_end';
ALTER TABLE offers ADD COLUMN transfer_fee REAL NOT NULL DEFAULT 0;
