-- Phases 5-8: finances, development, manufacturing, facilities, components, damage, penalties,
-- market (offers, academies), regulations, AI team strategy, event engine, injuries.

CREATE TABLE regulations (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  season_id INTEGER NOT NULL REFERENCES seasons(id),
  category_id INTEGER NOT NULL REFERENCES categories(id),
  name TEXT NOT NULL,
  major_change INTEGER NOT NULL DEFAULT 0,
  data_json TEXT NOT NULL,
  create_ts TEXT NOT NULL,
  UNIQUE (season_id, category_id)
);

CREATE TABLE team_finances (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  season_id INTEGER NOT NULL REFERENCES seasons(id),
  team_id INTEGER NOT NULL REFERENCES teams(id),
  cash REAL NOT NULL,
  season_budget REAL NOT NULL,
  sponsor_income REAL NOT NULL DEFAULT 0,
  prize_income REAL NOT NULL DEFAULT 0,
  cost_cap_spent REAL NOT NULL DEFAULT 0,
  update_ts TEXT NOT NULL,
  UNIQUE (season_id, team_id)
);

CREATE TABLE transactions (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  season_id INTEGER NOT NULL,
  round_id INTEGER,
  team_id INTEGER NOT NULL REFERENCES teams(id),
  type TEXT NOT NULL,
  amount REAL NOT NULL,
  cost_cap INTEGER NOT NULL DEFAULT 0,
  description TEXT NOT NULL,
  reference TEXT,
  create_ts TEXT NOT NULL
);
CREATE INDEX idx_tx_team ON transactions(team_id, season_id);

CREATE TABLE sponsors (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  season_id INTEGER NOT NULL,
  team_id INTEGER NOT NULL REFERENCES teams(id),
  name TEXT NOT NULL,
  base_payment REAL NOT NULL,
  race_bonus REAL NOT NULL DEFAULT 0,
  race_objective INTEGER,
  season_bonus REAL NOT NULL DEFAULT 0,
  season_objective INTEGER,
  reputation_requirement REAL NOT NULL DEFAULT 0,
  status TEXT NOT NULL DEFAULT 'active'
);

CREATE TABLE facilities (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  team_id INTEGER NOT NULL REFERENCES teams(id),
  kind TEXT NOT NULL,
  level INTEGER NOT NULL,
  upgrade_rounds_left INTEGER NOT NULL DEFAULT 0,
  UNIQUE (team_id, kind)
);

CREATE TABLE team_ai (
  team_id INTEGER PRIMARY KEY REFERENCES teams(id),
  risk_tolerance REAL NOT NULL,
  strategy TEXT NOT NULL,
  next_season_share REAL NOT NULL DEFAULT 0,
  notes_json TEXT NOT NULL DEFAULT '{}'
);

CREATE TABLE development_projects (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  team_id INTEGER NOT NULL REFERENCES teams(id),
  season_id INTEGER NOT NULL,
  target_year INTEGER NOT NULL,
  department TEXT NOT NULL,
  part TEXT NOT NULL,
  size TEXT NOT NULL,
  cost REAL NOT NULL,
  rounds_total INTEGER NOT NULL,
  rounds_left INTEGER NOT NULL,
  expected_gain REAL NOT NULL,
  actual_gain REAL,
  risk TEXT NOT NULL,
  outcome TEXT,
  status TEXT NOT NULL DEFAULT 'design',
  gain_mult REAL NOT NULL DEFAULT 1,
  start_round INTEGER,
  reason TEXT,
  create_ts TEXT NOT NULL
);

CREATE TABLE parts (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  project_id INTEGER NOT NULL REFERENCES development_projects(id),
  team_id INTEGER NOT NULL REFERENCES teams(id),
  season_id INTEGER NOT NULL,
  part TEXT NOT NULL,
  spec_no INTEGER NOT NULL,
  components_json TEXT NOT NULL,
  available INTEGER NOT NULL DEFAULT 0,
  manufacture_cost REAL NOT NULL,
  manufacture_rounds INTEGER NOT NULL,
  create_ts TEXT NOT NULL
);

CREATE TABLE manufacturing_orders (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  part_id INTEGER NOT NULL REFERENCES parts(id),
  team_id INTEGER NOT NULL REFERENCES teams(id),
  quantity INTEGER NOT NULL,
  cost REAL NOT NULL,
  rounds_left INTEGER NOT NULL,
  status TEXT NOT NULL DEFAULT 'in_progress',
  create_ts TEXT NOT NULL
);

CREATE TABLE part_installations (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  part_id INTEGER NOT NULL REFERENCES parts(id),
  driver_id INTEGER NOT NULL REFERENCES drivers(id),
  season_id INTEGER NOT NULL,
  round_no INTEGER,
  active INTEGER NOT NULL DEFAULT 1
);

CREATE TABLE next_season_bank (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  team_id INTEGER NOT NULL REFERENCES teams(id),
  target_year INTEGER NOT NULL,
  component TEXT NOT NULL,
  gain REAL NOT NULL,
  project_id INTEGER
);

CREATE TABLE power_components (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  season_id INTEGER NOT NULL,
  driver_id INTEGER NOT NULL REFERENCES drivers(id),
  team_id INTEGER NOT NULL REFERENCES teams(id),
  kind TEXT NOT NULL,
  serial INTEGER NOT NULL,
  wear REAL NOT NULL DEFAULT 0,
  km REAL NOT NULL DEFAULT 0,
  status TEXT NOT NULL DEFAULT 'fitted',
  create_ts TEXT NOT NULL
);
CREATE INDEX idx_pc_driver ON power_components(driver_id, season_id, kind);

CREATE TABLE penalties (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  season_id INTEGER NOT NULL,
  round_id INTEGER NOT NULL,
  driver_id INTEGER NOT NULL REFERENCES drivers(id),
  kind TEXT NOT NULL,
  value INTEGER NOT NULL,
  reason TEXT NOT NULL,
  applied INTEGER NOT NULL DEFAULT 0,
  create_ts TEXT NOT NULL
);

CREATE TABLE damage_reports (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  session_id INTEGER NOT NULL REFERENCES sessions(id) ON DELETE CASCADE,
  driver_id INTEGER NOT NULL REFERENCES drivers(id),
  team_id INTEGER NOT NULL REFERENCES teams(id),
  component TEXT NOT NULL,
  severity REAL NOT NULL,
  cost REAL NOT NULL,
  source TEXT NOT NULL,
  create_ts TEXT NOT NULL
);

CREATE TABLE academies (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  team_id INTEGER NOT NULL UNIQUE REFERENCES teams(id),
  name TEXT NOT NULL,
  cost_per_season REAL NOT NULL
);

CREATE TABLE academy_members (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  academy_id INTEGER NOT NULL REFERENCES academies(id),
  driver_id INTEGER NOT NULL REFERENCES drivers(id),
  since_year INTEGER NOT NULL,
  active INTEGER NOT NULL DEFAULT 1
);

CREATE TABLE offers (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  season_id INTEGER NOT NULL,
  driver_id INTEGER NOT NULL REFERENCES drivers(id),
  team_id INTEGER NOT NULL REFERENCES teams(id),
  category_code TEXT NOT NULL,
  role TEXT NOT NULL,
  salary REAL NOT NULL,
  years INTEGER NOT NULL,
  bonus_per_win REAL NOT NULL DEFAULT 0,
  release_clause REAL,
  origin TEXT NOT NULL,
  status TEXT NOT NULL DEFAULT 'open',
  reason_json TEXT NOT NULL DEFAULT '{}',
  create_ts TEXT NOT NULL
);

CREATE TABLE game_events (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  event_key TEXT NOT NULL,
  type TEXT NOT NULL,
  season_id INTEGER NOT NULL,
  round_id INTEGER,
  team_id INTEGER,
  driver_id INTEGER,
  project_id INTEGER,
  title TEXT NOT NULL,
  body TEXT,
  choices_json TEXT NOT NULL,
  status TEXT NOT NULL DEFAULT 'pending',
  choice INTEGER,
  result_json TEXT NOT NULL DEFAULT '{}',
  create_ts TEXT NOT NULL
);

CREATE TABLE injuries (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  driver_id INTEGER NOT NULL REFERENCES drivers(id),
  season_id INTEGER NOT NULL,
  rounds_left INTEGER NOT NULL,
  replacement_id INTEGER,
  championship_id INTEGER,
  reason TEXT NOT NULL,
  create_ts TEXT NOT NULL
);

CREATE TABLE player_telemetry (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  session_id INTEGER NOT NULL REFERENCES sessions(id) ON DELETE CASCADE,
  pit_stops INTEGER,
  max_damage_json TEXT NOT NULL DEFAULT '{}',
  samples INTEGER NOT NULL DEFAULT 0,
  create_ts TEXT NOT NULL
);
