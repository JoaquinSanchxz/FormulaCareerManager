-- Global application database: settings + installed Assetto Corsa content catalog.

CREATE TABLE settings (
  key TEXT PRIMARY KEY,
  value_json TEXT NOT NULL,
  update_ts TEXT NOT NULL
);

CREATE TABLE scan_runs (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  ac_root TEXT NOT NULL,
  cars INTEGER NOT NULL DEFAULT 0,
  tracks INTEGER NOT NULL DEFAULT 0,
  layouts INTEGER NOT NULL DEFAULT 0,
  warnings_json TEXT NOT NULL DEFAULT '[]',
  duration_ms INTEGER NOT NULL DEFAULT 0,
  create_ts TEXT NOT NULL
);

CREATE TABLE ac_cars (
  id TEXT PRIMARY KEY,                 -- folder id under content/cars
  name TEXT,
  brand TEXT,
  model TEXT,
  year INTEGER,
  class TEXT,
  country TEXT,
  author TEXT,
  description TEXT,
  tags_json TEXT NOT NULL DEFAULT '[]',
  specs_json TEXT NOT NULL DEFAULT '{}',
  path TEXT NOT NULL,
  has_data_acd INTEGER NOT NULL DEFAULT 0,
  has_data_folder INTEGER NOT NULL DEFAULT 0,
  has_ui INTEGER NOT NULL DEFAULT 0,
  is_kunos INTEGER NOT NULL DEFAULT 0,
  skin_count INTEGER NOT NULL DEFAULT 0,
  preview_path TEXT,
  badge_path TEXT,
  scan_id INTEGER,
  update_ts TEXT NOT NULL
);

CREATE TABLE ac_car_skins (
  car_id TEXT NOT NULL REFERENCES ac_cars(id) ON DELETE CASCADE,
  id TEXT NOT NULL,                    -- folder id under skins
  name TEXT,
  driver_name TEXT,
  team TEXT,
  number TEXT,
  country TEXT,
  preview_path TEXT,
  livery_path TEXT,
  sort_order INTEGER NOT NULL DEFAULT 0,
  PRIMARY KEY (car_id, id)
);

CREATE TABLE ac_tracks (
  id TEXT PRIMARY KEY,                 -- folder id under content/tracks
  name TEXT,
  path TEXT NOT NULL,
  is_kunos INTEGER NOT NULL DEFAULT 0,
  layout_count INTEGER NOT NULL DEFAULT 0,
  scan_id INTEGER,
  update_ts TEXT NOT NULL
);

CREATE TABLE ac_track_layouts (
  track_id TEXT NOT NULL REFERENCES ac_tracks(id) ON DELETE CASCADE,
  id TEXT NOT NULL,                    -- '' for single-layout tracks, else layout folder
  name TEXT,
  country TEXT,
  city TEXT,
  length_m REAL,
  width TEXT,
  pitboxes INTEGER,
  run TEXT,
  author TEXT,
  description TEXT,
  tags_json TEXT NOT NULL DEFAULT '[]',
  geotags_json TEXT NOT NULL DEFAULT '[]',
  preview_path TEXT,
  outline_path TEXT,
  has_data INTEGER NOT NULL DEFAULT 0,
  PRIMARY KEY (track_id, id)
);

CREATE TABLE ac_weathers (
  id TEXT PRIMARY KEY,
  name TEXT,
  path TEXT NOT NULL
);
