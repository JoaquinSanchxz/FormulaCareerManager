"""REST API. Handlers only validate input and delegate to services (no SQL here)."""
import os
import threading
from pathlib import Path

from fcm import __version__
from fcm.ac_integration import catalog, diagnostics, telemetry as ac_telemetry
from fcm.ac_integration.launcher import launcher
from fcm.api.http import HttpError, Response, file_response, route
from fcm.career_engine import championship as champ, editor, progression, queries, repo, sessions, weekend, world_builder
from fcm.career_engine.store import store
from fcm.management import components as mg_components, development as mg_dev, events as mg_events, market as mg_market, records as mg_records, regulations as mg_regs, team_view
from fcm.shared import config, safefs

_busy = threading.Lock()


def _db():
    return store.require()


def _int(v, name='id'):
    try:
        return int(v)
    except (TypeError, ValueError):
        raise HttpError(400, f'Invalid {name}')


# --- system -----------------------------------------------------------------------------
@route('GET', '/api/health')
def health(req):
    return {'ok': True, 'app': 'FormulaCareerManager', 'version': __version__, 'career': store.career_id}


@route('POST', '/api/heartbeat')
def heartbeat(req):
    return {'ok': True}


@route('GET', '/api/diagnostics')
def diag(req):
    return diagnostics.report(store)


@route('GET', '/api/diagnostics/export')
def diag_export(req):
    return Response(diagnostics.export_zip(store), 200, 'application/zip', {'Content-Disposition': 'attachment; filename="fcm_diagnostics.zip"'})


@route('GET', '/api/config')
def config_list(req):
    return {n: config.load(n) for n in config.names()}


@route('PUT', '/api/config/:name')
def config_put(req):
    name = req.params['name']
    if name not in config.names(): raise HttpError(404, 'Unknown config')
    config.save_user_override(name, req.json())
    return config.load(name)


# --- Assetto Corsa / content --------------------------------------------------------------
@route('GET', '/api/ac/status')
def ac_status(req):
    return {'content': catalog.status(store), 'launcher': launcher.status()}


@route('POST', '/api/ac/detect')
def ac_detect(req):
    return catalog.auto_detect(store)


@route('POST', '/api/ac/path')
def ac_path(req):
    return catalog.set_root(store, (req.json().get('path') or '').strip().strip('"'))


@route('POST', '/api/ac/scan')
def ac_scan(req):
    return catalog.scan(store)


@route('POST', '/api/ac/reset')
def ac_reset(req):
    launcher.reset()
    return launcher.status()


@route('GET', '/api/content/cars')
def content_cars(req):
    return catalog.cars(store, req.q('q'))


@route('GET', '/api/content/cars/:id')
def content_car(req):
    return catalog.car(store, req.params['id'])


@route('GET', '/api/content/tracks')
def content_tracks(req):
    return catalog.tracks(store, req.q('q'))


@route('GET', '/api/content/weathers')
def content_weathers(req):
    return catalog.weathers(store)


@route('GET', '/api/content/image')
def content_image(req):
    root = store.get_setting('ac_root')
    if not root: raise HttpError(404, 'AC not configured')
    p = safefs.ensure_within(Path(root) / 'content', req.q('path') or '')
    if p.suffix.lower() not in ('.png', '.jpg', '.jpeg', '.dds') or not p.is_file(): raise HttpError(404, 'Image not found')
    return file_response(p)


# --- saves --------------------------------------------------------------------------------
@route('GET', '/api/saves')
def saves(req):
    return {'saves': store.list_saves(), 'current': store.career_id, 'last': store.get_setting('last_career')}


@route('GET', '/api/templates/world')
def template_world(req):
    return world_builder.load_template()


@route('POST', '/api/careers')
def career_create(req):
    body = req.json()
    if body.get('grid_csv'): body['world'] = editor.csv_to_world(body.pop('grid_csv'), world_builder.load_template())
    with _busy:
        cid = world_builder.create_career(body)
    return {'id': cid}


@route('POST', '/api/careers/:id/open')
def career_open(req):
    store.open(req.params['id'])
    return {'id': store.career_id}


@route('POST', '/api/careers/close')
def career_close(req):
    store.close()
    return {'ok': True}


@route('DELETE', '/api/careers/:id')
def career_delete(req):
    store.delete(req.params['id'])
    return {'ok': True}


@route('GET', '/api/careers/current/export')
def career_export(req):
    p = store.export_path()
    return file_response(p, f'{store.career_id}.fcm')


@route('POST', '/api/careers/import')
def career_import(req):
    if not req.raw: raise HttpError(400, 'Fichero vacío')
    return {'id': store.import_file(req.raw, req.q('name') or 'imported')}


@route('POST', '/api/careers/current/backup')
def career_backup(req):
    return {'file': store.autosave('manual').name}


@route('GET', '/api/autosaves')
def autosaves(req):
    cid = req.q('career') or store.career_id
    return store.list_autosaves(cid) if cid else []


@route('POST', '/api/autosaves/restore')
def autosave_restore(req):
    store.restore_autosave(req.json()['file'])
    return {'id': store.career_id}


# --- career -------------------------------------------------------------------------------
@route('GET', '/api/career')
def career_hub(req):
    return queries.hub(_db())


@route('PATCH', '/api/career/settings')
def career_settings(req):
    db = _db()
    c = repo.career(db)
    body = req.json()
    repo.update_career(db, settings={**c['settings'], **body.get('settings', {})}, realism={**c['realism'], **body.get('realism', {})},
                       difficulty={**c['difficulty'], **body.get('difficulty', {})})
    return repo.career(db)


@route('GET', '/api/calendar')
def calendar(req):
    return queries.calendar(_db(), req.q('season_id') and _int(req.q('season_id')))


@route('GET', '/api/rounds/:id')
def round_get(req):
    return queries.round_view(_db(), _int(req.params['id']))


@route('PATCH', '/api/rounds/:id')
def round_patch(req):
    return editor.update_round(_db(), _int(req.params['id']), req.json())


@route('PATCH', '/api/track_profiles/:id')
def profile_patch(req):
    editor.update_profile(_db(), _int(req.params['id']), req.json())
    return {'ok': True}


@route('GET', '/api/championships')
def championships(req):
    db = _db()
    season_id = _int(req.q('season_id')) if req.q('season_id') else repo.current_season(db)['id']
    return repo.championships(db, season_id)


@route('PATCH', '/api/championships/:id')
def championship_patch(req):
    db, body, cid = _db(), req.json(), _int(req.params['id'])
    if 'ac_car_id' in body: editor.set_championship_car(db, cid, body['ac_car_id'], body.get('auto_skins', True))
    if 'player_mode' in body: editor.set_player_mode(db, cid, body['player_mode'])
    return repo.championship(db, cid)


@route('PATCH', '/api/entries/:id')
def entry_patch(req):
    editor.update_entry(_db(), _int(req.params['id']), req.json())
    return {'ok': True}


@route('POST', '/api/weekend/advance')
def weekend_advance(req):
    with _busy:
        db = _db()
        out = weekend.advance(db, stop_at_player=req.json().get('stop_at_player', True), max_rounds=int(req.json().get('max_rounds', 1)))
        store.autosave('advance')
        return out


@route('POST', '/api/season/simulate-all')
def season_simulate_all(req):
    with _busy:
        n = weekend.simulate_rest_of_season(_db())
        store.autosave('simulate_season')
        return {'simulated': n}


@route('POST', '/api/season/finish')
def season_finish(req):
    with _busy:
        store.autosave('before_season_end')
        out = progression.finish_season(_db())
        store.autosave('new_season')
        return out


# --- sessions -----------------------------------------------------------------------------
@route('GET', '/api/sessions/:id')
def session_get(req):
    return sessions.summary(_db(), _int(req.params['id']))


@route('GET', '/api/sessions/:id/preview')
def session_preview(req):
    p = sessions.prepare_play(_db(), _int(req.params['id']))
    return {k: v for k, v in p.items() if not k.startswith('_')}


@route('GET', '/api/sessions/:id/laps')
def session_laps(req):
    return queries.laps(_db(), _int(req.params['id']))


@route('POST', '/api/sessions/:id/simulate')
def session_simulate(req):
    with _busy:
        out = sessions.simulate(_db(), _int(req.params['id']))
        store.autosave('after_sim')
        return out


@route('POST', '/api/sessions/:id/skip')
def session_skip(req):
    with _busy:
        return sessions.skip(_db(), _int(req.params['id']))


@route('POST', '/api/sessions/:id/play')
def session_play(req):
    with _busy:
        return sessions.play(_db(), _int(req.params['id']))


@route('POST', '/api/sessions/:id/import-latest')
def session_import_latest(req):
    with _busy:
        out = sessions.import_latest(_db(), _int(req.params['id']))
        store.autosave('after_import')
        return out


@route('POST', '/api/sessions/:id/reset')
def session_reset(req):
    """Recover a session stuck in 'running' (e.g. app closed while AC was running)."""
    db = _db()
    if launcher.is_busy(): raise HttpError(400, 'Hay una sesión de Assetto Corsa en curso')
    sessions.reset_stuck(db, _int(req.params['id']))
    return {'ok': True}


# --- world --------------------------------------------------------------------------------
@route('GET', '/api/standings')
def standings(req):
    db = _db()
    cid = _int(req.q('championship_id'))
    upto = _int(req.q('upto'), 'upto') if req.q('upto') else None
    return {'drivers': champ.driver_standings(db, cid, upto), 'constructors': champ.constructor_standings(db, cid, upto), 'championship': repo.championship(db, cid)}


@route('GET', '/api/drivers')
def drivers(req):
    return queries.drivers(_db(), _int(req.q('championship_id')) if req.q('championship_id') else None)


@route('GET', '/api/drivers/:id')
def driver(req):
    return queries.driver_profile(_db(), _int(req.params['id']))


@route('PATCH', '/api/drivers/:id')
def driver_patch(req):
    editor.update_driver(_db(), _int(req.params['id']), req.json())
    return queries.driver_profile(_db(), _int(req.params['id']))


@route('GET', '/api/teams')
def teams(req):
    return queries.teams(_db(), _int(req.q('championship_id')))


@route('PATCH', '/api/teams/:id')
def team_patch(req):
    db, body, tid = _db(), req.json(), _int(req.params['id'])
    editor.update_team(db, tid, body)
    if body.get('car'): editor.update_car(db, repo.current_season(db)['id'], tid, body['car'])
    return {'ok': True}


@route('GET', '/api/news')
def news(req):
    return queries.news(_db(), _int(req.q('limit', 100)))


@route('GET', '/api/events')
def events(req):
    return queries.events(_db(), req.q('type'))


@route('GET', '/api/history')
def history(req):
    return queries.history(_db())


@route('POST', '/api/shutdown')
def shutdown(req):
    if launcher.is_busy(): raise HttpError(400, 'Hay una sesión de Assetto Corsa en curso')
    threading.Timer(0.5, lambda: os._exit(0)).start()
    return {'ok': True}


# --- management (phases 5-8) ----------------------------------------------------------------


@route('GET', '/api/team')
def team_overview(req):
    return team_view.overview(_db(), req.q('team_id'))


@route('POST', '/api/development/preview')
def dev_preview(req):
    db, b = _db(), req.json()
    season, tid = team_view.require_player_team(db)
    return mg_dev.preview(db, season['id'], tid, b['part'], b.get('size', 'standard'), int(b.get('target_year') or season['year']))


@route('POST', '/api/development/projects')
def dev_start(req):
    db, b = _db(), req.json()
    season, tid = team_view.require_player_team(db)
    rnd = weekend.current_round(db)
    with db.transaction():
        pid = mg_dev.start_project(db, season['id'], rnd and rnd['id'], tid, b['part'], b.get('size', 'standard'), int(b.get('target_year') or season['year']), 'Player decision')
    return {'project_id': pid}


@route('POST', '/api/development/parts/:id/manufacture')
def dev_manufacture(req):
    db = _db()
    season, tid = team_view.require_player_team(db)
    part = db.one('SELECT team_id FROM parts WHERE id = ?', (_int(req.params['id']),))
    if not part or part['team_id'] != tid: raise HttpError(400, 'No es una pieza de tu equipo')
    rnd = weekend.current_round(db)
    with db.transaction():
        return {'order_id': mg_dev.manufacture(db, season['id'], rnd and rnd['id'], _int(req.params['id']), int(req.json().get('quantity', 1)))}


@route('POST', '/api/development/parts/:id/install')
def dev_install(req):
    db = _db()
    season, tid = team_view.require_player_team(db)
    part = db.one('SELECT team_id FROM parts WHERE id = ?', (_int(req.params['id']),))
    if not part or part['team_id'] != tid: raise HttpError(400, 'No es una pieza de tu equipo')
    with db.transaction():
        mg_dev.install(db, season['id'], _int(req.params['id']), _int(req.json().get('driver_id'), 'driver_id'))
    return {'ok': True}


@route('POST', '/api/facilities/:kind/upgrade')
def facility_upgrade(req):
    db = _db()
    season, tid = team_view.require_player_team(db)
    rnd = weekend.current_round(db)
    with db.transaction():
        mg_dev.upgrade_facility(db, season['id'], rnd and rnd['id'], tid, req.params['kind'])
    return {'ok': True}


@route('POST', '/api/components/fit')
def component_fit(req):
    db, b = _db(), req.json()
    season, tid = team_view.require_player_team(db)
    with db.transaction():
        return mg_components.fit_new(db, season['id'], _int(b.get('driver_id'), 'driver_id'), b.get('kind'), 'Player decision')


@route('GET', '/api/market')
def market_overview(req):
    return mg_market.overview(_db())


@route('POST', '/api/market/negotiate')
def market_negotiate(req):
    db, b = _db(), req.json()
    with db.transaction():
        return mg_market.negotiate(db, _int(b.get('team_id'), 'team_id'), b.get('role', 'D2'), float(b.get('salary', 1)), int(b.get('years', 1)),
                                   float(b.get('bonus_per_win') or 0), b.get('release_clause'))


@route('POST', '/api/offers/:id/accept')
def offer_accept(req):
    return mg_market.accept_offer(_db(), _int(req.params['id']))


@route('POST', '/api/offers/:id/reject')
def offer_reject(req):
    return mg_market.reject_offer(_db(), _int(req.params['id']))


@route('GET', '/api/inbox')
def inbox(req):
    return mg_events.inbox(_db())


@route('POST', '/api/game-events/:id/resolve')
def game_event_resolve(req):
    db = _db()
    season, tid = team_view.require_player_team(db)
    with db.transaction():
        return mg_events.resolve(db, _int(req.params['id']), int(req.json().get('choice', 0)))


@route('GET', '/api/records')
def records(req):
    return mg_records.records(_db())


@route('GET', '/api/regulations')
def regulations_get(req):
    return mg_regs.current(_db())


@route('GET', '/api/sessions/:id/telemetry')
def session_telemetry(req):
    return {'laps': ac_telemetry.load_laps(store.career_id, _int(req.params['id'])), 'summary': queries.player_telemetry(_db(), _int(req.params['id']))}


@route('GET', '/api/physics')
def physics_status(req):
    from fcm.ac_integration import physics
    root = store.get_setting('ac_root')
    out = {'config': config.load('physics'), 'managed': physics.list_managed(root) if root else [], 'cars': []}
    if root and store.db:
        for ch in repo.championships(store.db, repo.current_season(store.db)['id']):
            if ch['ac_car_id']: out['cars'].append({'category': ch['category_code'], 'car_id': ch['ac_car_id'], **physics.support(root, ch['ac_car_id'])})
    return out


@route('POST', '/api/physics/cleanup')
def physics_cleanup(req):
    from fcm.ac_integration import physics
    if launcher.is_busy(): raise HttpError(400, 'Hay una sesión de Assetto Corsa en curso')
    root = store.get_setting('ac_root')
    return {'removed': physics.remove_all(root) if root else 0}


# --- career start / weekend strategy ---------------------------------------------------------
@route('GET', '/api/personality/questions')
def personality_questions(req):
    from fcm.career_engine import personality
    return personality.QUESTIONS


@route('POST', '/api/personality/evaluate')
def personality_evaluate(req):
    from fcm.career_engine import personality
    b = req.json()
    return personality.evaluate(b.get('answers') or {}, b.get('world') or world_builder.load_template(), tuple(b.get('categories') or ('F1', 'F2', 'F3')))


@route('GET', '/api/sessions/:id/strategy')
def strategy_get(req):
    return sessions.strategy_view(_db(), _int(req.params['id']))


@route('PUT', '/api/sessions/:id/strategy')
def strategy_put(req):
    return sessions.set_strategy(_db(), _int(req.params['id']), req.json())


@route('GET', '/api/season/setup')
def season_setup(req):
    db = _db()
    season = repo.current_season(db)
    return {'season': season, 'started': editor.season_started(db, season['id']), 'rounds': queries.calendar(db, season['id'])}
