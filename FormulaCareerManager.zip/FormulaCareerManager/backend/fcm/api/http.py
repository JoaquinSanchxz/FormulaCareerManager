"""Minimal JSON HTTP server (stdlib only) + static frontend hosting. Bound to 127.0.0.1."""
import json
import mimetypes
import re
import threading
import time
import traceback
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import parse_qs, urlparse

from fcm.shared import log, paths

_log = log.get('API')
ROUTES = []
last_activity = {'ts': time.time()}


class Response:
    def __init__(self, body=b'', status=200, content_type='application/octet-stream', headers=None):
        self.body, self.status, self.content_type, self.headers = body, status, content_type, headers or {}


class HttpError(Exception):
    def __init__(self, status, message):
        super().__init__(message)
        self.status = status


def route(method, pattern):
    rx = re.compile('^' + re.sub(r':(\w+)', r'(?P<\1>[^/]+)', pattern) + '$')

    def deco(fn):
        ROUTES.append((method, rx, fn))
        return fn
    return deco


class Request:
    def __init__(self, handler, params, query, raw):
        self.handler, self.params, self.query, self.raw = handler, params, query, raw

    def json(self):
        if not self.raw: return {}
        try:
            return json.loads(self.raw.decode('utf-8'))
        except ValueError:
            raise HttpError(400, 'Invalid JSON body')

    def q(self, name, default=None):
        v = self.query.get(name)
        return v[0] if v else default


class Handler(BaseHTTPRequestHandler):
    server_version = 'FCM/1'

    def log_message(self, fmt, *args):
        pass

    def _dispatch(self, method):
        url = urlparse(self.path)
        last_activity['ts'] = time.time()
        if url.path.startswith('/api/'):
            length = int(self.headers.get('Content-Length') or 0)
            raw = self.rfile.read(length) if length else b''
            for m, rx, fn in ROUTES:
                if m != method: continue
                mt = rx.match(url.path)
                if not mt: continue
                try:
                    out = fn(Request(self, mt.groupdict(), parse_qs(url.query), raw))
                    return self._send(out)
                except HttpError as e:
                    return self._json({'error': str(e)}, e.status)
                except (KeyError, IndexError) as e:
                    _log.error('%s %s failed: %r\n%s', method, url.path, e, traceback.format_exc())
                    return self._json({'error': f'Internal error: {e!r}'}, 500)
                except (ValueError, FileNotFoundError, RuntimeError) as e:
                    _log.warning('%s %s -> %s', method, url.path, e)
                    return self._json({'error': str(e)}, 400)
                except LookupError as e:
                    return self._json({'error': str(e), 'code': 'not_found'}, 404 if ('not found' in str(e).lower() or 'no encontrad' in str(e).lower()) else 409)
                except Exception as e:
                    _log.error('%s %s failed: %s\n%s', method, url.path, e, traceback.format_exc())
                    return self._json({'error': f'Internal error: {e}'}, 500)
            return self._json({'error': 'Not found'}, 404)
        if method != 'GET': return self._json({'error': 'Not found'}, 404)
        return self._static(url.path)

    def _send(self, out):
        if isinstance(out, Response):
            self.send_response(out.status)
            self.send_header('Content-Type', out.content_type)
            self.send_header('Content-Length', str(len(out.body)))
            for k, v in out.headers.items(): self.send_header(k, v)
            self.end_headers()
            self.wfile.write(out.body)
        else:
            self._json(out)

    def _json(self, obj, status=200):
        body = json.dumps(obj, default=str, ensure_ascii=False).encode('utf-8')
        self.send_response(status)
        self.send_header('Content-Type', 'application/json; charset=utf-8')
        self.send_header('Content-Length', str(len(body)))
        self.send_header('Cache-Control', 'no-store')
        self.end_headers()
        self.wfile.write(body)

    def _static(self, path):
        root = paths.frontend_dist_dir()
        rel = path.lstrip('/') or 'index.html'
        f = (root / rel).resolve()
        try:
            f.relative_to(root.resolve())
        except ValueError:
            return self._json({'error': 'Forbidden'}, 403)
        if not f.is_file(): f = root / 'index.html'
        if not f.is_file():
            body = b'<h1>Frontend not built</h1><p>Run build.bat (or npm run build in /frontend).</p>'
            self.send_response(200)
            self.send_header('Content-Type', 'text/html')
            self.send_header('Content-Length', str(len(body)))
            self.end_headers()
            return self.wfile.write(body)
        data = f.read_bytes()
        self.send_response(200)
        self.send_header('Content-Type', mimetypes.guess_type(str(f))[0] or 'application/octet-stream')
        self.send_header('Content-Length', str(len(data)))
        if '/assets/' in path: self.send_header('Cache-Control', 'max-age=31536000, immutable')
        self.end_headers()
        self.wfile.write(data)

    def do_GET(self): self._dispatch('GET')
    def do_POST(self): self._dispatch('POST')
    def do_PATCH(self): self._dispatch('PATCH')
    def do_PUT(self): self._dispatch('PUT')
    def do_DELETE(self): self._dispatch('DELETE')


def serve(host, port):
    srv = ThreadingHTTPServer((host, port), Handler)
    srv.daemon_threads = True
    t = threading.Thread(target=srv.serve_forever, daemon=True)
    t.start()
    _log.info('HTTP server on http://%s:%s', host, port)
    return srv


def file_response(path: Path, download_name=None):
    data = Path(path).read_bytes()
    ctype = mimetypes.guess_type(str(path))[0] or 'application/octet-stream'
    headers = {'Content-Disposition': f'attachment; filename="{download_name}"'} if download_name else {'Cache-Control': 'max-age=3600'}
    return Response(data, 200, ctype, headers)
