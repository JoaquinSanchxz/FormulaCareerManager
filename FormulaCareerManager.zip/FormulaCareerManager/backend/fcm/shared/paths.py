"""Filesystem locations used by the application.

- resource_dir(): read-only bundled resources (config defaults, templates, frontend build).
  Works both from source and from a PyInstaller bundle (sys._MEIPASS).
- data_dir(): writable per-user data (settings DB, saves, logs, backups).
  Override with env FCM_DATA_DIR (used by tests and portable mode).
"""
import os
import sys
from pathlib import Path

from fcm import APP_NAME


def resource_dir() -> Path:
    if getattr(sys, 'frozen', False) and hasattr(sys, '_MEIPASS'):
        return Path(sys._MEIPASS)
    # backend/fcm/shared/paths.py -> project root
    return Path(__file__).resolve().parents[3]


def config_defaults_dir() -> Path:
    return resource_dir() / 'data' / 'config'


def templates_dir() -> Path:
    return resource_dir() / 'data' / 'templates'


def frontend_dist_dir() -> Path:
    return resource_dir() / 'frontend' / 'dist'


def data_dir() -> Path:
    env = os.environ.get('FCM_DATA_DIR')
    if env:
        p = Path(env)
    elif getattr(sys, 'frozen', False) and (Path(sys.executable).parent / 'portable.txt').exists():
        p = Path(sys.executable).parent / 'userdata'
    else:
        base = os.environ.get('APPDATA') or str(Path.home() / '.config')
        p = Path(base) / APP_NAME
    p.mkdir(parents=True, exist_ok=True)
    return p


def sub_dir(name: str) -> Path:
    p = data_dir() / name
    p.mkdir(parents=True, exist_ok=True)
    return p


def saves_dir() -> Path:
    return sub_dir('saves')


def autosave_dir() -> Path:
    return sub_dir('saves/autosave')


def logs_dir() -> Path:
    return sub_dir('logs')


def backups_dir() -> Path:
    return sub_dir('backups')


def user_config_dir() -> Path:
    return sub_dir('config')


def app_db_path() -> Path:
    return data_dir() / 'app.sqlite'


def documents_dir() -> Path:
    """Real 'Documents' folder (handles OneDrive / relocated folders on Windows)."""
    if sys.platform == 'win32':
        try:
            import ctypes
            from ctypes import wintypes
            import uuid

            class GUID(ctypes.Structure):
                _fields_ = [('Data1', wintypes.DWORD), ('Data2', wintypes.WORD),
                            ('Data3', wintypes.WORD), ('Data4', ctypes.c_ubyte * 8)]

            u = uuid.UUID('{FDD39AD0-238F-46AF-ADB4-6C85480369C7}')  # FOLDERID_Documents
            guid = GUID(u.fields[0], u.fields[1], u.fields[2],
                        (ctypes.c_ubyte * 8).from_buffer_copy(u.bytes[8:]))
            out = ctypes.c_wchar_p()
            if ctypes.windll.shell32.SHGetKnownFolderPath(ctypes.byref(guid), 0, None, ctypes.byref(out)) == 0:
                path = out.value
                ctypes.windll.ole32.CoTaskMemFree(out)
                if path:
                    return Path(path)
        except Exception:
            pass
    return Path.home() / 'Documents'
