"""Safe file operations: path containment checks, backups, atomic writes."""
import os
import shutil
import tempfile
import time
from pathlib import Path


class UnsafePathError(ValueError):
    pass


def ensure_within(root, path) -> Path:
    """Resolve `path` and guarantee it lives inside `root` (prevents directory traversal)."""
    root_r = Path(root).resolve()
    p = Path(path)
    p_r = (p if p.is_absolute() else root_r / p).resolve()
    try:
        p_r.relative_to(root_r)
    except ValueError:
        raise UnsafePathError(f'Path {p_r} escapes {root_r}')
    return p_r


def safe_id(value: str) -> str:
    """Validate an AC content id (folder name). Rejects separators and traversal."""
    if not value or value in ('.', '..') or any(c in value for c in '/\\:*?"<>|') or value.strip() != value:
        raise UnsafePathError(f'Invalid content id: {value!r}')
    return value


def atomic_write_text(path, text: str, encoding='utf-8'):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    fd, tmp = tempfile.mkstemp(prefix='.fcm_', suffix='.tmp', dir=str(path.parent))
    try:
        with os.fdopen(fd, 'w', encoding=encoding, newline='\r\n') as f:
            f.write(text)
            f.flush()
            os.fsync(f.fileno())
        os.replace(tmp, path)
    except BaseException:
        try:
            os.unlink(tmp)
        except OSError:
            pass
        raise


def backup_file(path, backup_dir, keep=20):
    """Copy `path` into backup_dir with a timestamp. Returns backup path or None."""
    path = Path(path)
    if not path.exists(): return None
    backup_dir = Path(backup_dir)
    backup_dir.mkdir(parents=True, exist_ok=True)
    dest = backup_dir / f'{path.stem}_{time.strftime("%Y%m%d_%H%M%S")}_{int(time.time() * 1000) % 1000:03d}{path.suffix}'
    shutil.copy2(path, dest)
    olds = sorted(backup_dir.glob(f'{path.stem}_*{path.suffix}'))
    for old in olds[:-keep]:
        try:
            old.unlink()
        except OSError:
            pass
    return dest
