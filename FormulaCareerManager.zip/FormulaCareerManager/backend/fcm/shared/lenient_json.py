"""Tolerant JSON parser for Assetto Corsa ui_*.json files.

Real-world mod files frequently contain: UTF-8 BOM, raw newlines/tabs inside strings,
trailing commas, // comments, and non UTF-8 encodings. This module repairs these
cases before handing the text to the standard json module.
"""
import json
import re

_TRAILING_COMMA = re.compile(r',\s*([}\]])')


def _decode(raw: bytes) -> str:
    if raw[:2] in (b'\xff\xfe', b'\xfe\xff'): return raw.decode('utf-16', errors='replace')
    for enc in ('utf-8-sig', 'cp1252'):
        try:
            return raw.decode(enc)
        except UnicodeDecodeError:
            continue
    return raw.decode('latin-1')


def _sanitize(text: str) -> str:
    """Escape control chars inside strings and strip // comments outside strings."""
    out = []
    in_str = False
    esc = False
    i = 0
    n = len(text)
    while i < n:
        c = text[i]
        if in_str:
            if esc:
                esc = False
                out.append(c)
            elif c == '\\':
                esc = True
                out.append(c)
            elif c == '"':
                in_str = False
                out.append(c)
            elif c == '\n':
                out.append('\\n')
            elif c == '\r':
                pass
            elif c == '\t':
                out.append('\\t')
            elif ord(c) < 32:
                out.append(' ')
            else:
                out.append(c)
        else:
            if c == '"':
                in_str = True
                out.append(c)
            elif c == '/' and i + 1 < n and text[i + 1] == '/':
                while i < n and text[i] != '\n': i += 1
                continue
            else:
                out.append(c)
        i += 1
    return ''.join(out)


def loads(text: str):
    try:
        return json.loads(text)
    except ValueError:
        pass
    fixed = _TRAILING_COMMA.sub(r'\1', _sanitize(text))
    return json.loads(fixed)


def load_file(path):
    """Returns parsed dict, or None if the file is missing or unrecoverable."""
    try:
        with open(path, 'rb') as f:
            raw = f.read()
    except OSError:
        return None
    try:
        return loads(_decode(raw))
    except ValueError:
        return None
