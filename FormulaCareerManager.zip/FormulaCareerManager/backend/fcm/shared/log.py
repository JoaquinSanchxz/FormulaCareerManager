"""Categorised logging (AC, SESSION, DATABASE, CAREER, SIMULATION, FINANCE, DRIVER, CAR, ERROR)."""
import logging
import sys
from logging.handlers import RotatingFileHandler

from fcm.shared import paths

CATEGORIES = ('AC', 'SESSION', 'DATABASE', 'CAREER', 'SIMULATION', 'FINANCE', 'DRIVER', 'CAR', 'ERROR', 'API')
_configured = False


def setup(level=logging.INFO):
    global _configured
    if _configured: return
    root = logging.getLogger('fcm')
    root.setLevel(level)
    fmt = logging.Formatter('%(asctime)s [%(levelname)s] [%(name)s] %(message)s')
    fh = RotatingFileHandler(paths.logs_dir() / 'fcm.log', maxBytes=2_000_000, backupCount=5, encoding='utf-8')
    fh.setFormatter(fmt)
    root.addHandler(fh)
    if sys.stderr:  # windowed (no console) builds have no stderr
        sh = logging.StreamHandler()
        sh.setFormatter(fmt)
        root.addHandler(sh)
    _configured = True


def get(category: str) -> logging.Logger:
    return logging.getLogger(f'fcm.{category}')


def log_file_path():
    return paths.logs_dir() / 'fcm.log'
