"""Data-driven configuration.

Defaults live in <resources>/data/config/<name>.json (shipped, read-only).
Users may override any key by placing <data_dir>/config/<name>.json (deep-merged).
"""
import copy
import json
import threading

from fcm.shared import paths

_cache = {}
_lock = threading.Lock()


def _deep_merge(base, over):
    if isinstance(base, dict) and isinstance(over, dict):
        out = dict(base)
        for k, v in over.items():
            out[k] = _deep_merge(base.get(k), v) if k in base else v
        return out
    return over


def load(name: str) -> dict:
    with _lock:
        if name in _cache: return copy.deepcopy(_cache[name])
        with open(paths.config_defaults_dir() / f'{name}.json', encoding='utf-8') as f:
            data = json.load(f)
        user = paths.user_config_dir() / f'{name}.json'
        if user.exists():
            with open(user, encoding='utf-8') as f:
                data = _deep_merge(data, json.load(f))
        _cache[name] = data
        return copy.deepcopy(data)


def save_user_override(name: str, data: dict):
    with open(paths.user_config_dir() / f'{name}.json', 'w', encoding='utf-8') as f:
        json.dump(data, f, indent=2)
    reload()


def reload():
    with _lock:
        _cache.clear()


def names():
    return sorted(p.stem for p in paths.config_defaults_dir().glob('*.json'))
