"""Deterministic seeded RNG helpers. Every stochastic process derives its seed from
career_seed + stable keys so results are reproducible for debugging."""
import hashlib
import random


def derive_seed(base, *keys) -> int:
    h = hashlib.sha256(str(base).encode())
    for k in keys:
        h.update(b'|')
        h.update(str(k).encode())
    return int.from_bytes(h.digest()[:8], 'big') >> 1  # 63 bits: fits SQLite INTEGER


def rng_for(base, *keys) -> random.Random:
    return random.Random(derive_seed(base, *keys))
