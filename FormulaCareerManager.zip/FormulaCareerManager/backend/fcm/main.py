"""Entry point: starts the local API/UI server and opens the desktop window.

Window: Microsoft Edge / Chrome in --app mode with a dedicated profile (no browser chrome,
closes independently). Fallback: default browser + heartbeat-based idle shutdown.
"""
import argparse
import json
import os
import shutil
import subprocess
import sys
import threading
import time
import urllib.request
import webbrowser
from pathlib import Path

if __package__ in (None, ''):
    sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from fcm import __version__  # noqa: E402
from fcm.shared import config, log, paths  # noqa: E402

_log = log.get('CAREER')


def _already_running(url):
    try:
        with urllib.request.urlopen(url + '/api/health', timeout=1.5) as r:
            return json.loads(r.read()).get('app') == 'FormulaCareerManager'
    except Exception:
        return False


def _find_app_browser():
    cands = []
    for base in (os.environ.get('PROGRAMFILES(X86)'), os.environ.get('PROGRAMFILES'), os.environ.get('LOCALAPPDATA')):
        if not base: continue
        cands += [Path(base) / 'Microsoft/Edge/Application/msedge.exe', Path(base) / 'Google/Chrome/Application/chrome.exe']
    for c in cands:
        if c.is_file(): return str(c)
    for name in ('msedge', 'chrome', 'chromium', 'google-chrome'):
        p = shutil.which(name)
        if p: return p
    return None


def open_ui(url, mode):
    browser = _find_app_browser() if mode == 'app_window' else None
    if browser:
        profile = paths.sub_dir('browser_profile')
        try:
            return subprocess.Popen([browser, f'--app={url}', f'--user-data-dir={profile}', '--no-first-run', '--no-default-browser-check',
                                     '--window-size=1500,920'])
        except OSError:
            pass
    webbrowser.open(url)
    return None


def main(argv=None):
    ap = argparse.ArgumentParser(description='Formula Career Manager')
    ap.add_argument('--port', type=int)
    ap.add_argument('--no-browser', action='store_true')
    ap.add_argument('--browser', action='store_true', help='open in the default browser instead of an app window')
    args = ap.parse_args(argv)
    log.setup()
    cfg = config.load('app')
    host, port = cfg['server']['host'], args.port or cfg['server']['port']
    url = f'http://{host}:{port}'
    if _already_running(url):
        if not args.no_browser: open_ui(url, 'browser' if args.browser else cfg['ui']['open_mode'])
        return 0
    _log.info('Formula Career Manager %s starting (data: %s)', __version__, paths.data_dir())
    from fcm.career_engine.store import store
    from fcm.ac_integration import catalog
    from fcm.ac_integration.launcher import launcher
    from fcm.api import http, routes  # noqa: F401  (registers routes)
    store.init_app_db()
    last = store.get_setting('last_career')
    if last:
        try:
            store.open(last)
        except Exception as e:
            _log.warning('Could not reopen last career %s: %s', last, e)
    if not store.get_setting('ac_root'):
        threading.Thread(target=lambda: catalog.auto_detect(store), daemon=True).start()
    http.serve(host, port)
    if args.no_browser:
        while True: time.sleep(3600)
    proc = open_ui(url, 'browser' if args.browser else cfg['ui']['open_mode'])
    started = time.time()
    idle = cfg['ui']['idle_shutdown_s']
    while True:
        time.sleep(2)
        if launcher.is_busy(): continue
        if proc is not None and proc.poll() is not None and time.time() - started < 15:
            proc = None  # browser handed the window to another process: fall back to heartbeat mode
        if proc is not None:
            if proc.poll() is not None and time.time() - http.last_activity['ts'] > 5:
                break
        elif time.time() - http.last_activity['ts'] > idle:
            break
    _log.info('UI closed; shutting down')
    store.close()
    return 0


if __name__ == '__main__':
    sys.exit(main())
