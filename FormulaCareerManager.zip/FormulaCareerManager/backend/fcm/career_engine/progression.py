"""World progression: weekend completion (ratings, reputation), round completion (management tick),
snapshots, season end (ageing, retirements, finances, driver market, promotions, rookies, next-season cars/calendar)."""
from fcm.career_engine import championship as champ, newsroom, repo
from fcm.career_engine.rating import retirement_probability, season_end_update, weekend_update
from fcm.database.db import jdump, jload, now_ts
from fcm.shared import config, log
from fcm.shared.rng import derive_seed, rng_for
from fcm.simulation.model import overall_strength

_log = log.get('CAREER')


# ------------------------------------------------------------------------------------------
# After each session
# ------------------------------------------------------------------------------------------
def after_session(db, s):
    open_ch = db.value("SELECT COUNT(*) FROM sessions WHERE round_id = ? AND championship_id = ? AND status NOT IN ('completed', 'skipped')",
                       (s['round_id'], s['championship_id']))
    if open_ch == 0: complete_championship_weekend(db, s['round_id'], s['championship_id'])
    else: db.execute("UPDATE calendar_rounds SET status = 'in_progress' WHERE id = ? AND status = 'scheduled'", (s['round_id'],))
    open_round = db.value("SELECT COUNT(*) FROM sessions WHERE round_id = ? AND status NOT IN ('completed', 'skipped')", (s['round_id'],))
    if open_round == 0: complete_round(db, s['round_id'])


def complete_championship_weekend(db, round_id, championship_id):
    from fcm.management import market
    c = repo.career(db)
    rnd = db.one('SELECT * FROM calendar_rounds WHERE id = ?', (round_id,))
    ch = repo.championship(db, championship_id)
    pcfg = config.load('progression')
    mcfg = config.load('market')
    for e in repo.entries(db, championship_id):
        ev = db.all('SELECT dp.*, s.type session_type FROM driver_performance dp JOIN sessions s ON s.id = dp.session_id '
                    'WHERE s.round_id = ? AND s.championship_id = ? AND dp.driver_id = ?', (round_id, championship_id, e['driver_id']))
        evidence = [{'session_type': x['session_type'], 'score': x['score'], 'confidence': x['confidence'], 'expected_pos': x['expected_pos'],
                     'actual_pos': x['actual_pos'], 'teammate_delta': x['teammate_delta'], 'details': jload(x['details_json'], {})} for x in ev]
        st = repo.driver_state(db, e['driver_id'], ch['year'])
        if c['realism'].get('academies') and market.academy_team(db, e['driver_id']): st['development_rate'] *= mcfg['academy_dev_mult']
        new, rec = weekend_update(st, evidence, pcfg, label=f"{ch['year']} R{rnd['round_no']}")
        if c['realism'].get('driver_progression', True):
            new['development_rate'] = repo.driver_state(db, e['driver_id'], ch['year'])['development_rate']
            repo.save_driver_state(db, new, rec, rnd['season_id'], round_id)
        market.update_reputation(db, e['driver_id'], rec.get('score') or 0.0, rec.get('confidence') or 0.0, round_id)
    db.execute("UPDATE drivers SET experience_races = experience_races + 1 WHERE id IN (SELECT r.driver_id FROM results r JOIN sessions s ON s.id = r.session_id "
               "WHERE s.round_id = ? AND s.championship_id = ? AND s.type = 'race' AND r.status != 'DNS')", (round_id, championship_id))
    champ.store_standings_snapshot(db, championship_id, round_id, rnd['round_no'])
    repo.emit(db, 'RATING_UPDATED', {'championship_id': championship_id}, season_id=rnd['season_id'], round_id=round_id)


def complete_round(db, round_id):
    from fcm.management import lifecycle
    rnd = db.one('SELECT * FROM calendar_rounds WHERE id = ?', (round_id,))
    if rnd['status'] == 'completed': return
    db.update('calendar_rounds', round_id, {'status': 'completed'})
    repo.emit(db, 'ROUND_COMPLETED', {'round_no': rnd['round_no']}, season_id=rnd['season_id'], round_id=round_id)
    lifecycle.round_complete(db, rnd)
    snapshot_pre_round(db)


def snapshot_pre_round(db):
    season = repo.current_season(db)
    if not season: return
    nxt = db.one("SELECT * FROM calendar_rounds WHERE season_id = ? AND status != 'completed' ORDER BY round_no LIMIT 1", (season['id'],))
    if not nxt or db.value("SELECT 1 FROM snapshots WHERE round_id = ? AND kind = 'pre_round'", (nxt['id'],)): return
    cm = config.load('car_model')
    from fcm.management import development
    data = {'drivers': db.all('SELECT d.id, d.form, d.morale, d.potential, d.reputation, a.base_rating FROM drivers d JOIN driver_attributes a ON a.driver_id = d.id WHERE d.retired = 0'),
            'cars': [{'team_id': r['team_id'], 'base_overall': overall_strength({k: r[k] for k in repo.CAR_FIELDS}, cm),
                      'raced_overall': overall_strength(development.team_car_now(db, season['id'], r['team_id']), cm)}
                     for r in db.all('SELECT * FROM car_performance WHERE season_id = ?', (season['id'],))],
            'budgets': db.all('SELECT team_id, cash, cost_cap_spent FROM team_finances WHERE season_id = ?', (season['id'],)),
            'contracts': db.all("SELECT driver_id, team_id, start_season, end_season, role, salary FROM contracts WHERE status = 'active'"),
            'parts': db.all('SELECT team_id, part, spec_no, available FROM parts WHERE season_id = ?', (season['id'],)),
            'regulations': db.all('SELECT category_id, name, data_json FROM regulations WHERE season_id = ?', (season['id'],))}
    db.insert('snapshots', {'season_id': season['id'], 'round_id': nxt['id'], 'kind': 'pre_round', 'data_json': jdump(data), 'create_ts': now_ts()})


# ------------------------------------------------------------------------------------------
# Season end
# ------------------------------------------------------------------------------------------
def finish_season(db):
    from fcm.career_engine import world_builder
    from fcm.management import lifecycle, market
    c = repo.career(db)
    season = repo.current_season(db)
    if db.value("SELECT COUNT(*) FROM calendar_rounds WHERE season_id = ? AND status != 'completed'", (season['id'],)):
        raise RuntimeError('Hay que completar todas las rondas antes de cerrar la temporada')
    year, new_year = season['year'], season['year'] + 1
    pcfg = config.load('progression')
    rng = rng_for(c['seed'], 'season_end', year)
    ts = now_ts()
    old_champs = repo.championships(db, season['id'])
    with db.transaction():
        final = {}
        for ch in old_champs:
            st = champ.driver_standings(db, ch['id'])
            final[ch['category_code']] = st
            if st:
                ev = repo.emit(db, 'CHAMPION_CROWNED', {'category': ch['category_code'], 'driver_id': st[0]['driver_id'], 'points': st[0]['points']}, season_id=season['id'])
                newsroom.champion(db, ch['category_name'], st[0]['driver_id'], st[0]['team_id'], st[0]['points'], st[0]['wins'], year, season['id'], ev)
            cons = champ.constructor_standings(db, ch['id'])
            if cons: newsroom.constructors(db, ch['category_name'], cons[0]['team_id'], cons[0]['team_name'], cons[0]['points'], year, season['id'])
        lifecycle.season_end(db, season)
        db.execute("UPDATE offers SET status = 'expired' WHERE season_id = ? AND status = 'open'", (season['id'],))
        db.execute("UPDATE contracts SET status = 'expired' WHERE status = 'pending' AND effective = 'summer' AND start_season <= ?", (year,))
        db.update('seasons', season['id'], {'status': 'finished'})
        repo.emit(db, 'SEASON_FINISHED', {'year': year}, season_id=season['id'])
        # 1. career-scale driver development (ageing, potential, experience)
        season_scores = {r['driver_id']: r['m'] for r in db.all('SELECT dp.driver_id, AVG(dp.score * dp.confidence) m FROM driver_performance dp JOIN sessions s ON s.id = dp.session_id '
                                                                 'JOIN calendar_rounds cr ON cr.id = s.round_id WHERE cr.season_id = ? GROUP BY dp.driver_id', (season['id'],))}
        if c['realism'].get('driver_progression', True):
            for d in db.all('SELECT id FROM drivers WHERE retired = 0'):
                st = repo.driver_state(db, d['id'], new_year)
                new, rec = season_end_update(st, season_scores.get(d['id'], 0.0), pcfg, rng)
                repo.save_driver_state(db, new, rec, season['id'], None)
        # 2. retirements (drivers holding a future contract keep racing)
        for d in db.all('SELECT d.id, d.first_name, d.last_name, d.birth_date, a.base_rating FROM drivers d JOIN driver_attributes a ON a.driver_id = d.id WHERE d.retired = 0 AND d.is_player = 0'):
            age = repo.age_in(d['birth_date'], new_year)
            if db.value("SELECT 1 FROM contracts WHERE driver_id = ? AND start_season = ? AND status = 'active'", (d['id'], new_year)): continue
            if rng.random() < retirement_probability(age, d['base_rating'], pcfg['retirement']):
                db.update('drivers', d['id'], {'retired': 1, 'retired_season': year})
                db.execute("UPDATE contracts SET status = 'terminated' WHERE driver_id = ? AND status = 'active'", (d['id'],))
                db.execute("UPDATE academy_members SET active = 0 WHERE driver_id = ?", (d['id'],))
                ev = repo.emit(db, 'DRIVER_RETIRED', {'driver_id': d['id'], 'age': age}, season_id=season['id'])
                if db.value('SELECT 1 FROM results WHERE driver_id = ? LIMIT 1', (d['id'],)):
                    newsroom.retirement(db, d['id'], age, season['id'], ev)
        # 3. new season structure
        new_seed = derive_seed(c['seed'], 'season', new_year)
        new_season = db.insert('seasons', {'year': new_year, 'status': 'active', 'seed': new_seed, 'create_ts': ts})
        champ_by_code, cats = {}, {}
        for ch in old_champs:
            champ_by_code[ch['category_code']] = db.insert('championships', {'season_id': new_season, 'category_id': ch['category_id'], 'ac_car_id': ch['ac_car_id'],
                                                                             'player_mode': ch['player_mode'], 'status': 'active', 'rules_json': jdump(ch['rules'])})
            cats[ch['category_code']] = repo.category_config(db, ch['category_id'])['config']
        lifecycle.next_season_cars(db, season['id'], new_season, c['seed'], new_year)
        market.run_season_market(db, c, season, new_year, old_champs, champ_by_code, final, rng)
        cal = []
        for r in db.all('SELECT * FROM calendar_rounds WHERE season_id = ? ORDER BY round_no', (season['id'],)):
            codes = [x['category_code'] for x in db.all('SELECT DISTINCT c.code category_code FROM sessions s JOIN championships ch ON ch.id = s.championship_id '
                                                         'JOIN categories c ON c.id = ch.category_id WHERE s.round_id = ?', (r['id'],))]
            cal.append({'event_name': r['event_name'], 'country': r['country'], 'ac_track_id': r['ac_track_id'], 'ac_layout_id': r['ac_layout_id'],
                        'track_profile_id': r['track_profile_id'], 'date': (r['date'] or '')[5:] or None, 'sprint': r['sprint'], 'categories': codes,
                        **{k: r[k] for k in ('circuit', 'official_length_m', 'length_override_m', 'race_distance_km', 'start_time', 'night', 'climate', 'summer_break_after')}})
        world_builder.create_calendar(db, new_season, new_year, cal, new_seed, champ_by_code, cats)
        repo.update_career(db, current_season_id=new_season)
        lifecycle.init_season(db, new_season, new_year, c['seed'])
        ev = repo.emit(db, 'SEASON_STARTED', {'year': new_year}, season_id=new_season)
        newsroom.season(db, new_year, len(cal), new_season, ev)
    snapshot_pre_round(db)
    _log.info('Season %s finished; %s created', year, new_year)
    return {'finished': year, 'new_season': new_year}
