"""Shared data-access helpers for the career database (all SQL for career entities lives here
or in the owning service; API handlers never run SQL directly)."""
from fcm.database.db import jdump, jload, now_ts
from fcm.simulation.model import ATTRIBUTES, TRACK_KEYS

RACE_ROLES = ('D1', 'D2', 'D3')
RACE_ROLES = ('D1', 'D2', 'D3')
CAR_FIELDS = ('power', 'energy_recovery', 'low_speed_downforce', 'medium_speed_downforce', 'high_speed_downforce', 'drag_efficiency',
              'traction', 'mechanical_grip', 'braking', 'weight', 'tyre_usage', 'cooling', 'reliability')


def career(db):
    c = db.one('SELECT * FROM career WHERE id = 1')
    if not c: return None
    for k in ('difficulty', 'realism', 'settings'): c[k] = jload(c.pop(f'{k}_json'), {})
    return c


def update_career(db, **fields):
    for k in ('difficulty', 'realism', 'settings'):
        if k in fields: fields[f'{k}_json'] = jdump(fields.pop(k))
    fields['update_ts'] = now_ts()
    db.update('career', 1, fields)


def current_season(db):
    return db.one('SELECT s.* FROM seasons s JOIN career c ON c.current_season_id = s.id')


def category_config(db, category_id):
    r = db.one('SELECT * FROM categories WHERE id = ?', (category_id,))
    r['config'] = jload(r.pop('config_json'), {})
    return r


def championship(db, championship_id):
    ch = db.one('SELECT ch.*, c.code category_code, c.name category_name, c.tier, s.year FROM championships ch JOIN categories c ON c.id = ch.category_id JOIN seasons s ON s.id = ch.season_id WHERE ch.id = ?', (championship_id,))
    if ch: ch['rules'] = jload(ch.pop('rules_json'), {})
    return ch


def championships(db, season_id):
    rows = db.all('SELECT ch.*, c.code category_code, c.name category_name, c.tier FROM championships ch JOIN categories c ON c.id = ch.category_id WHERE ch.season_id = ? ORDER BY c.tier', (season_id,))
    for r in rows: r['rules'] = jload(r.pop('rules_json'), {})
    return rows


def age_in(birth_date, year):
    try:
        return year - int(str(birth_date)[:4])
    except (TypeError, ValueError):
        return 25


def driver_state(db, driver_id, year):
    d = db.one('SELECT d.*, a.* FROM drivers d JOIN driver_attributes a ON a.driver_id = d.id WHERE d.id = ?', (driver_id,))
    return {'id': driver_id, 'attrs': {a: d[a] for a in ATTRIBUTES}, 'base': d['base_rating'], 'form': d['form'], 'morale': d['morale'],
            'potential': d['potential'], 'age': age_in(d['birth_date'], year), 'development_rate': d['development_rate'],
            'progress': jload(d['progress_json'], {}), 'reputation': d['reputation']}


def save_driver_state(db, state, record=None, season_id=None, round_id=None):
    ts = now_ts()
    db.update('driver_attributes', state['id'], {**{a: round(state['attrs'][a], 4) for a in ATTRIBUTES}, 'base_rating': round(state['base'], 4), 'update_ts': ts}, key='driver_id')
    db.update('drivers', state['id'], {'form': state['form'], 'morale': state['morale'], 'potential': round(state['potential'], 3),
                                       'progress_json': jdump(state.get('progress', {})), 'update_ts': ts})
    if record:
        db.insert('driver_rating_history', {'driver_id': state['id'], 'season_id': season_id, 'round_id': round_id, 'kind': record['kind'],
                                            'base_before': round(record['base_before'], 4), 'base_after': round(record['base_after'], 4),
                                            'delta': round(record['delta'], 4), 'form_before': record.get('form_before'), 'form_after': record.get('form_after'),
                                            'morale_after': record.get('morale_after'), 'confidence': record.get('confidence'),
                                            'reasons_json': jdump(record.get('reasons', [])),
                                            'attributes_json': jdump({a: round(state['attrs'][a], 2) for a in ATTRIBUTES}), 'create_ts': ts})


def car(db, season_id, team_id):
    r = db.one('SELECT * FROM car_performance WHERE season_id = ? AND team_id = ?', (season_id, team_id))
    return {k: r[k] for k in CAR_FIELDS + ('development_efficiency',)} if r else None


def track_profile(db, profile_id):
    r = db.one('SELECT * FROM track_profiles WHERE id = ?', (profile_id,)) if profile_id else None
    if not r: return {k: 0.5 for k in TRACK_KEYS} | {'overtaking_difficulty': 0.5, 'wet_probability': 0.1, 'length_m': None, 'name': 'default'}
    return r


def entries(db, championship_id, active_only=True):
    sql = ('SELECT e.*, d.first_name, d.last_name, d.short_name, d.nationality, d.is_player, t.name team_name, t.short_name team_short, t.color team_color '
           'FROM championship_entries e JOIN drivers d ON d.id = e.driver_id JOIN teams t ON t.id = e.team_id WHERE e.championship_id = ?')
    if active_only: sql += " AND e.active = 1 AND e.role IN ('D1', 'D2', 'D3')"
    return db.all(sql + ' ORDER BY t.id, e.role', (championship_id,))


def cars_per_team(db, championship_id):
    ch = championship(db, championship_id)
    return int(category_config(db, ch['category_id'])['config'].get('cars_per_team', 2))


def cars_per_team(db, championship_id):
    ch = championship(db, championship_id)
    return int(category_config(db, ch['category_id'])['config'].get('cars_per_team', 2))


def emit(db, type_, payload=None, season_id=None, round_id=None, session_id=None):
    """Append-only domain event log (event sourcing for important changes)."""
    return db.insert('domain_events', {'type': type_, 'season_id': season_id, 'round_id': round_id, 'session_id': session_id,
                                       'payload_json': jdump(payload or {}), 'create_ts': now_ts()})


def news(db, headline, body=None, season_id=None, round_id=None, event_id=None, kind='general', team_id=None, driver_id=None):
    db.insert('news', {'season_id': season_id, 'round_id': round_id, 'event_id': event_id, 'headline': headline, 'body': body, 'kind': kind,
                       'team_id': team_id, 'driver_id': driver_id, 'create_ts': now_ts()})
