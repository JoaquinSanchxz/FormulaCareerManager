"""Redacción: convierte los hechos del juego en noticias con tono de prensa deportiva, variadas y sin datos internos.
Solo se publica lo que ha pasado de verdad en la partida. Sembrado -> reproducible."""
from fcm.career_engine import repo
from fcm.shared.rng import rng_for

PARTS = {'front_wing': ('alerón delantero', 'm'), 'rear_wing': ('alerón trasero', 'm'), 'floor': ('fondo', 'm'), 'diffuser': ('difusor', 'm'),
         'sidepods': ('pontones', 'mp'), 'cooling': ('sistema de refrigeración', 'm'), 'suspension': ('suspensión', 'f'), 'brakes': ('frenos', 'mp'),
         'weight_reduction': ('paquete de aligeramiento', 'm'), 'power_unit': ('unidad de potencia', 'f'), 'ers': ('sistema híbrido', 'm'),
         'gearbox': ('caja de cambios', 'f'), 'reliability_pack': ('paquete de fiabilidad', 'm')}
MAJOR_PARTS = ('front_wing', 'rear_wing', 'floor', 'sidepods', 'power_unit', 'diffuser')
COMPONENTS = {'ICE': 'motor de combustión', 'TURBO': 'turbo', 'ERS': 'sistema híbrido', 'ES': 'batería', 'CE': 'centralita', 'GEARBOX': 'caja de cambios'}
ROLES = {'D1': 'primer piloto', 'D2': 'segundo piloto', 'D3': 'tercer piloto', 'reserve': 'piloto reserva'}
ORD = ['', 'primero', 'segundo', 'tercero', 'cuarto', 'quinto', 'sexto', 'séptimo', 'octavo', 'noveno', 'décimo']


def place(event_name):
    for p in ('Gran Premio de los ', 'Gran Premio de la ', 'Gran Premio del ', 'Gran Premio de '):
        if event_name.startswith(p): return event_name[len(p):]
    return event_name


def part_name(part, form='un'):
    """form: 'un' -> 'un nuevo fondo' / 'una nueva suspensión' / 'unos nuevos pontones'; 'el' -> 'el nuevo fondo'…; '' -> 'fondo'."""
    name, g = PARTS.get(part, (part.replace('_', ' '), 'm'))
    if not form: return name
    art = {'un': {'m': 'un nuevo', 'f': 'una nueva', 'mp': 'unos nuevos'}, 'el': {'m': 'el nuevo', 'f': 'la nueva', 'mp': 'los nuevos'}}[form][g]
    return f'{art} {name}'


def ordinal(n):
    return ORD[n] if 0 < n < len(ORD) else f'{n}.º'


def gap(ms):
    s = (ms or 0) / 1000
    return f"{s:.1f}".replace('.', ',') + ' s' if s < 60 else f"{int(s // 60)} min {int(s % 60)} s"


def _pick(db, options, salt):
    n = db.value('SELECT COUNT(*) FROM news')
    return rng_for(repo.career(db)['seed'], 'news', salt, n).choice(options)


def publish(db, kind, options, ctx, season_id=None, round_id=None, event_id=None, team_id=None, driver_id=None):
    h, b = _pick(db, options, kind)
    h = h.format(**ctx)
    if db.value('SELECT 1 FROM news WHERE headline = ? AND round_id IS ?', (h, round_id)): return
    repo.news(db, h, b.format(**ctx) if b else None, season_id, round_id, event_id, kind=kind, team_id=team_id, driver_id=driver_id)


def _driver(db, did):
    d = db.one('SELECT first_name, last_name FROM drivers WHERE id = ?', (did,)) or {'first_name': '?', 'last_name': '?'}
    return f"{d['first_name']} {d['last_name']}", d['last_name']


def _team(db, tid):
    return db.value('SELECT name FROM teams WHERE id = ?', (tid,)) or '?'


# ------------------------------------------------------------------------------------------
# Sesiones
# ------------------------------------------------------------------------------------------
def session_result(db, s, rows, ev):
    """F1: pole, sprint y carrera con crónica. F2/F3: solo la carrera principal, en breve."""
    ch = repo.championship(db, s['championship_id'])
    cat = ch['category_code']
    fin = [r for r in sorted(rows, key=lambda r: r['position']) if r.get('status', 'FIN') == 'FIN']
    if len(fin) < 3 or (cat != 'F1' and s['type'] != 'race'): return
    w, p2, p3 = fin[0], fin[1], fin[2]
    (wn, wl), (p2n, p2l), (p3n, p3l) = _driver(db, w['driver_id']), _driver(db, p2['driver_id']), _driver(db, p3['driver_id'])
    ctx = {'w': wn, 'wl': wl, 'p2': p2n, 'p2l': p2l, 'p3': p3n, 'p3l': p3l, 'team': _team(db, w['team_id']), 'pl': place(s['event_name']), 'cat': cat, 'ev': s['event_name']}
    meta = {'season_id': s['season_id'], 'round_id': s['round_id'], 'event_id': ev, 'team_id': w['team_id'], 'driver_id': w['driver_id']}
    if s['type'] == 'qualifying':
        if cat != 'F1': return
        lap = lambda r: r.get('q3_ms') or r.get('best_lap_ms') or 0
        d = lap(p2) - lap(w)
        ctx['gap'] = gap(d).replace(' s', ' segundos') if d >= 50 else 'apenas unas milésimas'
        opts = [('Pole para {w} en {pl}', '{wl} fue el más rápido de la clasificación y saldrá primero, {gap} por delante de {p2}. {p3l} saldrá tercero.'),
                ('{w} manda en la clasificación de {pl}', 'El piloto de {team} firmó la mejor vuelta en la Q3. {p2} y {p3} le acompañarán en las primeras posiciones.'),
                ('{wl} se queda con la pole en {pl}', 'Vuelta perfecta de {w}, que batió a {p2} por {gap}. {p3} saldrá tercero.'),
                ('{team} sonríe: {wl} saldrá desde la pole en {pl}', '{p2l} y {p3l} no pudieron con el crono de {wl} en el último intento.')]
        if s['code'] == 'SQ':
            opts = [('{wl} saldrá primero en la sprint de {pl}', 'Por detrás arrancarán {p2} y {p3}.'), ('Pole sprint para {w} en {pl}', '{team} se asegura la mejor posición para la carrera corta.')]
        return publish(db, 'clasificacion', opts, ctx, **meta)
    if s['type'] == 'sprint':
        return publish(db, 'carrera', [('{w} se lleva la sprint de {pl}', '{p2} y {p3} completaron el podio de la carrera corta.'),
                                       ('Sprint para {wl} en {pl}', 'El piloto de {team} suma ocho puntos antes del Gran Premio. {p2l} fue segundo y {p3l}, tercero.'),
                                       ('{wl} gana la carrera sprint', 'Buen aperitivo en {pl}: {w} por delante de {p2} y {p3}.')], ctx, **meta)
    if cat != 'F1':
        return publish(db, 'carrera', [('{cat}: {w} gana la carrera principal en {pl}', '{p2} y {p3} completaron el podio.'),
                                       ('{cat}: triunfo de {wl} en {pl}', 'El piloto de {team} se impuso a {p2} y {p3}.'),
                                       ('{cat}: {wl} vence en {pl}', 'Victoria para {team}. Podio para {p2l} y {p3l}.')], ctx, **meta)
    ctx['gap'] = gap(p2.get('gap_ms'))
    ctx['grid'] = w.get('grid_position') or 0
    wet = db.value('SELECT weather FROM sessions WHERE id = ?', (s['id'],)) == 'wet'
    close, big = (p2.get('gap_ms') or 99999) < 1500, (p2.get('gap_ms') or 0) > 15000
    if wet: heads = ['{w} brilla bajo la lluvia de {pl}', 'Lección de pilotaje en mojado: {wl} gana en {pl}', '{wl} domina el caos de {pl}']
    elif ctx['grid'] >= 6: heads = ['Remontada de {wl}: de la {grid}.ª posición a la victoria en {pl}', '{wl} firma una remontada histórica en {pl}', '¡Qué carrera de {wl}! Gana en {pl} saliendo {grid}.º']
    elif close: heads = ['{wl} resiste a {p2l} en un final de infarto en {pl}', 'Por los pelos: {wl} gana en {pl} con {p2l} pegado a su caja de cambios', '{wl} aguanta la presión y vence en {pl}']
    elif big and ctx['grid'] == 1: heads = ['Paseo de {wl} en {pl}', '{w} domina de principio a fin en {pl}', 'Exhibición de {wl} en {pl}']
    else: heads = ['{w} gana el {ev}', '{wl} se impone en {pl}', 'Victoria de {wl} en {pl}', '{wl} conquista {pl}', '{team} celebra en {pl} con {wl}']
    body = _pick(db, ['{wl} cruzó la meta con {gap} de ventaja sobre {p2}. {p3} completó el podio.', '{w} se impuso por {gap} a {p2l}, con {p3l} en el tercer escalón del podio.',
                      'Por detrás de {wl}, {p2} fue segundo a {gap} y {p3} terminó tercero.'], 'body')
    extra = []
    if ctx['grid'] >= 6 and not wet: extra.append('Había salido desde la {grid}.ª posición.')
    if wet: extra.append('La lluvia obligó a varios cambios de neumáticos y puso a prueba a todos.')
    dnf = sorted((r for r in rows if r.get('status') == 'DNF' and r.get('grid_position')), key=lambda r: r['grid_position'])
    if dnf and dnf[0]['grid_position'] <= 6:
        extra.append(f"{_driver(db, dnf[0]['driver_id'])[0]} abandonó por {'una avería' if dnf[0].get('dnf_reason') == 'mechanical' else 'un accidente'}.")
    from fcm.career_engine import championship as champ
    st = champ.driver_standings(db, s['championship_id'])
    if len(st) > 1:
        ld, sd = _driver(db, st[0]['driver_id'])[1], _driver(db, st[1]['driver_id'])[1]
        diff = round(st[0]['points'] - st[1]['points'])
        extra.append(f"{ld} lidera el campeonato con {diff} punto{'s' if diff != 1 else ''} de ventaja sobre {sd}." if diff else f"{ld} y {sd} están empatados al frente del campeonato.")
    repo.news(db, _pick(db, heads, 'head').format(**ctx), ' '.join([body] + extra).format(**ctx), kind='carrera', **meta)


def milestone(db, s, driver_id, kind, count, cat, ev):
    name, last = _driver(db, driver_id)
    ctx = {'name': name, 'last': last, 'cat': cat, 'n': count, 'pl': place(s['event_name'])}
    if count == 1:
        opts = {'wins': [('¡Primera victoria de {name} en {cat}!', 'Un día que {last} no olvidará: su primer triunfo llega en {pl}.'), ('{name} ya sabe lo que es ganar en {cat}', 'Primera victoria de su carrera, en {pl}.')],
                'podiums': [('Primer podio en {cat} para {name}', '{last} sube por primera vez al cajón en {pl}.'), ('{name} estrena su casillero de podios', 'Primer podio en {cat}, conseguido en {pl}.')],
                'poles': [('Primera pole de {name} en {cat}', '{last} saldrá desde la primera posición por primera vez en {pl}.')]}[kind]
    else:
        label = {'wins': 'victorias', 'podiums': 'podios', 'poles': 'poles', 'starts': 'grandes premios'}[kind]
        ctx['label'] = label
        opts = [('{name} alcanza las {n} {label} en {cat}', 'La cifra redonda llegó en {pl}.'), ('{n} {label} para {name}', '{last} sigue sumando para la historia en {pl}.')]
    publish(db, 'hito', opts, ctx, s['season_id'], s['round_id'], ev, driver_id=driver_id)


# ------------------------------------------------------------------------------------------
# Temporada y campeonatos
# ------------------------------------------------------------------------------------------
def champion(db, cat_name, driver_id, team_id, points, wins, year, season_id, ev):
    name, last = _driver(db, driver_id)
    publish(db, 'campeonato', [('¡{name}, campeón de {cat} {year}!', '{last} cierra la temporada con {pts} puntos y {wins} victorias.'),
                               ('{name} conquista el título de {cat}', 'Campeón {year} con {wins} victorias y {pts} puntos.'),
                               ('{last} ya es campeón de {cat}', 'Un año para enmarcar: {wins} victorias y el título de {year}.')],
            {'name': name, 'last': last, 'cat': cat_name, 'year': year, 'pts': f'{points:g}', 'wins': wins}, season_id, None, ev, team_id, driver_id)


def constructors(db, cat_name, team_id, team_name, points, year, season_id):
    publish(db, 'campeonato', [('{team} gana el título de constructores de {cat}', 'Campeón del mundo de equipos {year} con {pts} puntos.'),
                               ('Fiesta en {team}: campeones de constructores {year}', 'El equipo suma {pts} puntos en {cat}.')],
            {'team': team_name, 'cat': cat_name, 'year': year, 'pts': f'{points:g}'}, season_id, team_id=team_id)


def retirement(db, driver_id, age, season_id, ev):
    name, last = _driver(db, driver_id)
    publish(db, 'mercado', [('{name} cuelga el casco a los {age} años', 'Se cierra una etapa: {last} no estará en la parrilla la próxima temporada.'),
                            ('Adiós a {name}', '{last} anuncia su retirada a los {age} años.'), ('{name} anuncia su retirada', 'A los {age} años, {last} pone fin a su carrera deportiva.')],
            {'name': name, 'last': last, 'age': age}, season_id, None, ev, driver_id=driver_id)


def season(db, year, rounds, season_id, ev, first=False):
    publish(db, 'temporada', [('Arranca la temporada {year}', '{n} grandes premios por delante. Que empiece el espectáculo.'), ('Todo listo para {year}', 'El calendario incluye {n} citas.')] if first else
            [('La temporada {year} ya tiene calendario', '{n} grandes premios esperan a los equipos.'), ('Cuenta atrás para {year}', 'Los equipos preparan sus coches para un calendario de {n} carreras.')],
            {'year': year, 'n': rounds}, season_id, None, ev)


def regulation(db, year, season_id, ev):
    publish(db, 'reglamento', [('Nuevo reglamento técnico para {y}', 'Los coches cambiarán a fondo: el desarrollo del coche del año que viene será clave.'),
                               ('La FIA confirma cambios técnicos para {y}', 'Los equipos tendrán que repartir recursos entre el coche actual y el nuevo.')],
            {'y': year + 1}, season_id, None, ev)


# ------------------------------------------------------------------------------------------
# Equipos, técnica y mercado
# ------------------------------------------------------------------------------------------
def development(db, team_id, part, outcome, is_player_team, tier, season_id, round_id, ev, rng):
    """Solo F1. Tu equipo: siempre. Rivales: piezas importantes o historias (acierto/fracaso), no cada pieza."""
    if tier != 1: return
    story = outcome in ('overperformed', 'failed')
    if not is_player_team:
        if not story and not (part in MAJOR_PARTS and rng.random() < 0.25): return
        same = db.value("SELECT COUNT(*) FROM news WHERE kind = 'tecnica' AND round_id IS ? AND team_id = ?", (round_id, team_id))
        total = db.value("SELECT COUNT(*) FROM news WHERE kind = 'tecnica' AND round_id IS ?", (round_id,))
        if same or total >= 2: return      # one story per team and a couple per weekend, like the real press
    ctx = {'team': _team(db, team_id), 'un': part_name(part), 'el': part_name(part, 'el'), 'p': part_name(part, '')}
    if outcome == 'failed':
        opts = [('Contratiempo en {team}: {el} no funciona como esperaban', 'El equipo tendrá que volver a la mesa de diseño.'), ('Revés técnico para {team}', 'Las pruebas de {el} no han salido bien.')]
    elif is_player_team:
        opts = [('Tu equipo termina el diseño de {un}', 'La pieza ya puede fabricarse en Mi equipo.'), ('Listo {un} en la fábrica', 'Los ingenieros han terminado el diseño: toca fabricarlo e instalarlo.')] if outcome != 'overperformed' else \
               [('¡Buenas noticias en la fábrica! {el} rinde por encima de lo esperado', 'Ya puede fabricarse en Mi equipo.')]
    elif outcome == 'overperformed':
        opts = [('{team} da con la tecla: {el} supera las expectativas', 'Los rivales toman nota.'), ('Paso adelante de {team} con {el}', 'Los datos del túnel de viento ilusionan en la fábrica.')]
    else:
        opts = [('{team} prepara {un}', 'Llegará a la pista en las próximas carreras.'), ('Rumores en el paddock: {team} trabaja en {un}', None),
                ('{team} tiene lista la evolución de su {p}', 'Ahora queda fabricarla.')]
    publish(db, 'tecnica', opts, ctx, season_id, round_id, ev, team_id)


def grid_penalty(db, driver_id, places, component, season_id, round_id, ev):
    name, last = _driver(db, driver_id)
    publish(db, 'equipo', [('{name}, sancionado con {n} puestos en parrilla', 'Estrena {c} y supera el cupo permitido por el reglamento.'),
                           ('Penalización para {last}: {n} posiciones', 'El cambio de {c} le obliga a retrasar su salida.')],
            {'name': name, 'last': last, 'n': places, 'c': COMPONENTS.get(component, component.lower())}, season_id, round_id, ev, driver_id=driver_id)


def sponsor(db, team_id, season_id, round_id):
    publish(db, 'equipo', [('{team} cumple el reto de su patrocinador', 'Un extra económico que vendrá bien en la fábrica.'), ('Bonus de patrocinio para {team}', 'El resultado desbloquea una prima del patrocinador principal.')],
            {'team': _team(db, team_id)}, season_id, round_id, team_id=team_id)


def cost_cap(db, team_id, over, pct, season_id, ev):
    publish(db, 'equipo', [('{team} se salta el límite de gasto', 'Multa y {pct} % menos de desarrollo la próxima temporada.'), ('Sanción a {team} por superar el techo presupuestario', 'Pagará una multa y verá recortado su desarrollo un {pct} %.')],
            {'team': _team(db, team_id), 'pct': pct}, season_id, None, ev, team_id)


def objective(db, team_id, target, result, season_id, ev):
    ctx = {'team': _team(db, team_id), 'obj': ordinal(target), 'res': ordinal(result)}
    opts = [('{team} supera su objetivo de la temporada', 'Terminó {res} en constructores; el objetivo era ser {obj}.')] if result < target else \
           [('{team} cumple el objetivo', 'Terminó {res} en constructores, justo lo que se pedía.')] if result == target else \
           [('{team} no alcanza su objetivo', 'Terminó {res} en constructores; se esperaba ser {obj}. Toca reflexionar.')]
    publish(db, 'equipo', opts, ctx, season_id, None, ev, team_id)


def offers(db, n, season_id, round_id):
    publish(db, 'jugador', [('Tienes {n} oferta{s} sobre la mesa', 'Revísalas en Mercado y contratos antes de que caduquen.'), ('Hay equipos interesados en ti', '{n} oferta{s} esperan respuesta en Mercado y contratos.'),
                            ('Tu representante tiene novedades', 'Ha recibido {n} oferta{s} de contrato.')], {'n': n, 's': 's' if n != 1 else ''}, season_id, round_id)


def signing(db, driver_id, team_id, role, years, when, season_id, ev):
    name, last = _driver(db, driver_id)
    publish(db, 'mercado', [('{name} firma con {team}', 'Será {role} {when} con un contrato de {y} año{s}.'), ('Oficial: {last} correrá con {team}', 'Acuerdo por {y} año{s}, {when}.'),
                            ('{team} anuncia el fichaje de {name}', 'Llega como {role} {when}.')],
            {'name': name, 'last': last, 'team': _team(db, team_id), 'role': ROLES.get(role, role), 'y': years, 's': 's' if years != 1 else '', 'when': when}, season_id, None, ev, team_id, driver_id)


def midseason(db, driver_id, team_id, dropped_id, season_id, ev):
    name, last = _driver(db, driver_id)
    ctx = {'name': name, 'last': last, 'team': _team(db, team_id), 'out': _driver(db, dropped_id)[0] if dropped_id else ''}
    publish(db, 'mercado', [('Bombazo en pleno verano: {name} ficha por {team}', 'Ocupará el asiento de {out}.' if dropped_id else 'Debutará con el equipo tras el parón.'),
                            ('{last} cambia de aires: correrá con {team}', 'El movimiento se hará efectivo tras el parón de verano.'),
                            ('{team} mueve ficha: llega {name}', 'Sustituye a {out}.' if dropped_id else 'Se incorpora tras el parón de verano.')], ctx, season_id, None, ev, team_id, driver_id)


def injury(db, driver_id, rounds, replacement_id, season_id, round_id, ev):
    name, last = _driver(db, driver_id)
    publish(db, 'lesion', [('{name} se pierde {n} carrera{s} por lesión', 'Le sustituirá {rep}.'), ('Baja de {last} tras su accidente', 'Estará {n} carrera{s} fuera; {rep} ocupa su asiento.')],
            {'name': name, 'last': last, 'n': rounds, 's': 's' if rounds != 1 else '', 'rep': _driver(db, replacement_id)[0]}, season_id, round_id, ev, driver_id=driver_id)


def promotion(db, driver_id, team_id, cat_name, season_id, ev):
    name, last = _driver(db, driver_id)
    publish(db, 'mercado', [('{name} da el salto a {cat} con {team}', 'Premio a una gran temporada.'), ('{team} apuesta por {name}', '{last} sube a {cat} para la próxima temporada.'),
                            ('Ascenso para {last}: estará en {cat}', 'Correrá con {team}.')], {'name': name, 'last': last, 'team': _team(db, team_id), 'cat': cat_name}, season_id, None, ev, team_id, driver_id)
