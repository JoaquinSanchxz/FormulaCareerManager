"""Personality / background test for a new driver: suggests category, rating, potential, attribute profile
and the teams where the driver fits best. Pure data + scoring (no randomness)."""
from fcm.simulation.model import clamp

QUESTIONS = [
    {'id': 'background', 'text': '¿Cuál es tu trayectoria hasta ahora?', 'options': [
        {'id': 'karting', 'text': 'Campeón de karting, recién llegado a los monoplazas', 'effects': {'level': 60, 'age': 17}},
        {'id': 'f4', 'text': 'Buenas temporadas en F4 / Fórmula Regional', 'effects': {'level': 65, 'age': 18}},
        {'id': 'f3', 'text': 'Ganador de carreras en F3', 'effects': {'level': 71, 'age': 19}},
        {'id': 'f2', 'text': 'Aspirante al título de F2', 'effects': {'level': 77, 'age': 21}},
        {'id': 'ready', 'text': 'Preparado para la F1 ya', 'effects': {'level': 80, 'age': 22}}]},
    {'id': 'style', 'text': 'En pista, ¿cómo te describirías?', 'options': [
        {'id': 'attacker', 'text': 'Agresivo: siempre busco el adelantamiento', 'effects': {'overtaking': 4, 'racecraft': 2, 'awareness': -3}},
        {'id': 'calculator', 'text': 'Calculador: pienso la carrera a largo plazo', 'effects': {'tyre_management': 4, 'consistency': 3, 'overtaking': -2}},
        {'id': 'qualifier', 'text': 'Rapidísimo a una vuelta', 'effects': {'qualifying': 5, 'pace': 2, 'tyre_management': -3}},
        {'id': 'wall', 'text': 'Muy difícil de adelantar', 'effects': {'defending': 5, 'awareness': 2, 'starts': -1}}]},
    {'id': 'pressure', 'text': 'Última vuelta, tienes a un rival detrás a medio segundo...', 'options': [
        {'id': 'ice', 'text': 'Mantengo la calma y hago mi vuelta', 'effects': {'consistency': 3, 'awareness': 2}},
        {'id': 'risk', 'text': 'Arriesgo en cada curva para escaparme', 'effects': {'pace': 2, 'awareness': -3, 'racecraft': 1}},
        {'id': 'block', 'text': 'Cierro todas las puertas', 'effects': {'defending': 3, 'racecraft': 1}}]},
    {'id': 'rain', 'text': 'Empieza a llover en mitad de la carrera:', 'options': [
        {'id': 'love', 'text': 'Me encanta, es donde marco la diferencia', 'effects': {'wet_skill': 6, 'adaptability': 2}},
        {'id': 'fine', 'text': 'Me adapto sin problema', 'effects': {'wet_skill': 2, 'adaptability': 2}},
        {'id': 'hate', 'text': 'Prefiero el seco, sin duda', 'effects': {'wet_skill': -4, 'pace': 1}}]},
    {'id': 'start', 'text': 'Se apagan los semáforos:', 'options': [
        {'id': 'rocket', 'text': 'Suelo ganar posiciones en la salida', 'effects': {'starts': 5}},
        {'id': 'safe', 'text': 'Prefiero no arriesgar en la primera curva', 'effects': {'awareness': 3, 'starts': -1}}]},
    {'id': 'work', 'text': '¿Cómo trabajas con los ingenieros?', 'options': [
        {'id': 'technical', 'text': 'Muy técnico: me encanta la telemetría y el reglaje', 'effects': {'adaptability': 3, 'consistency': 1, 'potential': 1}},
        {'id': 'instinct', 'text': 'Piloto por instinto', 'effects': {'pace': 2, 'adaptability': -2}},
        {'id': 'leader', 'text': 'Soy líder, el equipo gira a mi alrededor', 'effects': {'reputation': 5, 'potential': 1}}]},
    {'id': 'ambition', 'text': '¿Qué tipo de equipo buscas?', 'options': [
        {'id': 'top', 'text': 'Un equipo grande para ganar ya', 'effects': {'team_pref': 'top'}},
        {'id': 'project', 'text': 'Un proyecto en crecimiento donde ser el líder', 'effects': {'team_pref': 'mid'}},
        {'id': 'any', 'text': 'Donde pueda demostrar lo que valgo', 'effects': {'team_pref': 'fit'}}]},
    {'id': 'talent', 'text': 'Sé sincero: tu talento natural es...', 'options': [
        {'id': 'generational', 'text': 'Generacional', 'effects': {'potential': 8, 'level': 1}},
        {'id': 'high', 'text': 'Muy alto', 'effects': {'potential': 5}},
        {'id': 'worker', 'text': 'Normal, pero trabajo más que nadie', 'effects': {'potential': 2, 'consistency': 2}}]},
]

PERSONALITY_BY_STYLE = {'attacker': 'aggressive', 'calculator': 'methodical', 'qualifier': 'streaky', 'wall': 'calm'}


def evaluate(answers, world, categories=('F1', 'F2', 'F3')):
    """answers: {question_id: option_id}. Returns profile + recommended category and ranked teams."""
    eff = {}
    for q in QUESTIONS:
        opt = next((o for o in q['options'] if o['id'] == answers.get(q['id'])), q['options'][0])
        for k, v in opt['effects'].items():
            eff[k] = v if isinstance(v, str) else eff.get(k, 0) + v
    level = eff.pop('level', 70)
    age = eff.pop('age', 19)
    pot_bonus = eff.pop('potential', 0)
    rep = 20 + eff.pop('reputation', 0) + max(0, level - 65)
    pref = eff.pop('team_pref', 'fit')
    rating = clamp(level, 55, 84)
    potential = clamp(rating + 8 + pot_bonus + max(0, (21 - age)) * 1.5, rating + 2, 97)
    cat = 'F1' if rating >= 78 else 'F2' if rating >= 69 else 'F3'
    if cat not in categories: cat = next((c for c in ('F2', 'F3', 'F1') if c in categories), 'F1')
    teams = world['categories'].get(cat, {}).get('teams', [])
    strengths = sorted((t.get('strength', 85) for t in teams), reverse=True)
    ranked = []
    for i, t in enumerate(teams):
        rank = strengths.index(t.get('strength', 85)) + 1
        n = len(teams)
        if pref == 'top': fit = n - rank
        elif pref == 'mid': fit = n / 2 - abs(rank - n * 0.55)
        else:
            drivers = t.get('drivers') or []
            weakest = min((d.get('rating', 70) for d in drivers), default=70)
            fit = 5 - abs(weakest - rating) / 2
        ranked.append({'team_index': i, 'name': t['name'], 'fit': round(fit, 2), 'car_rank': rank})
    ranked.sort(key=lambda x: -x['fit'])
    style = answers.get('style')
    return {'category': cat, 'rating': round(rating, 1), 'potential': round(potential, 1), 'age': age, 'reputation': round(rep, 1),
            'attribute_offsets': eff, 'personality': PERSONALITY_BY_STYLE.get(style, 'methodical'), 'teams': ranked[:5]}
