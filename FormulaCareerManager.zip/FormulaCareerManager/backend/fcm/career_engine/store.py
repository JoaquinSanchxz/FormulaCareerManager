"""Save-game management. Each career is one SQLite file: <data>/saves/<id>.fcm.

- autosave: SQLite online-backup copy into saves/autosave (before/after session, after decisions)
- export  : the .fcm file itself is the export format
- import  : validated copy of an .fcm file into saves/
"""
import re
import shutil
import sqlite3
import threading
import time
from pathlib import Path

from fcm.database.db import Database, jload
from fcm.shared import config, log, paths

_log = log.get('CAREER')


def slugify(text):
    s = re.sub(r'[^a-zA-Z0-9]+', '_', text or '').strip('_').lower()[:40]
    return s or 'career'


class CareerStore:
    def __init__(self):
        self.lock = threading.RLock()
        self.app_db = None
        self.db = None
        self.career_id = None

    def init_app_db(self):
        if not self.app_db: self.app_db = Database(paths.app_db_path(), 'app')
        return self.app_db

    # --- settings (app DB) ----------------------------------------------------------------
    def get_setting(self, key, default=None):
        r = self.app_db.one('SELECT value_json FROM settings WHERE key = ?', (key,))
        return jload(r['value_json'], default) if r else default

    def set_setting(self, key, value):
        from fcm.database.db import jdump, now_ts
        self.app_db.execute('INSERT INTO settings (key, value_json, update_ts) VALUES (?, ?, ?) ON CONFLICT(key) DO UPDATE SET value_json = excluded.value_json, update_ts = excluded.update_ts',
                            (key, jdump(value), now_ts()))

    # --- saves --------------------------------------------------------------------------
    def save_path(self, career_id) -> Path:
        if not re.fullmatch(r'[a-z0-9_]+', career_id or ''): raise ValueError('Invalid career id')
        return paths.saves_dir() / f'{career_id}.fcm'

    def new_career_id(self, name):
        base = slugify(name)
        cid, i = base, 2
        while self.save_path(cid).exists():
            cid = f'{base}_{i}'
            i += 1
        return cid

    def create(self, name) -> Database:
        with self.lock:
            self.close()
            cid = self.new_career_id(name)
            self.db = Database(self.save_path(cid), 'career')
            self.career_id = cid
            self.set_setting('last_career', cid)
            return self.db

    def open(self, career_id) -> Database:
        with self.lock:
            p = self.save_path(career_id)
            if not p.exists(): raise FileNotFoundError(f'Save {career_id} not found')
            if self.career_id == career_id and self.db: return self.db
            self.close()
            self.db = Database(p, 'career')
            self.career_id = career_id
            self.set_setting('last_career', career_id)
            from fcm.ac_integration.launcher import launcher
            if not launcher.is_busy():  # recover sessions left 'running' by a crash/close during AC
                self.db.execute("UPDATE sessions SET status = 'pending', mode = NULL WHERE status = 'running'")
            c = self.db.one('SELECT seed, current_season_id FROM career WHERE id = 1')
            if c and c['current_season_id'] and not self.db.value('SELECT COUNT(*) FROM team_ai'):
                from fcm.management import lifecycle  # save created before the management migration
                year = self.db.value('SELECT year FROM seasons WHERE id = ?', (c['current_season_id'],))
                with self.db.transaction():
                    lifecycle.init_season(self.db, c['current_season_id'], year, c['seed'], first=True)
            _log.info('Opened career %s', career_id)
            return self.db

    def close(self):
        with self.lock:
            if self.db: self.db.close()
            self.db, self.career_id = None, None

    def require(self) -> Database:
        if not self.db: raise LookupError('No hay ninguna partida cargada')
        return self.db

    def list_saves(self):
        out = []
        for f in sorted(paths.saves_dir().glob('*.fcm'), key=lambda p: p.stat().st_mtime, reverse=True):
            info = {'id': f.stem, 'file': f.name, 'size': f.stat().st_size, 'modified': time.strftime('%Y-%m-%d %H:%M', time.localtime(f.stat().st_mtime))}
            try:
                con = sqlite3.connect(f'file:{f}?mode=ro', uri=True)
                con.row_factory = sqlite3.Row
                c = con.execute('SELECT name, player_driver_id, current_season_id FROM career WHERE id = 1').fetchone()
                if c:
                    info['name'] = c['name']
                    s = con.execute('SELECT year FROM seasons WHERE id = ?', (c['current_season_id'],)).fetchone()
                    info['season'] = s['year'] if s else None
                    d = con.execute('SELECT first_name, last_name FROM drivers WHERE id = ?', (c['player_driver_id'],)).fetchone()
                    info['player'] = f"{d['first_name']} {d['last_name']}" if d else None
                    r = con.execute("SELECT round_no, event_name FROM calendar_rounds WHERE season_id = ? AND status != 'completed' ORDER BY round_no LIMIT 1", (c['current_season_id'],)).fetchone()
                    info['next_round'] = f"R{r['round_no']} {r['event_name']}" if r else None
                con.close()
            except sqlite3.Error as e:
                info['error'] = str(e)
            out.append(info)
        return out

    def delete(self, career_id):
        with self.lock:
            if self.career_id == career_id: self.close()
            p = self.save_path(career_id)
            dest = paths.backups_dir() / 'deleted'
            dest.mkdir(parents=True, exist_ok=True)
            shutil.move(str(p), str(dest / f'{career_id}_{int(time.time())}.fcm'))

    def autosave(self, tag):
        with self.lock:
            if not self.db: return None
            safe_tag = re.sub(r'[^a-z0-9_]+', '_', tag.lower())
            dest = paths.autosave_dir() / f'{self.career_id}__{time.strftime("%Y%m%d_%H%M%S")}__{safe_tag}.fcm'
            with self.db.lock:
                target = sqlite3.connect(str(dest))
                self.db.conn.backup(target)
                target.close()
            keep = config.load('app')['autosave']['keep']
            olds = sorted(paths.autosave_dir().glob(f'{self.career_id}__*.fcm'))
            for o in olds[:-keep]:
                try:
                    o.unlink()
                except OSError:
                    pass
            _log.info('Autosave %s', dest.name)
            return dest

    def list_autosaves(self, career_id):
        return [{'file': f.name, 'tag': f.stem.split('__')[-1], 'modified': time.strftime('%Y-%m-%d %H:%M:%S', time.localtime(f.stat().st_mtime))}
                for f in sorted(paths.autosave_dir().glob(f'{career_id}__*.fcm'), reverse=True)]

    def restore_autosave(self, file_name):
        src = paths.autosave_dir() / Path(file_name).name
        if not src.exists(): raise FileNotFoundError(file_name)
        cid = src.name.split('__')[0]
        with self.lock:
            if self.career_id == cid: self.close()
            if self.save_path(cid).exists(): shutil.copy2(self.save_path(cid), paths.backups_dir() / f'{cid}_before_restore_{int(time.time())}.fcm')
            shutil.copy2(src, self.save_path(cid))
            return self.open(cid)

    def export_path(self):
        with self.lock:
            self.require()
            dest = paths.backups_dir() / f'{self.career_id}_export.fcm'
            with self.db.lock:
                target = sqlite3.connect(str(dest))
                self.db.conn.backup(target)
                target.close()
            return dest

    def import_file(self, raw: bytes, name_hint='imported'):
        tmp = paths.backups_dir() / f'import_{int(time.time() * 1000)}.fcm'
        tmp.write_bytes(raw)
        try:
            con = sqlite3.connect(f'file:{tmp}?mode=ro', uri=True)
            row = con.execute('SELECT name FROM career WHERE id = 1').fetchone()
            con.close()
            if not row: raise ValueError('El fichero no es una partida')
        except sqlite3.Error as e:
            tmp.unlink(missing_ok=True)
            raise ValueError(f'Fichero de partida no válido: {e}')
        cid = self.new_career_id(row[0] or name_hint)
        shutil.move(str(tmp), str(self.save_path(cid)))
        return cid


store = CareerStore()
