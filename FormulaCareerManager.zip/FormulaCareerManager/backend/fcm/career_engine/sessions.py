"""SessionService: builds fields/grids, simulates sessions, prepares + launches AC sessions and
imports AC results. Played and simulated results share the same tables."""
import math

from fcm.ac_integration import csp_weather, detect, race_ini, results as ac_results
from fcm.ac_integration.launcher import launcher
from fcm.career_engine import championship as champ, repo
from fcm.career_engine.rating import session_scores
from fcm.career_engine.store import store
from fcm.career_engine.translator import translate_entry
from fcm.database.db import jdump, jload, now_ts
from fcm.shared import config, log
from fcm.shared.rng import rng_for
from fcm.simulation import engine, weather
from fcm.simulation.model import car_track_strength
from fcm.management import components, development, lifecycle, regulations
from fcm.ac_integration import telemetry as ac_telemetry

_log = log.get('SESSION')
DEFAULT_LENGTH_M = 5000.0


class SessionError(RuntimeError):
    pass


# ------------------------------------------------------------------------------------------
# Lookups
# ------------------------------------------------------------------------------------------
def get(db, session_id):
    s = db.one('SELECT s.*, cr.round_no, cr.event_name, cr.ac_track_id, cr.ac_layout_id, cr.track_profile_id, cr.season_id, cr.status round_status, '
               'cr.official_length_m, cr.length_override_m, cr.race_distance_km, cr.start_time, cr.night, cr.climate '
               'FROM sessions s JOIN calendar_rounds cr ON cr.id = s.round_id WHERE s.id = ?', (session_id,))
    if not s: raise SessionError(f'Sesión {session_id} no encontrada')
    s['grid_rule'] = jload(s.pop('grid_rule_json'), {})
    s['conditions'] = jload(s.pop('conditions_json'), {})
    s['strategy'] = jload(s.pop('strategy_json'), {})
    return s


def knockout(s):
    return (s.get('grid_rule') or {}).get('knockout') if s['type'] == 'qualifying' else None


def track_length_m(db, s):
    """Priority: manual override > official circuit length > AC layout length > profile > default."""
    for k in ('length_override_m', 'official_length_m'):
        if s.get(k): return float(s[k])
    if s['ac_track_id'] and store.app_db:
        l = store.app_db.one('SELECT length_m FROM ac_track_layouts WHERE track_id = ? AND id = ?', (s['ac_track_id'], s['ac_layout_id'] or ''))
        if l and l['length_m']: return float(l['length_m'])
    prof = repo.track_profile(db, s['track_profile_id'])
    return float(prof.get('length_m') or DEFAULT_LENGTH_M)


def session_format(db, s):
    """Laps (races) or minutes (timed) actually used, derived from career length settings."""
    ch = repo.championship(db, s['championship_id'])
    cat = repo.category_config(db, ch['category_id'])['config']
    settings = repo.career(db)['settings']
    acs = config.load('ac_session')
    length = track_length_m(db, s)
    mode = str(settings.get('race_length', settings.get('race_length_pct', 100)))
    if s['type'] in ('race', 'sprint'):
        if s['status'] == 'completed' and s['laps']: return {'laps': s['laps'], 'duration_min': 0, 'length_m': length, 'distance_km': round(s['laps'] * length / 1000, 3)}
        if mode == 'laps5':
            laps = acs['fixed_laps_sprint'] if s['type'] == 'sprint' else acs['fixed_laps_race']
            return {'laps': laps, 'duration_min': 0, 'length_m': length, 'distance_km': round(laps * length / 1000, 3), 'mode': mode}
        full = cat['sprint_distance_km'] if s['type'] == 'sprint' else (float(s['race_distance_km']) if s.get('race_distance_km') and cat['tier'] == 1 else cat['race_distance_km'])
        dist = full * float(mode) / 100
        laps = max(acs['min_race_laps'], math.floor(dist * 1000 / length) + 1)  # F1 rule: fewest laps exceeding the distance
        return {'laps': laps, 'duration_min': 0, 'length_m': length, 'distance_km': round(laps * length / 1000, 3), 'full_distance_km': full, 'mode': mode}
    pct = settings.get('session_length_pct', 100) / 100
    ko = knockout(s)
    if ko:
        stages = [max(acs['min_session_minutes'], int(round(m * pct))) for m in ko['stages_min']]
        stage = min(len(stages), (s.get('stage') or 0) + 1)
        return {'laps': 0, 'duration_min': stages[stage - 1], 'stages_min': stages, 'stage': stage, 'length_m': length}
    mins = s['duration_min'] or 30
    return {'laps': 0, 'duration_min': max(acs['min_session_minutes'], int(round(mins * pct))), 'length_m': length}


def conditions(db, s):
    """Session conditions: real GP time slot of the round + dynamic weather plan from the round climate. Stable once drawn.
    Weekends with a rain system (climate rain_chance, shared by all categories of the round) make rain likely in every session."""
    if s.get('conditions') and (s['conditions'].get('plan') or s['status'] != 'pending'): return s['conditions']
    acs = config.load('ac_session')
    rng = rng_for(s['seed'], 'conditions')
    base = s.get('start_time') or acs['default_time']
    h, m = (int(x) for x in base.split(':')[:2])
    h = (h + acs['session_times'].get(s['type'], 0)) % 24
    clim = acs['climates'].get(s.get('climate') or 'temperate', acs['climates']['temperate'])
    states, wcfg = acs['weather_states'], acs['weather']
    unstable_weekend = rng_for(repo.career(db)['seed'], 'weekend_weather', s['round_id']).random() < clim.get('rain_chance', 0.15)
    unstable = rng.random() < (wcfg['unstable_session_probability'] if unstable_weekend else wcfg['isolated_shower_factor'] * clim.get('rain_chance', 0.15))
    plan = weather.plan(rng_for(s['seed'], 'weather_plan'), clim, wcfg, unstable)
    ambient = round(rng.uniform(*clim['ambient']))
    if s.get('night'): ambient -= 4
    wet = weather.is_wet(plan, states)
    road = ambient + round(rng.uniform(*clim['road_delta']) * (0.5 if s.get('night') else 1) * (0.3 if wet else 1))
    cond = {'time': f'{h:02d}:{m:02d}', 'night': bool(s.get('night')), 'weather': plan[0]['state'], 'ambient': ambient - (2 if wet else 0), 'road': road,
            'plan': plan, 'forecast': weather.forecast(plan, states), 'wet_sim': wet}
    db.update('sessions', s['id'], {'conditions_json': jdump(cond)})
    s['conditions'] = cond
    return cond


def forecast(db, s):
    """What the player sees: a weather report, not the plan. Rain probability for the start, middle and end of the session,
    blurred with the uncertainty of a real forecast (larger for sessions further ahead in the weekend). Stable per session."""
    cond = conditions(db, s)
    plan = cond.get('plan')
    if not plan: return None
    acs = config.load('ac_session')
    states, ladder = acs['weather_states'], acs['weather']['ladder']
    ahead = db.value("SELECT COUNT(*) FROM sessions WHERE round_id = ? AND championship_id = ? AND order_no < ? AND status = 'pending'",
                     (s['round_id'], s['championship_id'], s['order_no'])) or 0
    rng = rng_for(s['seed'], 'forecast')
    sigma = 0.08 + 0.05 * min(ahead, 4)
    parts = []
    for k, label in enumerate(('Inicio', 'Mitad', 'Final')):
        sample = [weather.state_at(plan, (k + (i + 0.5) / 10) / 3) for i in range(10)]
        wet = [x for x in sample if states[x]['wet'] >= 0.2]
        frac = len(wet) / 10
        p = frac * 0.8 + 0.08 + rng.gauss(0, sigma)
        p = max(0.0, min(0.95 if frac else 0.3, p))
        dry = [x for x in sample if x not in wet] or sample
        icon = max(wet, key=lambda x: states[x]['wet']) if p >= 0.5 and wet else 'drizzle' if p >= 0.35 else max(set(dry), key=dry.count)
        parts.append({'label': label, 'rain': int(round(p * 20)) * 5, 'state': icon if icon in states else ladder[0]})
    return {'time': cond['time'], 'night': cond['night'], 'ambient': cond['ambient'], 'road': cond['road'], 'parts': parts, 'rain': max(x['rain'] for x in parts)}


def weather_ctx(db, s, fmt, part=None, runs=None):
    """Track wetness for the simulator from the session weather plan: per lap (races) or per run (timed sessions).
    part = (p0, p1) slice of the session (knockout stage)."""
    acs = config.load('ac_session')
    cond = conditions(db, s)
    if not cond.get('plan'): return {'wet': 1.0 if cond.get('wet_sim') else 0.0, 'wet_max': 1.0 if cond.get('wet_sim') else 0.0}
    states, wcfg = acs['weather_states'], acs['weather']
    if fmt.get('laps') and s['type'] in ('race', 'sprint'):
        wl = weather.wetness_curve(cond['plan'], int(fmt['laps']), states, wcfg)
        return {'wet': round(sum(wl) / len(wl), 3), 'wet_laps': wl, 'wet_max': max(wl)}
    curve = weather.wetness_curve(cond['plan'], wcfg['curve_steps'], states, wcfg)
    p0, p1 = part or (0.0, 1.0)
    scfg = config.load('simulation')
    n = runs or (scfg['qualifying_runs'] if s['type'] == 'qualifying' else scfg['practice_laps_equivalent'])
    wr = [weather.wet_at(curve, p0 + (p1 - p0) * (k + 0.5) / n) for k in range(n)]
    return {'wet': round(sum(wr) / len(wr), 3), 'wet_runs': wr, 'wet_max': max(curve)}


def previous_sessions_done(db, s):
    n = db.value("SELECT COUNT(*) FROM sessions WHERE round_id = ? AND championship_id = ? AND order_no < ? AND status NOT IN ('completed', 'skipped')",
                 (s['round_id'], s['championship_id'], s['order_no']))
    return n == 0


def round_is_current(db, s):
    first_open = db.value("SELECT MIN(round_no) FROM calendar_rounds WHERE season_id = ? AND status != 'completed'", (s['season_id'],))
    return first_open == s['round_no']


# ------------------------------------------------------------------------------------------
# Field / grid
# ------------------------------------------------------------------------------------------
def build_field(db, s):
    ch = repo.championship(db, s['championship_id'])
    year = ch['year']
    profile = repo.track_profile(db, s['track_profile_id'])
    car_cfg = config.load('car_model')
    field = []
    for e in repo.entries(db, s['championship_id']):
        st = repo.driver_state(db, e['driver_id'], year)
        car = development.driver_car(db, ch['season_id'], e['team_id'], e['driver_id'])
        field.append({'driver_id': e['driver_id'], 'team_id': e['team_id'], 'attrs': st['attrs'], 'form': st['form'], 'morale': st['morale'],
                      'base': st['base'], 'car': car, 'car_track': car_track_strength(car, profile, car_cfg), 'number': e['number'], 'skin': e['skin'],
                      'is_player': e['is_player'], 'name': f"{e['first_name']} {e['last_name']}", 'nationality': e['nationality'],
                      'team_name': e['team_name'], 'team_short': e['team_short'], 'team_color': e['team_color']})
    if s['type'] in ('race', 'sprint'): _apply_grid(db, s, field)
    return field, profile


def _apply_grid(db, s, field):
    rule = s['grid_rule'] or {}
    src_code = rule.get('from')
    order = []
    if src_code:
        src = db.one('SELECT id, status FROM sessions WHERE round_id = ? AND championship_id = ? AND code = ?', (s['round_id'], s['championship_id'], src_code))
        if src and src['status'] == 'completed':
            order = [r['driver_id'] for r in db.all('SELECT driver_id FROM results WHERE session_id = ? ORDER BY position', (src['id'],))]
    rest = sorted((f for f in field if f['driver_id'] not in order), key=lambda f: -(f['car_track'] * 0.6 + f['base'] * 0.4))
    order = [d for d in order if any(f['driver_id'] == d for f in field)] + [f['driver_id'] for f in rest]
    rev = int(rule.get('reverse_top') or 0)
    if rev: order = list(reversed(order[:rev])) + order[rev:]
    order = components.apply_grid_penalties(db, s, order)
    for f in field: f['grid_position'] = order.index(f['driver_id']) + 1
    field.sort(key=lambda f: f['grid_position'])


def sim_context(db, s, profile, fmt, wx):
    ch = repo.championship(db, s['championship_id'])
    cat = repo.category_config(db, ch['category_id'])['config']
    base_lap = fmt['length_m'] / 1000 / cat['base_lap_speed_kmh'] * 3600
    return {'scfg': config.load('simulation'), 'pcfg': config.load('progression'), 'car_cfg': config.load('car_model'), 'profile': profile,
            'base_lap_s': base_lap, 'laps': fmt['laps'], 'category': ch['category_code'], **wx}


# ------------------------------------------------------------------------------------------
# Result storage (shared by simulated and played sessions)
# ------------------------------------------------------------------------------------------
def _store_entries(db, s, field, translations=None):
    db.execute('DELETE FROM session_entries WHERE session_id = ?', (s['id'],))
    for idx, f in enumerate(field):
        t = (translations or {}).get(f['driver_id'], {})
        db.insert('session_entries', {'session_id': s['id'], 'driver_id': f['driver_id'], 'team_id': f['team_id'], 'car_index': t.get('car_index', idx),
                                      'grid_position': f.get('grid_position'), 'ai_level': t.get('ai_level'), 'ai_aggression': t.get('ai_aggression'),
                                      'ballast': t.get('ballast', 0), 'restrictor': t.get('restrictor', 0), 'skin': t.get('skin') or f.get('skin'),
                                      'is_player': f['is_player'], 'translation_json': jdump(t.get('breakdown', {}))})


def store_results(db, s, field, rows, source, ctx, raw=None, lap_rows=None, telemetry=None):
    """rows: list of result dicts ordered by position. Computes points + rating evidence, completes session."""
    is_race = s['type'] in ('race', 'sprint')
    if is_race:
        fl = min((r for r in rows if r.get('best_lap_ms')), key=lambda r: r['best_lap_ms'], default=None)
        for r in rows: r['fastest_lap'] = int(fl is not None and r['driver_id'] == fl['driver_id'])
    pts = champ.points_for(rows, regulations.points_system_override(db, s)) if is_race else {}
    db.execute('DELETE FROM results WHERE session_id = ?', (s['id'],))
    db.execute('DELETE FROM laps WHERE session_id = ?', (s['id'],))
    db.execute('DELETE FROM driver_performance WHERE session_id = ?', (s['id'],))
    for r in rows:
        db.insert('results', {'session_id': s['id'], 'driver_id': r['driver_id'], 'team_id': r['team_id'], 'position': r['position'],
                              'grid_position': r.get('grid_position'), 'laps': r.get('laps') or 0, 'total_time_ms': r.get('total_time_ms'),
                              'best_lap_ms': r.get('best_lap_ms'), 'gap_ms': r.get('gap_ms'), 'status': r['status'], 'dnf_reason': r.get('dnf_reason'),
                              'points': pts.get(r['driver_id'], 0), 'fastest_lap': r.get('fastest_lap', 0), 'pit_stops': r.get('pit_stops'),
                              'incidents': r.get('incidents'), 'source': r.get('source', source), 'q1_ms': r.get('q1_ms'), 'q2_ms': r.get('q2_ms'),
                              'q3_ms': r.get('q3_ms'), 'q_stage': r.get('q_stage'), 'strategy': r.get('strategy')})
    for lr in lap_rows or []: db.insert('laps', lr)
    if raw is not None:
        db.insert('raw_results', {'session_id': s['id'], 'source_path': raw.get('path'), 'raw_json': jdump(raw.get('data')), 'race_ini': raw.get('race_ini'), 'imported_ts': now_ts()})
    # rating evidence (expected vs actual)
    pcfg = config.load('progression')
    conf = pcfg['session']['confidence']
    by_id = {f['driver_id']: f for f in field}
    ev_rows = []
    for r in rows:
        f = by_id.get(r['driver_id'])
        if not f: continue
        c = conf['simulated'] if r.get('source', source) == 'simulated' else conf['played_human'] if f['is_player'] else conf['played_ai']
        ev_rows.append({'driver_id': r['driver_id'], 'team_id': r['team_id'], 'strength': engine.expected_perf(f, s['type'], ctx), 'position': r['position'],
                        'status': r['status'], 'dnf_reason': r.get('dnf_reason'), 'best_lap_ms': r.get('best_lap_ms'), 'source_confidence': c})
    evidence = session_scores(s['type'], ev_rows, pcfg, ctx['scfg']['laptime_per_point'] * 100)
    for e in evidence:
        db.insert('driver_performance', {'session_id': s['id'], 'driver_id': e['driver_id'], 'expected_pos': e['expected_pos'], 'actual_pos': e['actual_pos'],
                                         'teammate_delta': e['teammate_delta'], 'score': e['score'], 'confidence': e['confidence'],
                                         'source': source, 'details_json': jdump(e['details'])})
    db.update('sessions', s['id'], {'status': 'completed', 'mode': source, 'played_ts': now_ts(), 'laps': s.get('laps') or (ctx['laps'] or None)})
    lifecycle.after_session(db, s, rows, field, source, rng_for(s['seed'], 'after'), telemetry)
    winner = rows[0] if rows else None
    ev = repo.emit(db, 'SESSION_FINISHED', {'code': s['code'], 'source': source, 'winner': winner and winner['driver_id']},
                   season_id=s['season_id'], round_id=s['round_id'], session_id=s['id'])
    if source == 'played': repo.emit(db, 'RESULT_IMPORTED', {'session_id': s['id']}, season_id=s['season_id'], round_id=s['round_id'], session_id=s['id'])
    if winner and s['type'] in ('race', 'sprint', 'qualifying'):
        from fcm.career_engine import newsroom
        newsroom.session_result(db, s, rows, ev)
    from fcm.career_engine import progression
    progression.after_session(db, s)


# ------------------------------------------------------------------------------------------
# Simulation
# ------------------------------------------------------------------------------------------
def simulate(db, session_id):
    s = get(db, session_id)
    _check_can_run(db, s)
    fmt = session_format(db, s)
    s['laps'] = fmt['laps'] or None
    field, profile = build_field(db, s)
    ctx = sim_context(db, s, profile, fmt, weather_ctx(db, s, fmt))
    rng = rng_for(s['seed'], 'sim')
    if knockout(s):
        with db.transaction():
            simulate_knockout(db, s, field, ctx, from_stage=(s['stage'] or 0) + 1)
        return summary(db, session_id)
    _apply_strategies(s, field)
    with db.transaction():
        components.pre_roll_failures(db, s, field, fmt['laps'], rng_for(s['seed'], 'failures'))
        _store_entries(db, s, field)
        rows = engine.simulate(field, s['type'], ctx, rng)
        db.update('sessions', s['id'], {'weather': 'wet' if ctx['wet_max'] >= 0.2 else 'dry'})
        lap_rows = []
        if config.load('simulation').get('store_simulated_laps'):
            for r in rows:
                lap_rows += [{'session_id': s['id'], 'driver_id': r['driver_id'], 'lap_no': i + 1, 'time_ms': t, 'sectors_json': '[]', 'cuts': 0, 'tyre': None}
                             for i, t in enumerate(r.get('lap_times', []))]
        store_results(db, s, field, rows, 'simulated', ctx, lap_rows=lap_rows)
    _log.info('Simulated session %s (%s %s)', s['id'], s['event_name'], s['code'])
    return summary(db, session_id)


def _apply_strategies(s, field):
    """Player's planned strategy (if any) goes into the simulation; AI strategies are generated by the engine."""
    if s['type'] not in ('race', 'sprint') or not s.get('strategy', {}).get('compounds'): return
    for f in field:
        if f['is_player']: f['strategy'] = {'compounds': s['strategy']['compounds'], 'pit_laps': s['strategy'].get('pit_laps', [])}


def set_strategy(db, session_id, strategy):
    s = get(db, session_id)
    if s['type'] not in ('race', 'sprint'): raise SessionError('La estrategia solo se define para carreras')
    if s['status'] == 'completed': raise SessionError('La sesión ya está completada')
    fmt = session_format(db, s)
    ok, msg = engine.validate_strategy(strategy, fmt['laps'], repo.championship(db, s['championship_id'])['category_code'], config.load('simulation'),
                                       dry=not conditions(db, s).get('wet_sim'))
    if not ok: raise SessionError(msg)
    fuel = strategy.get('fuel_liters')
    data = {'compounds': strategy['compounds'], 'pit_laps': sorted(int(x) for x in strategy.get('pit_laps') or []),
            'fuel_liters': float(fuel) if fuel not in (None, '') else None}
    db.update('sessions', session_id, {'strategy_json': jdump(data)})
    return data


def strategy_view(db, session_id):
    s = get(db, session_id)
    fmt = session_format(db, s)
    ch = repo.championship(db, s['championship_id'])
    prof = repo.track_profile(db, s['track_profile_id'])
    wx = weather_ctx(db, s, fmt)
    suggestion = engine.default_strategy(fmt['laps'], prof, rng_for(s['seed'], 'suggest'), config.load('simulation'), ch['category_code'], (wx.get('wet_laps') or [0])[0])
    fuel_info = tyre_info = None
    ac_root = store.get_setting('ac_root') if store.app_db else None
    if ac_root and ch['ac_car_id']:
        from fcm.ac_integration import car_data
        try:
            fuel_info, tyre_info = car_data.fuel(ac_root, ch['ac_car_id']), car_data.tyres(ac_root, ch['ac_car_id'])
        except Exception:
            pass
    return {'session': s, 'format': fmt, 'conditions': conditions(db, s), 'forecast': forecast(db, s), 'strategy': s['strategy'] or None, 'suggestion': suggestion,
            'car_fuel': fuel_info, 'car_tyres': tyre_info,
            'tyres': {k: v for k, v in config.load('simulation')['tyres'].items() if k in ('S', 'M', 'H', 'I', 'W')}, 'wet_laps': wx.get('wet_laps'),
            'two_compounds_required': ch['category_code'] in config.load('simulation')['tyres'].get('mandatory_two_compounds', []) and fmt['laps'] >= 10
                                      and not conditions(db, s).get('wet_sim')}


# ------------------------------------------------------------------------------------------
# Knockout qualifying (Q1/Q2/Q3)
# ------------------------------------------------------------------------------------------
def _advance_counts(n, ko):
    q3 = min(ko.get('q3_cars', 10), n)
    out1 = math.ceil((n - q3) / 2)
    return [n - out1, q3]


def stage_field(db, s, field, stage):
    if stage <= 1: return list(field)
    adv = _advance_counts(len(field), knockout(s))[stage - 2]
    ids = [r['driver_id'] for r in db.all('SELECT driver_id FROM session_stage_results WHERE session_id = ? AND stage = ? ORDER BY position LIMIT ?',
                                          (s['id'], stage - 1, adv))]
    return [f for f in field if f['driver_id'] in ids]


def _store_stage(db, s, stage, rows, source_of):
    db.execute('DELETE FROM session_stage_results WHERE session_id = ? AND stage = ?', (s['id'], stage))
    for pos, r in enumerate(rows, start=1):
        db.insert('session_stage_results', {'session_id': s['id'], 'stage': stage, 'driver_id': r['driver_id'], 'team_id': r['team_id'], 'position': pos,
                                            'best_lap_ms': r.get('best_lap_ms'), 'laps': r.get('laps') or 0, 'source': source_of(r)})
    db.update('sessions', s['id'], {'stage': stage})
    s['stage'] = stage


def simulate_knockout(db, s, field, ctx, from_stage=1):
    ko = knockout(s)
    scfg = ctx['scfg']
    day = engine.day_factors(field, scfg, rng_for(s['seed'], 'day'))
    n = len(ko['stages_min'])
    fmt = session_format(db, s)
    for stage in range(from_stage, n + 1):
        fs = stage_field(db, s, field, stage)
        runs = scfg.get('knockout_runs', 2)
        c2 = dict(ctx, day=day, runs=runs, evolution=scfg.get('knockout_track_evolution', 0.001) * (stage - 1),
                  **weather_ctx(db, s, fmt, ((stage - 1) / n, stage / n), runs))
        rows = engine.simulate(fs, 'qualifying', c2, rng_for(s['seed'], 'ko', stage))
        _store_stage(db, s, stage, rows, lambda r: 'simulated')
    finalize_knockout(db, s, field, ctx)


def finalize_knockout(db, s, field, ctx):
    n_stages = len(knockout(s)['stages_min'])
    st = db.all('SELECT * FROM session_stage_results WHERE session_id = ? ORDER BY stage DESC, position', (s['id'],))
    placed, rows = set(), []
    times = {}
    for r in st: times.setdefault(r['driver_id'], {})[r['stage']] = r['best_lap_ms']
    for stage in range(n_stages, 0, -1):
        for r in (x for x in st if x['stage'] == stage):
            if r['driver_id'] in placed: continue
            placed.add(r['driver_id'])
            t = times[r['driver_id']]
            best = min((v for v in t.values() if v), default=None)
            rows.append({'driver_id': r['driver_id'], 'team_id': r['team_id'], 'position': len(rows) + 1, 'best_lap_ms': best, 'laps': r['laps'],
                         'status': 'FIN', 'q1_ms': t.get(1), 'q2_ms': t.get(2), 'q3_ms': t.get(3), 'q_stage': stage, 'source': r['source']})
    pole = rows[0]['best_lap_ms'] if rows and rows[0]['best_lap_ms'] else None
    for r in rows: r['gap_ms'] = (r['best_lap_ms'] - pole) if pole and r['best_lap_ms'] else None
    source = 'played' if any(r['source'] == 'played' for r in rows) else 'simulated'
    store_results(db, s, field, rows, source, ctx)


def skip(db, session_id):
    s = get(db, session_id)
    _check_can_run(db, s)
    if s['type'] != 'practice': raise SessionError('Solo se pueden saltar los entrenamientos libres')
    with db.transaction():
        db.update('sessions', s['id'], {'status': 'skipped', 'mode': 'skip'})
        from fcm.career_engine import progression
        progression.after_session(db, get(db, session_id))
    return {'ok': True}


def _check_can_run(db, s):
    if s['status'] in ('completed', 'skipped', 'running'): raise SessionError('La sesión ya está completada' if s['status'] != 'running' else 'La sesión está en curso en Assetto Corsa')
    if not round_is_current(db, s): raise SessionError('Primero hay que completar las rondas anteriores')
    if not previous_sessions_done(db, s): raise SessionError('Primero hay que completar las sesiones anteriores del fin de semana')


# ------------------------------------------------------------------------------------------
# Played session (Assetto Corsa)
# ------------------------------------------------------------------------------------------
def prepare_play(db, session_id):
    """Builds the full AC configuration and validates it. Returns dict with errors/warnings/race_ini."""
    s = get(db, session_id)
    errors, warnings = [], []
    try:
        _check_can_run(db, s)
    except SessionError as e:
        errors.append(str(e))
    ch = repo.championship(db, s['championship_id'])
    ac_root = store.get_setting('ac_root')
    if not ac_root or not detect.validate_install(ac_root)['valid']: errors.append('Instalación de Assetto Corsa no configurada (Contenido AC).')
    app = store.app_db
    car_id = ch['ac_car_id']
    car = app.one('SELECT * FROM ac_cars WHERE id = ?', (car_id,)) if car_id else None
    if not car_id: errors.append(f"No hay coche de Assetto Corsa asignado a {ch['category_code']} {ch['year']} (Contenido AC → Coches de la partida).")
    elif not car: errors.append(f'El coche "{car_id}" no está en el contenido escaneado. Vuelve a escanear.')
    skins = [r['id'] for r in app.all('SELECT id FROM ac_car_skins WHERE car_id = ? ORDER BY sort_order, id', (car_id,))] if car else []
    layout = None
    if not s['ac_track_id']: errors.append(f"No hay circuito de Assetto Corsa asignado a {s['event_name']} (Calendario).")
    else:
        layout = app.one('SELECT * FROM ac_track_layouts WHERE track_id = ? AND id = ?', (s['ac_track_id'], s['ac_layout_id'] or ''))
        if not layout: errors.append(f"Circuito/layout {s['ac_track_id']}/{s['ac_layout_id'] or '-'} no encontrado en el contenido escaneado.")
    fmt = session_format(db, s)
    field, profile = build_field(db, s)
    ko = knockout(s)
    stage_label = ''
    if ko:
        stage = fmt['stage']
        field = stage_field(db, s, field, stage)
        stage_label = f" {'SQ' if s['code'] == 'SQ' else 'Q'}{stage}"
    players = [f for f in field if f['is_player']]
    if not players: errors.append('Has quedado eliminado en la fase anterior: simula el resto de la clasificación.' if ko and fmt['stage'] > 1 else 'El jugador no corre en este campeonato.')
    cond = conditions(db, s)
    time_of_day = cond['time']
    acs = config.load('ac_session')
    lo, hi = acs['vanilla_time_range']
    csp = detect.detect_extras(ac_root)['csp'] if ac_root else {}
    if ac_root and not csp.get('weather'):
        errors.append('Para jugar hace falta Custom Shaders Patch (CSP) con WeatherFX activado (clima dinámico y lluvia). '
                      'Instálalo desde Content Manager → Ajustes → Custom Shaders Patch y activa Weather FX. Sin CSP puedes simular la sesión.')
    elif ac_root and not csp.get('rain'):
        errors.append('Activa Rain FX en la configuración de CSP (Content Manager → Ajustes → Custom Shaders Patch → Rain FX): la lluvia forma parte del clima de la trayectoria.')
    unclamped = False
    if not (lo <= time_of_day <= hi):
        if csp.get('night'): unclamped = True
        else:
            warnings.append(f'Hora real {time_of_day}: sin CSP (función 24 h), Assetto Corsa solo permite horas diurnas; se usará {hi if time_of_day > hi else lo}.')
            time_of_day = hi if time_of_day > hi else lo
    states = acs['weather_states']
    part = ((fmt['stage'] - 1) / len(ko['stages_min']), fmt['stage'] / len(ko['stages_min'])) if ko else (0.0, 1.0)
    wplan = csp_weather.local_plan(cond.get('plan') or [{'at': 0.0, 'state': 'clear'}], *part)
    start = states[wplan[0]['state']]
    weather_name = start['ac'] if store.app_db and store.app_db.one('SELECT 1 FROM ac_weathers WHERE id = ?', (start['ac'],)) else _weather(acs)
    extra_lighting = {'__CM_WEATHER_TYPE': start['csp'], '__CM_WEATHER_CONTROLLER': csp_weather.NAME}
    wet_played = weather.is_wet(wplan, states)
    wx = weather_ctx(db, s, fmt, part)
    warnings.append(f"Clima: {weather.forecast(wplan, states)}" + (' · habrá lluvia: lleva intermedios/lluvia cuando toque' if wet_played else ''))
    setup_values, setup_notes = {}, []
    strat = s.get('strategy') or {}
    if car_id and s['type'] in ('race', 'sprint') and strat:
        from fcm.ac_integration import car_data
        if strat.get('fuel_liters'): setup_values['FUEL'] = float(strat['fuel_liters'])
        if strat.get('compounds'):
            idx = car_data.compound_index(car_data.tyres(ac_root, car_id) if ac_root else None, strat['compounds'][0])
            if idx is not None: setup_values['TYRES'] = idx
            else: setup_notes.append('No se pudo leer los compuestos del coche (data.acd empaquetado o nombres no reconocidos): elige el neumático de salida en AC.')
    warnings += setup_notes
    if layout and layout['pitboxes'] and layout['pitboxes'] < len(field):
        errors.append(f"El circuito tiene {layout['pitboxes']} boxes pero la parrilla tiene {len(field)} coches.")
    wet = wx['wet']  # AI wet skill weighted by the expected wetness of the session
    amap, cmap = config.load('ai_mapping'), config.load('car_performance_mapping')
    amap['global_offset'] = amap.get('global_offset', 0) + float(repo.career(db)['difficulty'].get('driving_ai', 0) or 0)
    if config.load('physics').get('enabled'): amap['car_to_ai_level'] = amap.get('car_to_ai_level', 0) * config.load('physics')['car_to_ai_scale_when_enabled']
    pcfg = config.load('progression')
    avg_car = sum(f['car_track'] for f in field) / max(1, len(field))
    best_car = max((f['car_track'] for f in field), default=0)
    ordered = ([p for p in players] + [f for f in field if not f['is_player']]) if players else field
    translations = {}
    for idx, f in enumerate(ordered):
        t = translate_entry('qualifying' if s['type'] == 'qualifying' else 'race', f['attrs'], f['form'], f['morale'], f['car_track'], avg_car, best_car,
                            wet, amap, cmap, pcfg, is_player=bool(f['is_player']))
        skin = f['skin'] if f['skin'] in skins else None
        if not skin and skins:
            skin = skins[idx % len(skins)]
            if f['skin']: warnings.append(f"Skin {f['skin']} no encontrada para {f['name']}; se usa {skin}.")
        t.update({'car_index': idx, 'skin': skin or ''})
        translations[f['driver_id']] = t
    acs = config.load('ac_session')
    spec = None
    ini_text = None
    models = {}
    pcfg_phys = config.load('physics')
    if not errors and pcfg_phys.get('enabled'):
        from fcm.ac_integration import physics
        sup = physics.support(ac_root, car_id)
        if not sup['supported']:
            warnings.append(f"Física avanzada no disponible para {car_id}: {sup['reason']}")
        else:
            keys = repo.CAR_FIELDS
            mean = {k: sum(f['car'][k] for f in ordered) / len(ordered) for k in keys}
            for f in ordered:
                mods = physics.modifiers(f['car'], mean)
                models[f['driver_id']] = physics.build(ac_root, car_id, f"{f['team_short']}{f['number']}", f"{f['team_short']} #{f['number']}", mods)
                t = translations[f['driver_id']]
                t['ballast'] = round(t['ballast'] * pcfg_phys['ballast_scale_when_enabled'])
                t['restrictor'] = round(t['restrictor'] * pcfg_phys['ballast_scale_when_enabled'])
                t['breakdown']['physics'] = mods
                t['model'] = models[f['driver_id']]
    if not errors:
        player = players[0]
        pt = translations[player['driver_id']]
        spec = race_ini.SessionSpec(
            track=s['ac_track_id'], layout=s['ac_layout_id'] or '', session_type='race' if s['type'] in ('race', 'sprint') else s['type'],
            name=f"{s['event_name']} - {s['name']}{stage_label}", laps=fmt['laps'], duration_min=fmt['duration_min'],
            player=race_ini.CarEntry(model=models.get(player['driver_id'], car_id), skin=pt['skin'], driver_name=player['name'], nationality=player['nationality'] or '',
                                     nation_code=player['nationality'] or '', ballast=pt['ballast'], restrictor=pt['restrictor'], setup='fcm_strategy' if setup_values else ''),
            opponents=[race_ini.CarEntry(model=models.get(f['driver_id'], car_id), skin=translations[f['driver_id']]['skin'], driver_name=f['name'], nationality=f['nationality'] or '',
                                         nation_code=f['nationality'] or '', ai_level=translations[f['driver_id']]['ai_level'],
                                         ai_aggression=translations[f['driver_id']]['ai_aggression'], ballast=translations[f['driver_id']]['ballast'],
                                         restrictor=translations[f['driver_id']]['restrictor']) for f in ordered[1:]],
            player_grid_position=player.get('grid_position') or len(field), time_of_day=time_of_day, weather=weather_name, ambient=cond['ambient'], road=cond['road'],
            unclamped_time=unclamped, extra_lighting=extra_lighting,
            player_setup_file=str(detect.ac_documents_dir() / 'setups' / models.get(player['driver_id'], car_id) / s['ac_track_id'] / 'fcm_strategy.ini') if setup_values else '',
            race_ai_level=round(sum(t['ai_level'] for t in translations.values()) / len(translations), 1), options=acs)
        ini_text = race_ini.build(spec)
    return {'session': s, 'format': fmt, 'conditions': {**cond, 'time_used': time_of_day, 'wet_played': wet_played, 'weather_used': weather_name, 'plan_played': wplan},
            'setup': setup_values, '_weather_plan': wplan, 'forecast': forecast(db, s),
            'stage_label': stage_label.strip(), 'errors': errors, 'warnings': warnings, 'race_ini': ini_text, 'ac_root': ac_root, '_setup_model': models.get(players[0]['driver_id'], car_id) if players else car_id,
            'field': [{**{k: f[k] for k in ('driver_id', 'name', 'team_name', 'team_color', 'number', 'is_player', 'car_track')},
                       'grid_position': f.get('grid_position'), **{k: v for k, v in translations.get(f['driver_id'], {}).items()}} for f in ordered],
            '_ordered': ordered, '_translations': translations, '_profile': profile}


def _weather(acs):
    w = acs.get('default_weather', '3_clear')
    if store.app_db and not store.app_db.one('SELECT 1 FROM ac_weathers WHERE id = ?', (w,)):
        first = store.app_db.one('SELECT id FROM ac_weathers ORDER BY id LIMIT 1')
        if first: return first['id']
    return w


def play(db, session_id):
    prep = prepare_play(db, session_id)
    if prep['errors']: raise SessionError('; '.join(prep['errors']))
    s = prep['session']
    if prep['setup']:
        from fcm.ac_integration import car_data
        car_data.write_setup(detect.ac_documents_dir(), prep['_setup_model'], s['ac_track_id'], prep['setup'])
    fmt = prep['format']
    race = s['type'] in ('race', 'sprint') and fmt['laps']
    csp_weather.write_controller(prep['ac_root'], prep['_weather_plan'], config.load('ac_session')['weather_states'], laps=fmt['laps'] if race else 0,
                                 duration_s=0 if race else (fmt['duration_min'] or 0) * 60, transition=config.load('ac_session')['weather']['transition'])
    with db.transaction():
        _store_entries(db, s, prep['_ordered'], prep['_translations'])
        db.update('sessions', s['id'], {'status': 'running', 'mode': 'played', 'weather': 'wet' if prep['conditions']['wet_played'] else 'dry'})
    store.autosave(f'before_{s["code"]}_r{s["round_no"]}')
    career_id = store.career_id
    ini_text = prep['race_ini']

    def on_finished(result_path, info):
        if store.career_id != career_id: store.open(career_id)
        d = store.require()
        if not result_path:
            d.update('sessions', session_id, {'status': 'pending', 'mode': None})
            raise SessionError(info.get('error') or 'Sin fichero de resultados')
        out = import_result_file(d, session_id, result_path, ini_text, info.get('telemetry'))
        store.autosave(f'after_{s["code"]}_r{s["round_no"]}')
        return out

    try:
        launcher.launch(prep['ac_root'], ini_text, {'session_id': session_id, 'career_id': career_id, 'label': f"{s['event_name']} {s['name']} {prep['stage_label']}".strip()},
                        on_finished, restore_ini=config.load('app')['ac']['restore_race_ini'])
    except Exception:
        db.update('sessions', session_id, {'status': 'pending', 'mode': None})
        raise
    return {'ok': True, 'status': launcher.status()}


def import_result_file(db, session_id, path, race_ini_text=None, telemetry=None):
    raw = ac_results.load(path)
    return import_result(db, session_id, raw, str(path), race_ini_text, telemetry)


def import_result(db, session_id, raw, source_path=None, race_ini_text=None, telemetry=None):
    s = get(db, session_id)
    ents = db.all('SELECT se.*, d.first_name, d.last_name FROM session_entries se JOIN drivers d ON d.id = se.driver_id WHERE se.session_id = ? ORDER BY se.car_index', (session_id,))
    if not ents: raise SessionError('La sesión no tiene inscritos generados (¿se lanzó desde el Career Manager?)')
    parsed = ac_results.parse(raw, s['type'], [f"{e['first_name']} {e['last_name']}" for e in ents])
    if not any(c['lap_count'] or c['best_lap_ms'] for c in parsed['cars']):
        db.update('sessions', session_id, {'status': 'pending', 'mode': None})
        raise SessionError('El fichero de resultados no contiene vueltas (sesión abortada antes de empezar). Sesión reiniciada: juégala o simúlala de nuevo.')
    by_index = {e['car_index']: e for e in ents}
    rows, lap_rows = [], []
    for i in parsed['order']:
        c = parsed['cars'][i]
        e = by_index[i]
        rows.append({'driver_id': e['driver_id'], 'team_id': e['team_id'], 'position': c['position'], 'grid_position': e['grid_position'],
                     'laps': c['lap_count'], 'total_time_ms': c['total_time_ms'] or None, 'best_lap_ms': c['best_lap_ms'], 'gap_ms': c.get('gap_ms'),
                     'status': c['status'], 'dnf_reason': None, 'pit_stops': None, 'incidents': c['cuts'], 'source': 'played'})
        lap_rows += [{'session_id': session_id, 'driver_id': e['driver_id'], 'lap_no': l['lap_no'], 'time_ms': l['time_ms'], 'sectors_json': jdump(l['sectors']),
                      'cuts': l['cuts'], 'tyre': l['tyre']} for l in c['laps']]
    pid = repo.career(db)['player_driver_id']
    tele = telemetry if telemetry and telemetry.get('samples') else None
    if tele:
        for r in rows:
            if r['driver_id'] != pid: continue
            if s['type'] in ('race', 'sprint'): r['pit_stops'] = tele.get('pit_entries')
            scale = config.load('components').get('ac_damage_scale', 100.0)
            if r['status'] == 'DNF' and max(tele.get('max_damage', {}).values() or [0]) >= scale * 0.5: r['dnf_reason'] = 'incident'
    fmt = session_format(db, s)
    s['laps'] = fmt['laps'] or None
    field, profile = build_field(db, s)
    for f in field:
        e = next((x for x in ents if x['driver_id'] == f['driver_id']), None)
        if e: f['grid_position'] = e['grid_position']
    ctx = sim_context(db, s, profile, fmt, weather_ctx(db, s, fmt))
    if knockout(s):
        stage = fmt['stage']
        n_stages = len(knockout(s)['stages_min'])
        with db.transaction():
            _store_stage(db, s, stage, rows, lambda r: 'played')
            db.insert('raw_results', {'session_id': session_id, 'source_path': source_path, 'raw_json': jdump(raw), 'race_ini': race_ini_text, 'imported_ts': now_ts()})
            player_row = next((r for r in rows if r['driver_id'] == pid), None)
            adv = _advance_counts(len(field), knockout(s))
            eliminated = stage < n_stages and player_row and player_row['position'] > adv[stage - 1]
            if stage >= n_stages: finalize_knockout(db, s, field, ctx)
            elif eliminated: simulate_knockout(db, s, field, ctx, from_stage=stage + 1)
            else: db.update('sessions', session_id, {'status': 'pending', 'mode': None})
        out = summary(db, session_id)
        out['warnings'] = parsed['warnings'] + ([f'Eliminado en {s["code"]}{stage}: el resto de la clasificación se ha simulado.'] if eliminated else [])
        return out
    with db.transaction():
        store_results(db, s, field, rows, 'played', ctx, raw={'path': source_path, 'data': raw, 'race_ini': race_ini_text}, lap_rows=lap_rows, telemetry=tele)
        if tele:
            db.insert('player_telemetry', {'session_id': session_id, 'pit_stops': tele.get('pit_entries'), 'max_damage_json': jdump(tele.get('max_damage', {})),
                                           'samples': tele.get('samples', 0), 'create_ts': now_ts()})
    if tele: ac_telemetry.store_laps(store.career_id, session_id, tele.get('laps'))
    _log.info('Imported AC result for session %s (%d cars, complete=%s)', session_id, len(rows), parsed['complete'])
    out = summary(db, session_id)
    out['warnings'] = parsed['warnings'] + ([] if parsed['complete'] else ['La sesión parece incompleta (no se completaron todas las vueltas).'])
    return out


def import_latest(db, session_id):
    """Manual fallback: import Documents/Assetto Corsa/out/race_out.json for a session that was launched."""
    path = detect.ac_documents_dir() / 'out' / 'race_out.json'
    if not path.exists(): raise SessionError(f'{path} no encontrado')
    ini = db.one('SELECT race_ini FROM raw_results WHERE session_id = ? ORDER BY id DESC LIMIT 1', (session_id,))
    return import_result_file(db, session_id, path, ini and ini['race_ini'])


def reset_stuck(db, session_id):
    s = get(db, session_id)
    if s['status'] != 'running': raise SessionError('La sesión no está bloqueada')
    db.update('sessions', s['id'], {'status': 'pending', 'mode': None})


def summary(db, session_id):
    s = get(db, session_id)
    rows = db.all('SELECT r.*, d.first_name, d.last_name, d.short_name, d.is_player, t.name team_name, t.color team_color, se.number number, '
                  'dp.expected_pos, dp.score perf_score FROM results r JOIN drivers d ON d.id = r.driver_id JOIN teams t ON t.id = r.team_id '
                  'LEFT JOIN championship_entries se ON se.driver_id = r.driver_id AND se.championship_id = ? '
                  'LEFT JOIN driver_performance dp ON dp.session_id = r.session_id AND dp.driver_id = r.driver_id '
                  'WHERE r.session_id = ? ORDER BY r.position', (s['championship_id'], session_id))
    stages = db.all('SELECT st.*, d.first_name, d.last_name, d.is_player, t.name team_name, t.color team_color FROM session_stage_results st JOIN drivers d ON d.id = st.driver_id '
                    'JOIN teams t ON t.id = st.team_id WHERE st.session_id = ? ORDER BY st.stage, st.position', (session_id,))
    return {'session': s, 'results': rows, 'stages': stages, 'format': session_format(db, s)}
