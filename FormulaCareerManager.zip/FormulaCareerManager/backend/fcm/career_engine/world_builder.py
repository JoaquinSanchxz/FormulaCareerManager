"""Career creation: categories, season, calendar, teams, cars, drivers, contracts, sessions.

The starting world comes from a template/import JSON (data/templates/default_world.json format,
see data/schemas/world.schema.json). Drivers missing from the JSON are generated from the seed.
"""
import json
import random

from fcm import __version__
from fcm.career_engine import repo
from fcm.career_engine.store import store
from fcm.database.db import jdump, now_ts
from fcm.shared import config, log, paths
from fcm.shared.rng import derive_seed, rng_for
from fcm.simulation.model import ATTRIBUTES, base_rating, clamp, overall_strength

_log = log.get('CAREER')

AGE_RANGES = {1: (21, 36), 2: (18, 25), 3: (17, 21)}
PERSONALITIES = ('methodical', 'aggressive', 'calm', 'streaky', 'technical', 'charismatic')
DEFAULT_SETTINGS = {'race_length_pct': 25, 'session_length_pct': 50, 'practice_mode': 'skip', 'delegate_team_management': False}
DEFAULT_DIFFICULTY = {'career': 'normal', 'driving_ai': 0, 'economy': 'normal', 'development': 'normal'}
DEFAULT_REALISM = {'finances': True, 'contracts': True, 'development': True, 'failures': True, 'driver_progression': True,
                   'driver_market': True, 'regulation_changes': True, 'academies': True, 'f2': True, 'f3': False,
                   'generated_rookies': True, 'random_events': True, 'injuries': False, 'super_license': True}


def load_template(name='real_2026'):
    with open(paths.templates_dir() / f'{name}.json', encoding='utf-8') as f:
        return json.load(f)


def _names():
    with open(paths.templates_dir() / 'names.json', encoding='utf-8') as f:
        return json.load(f)


# ------------------------------------------------------------------------------------------
# Generators
# ------------------------------------------------------------------------------------------
def make_car(strength, rng):
    cm = config.load('car_model')
    comps = {c: strength + rng.gauss(0, 1.3) for c in cm['components']}
    comps['reliability'] = strength - 4 + rng.gauss(0, 2.0)
    shift = strength - overall_strength(comps, cm)
    comps = {k: round(clamp(v + shift, 40, 100), 2) for k, v in comps.items()}
    comps['development_efficiency'] = round(clamp(strength - 12 + rng.gauss(0, 4), 50, 98), 2)
    return comps


def attrs_around(level, rng, sd=2.5):
    pcfg = config.load('progression')
    attrs = {a: rng.gauss(level, sd) for a in ATTRIBUTES}
    shift = level - base_rating(attrs, pcfg['attribute_weights'])
    return {a: round(clamp(v + shift, 35, 99), 2) for a, v in attrs.items()}


def generate_identity(db, rng, nationality=None):
    names = _names()
    nat = nationality or rng.choice(sorted(names))
    pool = names.get(nat) or names['GBR']
    for _ in range(50):
        first, last = rng.choice(pool['first']), rng.choice(pool['last'])
        if not db.value('SELECT 1 FROM drivers WHERE first_name = ? AND last_name = ?', (first, last)): break
    short = ''.join(ch for ch in last.upper() if ch.isalpha())[:3].ljust(3, 'X')
    return {'first_name': first, 'last_name': last, 'short_name': short, 'nationality': nat}


def insert_driver(db, ident, attrs, potential, birth_year, rng, is_player=False, is_generated=True, reputation=None, development_rate=None, birth_date=None):
    ts = now_ts()
    pcfg = config.load('progression')
    base = base_rating(attrs, pcfg['attribute_weights'])
    if 'personality' not in ident: ident = {**ident, 'personality': rng.choice(PERSONALITIES)}
    did = db.insert('drivers', {**ident, 'birth_date': birth_date or f'{birth_year}-{rng.randint(1, 12):02d}-{rng.randint(1, 28):02d}', 'is_player': int(is_player),
                                'is_generated': int(is_generated), 'potential': round(max(potential, base), 2),
                                'reputation': round(reputation if reputation is not None else clamp((base - 60) * 2, 5, 95), 1),
                                'morale': 60, 'form': 0, 'development_rate': development_rate or round(clamp(rng.gauss(1, 0.15), 0.6, 1.5), 3),
                                'market_value': 0, 'progress_json': '{}', 'create_ts': ts, 'update_ts': ts})
    db.insert('driver_attributes', {'driver_id': did, **attrs, 'base_rating': base, 'update_ts': ts})
    db.insert('driver_rating_history', {'driver_id': did, 'kind': 'initial', 'base_before': base, 'base_after': base, 'delta': 0, 'form_before': 0,
                                        'form_after': 0, 'morale_after': 60, 'confidence': 1, 'reasons_json': jdump([{'label': 'Rating inicial', 'value': base}]),
                                        'attributes_json': jdump(attrs), 'create_ts': ts})
    return did


def generate_driver(db, rng, level, tier, year, age=None):
    lo, hi = AGE_RANGES.get(tier, (18, 30))
    age = age or rng.randint(lo, hi)
    attrs = attrs_around(level + rng.gauss(0, 2.5), rng)
    base = base_rating(attrs, config.load('progression')['attribute_weights'])
    headroom = max(0.5, (27 - age) * 0.9) + abs(rng.gauss(0, 2))
    return insert_driver(db, generate_identity(db, rng), attrs, clamp(base + headroom, base, 98), year - age, rng)


def generate_rookie(db, rng, year):
    from fcm.career_engine.rating import generate_rookie_attributes
    r = generate_rookie_attributes(rng, config.load('progression'))
    return insert_driver(db, generate_identity(db, rng), r['attrs'], r['potential'], year - r['age'], rng, development_rate=r['development_rate'])


# ------------------------------------------------------------------------------------------
# Season structure
# ------------------------------------------------------------------------------------------
def create_sessions(db, round_row, championship_id, cat_cfg, season_seed):
    fmt_name = 'sprint' if round_row['sprint'] and 'sprint' in cat_cfg['weekend_formats'] else 'standard'
    ts = now_ts()
    for i, s in enumerate(cat_cfg['weekend_formats'][fmt_name], start=1):
        db.insert('sessions', {'round_id': round_row['id'], 'championship_id': championship_id, 'code': s['code'], 'type': s['type'], 'name': s['name'],
                               'order_no': i, 'duration_min': s.get('duration_min'), 'points_system': s.get('points_system'),
                               'grid_rule_json': jdump({**s.get('grid', {}), **({'knockout': s['knockout']} if s.get('knockout') else {})}), 'status': 'pending',
                               'seed': derive_seed(season_seed, round_row['round_no'], championship_id, s['code']), 'create_ts': ts})


def create_calendar(db, season_id, year, calendar, season_seed, champ_by_code, cats):
    archetypes = config.load('track_archetypes')
    for n, r in enumerate(calendar, start=1):
        prof = archetypes.get(r.get('archetype', 'balanced'), archetypes['balanced'])
        pid = r.get('track_profile_id') or db.insert('track_profiles', {'name': r['event_name'], 'archetype': r.get('archetype', 'balanced'),
                                                                         **{k: prof[k] for k in prof}, 'length_m': r.get('length_m')})
        date = r.get('date')
        official = r.get('official_length_m') or (float(r['length_km']) * 1000 if r.get('length_km') else None)
        rid = db.insert('calendar_rounds', {'season_id': season_id, 'round_no': n, 'event_name': r['event_name'], 'country': r.get('country'),
                                            'ac_track_id': r.get('ac_track_id'), 'ac_layout_id': r.get('ac_layout_id'), 'track_profile_id': pid,
                                            'date': f'{year}-{date}' if date and len(date) == 5 else date, 'sprint': int(bool(r.get('sprint'))), 'status': 'scheduled',
                                            'circuit': r.get('circuit'), 'official_length_m': official, 'length_override_m': r.get('length_override_m'),
                                            'race_distance_km': r.get('race_distance_km'), 'start_time': r.get('start_time'), 'night': int(bool(r.get('night'))),
                                            'climate': r.get('climate'), 'summer_break_after': int(bool(r.get('summer_break_after')))})
        rr = db.one('SELECT * FROM calendar_rounds WHERE id = ?', (rid,))
        for code in r.get('categories') or ['F1']:
            if code in champ_by_code: create_sessions(db, rr, champ_by_code[code], cats[code], season_seed)


def create_career(opts: dict):
    """opts: name, seed?, start_year?, categories[], player{}, settings{}, difficulty{}, realism{}, world(json)?"""
    world = opts.get('world') or load_template()
    seed = int(opts.get('seed') or random.SystemRandom().randint(1, 2 ** 31))
    year = int(opts.get('start_year') or world.get('season') or 2026)
    codes = [c for c in (opts.get('categories') or ['F1']) if c in world['categories']]
    if 'F1' not in codes: codes.insert(0, 'F1')
    all_cats = config.load('categories')
    db = store.create(opts.get('name') or 'My Career')
    rng = rng_for(seed, 'world')
    ts = now_ts()
    with db.transaction():
        db.insert('career', {'id': 1, 'name': opts.get('name') or 'My Career', 'seed': seed, 'difficulty_json': jdump({**DEFAULT_DIFFICULTY, **(opts.get('difficulty') or {})}),
                             'realism_json': jdump({**DEFAULT_REALISM, **(opts.get('realism') or {})}),
                             'settings_json': jdump({**DEFAULT_SETTINGS, **(opts.get('settings') or {})}), 'app_version': __version__, 'create_ts': ts, 'update_ts': ts})
        season_seed = derive_seed(seed, 'season', year)
        season_id = db.insert('seasons', {'year': year, 'status': 'active', 'seed': season_seed, 'create_ts': ts})
        cat_ids, champ_by_code, cats = {}, {}, {}
        for code in codes:
            cfg = all_cats[code]
            cats[code] = cfg
            cat_ids[code] = db.insert('categories', {'code': code, 'name': cfg['name'], 'tier': cfg['tier'], 'config_json': jdump(cfg)})
            champ_by_code[code] = db.insert('championships', {'season_id': season_id, 'category_id': cat_ids[code], 'player_mode': 'simulate', 'status': 'active', 'rules_json': '{}'})
        player = opts.get('player') or {}
        player_cat = player.get('category') if player.get('category') in codes else 'F1'
        player_id = None
        by_name = {}
        reserves = []
        for code in codes:
            ch_id = champ_by_code[code]
            tier = cats[code]['tier']
            used_numbers = set()
            teams = world['categories'][code]['teams']
            player_team_idx = int(player.get('team_index', len(teams) - 1)) if code == player_cat else None
            n_cars = int(cats[code].get('cars_per_team', 2))
            for ti, t in enumerate(teams):
                team_id = db.insert('teams', {'name': t['name'], 'short_name': t.get('short_name') or t['name'][:3].upper(), 'country': t.get('country'),
                                              'color': t.get('color'), 'category_id': cat_ids[code], 'reputation': round(clamp((t.get('strength', 85) - 80) * 5, 5, 95), 1), 'create_ts': ts})
                car = t.get('car') or make_car(float(t.get('strength', 85)), rng)
                db.insert('car_performance', {'season_id': season_id, 'team_id': team_id, **{k: car[k] for k in repo.CAR_FIELDS},
                                              'development_efficiency': car.get('development_efficiency', 75), 'update_ts': ts})
                cm = config.load('car_model')
                db.insert('team_performance_history', {'season_id': season_id, 'team_id': team_id, 'overall': overall_strength({k: car[k] for k in repo.CAR_FIELDS}, cm),
                                                       'components_json': jdump({k: car[k] for k in repo.CAR_FIELDS}), 'reason': 'initial', 'create_ts': ts})
                drivers = list(t.get('drivers') or [])
                slots = []
                for di in range(n_cars):
                    spec = drivers[di] if di < len(drivers) else None
                    if spec: did = _driver_from_spec(db, spec, year, rng)
                    else: did = generate_driver(db, rng, float(t.get('driver_level', 80)), tier, year)
                    if spec: by_name[f"{spec['first_name']} {spec['last_name']}"] = did
                    slots.append((did, spec))
                if player_team_idx == ti:
                    slot = min(n_cars - 1, int(player.get('slot', n_cars - 1)))
                    if player.get('mode') == 'existing':
                        player_id = slots[slot][0]
                    else:
                        player_id = _create_player(db, player, year, rng)
                        slots[slot] = (player_id, {'number': player.get('number') or (slots[slot][1] or {}).get('number')})
                    db.execute('UPDATE drivers SET is_player = 1 WHERE id = ?', (player_id,))
                if t.get('reserve') and tier == 1: reserves.append((ch_id, team_id, t['reserve']))
                for di, (did, spec) in enumerate(slots):
                    num = (spec or {}).get('number')
                    if not num or num in used_numbers:
                        num = next(n for n in (rng.randint(2, 99) for _ in range(500)) if n not in used_numbers)
                    used_numbers.add(num)
                    role = f'D{di + 1}'
                    db.insert('championship_entries', {'championship_id': ch_id, 'driver_id': did, 'team_id': team_id, 'number': int(num), 'role': role, 'active': 1})
                    from fcm.management.market import salary_for
                    dr = db.one('SELECT d.reputation, a.base_rating FROM drivers d JOIN driver_attributes a ON a.driver_id = d.id WHERE d.id = ?', (did,))
                    sal = float((spec or {}).get('salary') or salary_for(tier, dr['base_rating'], dr['reputation']))
                    db.insert('contracts', {'driver_id': did, 'team_id': team_id, 'start_season': year,
                                            'end_season': int((spec or {}).get('contract_end') or year + rng.randint(0, 2)),
                                            'salary': sal, 'role': role, 'release_clause': round(sal * 2, 3), 'status': 'active', 'create_ts': ts})
        for ch_id, team_id, spec in reserves:
            did = by_name.get(spec.get('same_as')) if spec.get('same_as') else by_name.get(f"{spec['first_name']} {spec['last_name']}")
            if not did and not spec.get('same_as'):
                did = _driver_from_spec(db, spec, year, rng)
                by_name[f"{spec['first_name']} {spec['last_name']}"] = did
            if not did: continue
            used = {r['number'] for r in db.all('SELECT number FROM championship_entries WHERE championship_id = ?', (ch_id,))}
            num = spec.get('number') if spec.get('number') and spec['number'] not in used else next(n for n in range(2, 100) if n not in used)
            db.insert('championship_entries', {'championship_id': ch_id, 'driver_id': did, 'team_id': team_id, 'number': num, 'role': 'reserve', 'active': 1})
        academy_seed = {}
        for code in codes:
            for t in world['categories'][code]['teams']:
                for spec in t.get('drivers') or []:
                    if spec.get('academy'): academy_seed.setdefault(spec['academy'], []).append(by_name.get(f"{spec['first_name']} {spec['last_name']}"))
        db.execute('UPDATE championships SET player_mode = ? WHERE id = ?', ('play', champ_by_code[player_cat]))
        create_calendar(db, season_id, year, world['calendar'], season_seed, champ_by_code, cats)
        repo.update_career(db, player_driver_id=player_id, current_season_id=season_id)
        from fcm.management import lifecycle
        lifecycle.init_season(db, season_id, year, seed, first=True, academy_seed=academy_seed)
        ev = repo.emit(db, 'CAREER_CREATED', {'seed': seed, 'year': year, 'categories': codes}, season_id=season_id)
        from fcm.career_engine import newsroom
        newsroom.season(db, year, len(world['calendar']), season_id, ev, first=True)
    _log.info('Career %s created (seed %s)', store.career_id, seed)
    from fcm.career_engine.progression import snapshot_pre_round
    snapshot_pre_round(db)
    store.autosave('created')
    return store.career_id


def attrs_from_ea(overall, ea, rng):
    """EA-style ratings (overall + experience/racecraft/awareness/pace) -> our 12 attributes.
    The four EA values are kept; the rest are derived from them and shifted so the base rating equals the overall."""
    w = config.load('progression')['attribute_weights']
    pace, rc, aw, ex = float(ea['pace']), float(ea['racecraft']), float(ea['awareness']), float(ea['experience'])
    derived = {'qualifying': pace + (pace - rc) * 0.3, 'consistency': (aw + pace) / 2, 'tyre_management': ex * 0.4 + rc * 0.6,
               'wet_skill': overall + (ex - 80) * 0.12, 'starts': rc * 0.7 + aw * 0.3, 'defending': (rc + aw) / 2, 'overtaking': rc + (pace - aw) * 0.2,
               'adaptability': (ex + pace) / 2}
    derived = {k: v + rng.gauss(0, 1.0) for k, v in derived.items()}
    fixed = {'pace': pace, 'racecraft': rc, 'awareness': aw, 'experience': ex}
    tw = sum(w.values())
    fixed_part = sum(fixed[k] * w[k] for k in fixed) / tw
    dw = sum(w[k] for k in derived) / tw
    shift = (overall - fixed_part - sum(derived[k] * w[k] for k in derived) / tw) / dw
    attrs = {**fixed, **{k: v + shift for k, v in derived.items()}}
    return {a: round(clamp(attrs[a], 25, 99.5), 2) for a in ATTRIBUTES}


def _driver_from_spec(db, spec, year, rng):
    ident = {'first_name': spec['first_name'], 'last_name': spec['last_name'],
             'short_name': (spec.get('short_name') or spec['last_name'][:3]).upper(), 'nationality': spec.get('nationality')}
    rating = float(spec.get('rating', 80))
    if spec.get('attributes'): attrs = {a: float(spec['attributes'].get(a, rating)) for a in ATTRIBUTES}
    elif spec.get('ea'): attrs = attrs_from_ea(rating, spec['ea'], rng)
    else: attrs = attrs_around(rating, rng)
    bd = str(spec['birth_date']) if spec.get('birth_date') else None
    birth = int(bd[:4]) if bd else year - int(spec.get('age', 25))
    base = base_rating(attrs, config.load('progression')['attribute_weights'])
    age = year - birth
    potential = float(spec['potential']) if spec.get('potential') else base + max(0.5, (27 - age) * 0.8)
    rep = spec.get('reputation') if spec.get('reputation') is not None else round(clamp((base - 55) * 2.2, 5, 95), 1)
    return insert_driver(db, ident, attrs, potential, birth, rng, is_generated=False, reputation=rep, birth_date=bd if bd and len(bd) == 10 else None)


def _create_player(db, p, year, rng):
    rating = float(p.get('rating', 80))
    ident = {'first_name': p.get('first_name') or 'Player', 'last_name': p.get('last_name') or 'One',
             'short_name': (p.get('short_name') or (p.get('last_name') or 'PLY')[:3]).upper(), 'nationality': p.get('nationality') or 'ESP'}
    attrs = attrs_around(rating, rng, sd=0.8)
    for a, off in (p.get('attribute_offsets') or {}).items():
        if a in attrs: attrs[a] = round(clamp(attrs[a] + float(off), 30, 99), 2)
    shift = rating - base_rating(attrs, config.load('progression')['attribute_weights'])
    attrs = {a: round(clamp(v + shift, 30, 99), 2) for a, v in attrs.items()}
    birth = int(str(p['birth_date'])[:4]) if p.get('birth_date') else year - int(p.get('age', 20))
    ident['personality'] = p.get('personality') or 'methodical'
    return insert_driver(db, ident, attrs, float(p.get('potential', rating + 6)), birth, rng, is_player=True, is_generated=True, reputation=p.get('reputation', 30))
