"""Weekend orchestration: which session is next, and auto-simulation of everything the player
does not drive (other categories, or player's own sessions set to 'simulate')."""
from fcm.career_engine import repo, sessions


def current_round(db):
    season = repo.current_season(db)
    if not season: return None
    return db.one("SELECT * FROM calendar_rounds WHERE season_id = ? AND status != 'completed' ORDER BY round_no LIMIT 1", (season['id'],))


def pending_sessions(db, round_id):
    """Pending sessions of a round in execution order: by order_no, lower categories first (support races)."""
    return db.all("SELECT s.id, s.code, s.type, s.order_no, s.championship_id, ch.player_mode, c.tier FROM sessions s JOIN championships ch ON ch.id = s.championship_id "
                  "JOIN categories c ON c.id = ch.category_id WHERE s.round_id = ? AND s.status IN ('pending') ORDER BY s.order_no, c.tier DESC", (round_id,))


def is_player_session(db, row):
    if row['player_mode'] != 'play': return False
    pid = repo.career(db)['player_driver_id']
    return bool(db.value('SELECT 1 FROM championship_entries WHERE championship_id = ? AND driver_id = ? AND active = 1', (row['championship_id'], pid)))


def advance(db, stop_at_player=True, max_rounds=1):
    """Simulates pending sessions until the next session the player must decide on (play/simulate/skip)."""
    done, rounds = [], 0
    settings = repo.career(db)['settings']
    while rounds < max_rounds:
        rnd = current_round(db)
        if not rnd: break
        progressed = False
        for row in pending_sessions(db, rnd['id']):
            if stop_at_player and is_player_session(db, row): return {'stopped_at': row['id'], 'simulated': done}
            if not sessions.previous_sessions_done(db, sessions.get(db, row['id'])): continue
            if row['type'] == 'practice' and (not is_player_session(db, row) or settings.get('practice_mode') == 'skip'): sessions.skip(db, row['id'])
            else: sessions.simulate(db, row['id'])
            done.append(row['id'])
            progressed = True
            break
        if not progressed:
            if db.one('SELECT status FROM calendar_rounds WHERE id = ?', (rnd['id'],))['status'] == 'completed': rounds += 1
            else: break
        elif db.one('SELECT status FROM calendar_rounds WHERE id = ?', (rnd['id'],))['status'] == 'completed':
            rounds += 1
    return {'stopped_at': None, 'simulated': done}


def simulate_rest_of_season(db):
    """Debug/utility: simulates everything (including player sessions) until the season ends."""
    total = 0
    while current_round(db):
        rnd = current_round(db)
        for row in pending_sessions(db, rnd['id']):
            s = sessions.get(db, row['id'])
            if not sessions.previous_sessions_done(db, s): continue
            (sessions.skip if row['type'] == 'practice' else sessions.simulate)(db, row['id'])
            total += 1
            break
    return total
