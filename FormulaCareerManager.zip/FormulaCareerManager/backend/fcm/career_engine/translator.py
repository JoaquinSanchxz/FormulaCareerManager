"""Performance Translator: career model -> parameters Assetto Corsa really supports.

Driver -> AI_LEVEL / AI_AGGRESSION (per [CAR_n], see race_ini.py)
Car    -> AI_LEVEL offset and BALLAST / RESTRICTOR (per [CAR_n])
Physics files (aero.ini, engine.ini, power.lut) are NOT modified in this version (spec section 77).
Mappings are data (ai_mapping.json, car_performance_mapping.json) so they can be calibrated.
"""
from fcm.simulation.model import clamp, interp, morale_effect, weighted


def driver_rating_for(session_type, attrs, form, morale, amap, pcfg):
    inputs = amap['qualifying_inputs'] if session_type == 'qualifying' else amap['race_inputs']
    r = weighted(attrs, inputs)
    if amap.get('use_form_and_morale', True): r += form + morale_effect(morale, pcfg['morale'])
    return r


def translate_entry(session_type, attrs, form, morale, car_track, field_avg_car, best_car, wet, amap, cmap, pcfg, is_player=False):
    rating = driver_rating_for(session_type, attrs, form, morale, amap, pcfg)
    if wet: rating += amap.get('wet_skill_weight', 0) * float(wet) * (attrs['wet_skill'] - rating)
    level_from_driver = interp(amap['ai_level_points'], rating)
    car_offset = amap.get('car_to_ai_level', 0) * (car_track - field_avg_car)
    ai_level = clamp(level_from_driver + car_offset + amap.get('global_offset', 0), amap['ai_level_min'], amap['ai_level_max'])
    ag = amap['aggression']
    aggression = clamp(ag['base'] + ag['racecraft_weight'] * (attrs['racecraft'] - 75) + ag['awareness_weight'] * (attrs['awareness'] - 75), ag['min'], ag['max'])
    deficit = max(0.0, best_car - car_track)
    ballast = restrictor = 0.0
    if deficit > cmap['deadband_points'] and (not is_player or cmap.get('apply_to_player', True)):
        ballast = round(min(cmap['ballast_max_kg'], deficit * cmap['ballast_kg_per_point']))
        restrictor = round(min(cmap['restrictor_max_pct'], deficit * cmap['restrictor_pct_per_point']))
    return {'ai_level': round(ai_level, 1), 'ai_aggression': round(aggression * ag.get('output_scale', 100) / 100, 2),
            'ballast': ballast, 'restrictor': restrictor,
            'breakdown': {'driver_rating': round(rating, 2), 'level_from_driver': round(level_from_driver, 2), 'car_track': round(car_track, 2),
                          'car_offset': round(car_offset, 2), 'car_deficit': round(deficit, 2), 'aggression_0_100': round(aggression, 1)}}
