"""Read models for the UI (hub, calendar, weekend, drivers, teams, history). Pure reads."""
from fcm.career_engine import championship as champ, repo, sessions, weekend
from fcm.career_engine.store import store
from fcm.database.db import jload
from fcm.shared import config
from fcm.simulation.model import car_track_strength, overall_strength


def _img(path):
    """URL of an AC content image (served by /api/content/image, path relative to <AC>/content)."""
    root = store.get_setting('ac_root') if path and store.app_db else None
    if not root: return None
    from urllib.parse import quote
    from pathlib import Path
    content = str(Path(root) / 'content')
    return '/api/content/image?path=' + quote(path[len(content) + 1:] if path.startswith(content) else path)


def _app_track_name(track_id, layout_id):
    if not track_id or not store.app_db: return None
    r = store.app_db.one('SELECT l.name, l.length_m, l.pitboxes, l.preview_path, l.outline_path FROM ac_track_layouts l WHERE l.track_id = ? AND l.id = ?', (track_id, layout_id or ''))
    if r: r.update(preview_url=_img(r.pop('preview_path')), outline_url=_img(r.pop('outline_path')))
    return r


def hub(db):
    c = repo.career(db)
    season = repo.current_season(db)
    player = db.one('SELECT d.*, a.base_rating FROM drivers d JOIN driver_attributes a ON a.driver_id = d.id WHERE d.id = ?', (c['player_driver_id'],))
    entry = db.one('SELECT e.*, ch.id championship_id, cat.code category_code, t.name team_name, t.color team_color FROM championship_entries e '
                   'JOIN championships ch ON ch.id = e.championship_id JOIN categories cat ON cat.id = ch.category_id JOIN teams t ON t.id = e.team_id '
                   'WHERE e.driver_id = ? AND ch.season_id = ? AND e.active = 1', (c['player_driver_id'], season['id']))
    rnd = weekend.current_round(db)
    standing = None
    team_rank = None
    if entry:
        st = champ.driver_standings(db, entry['championship_id'])
        standing = next((d for d in st if d['driver_id'] == c['player_driver_id']), None)
        cons = champ.constructor_standings(db, entry['championship_id'])
        team_rank = next((t for t in cons if t['team_id'] == entry['team_id']), None)
    recent = db.all("SELECT r.position, r.status, r.points, s.name session_name, cr.event_name, cr.round_no FROM results r JOIN sessions s ON s.id = r.session_id "
                    "JOIN calendar_rounds cr ON cr.id = s.round_id WHERE r.driver_id = ? AND s.type IN ('race', 'sprint') ORDER BY r.id DESC LIMIT 6", (c['player_driver_id'],))
    car_rank = None
    if entry:
        cm = config.load('car_model')
        cars = sorted(((overall_strength(repo.car(db, season['id'], t['team_id']), cm), t['team_id']) for t in
                       db.all('SELECT DISTINCT team_id FROM championship_entries WHERE championship_id = ?', (entry['championship_id'],))), reverse=True)
        car_rank = {'rank': [t for _, t in cars].index(entry['team_id']) + 1, 'of': len(cars), 'overall': next(o for o, t in cars if t == entry['team_id'])}
    mgmt = None
    if entry:
        f = db.one('SELECT * FROM team_finances WHERE season_id = ? AND team_id = ?', (season['id'], entry['team_id']))
        ai = db.one('SELECT notes_json FROM team_ai WHERE team_id = ?', (entry['team_id'],))
        mgmt = {'cash': f and f['cash'], 'cost_cap_spent': f and f['cost_cap_spent'],
                'objective': jload(ai['notes_json'], {}).get('objective') if ai else None,
                'projects': db.value("SELECT COUNT(*) FROM development_projects WHERE team_id = ? AND status = 'design'", (entry['team_id'],)),
                'parts_ready': db.value('SELECT COALESCE(SUM(available), 0) FROM parts WHERE team_id = ? AND season_id = ?', (entry['team_id'], season['id'])),
                'pending_events': db.value("SELECT COUNT(*) FROM game_events WHERE team_id = ? AND status = 'pending'", (entry['team_id'],)),
                'open_offers': db.value("SELECT COUNT(*) FROM offers WHERE driver_id = ? AND status = 'open'", (c['player_driver_id'],)),
                'worn': db.value("SELECT COUNT(*) FROM power_components WHERE season_id = ? AND driver_id = ? AND status = 'fitted' AND wear >= 0.85", (season['id'], c['player_driver_id'])),
                'delegated': bool(c['settings'].get('delegate_team_management'))}
    return {'career': c, 'season': season, 'player': player, 'entry': entry, 'standing': standing, 'team_standing': team_rank, 'car_rank': car_rank, 'management': mgmt,
            'next_round': round_view(db, rnd['id']) if rnd else None, 'recent': recent,
            'news': news(db, 8),
            'season_complete': rnd is None,
            'preseason': not db.value("SELECT 1 FROM sessions s JOIN calendar_rounds cr ON cr.id = s.round_id WHERE cr.season_id = ? AND s.status IN ('completed', 'skipped', 'running') LIMIT 1", (season['id'],)),
            'championships': repo.championships(db, season['id'])}


def calendar(db, season_id=None):
    season_id = season_id or repo.current_season(db)['id']
    rounds = db.all('SELECT cr.*, tp.archetype, tp.name profile_name FROM calendar_rounds cr LEFT JOIN track_profiles tp ON tp.id = cr.track_profile_id WHERE cr.season_id = ? ORDER BY round_no', (season_id,))
    for r in rounds:
        r['categories'] = [x['code'] for x in db.all('SELECT DISTINCT cat.code FROM sessions s JOIN championships ch ON ch.id = s.championship_id JOIN categories cat ON cat.id = ch.category_id WHERE s.round_id = ? ORDER BY cat.tier', (r['id'],))]
        r['ac_layout'] = _app_track_name(r['ac_track_id'], r['ac_layout_id'])
        win = db.one("SELECT d.first_name, d.last_name, cat.code FROM results res JOIN sessions s ON s.id = res.session_id JOIN championships ch ON ch.id = s.championship_id "
                     "JOIN categories cat ON cat.id = ch.category_id JOIN drivers d ON d.id = res.driver_id WHERE s.round_id = ? AND s.type = 'race' AND res.position = 1 ORDER BY cat.tier LIMIT 1", (r['id'],))
        r['winner'] = f"{win['first_name']} {win['last_name']}" if win else None
    return rounds


def round_view(db, round_id):
    r = db.one('SELECT cr.*, tp.* , cr.id id, tp.id profile_id, tp.name profile_name FROM calendar_rounds cr LEFT JOIN track_profiles tp ON tp.id = cr.track_profile_id WHERE cr.id = ?', (round_id,))
    r['ac_layout'] = _app_track_name(r['ac_track_id'], r['ac_layout_id'])
    ss = db.all('SELECT s.*, cat.code category_code, cat.tier, ch.player_mode FROM sessions s JOIN championships ch ON ch.id = s.championship_id JOIN categories cat ON cat.id = ch.category_id '
                'WHERE s.round_id = ? ORDER BY cat.tier, s.order_no', (round_id,))
    pid = repo.career(db)['player_driver_id']
    for s in ss:
        full = sessions.get(db, s['id'])
        s['format'] = sessions.session_format(db, full)
        s['can_run'] = s['status'] == 'pending' and sessions.round_is_current(db, full) and sessions.previous_sessions_done(db, full)
        s['player_session'] = bool(db.value('SELECT 1 FROM championship_entries WHERE championship_id = ? AND driver_id = ? AND active = 1', (s['championship_id'], pid)))
        s['winner'] = db.one('SELECT d.first_name, d.last_name, r.best_lap_ms, r.total_time_ms FROM results r JOIN drivers d ON d.id = r.driver_id WHERE r.session_id = ? AND r.position = 1', (s['id'],))
        s['player_result'] = db.one('SELECT position, status, points, best_lap_ms FROM results WHERE session_id = ? AND driver_id = ?', (s['id'], pid))
        s['conditions'] = sessions.conditions(db, full)
        s['forecast'] = sessions.forecast(db, full) if s['status'] == 'pending' else None
        s['strategy'] = full['strategy'] or None
        s.pop('conditions_json', None)
        s.pop('strategy_json', None)
        s['grid_rule'] = jload(s.pop('grid_rule_json'), {})
    r['sessions'] = ss
    # previous editions of this Grand Prix in the career (winners of the main race of each category)
    r['history'] = db.all("SELECT cr2.date, cat.code category_code, d.first_name || ' ' || d.last_name winner, t.name team, t.color team_color FROM calendar_rounds cr2 "
                          "JOIN sessions s ON s.round_id = cr2.id AND s.type = 'race' JOIN championships ch ON ch.id = s.championship_id JOIN categories cat ON cat.id = ch.category_id "
                          "JOIN results res ON res.session_id = s.id AND res.position = 1 JOIN drivers d ON d.id = res.driver_id JOIN teams t ON t.id = res.team_id "
                          "WHERE cr2.event_name = ? AND cr2.id != ? AND cat.tier = 1 ORDER BY cr2.date DESC LIMIT 5", (r['event_name'], round_id))
    r['player_best'] = db.value("SELECT MIN(res.position) FROM results res JOIN sessions s ON s.id = res.session_id JOIN calendar_rounds cr2 ON cr2.id = s.round_id "
                                "WHERE cr2.event_name = ? AND s.type = 'race' AND res.driver_id = ? AND res.status = 'FIN'", (r['event_name'], pid))
    # expected performance of the player's car at this track
    season = repo.current_season(db)
    entry = db.one('SELECT e.* FROM championship_entries e JOIN championships ch ON ch.id = e.championship_id WHERE e.driver_id = ? AND ch.season_id = ? AND e.active = 1', (pid, season['id']))
    if entry:
        prof = repo.track_profile(db, r['track_profile_id'])
        cm = config.load('car_model')
        ranks = sorted(((car_track_strength(repo.car(db, season['id'], t['team_id']), prof, cm), t['team_id'])
                        for t in db.all('SELECT DISTINCT team_id FROM championship_entries WHERE championship_id = ?', (entry['championship_id'],))), reverse=True)
        r['car_rank_here'] = [t for _, t in ranks].index(entry['team_id']) + 1
        r['car_rank_of'] = len(ranks)
    return r


def drivers(db, championship_id=None, include_free=False):
    season = repo.current_season(db)
    if championship_id:
        rows = db.all('SELECT d.*, a.*, e.number, e.role, e.skin, e.id entry_id, t.id team_id, t.name team_name, t.color team_color FROM championship_entries e '
                      'JOIN drivers d ON d.id = e.driver_id JOIN driver_attributes a ON a.driver_id = d.id JOIN teams t ON t.id = e.team_id WHERE e.championship_id = ? ORDER BY t.id, e.role', (championship_id,))
    else:
        rows = db.all('SELECT d.*, a.*, NULL number, NULL team_name FROM drivers d JOIN driver_attributes a ON a.driver_id = d.id WHERE d.retired = 0 ORDER BY a.base_rating DESC')
    for r in rows:
        r['age'] = repo.age_in(r['birth_date'], season['year'])
        r.pop('progress_json', None)
    return rows


def driver_profile(db, driver_id):
    season = repo.current_season(db)
    d = db.one('SELECT d.*, a.* FROM drivers d JOIN driver_attributes a ON a.driver_id = d.id WHERE d.id = ?', (driver_id,))
    if not d: raise LookupError('Driver not found')
    d['age'] = repo.age_in(d['birth_date'], season['year'])
    d['progress'] = jload(d.pop('progress_json'), {})
    mcfg = config.load('progression')['morale']
    from fcm.simulation.model import morale_effect
    d['effective_rating'] = round(d['base_rating'] + d['form'] + morale_effect(d['morale'], mcfg), 2)
    hist = db.all('SELECT h.*, s.year, cr.round_no FROM driver_rating_history h LEFT JOIN seasons s ON s.id = h.season_id LEFT JOIN calendar_rounds cr ON cr.id = h.round_id '
                  'WHERE h.driver_id = ? ORDER BY h.id', (driver_id,))
    for h in hist:
        h['reasons'] = jload(h.pop('reasons_json'), [])
        h['attributes'] = jload(h.pop('attributes_json'), {})
    contract = db.one("SELECT c.*, t.name team_name FROM contracts c JOIN teams t ON t.id = c.team_id WHERE c.driver_id = ? AND c.status = 'active' ORDER BY c.end_season DESC LIMIT 1", (driver_id,))
    entry = db.one('SELECT e.*, t.name team_name, t.color team_color, cat.code category_code FROM championship_entries e JOIN championships ch ON ch.id = e.championship_id '
                   'JOIN categories cat ON cat.id = ch.category_id JOIN teams t ON t.id = e.team_id WHERE e.driver_id = ? AND ch.season_id = ?', (driver_id, season['id']))
    recent = db.all("SELECT r.position, r.grid_position, r.status, r.points, s.code, s.type, cr.event_name, cr.round_no, dp.expected_pos, dp.score FROM results r "
                    "JOIN sessions s ON s.id = r.session_id JOIN calendar_rounds cr ON cr.id = s.round_id LEFT JOIN driver_performance dp ON dp.session_id = r.session_id AND dp.driver_id = r.driver_id "
                    "WHERE r.driver_id = ? AND s.type != 'practice' ORDER BY r.id DESC LIMIT 15", (driver_id,))
    tm_h2h = None
    if entry:
        mate = db.one('SELECT driver_id FROM championship_entries WHERE championship_id = ? AND team_id = ? AND driver_id != ? AND active = 1', (entry['championship_id'], entry['team_id'], driver_id))
        if mate: tm_h2h = teammate_h2h(db, driver_id, mate['driver_id'], entry['championship_id'])
    return {'driver': d, 'history': hist, 'contract': contract, 'entry': entry, 'recent': recent,
            'season_stats': champ.driver_stats(db, driver_id, season['id']), 'career_stats': champ.driver_stats(db, driver_id), 'teammate': tm_h2h}


def teammate_h2h(db, a, b, championship_id):
    rows = db.all("SELECT s.id, s.type, r.driver_id, r.position, r.status, r.best_lap_ms FROM results r JOIN sessions s ON s.id = r.session_id "
                  "WHERE s.championship_id = ? AND s.type IN ('qualifying', 'race') AND r.driver_id IN (?, ?)", (championship_id, a, b))
    by = {}
    for r in rows: by.setdefault(r['id'], {})[r['driver_id']] = r
    q = [0, 0]; rc = [0, 0]; deltas = []
    for sid, pair in by.items():
        if a not in pair or b not in pair: continue
        x, y = pair[a], pair[b]
        if x['type'] == 'qualifying':
            q[0 if x['position'] < y['position'] else 1] += 1
            if x['best_lap_ms'] and y['best_lap_ms']: deltas.append((x['best_lap_ms'] - y['best_lap_ms']) / y['best_lap_ms'] * 100)
        elif x['status'] == 'FIN' and y['status'] == 'FIN':
            rc[0 if x['position'] < y['position'] else 1] += 1
    mate = db.one('SELECT first_name, last_name FROM drivers WHERE id = ?', (b,))
    deltas.sort()
    return {'teammate_id': b, 'teammate_name': f"{mate['first_name']} {mate['last_name']}", 'qualifying': q, 'race': rc,
            'median_quali_delta_pct': round(deltas[len(deltas) // 2], 3) if deltas else None, 'samples': len(deltas)}


def teams(db, championship_id):
    season = repo.current_season(db)
    ch = repo.championship(db, championship_id)
    cm = config.load('car_model')
    out = []
    rnd = weekend.current_round(db)
    prof = repo.track_profile(db, rnd['track_profile_id']) if rnd else None
    for t in db.all('SELECT DISTINCT t.* FROM teams t JOIN championship_entries e ON e.team_id = t.id WHERE e.championship_id = ?', (championship_id,)):
        car = repo.car(db, ch['season_id'], t['id'])
        t['car'] = car
        t['overall'] = overall_strength(car, cm)
        t['next_track_strength'] = car_track_strength(car, prof, cm) if prof else None
        t['drivers'] = db.all('SELECT d.id, d.first_name, d.last_name, e.number, e.role, a.base_rating FROM championship_entries e JOIN drivers d ON d.id = e.driver_id '
                              'JOIN driver_attributes a ON a.driver_id = d.id WHERE e.championship_id = ? AND e.team_id = ? ORDER BY e.role', (championship_id, t['id']))
        t['history'] = db.all('SELECT h.overall, h.reason, h.create_ts, cr.round_no, s.year FROM team_performance_history h JOIN seasons s ON s.id = h.season_id '
                              'LEFT JOIN calendar_rounds cr ON cr.id = h.round_id WHERE h.team_id = ? ORDER BY h.id', (t['id'],))
        out.append(t)
    out.sort(key=lambda t: -t['overall'])
    for i, t in enumerate(out, 1): t['overall_rank'] = i
    if prof:
        for i, t in enumerate(sorted(out, key=lambda t: -t['next_track_strength']), 1): t['next_track_rank'] = i
    return {'teams': out, 'next_round': rnd, 'season': season}


def history(db):
    seasons = db.all('SELECT * FROM seasons ORDER BY year')
    for s in seasons:
        s['championships'] = []
        for ch in repo.championships(db, s['id']):
            st = champ.driver_standings(db, ch['id'])
            cons = champ.constructor_standings(db, ch['id'])
            s['championships'].append({'id': ch['id'], 'category_code': ch['category_code'], 'leader': st[0] if st else None,
                                       'constructor_leader': cons[0] if cons else None})
        s['rounds'] = calendar(db, s['id'])
    return seasons


def laps(db, session_id):
    return db.all('SELECT l.*, d.first_name, d.last_name FROM laps l JOIN drivers d ON d.id = l.driver_id WHERE l.session_id = ? ORDER BY l.driver_id, l.lap_no', (session_id,))


def news(db, limit=100):
    return db.all('SELECT n.*, t.name team_name, t.color team_color, cr.event_name, cr.country FROM news n LEFT JOIN teams t ON t.id = n.team_id '
                  'LEFT JOIN calendar_rounds cr ON cr.id = n.round_id ORDER BY n.id DESC LIMIT ?', (limit,))


def events(db, type_=None):
    if type_: return db.all('SELECT * FROM domain_events WHERE type = ? ORDER BY id DESC LIMIT 300', (type_,))
    return db.all('SELECT * FROM domain_events ORDER BY id DESC LIMIT 300')


def player_telemetry(db, session_id):
    r = db.one('SELECT * FROM player_telemetry WHERE session_id = ? ORDER BY id DESC LIMIT 1', (session_id,))
    if r: r['max_damage'] = jload(r.pop('max_damage_json'), {})
    return r
