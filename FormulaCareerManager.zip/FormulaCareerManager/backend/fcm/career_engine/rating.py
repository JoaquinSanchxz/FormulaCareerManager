"""Driver development model (pure functions, no DB). Math documented in RATING_MODEL.md.

Three time scales:
  A. immediate  -> form (-3..+3, decays to 0) and morale
  B. season     -> small, capped base-rating changes from EMA-smoothed evidence
  C. career     -> season-end age curve, potential convergence, experience
Every change returns an audit record with the reasons behind it.
"""
import copy
import math

from fcm.simulation.model import ATTRIBUTES, base_rating, clamp, expected_positions, interp

SCORED_TYPES = ('qualifying', 'sprint', 'race')


# ---------------------------------------------------------------------------------------------
# Session evidence
# ---------------------------------------------------------------------------------------------
def session_scores(session_type, rows, pcfg, laptime_pct_per_point=0.13):
    """rows: [{driver_id, team_id, strength, position, status, dnf_reason, best_lap_ms, source_confidence}]
    strength = expected performance (car at track + effective driver), same units as the simulator.
    Returns one evidence dict per driver (drivers that did not start are skipped)."""
    c = pcfg['session']
    rows = [r for r in rows if r.get('status') != 'DNS' and r.get('position')]
    n = len(rows)
    if n < 2 or session_type not in SCORED_TYPES: return []
    exp = expected_positions([r['strength'] for r in rows], c['expected_sigma'])
    by_team = {}
    for r, e in zip(rows, exp):
        r['_exp'] = e
        by_team.setdefault(r['team_id'], []).append(r)
    out = []
    S = c['score_saturation']
    for r in rows:
        conf = r.get('source_confidence', 1.0)
        actual = r['position']
        dnf = r.get('status') in ('DNF', 'DSQ')
        if dnf:
            reason = r.get('dnf_reason')
            conf *= c['dnf_mechanical_confidence'] if (reason or '').startswith('mechanical') else c['dnf_incident_confidence'] if reason == 'incident' else c['dnf_unknown_confidence']
            actual = n
        pos_score = (r['_exp'] - actual) / (n - 1) * c['position_scale']
        tm_score, tm_detail = None, None
        mates = [m for m in by_team.get(r['team_id'], []) if m['driver_id'] != r['driver_id']]
        if mates and not dnf:
            m = mates[0]
            if session_type == 'qualifying' and r.get('best_lap_ms') and m.get('best_lap_ms'):
                delta_pct = (m['best_lap_ms'] - r['best_lap_ms']) / m['best_lap_ms'] * 100
                expected_pct = (r['strength'] - m['strength']) * laptime_pct_per_point
                tm_score = clamp((delta_pct - expected_pct) * c['teammate_quali_scale_per_pct'], -c['teammate_cap'], c['teammate_cap'])
                tm_detail = {'teammate_id': m['driver_id'], 'delta_pct': round(delta_pct, 3), 'expected_pct': round(expected_pct, 3)}
            elif session_type != 'qualifying' and m.get('status') == 'FIN':
                rel = ((m['position'] - r['position']) - (m['_exp'] - r['_exp'])) / (n - 1) * c['teammate_race_scale']
                tm_score = clamp(rel, -c['teammate_cap'], c['teammate_cap'])
                tm_detail = {'teammate_id': m['driver_id'], 'pos_diff': m['position'] - r['position'], 'expected_diff': round(m['_exp'] - r['_exp'], 2)}
        raw = pos_score if tm_score is None else c['weight_position'] * pos_score + c['weight_teammate'] * tm_score
        score = S * math.tanh(raw / S)
        out.append({'driver_id': r['driver_id'], 'session_type': session_type, 'expected_pos': round(r['_exp'], 2), 'actual_pos': actual,
                    'teammate_delta': round(tm_score, 3) if tm_score is not None else None, 'score': round(score, 4),
                    'confidence': round(conf, 3), 'details': {'position_score': round(pos_score, 3), 'teammate': tm_detail, 'field': n,
                                                              'status': r.get('status'), 'dnf_reason': r.get('dnf_reason')}})
    return out


# ---------------------------------------------------------------------------------------------
# Weekend update (form, morale, small base change)
# ---------------------------------------------------------------------------------------------
def _age_factor(age, positive, pcfg):
    return interp(pcfg['age_factor_positive' if positive else 'age_factor_negative'], age)


def _headroom(base, potential, pcfg):
    h = pcfg['potential_headroom']
    gap = potential - base
    if gap <= 0: return h['at_or_above']
    return clamp(h['min'] + gap * h['per_point'], h['min'], h['max'])


def _apply_to_attributes(attrs, shares, delta, pcfg):
    """Distribute a base-rating delta onto attribute groups so that weighted mean moves by ~delta."""
    w = pcfg['attribute_weights']
    tw = sum(w.values())
    new = dict(attrs)
    for group, share in shares.items():
        if share <= 0: continue
        names = pcfg['attribute_groups'][group]
        gw = sum(w[a] for a in names) / tw
        for a in names:
            new[a] = clamp(new[a] + delta * share / gw, pcfg['attribute_min'], pcfg['attribute_max'])
    return new


def weekend_update(state, evidence, pcfg, label=''):
    """state: {attrs, base, form, morale, potential, age, development_rate, progress{}}
    evidence: list of session evidence dicts from session_scores (one driver).
    Returns (new_state, audit_record)."""
    s = copy.deepcopy(state)
    prog = s.setdefault('progress', {})
    prog.setdefault('trend', 0.0)
    prog.setdefault('season_delta', 0.0)
    prog.setdefault('recent', [])
    prog.setdefault('weekends', 0)
    ww = pcfg['session']['weekend_weights']
    fcfg, mcfg, bcfg = pcfg['form'], pcfg['morale'], pcfg['base']
    wsum = sum(ww.get(e['session_type'], 0) for e in evidence)
    wc = sum(ww.get(e['session_type'], 0) * e['confidence'] for e in evidence)
    form_before, base_before = s['form'], s['base']
    if wsum <= 0 or wc <= 0:
        s['form'] = round(s['form'] * fcfg['decay'], 4)
        return s, {'kind': 'race', 'base_before': base_before, 'base_after': base_before, 'delta': 0.0, 'form_before': form_before,
                   'form_after': s['form'], 'morale_after': s['morale'], 'confidence': 0.0,
                   'reasons': [{'label': 'Sin evidencia utilizable este fin de semana (la forma tiende a 0)', 'value': 0.0}]}
    score = sum(ww.get(e['session_type'], 0) * e['confidence'] * e['score'] for e in evidence) / wc
    conf = clamp(wc / wsum, 0, 1)
    # A. form + morale (fast)
    s['form'] = round(clamp(s['form'] * fcfg['decay'] + score * fcfg['gain'] * conf, fcfg['min'], fcfg['max']), 4)
    s['morale'] = round(clamp(s['morale'] + score * mcfg['gain'] * conf + (mcfg['neutral'] - s['morale']) * mcfg['reversion'], mcfg['min'], mcfg['max']), 3)
    # B. base (slow)
    positive = score >= 0
    age_f = _age_factor(s['age'], positive, pcfg)
    pot_f = _headroom(s['base'], s['potential'], pcfg) if positive else 1.0
    neg_f = 1.0 if positive else bcfg['negative_factor']
    dev = s.get('development_rate', 1.0)
    immediate = score * conf * bcfg['rate'] * dev * age_f * pot_f * neg_f
    prog['trend'] = prog['trend'] * (1 - bcfg['trend_alpha']) + bcfg['trend_alpha'] * score * conf
    n = prog['weekends'] + 1
    sample = n / (n + bcfg['trend_sample_k'])
    t_pos = prog['trend'] >= 0
    trend_term = prog['trend'] * bcfg['trend_rate'] * sample * dev * _age_factor(s['age'], t_pos, pcfg) * \
        (_headroom(s['base'], s['potential'], pcfg) if t_pos else bcfg['negative_factor'])
    raw_delta = immediate + trend_term
    delta = clamp(raw_delta, -bcfg['max_per_race'], bcfg['max_per_race'])
    window = sum(prog['recent'][-(bcfg['window_races'] - 1):])
    delta = clamp(window + delta, -bcfg['max_per_window'], bcfg['max_per_window']) - window
    cap = bcfg['max_per_season_young'] if s['age'] <= bcfg['young_age'] else bcfg['max_per_season']
    delta = clamp(prog['season_delta'] + delta, -cap, cap) - prog['season_delta']
    q = sum(ww['qualifying'] * e['confidence'] for e in evidence if e['session_type'] == 'qualifying')
    shares = {'qualifying': q / wc, 'race': 1 - q / wc}
    s['attrs'] = _apply_to_attributes(s['attrs'], shares, delta, pcfg)
    s['base'] = base_rating(s['attrs'], pcfg['attribute_weights'])
    real_delta = round(s['base'] - base_before, 4)
    prog['recent'] = (prog['recent'] + [real_delta])[-(bcfg['window_races'] - 1):]
    prog['season_delta'] = round(prog['season_delta'] + real_delta, 4)
    prog['weekends'] = n
    reasons = []
    for e in evidence:
        if e['confidence'] <= 0: continue
        share = ww.get(e['session_type'], 0) * e['confidence'] / wc
        name = {'qualifying': 'Clasificación', 'sprint': 'Sprint', 'race': 'Carrera'}[e['session_type']]
        reasons.append({'label': f"{name}: P{int(e['actual_pos'])} vs esperado P{e['expected_pos']:.1f}", 'value': round(e['details']['position_score'] * share, 3)})
        if e.get('teammate_delta') is not None: reasons.append({'label': f'{name} vs compañero', 'value': round(e['teammate_delta'] * share, 3)})
        if e['details'].get('status') in ('DNF', 'DSQ'): reasons.append({'label': f"{name}: {e['details']['status']} ({e['details'].get('dnf_reason') or 'causa desconocida'})", 'value': 0.0})
    reasons += [{'label': 'Puntuación de rendimiento del fin de semana', 'value': round(score, 3)},
                {'label': 'Tendencia sostenida (EMA)', 'value': round(prog['trend'], 3)},
                {'label': f"Factor edad ({s['age']})", 'value': round(age_f, 2)},
                {'label': 'Factor margen de potencial', 'value': round(pot_f, 2)}]
    if abs(raw_delta - delta) > 1e-6: reasons.append({'label': 'Cambio limitado por topes de estabilidad', 'value': round(raw_delta, 4)})
    return s, {'kind': 'race', 'label': label, 'base_before': base_before, 'base_after': s['base'], 'delta': real_delta,
               'form_before': form_before, 'form_after': s['form'], 'morale_after': s['morale'], 'confidence': round(conf, 3),
               'score': round(score, 4), 'reasons': reasons}


# ---------------------------------------------------------------------------------------------
# Season end (career scale)
# ---------------------------------------------------------------------------------------------
def season_end_update(state, season_mean_score, pcfg, rng):
    s = copy.deepcopy(state)
    ec = pcfg['season_end']
    base_before, form_before = s['base'], s['form']
    drift = interp(ec['age_drift'], s['age'])
    dev = s.get('development_rate', 1.0)
    head = _headroom(s['base'], s['potential'], pcfg)
    if drift > 0: drift *= dev * min(1.0, head)
    noise = rng.gauss(0, ec['noise_sd'])
    perf = (season_mean_score or 0) * ec['performance_weight']
    change = clamp(drift + noise + perf, -ec['max_change'], ec['max_change'])
    if change > 0: change = min(change, max(0.0, s['potential'] + 1 - s['base']))
    w = pcfg['attribute_weights']
    others = [a for a in ATTRIBUTES if a != 'experience']
    ow = sum(w[a] for a in others) / sum(w.values())
    for a in others: s['attrs'][a] = clamp(s['attrs'][a] + change / ow, pcfg['attribute_min'], pcfg['attribute_max'])
    s['attrs']['experience'] = min(ec['experience_max'], s['attrs']['experience'] + ec['experience_per_season'])
    s['base'] = base_rating(s['attrs'], w)
    if s['age'] >= ec['potential_convergence_age']:
        s['potential'] = round(max(s['base'], s['potential'] - ec['potential_convergence_rate'] * max(0.0, s['potential'] - s['base'])), 3)
    s['potential'] = max(s['potential'], s['base'])
    s['form'] = round(s['form'] * pcfg['form']['season_end_carry'], 4)
    p = s.setdefault('progress', {})
    p.update({'season_delta': 0.0, 'recent': [], 'weekends': 0, 'trend': round(p.get('trend', 0.0) * 0.5, 4)})
    reasons = [{'label': f"Curva de edad ({s['age']})", 'value': round(drift, 3)}, {'label': 'Varianza de desarrollo', 'value': round(noise, 3)},
               {'label': 'Rendimiento de la temporada', 'value': round(perf, 3)}, {'label': 'Experiencia ganada', 'value': ec['experience_per_season']}]
    return s, {'kind': 'season_end', 'base_before': base_before, 'base_after': s['base'], 'delta': round(s['base'] - base_before, 4),
               'form_before': form_before, 'form_after': s['form'], 'morale_after': s['morale'], 'confidence': 1.0, 'reasons': reasons}


def retirement_probability(age, base, rcfg):
    if age >= rcfg['max_age']: return 1.0
    if age < rcfg['start_age']: return 0.0
    p = rcfg['base_probability'] + rcfg['per_year'] * (age - rcfg['start_age'])
    if base < rcfg['low_rating']: p += rcfg['low_rating_bonus']
    return clamp(p, 0, 1)


def generate_rookie_attributes(rng, pcfg, potential=None):
    rc = pcfg['rookies']
    pot = potential if potential is not None else clamp(rng.gauss(rc['potential_mean'], rc['potential_sd']), rc['potential_min'], rc['potential_max'])
    base_target = pot - rng.uniform(rc['gap_min'], rc['gap_max'])
    attrs = {a: clamp(rng.gauss(base_target, rc['attribute_sd']), 40, 95) for a in ATTRIBUTES}
    attrs['experience'] = clamp(rng.gauss(base_target - 12, 4), 30, 80)
    shift = base_target - base_rating(attrs, pcfg['attribute_weights'])
    attrs = {a: round(clamp(v + shift, 35, 97), 2) for a, v in attrs.items()}
    return {'attrs': attrs, 'potential': round(max(pot, base_rating(attrs, pcfg['attribute_weights'])), 2),
            'development_rate': round(clamp(rng.gauss(1.0, rc['development_rate_sd']), 0.6, 1.5), 3),
            'age': rng.randint(rc['age_min'], rc['age_max'])}
