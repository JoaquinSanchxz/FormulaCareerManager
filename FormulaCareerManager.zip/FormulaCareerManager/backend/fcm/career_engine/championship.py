"""Points, standings and statistics. Standings are always derived from stored results
(never overwritten destructively); snapshots per round are stored for history."""
from fcm.database.db import jdump, now_ts
from fcm.shared import config

RACE_TYPES = ('race', 'sprint')


def points_for(results, points_system_id):
    """results: ordered list of dicts (position, status, fastest_lap, grid_position). Returns {driver_id: points}."""
    ps = config.load('points_systems').get(points_system_id) if points_system_id else None
    out = {r['driver_id']: 0.0 for r in results}
    if not ps: return out
    table = ps['points']
    for r in results:
        if r['status'] == 'FIN' and r['position'] and r['position'] <= len(table): out[r['driver_id']] += table[r['position'] - 1]
        if ps.get('fastest_lap') and r.get('fastest_lap') and r['status'] == 'FIN' and r['position'] <= ps.get('fastest_lap_max_pos', 10):
            out[r['driver_id']] += ps['fastest_lap']
        if ps.get('pole') and r.get('grid_position') == 1: out[r['driver_id']] += ps['pole']
    return out


def driver_standings(db, championship_id, upto_round_no=None):
    params = [championship_id]
    extra = ''
    if upto_round_no is not None:
        extra = ' AND cr.round_no <= ?'
        params.append(upto_round_no)
    rows = db.all('SELECT r.*, s.type session_type, s.code session_code, cr.round_no FROM results r JOIN sessions s ON s.id = r.session_id '
                  f"JOIN calendar_rounds cr ON cr.id = s.round_id WHERE s.championship_id = ? AND s.status = 'completed'{extra}", tuple(params))
    table = {}
    for r in rows:
        d = table.setdefault(r['driver_id'], {'driver_id': r['driver_id'], 'team_id': r['team_id'], 'points': 0.0, 'wins': 0, 'podiums': 0, 'poles': 0,
                                               'fastest_laps': 0, 'dnfs': 0, 'starts': 0, 'sprint_wins': 0, 'finishes': [], 'rounds': {}, '_last_round': 0})
        if r['round_no'] >= d['_last_round']:
            d['team_id'], d['_last_round'] = r['team_id'], r['round_no']
        d['points'] += r['points']
        rd = d['rounds'].setdefault(r['round_no'], {'points': 0.0})
        rd['points'] += r['points']
        if r['session_code'] == 'Q' and r['position'] == 1: d['poles'] += 1
        if r['session_type'] == 'race':
            d['starts'] += 1
            rd['race'] = r['position'] if r['status'] == 'FIN' else r['status']
            if r['status'] == 'FIN':
                d['finishes'].append(r['position'])
                if r['position'] == 1: d['wins'] += 1
                if r['position'] <= 3: d['podiums'] += 1
            else:
                d['dnfs'] += 1
            if r['fastest_lap']: d['fastest_laps'] += 1
        elif r['session_type'] == 'sprint':
            rd['sprint'] = r['position'] if r['status'] == 'FIN' else r['status']
            if r['status'] == 'FIN' and r['position'] == 1: d['sprint_wins'] += 1
    out = sorted(table.values(), key=lambda d: (-d['points'], [-d['finishes'].count(p) for p in range(1, 31)]))
    for i, d in enumerate(out, start=1):
        d['position'] = i
        d['best_finish'] = min(d['finishes']) if d['finishes'] else None
        for k in ('_last_round', 'finishes'): d.pop(k, None)
    _decorate(db, out)
    return out


def constructor_standings(db, championship_id, upto_round_no=None):
    teams = {}
    params = [championship_id]
    extra = ''
    if upto_round_no is not None:
        extra = ' AND cr.round_no <= ?'
        params.append(upto_round_no)
    rows = db.all('SELECT r.team_id, r.points, r.position, r.status, s.type FROM results r JOIN sessions s ON s.id = r.session_id JOIN calendar_rounds cr ON cr.id = s.round_id '
                  f"WHERE s.championship_id = ? AND s.status = 'completed'{extra}", tuple(params))
    for r in rows:
        t = teams.setdefault(r['team_id'], {'team_id': r['team_id'], 'points': 0.0, 'wins': 0, 'podiums': 0})
        t['points'] += r['points']
        if r['type'] == 'race' and r['status'] == 'FIN':
            t['wins'] += r['position'] == 1
            t['podiums'] += r['position'] <= 3
    for t in db.all('SELECT DISTINCT team_id FROM championship_entries WHERE championship_id = ?', (championship_id,)):
        teams.setdefault(t['team_id'], {'team_id': t['team_id'], 'points': 0.0, 'wins': 0, 'podiums': 0})
    out = sorted(teams.values(), key=lambda t: (-t['points'], -t['wins'], -t['podiums']))
    for i, t in enumerate(out, start=1):
        t['position'] = i
        tm = db.one('SELECT name, short_name, color FROM teams WHERE id = ?', (t['team_id'],))
        t.update({'team_name': tm['name'], 'team_short': tm['short_name'], 'team_color': tm['color']})
    return out


def _decorate(db, rows):
    for d in rows:
        dr = db.one('SELECT first_name, last_name, short_name, nationality, is_player FROM drivers WHERE id = ?', (d['driver_id'],))
        tm = db.one('SELECT name, short_name, color FROM teams WHERE id = ?', (d['team_id'],))
        d.update({'name': f"{dr['first_name']} {dr['last_name']}", 'short_name': dr['short_name'], 'nationality': dr['nationality'],
                  'is_player': dr['is_player'], 'team_name': tm['name'], 'team_short': tm['short_name'], 'team_color': tm['color']})


def store_standings_snapshot(db, championship_id, round_id, round_no):
    ts = now_ts()
    db.insert('standings_snapshots', {'championship_id': championship_id, 'round_id': round_id, 'kind': 'drivers',
                                      'data_json': jdump([{k: d[k] for k in ('driver_id', 'team_id', 'points', 'position', 'wins')} for d in driver_standings(db, championship_id, round_no)]), 'create_ts': ts})
    db.insert('standings_snapshots', {'championship_id': championship_id, 'round_id': round_id, 'kind': 'constructors',
                                      'data_json': jdump([{k: t[k] for k in ('team_id', 'points', 'position')} for t in constructor_standings(db, championship_id, round_no)]), 'create_ts': ts})


def driver_stats(db, driver_id, season_id=None):
    """Career (season_id None) or season statistics for one driver."""
    params = [driver_id]
    extra = ''
    if season_id:
        extra = ' AND cr.season_id = ?'
        params.append(season_id)
    rows = db.all('SELECT r.*, s.type, s.code, cr.season_id, c.code category FROM results r JOIN sessions s ON s.id = r.session_id '
                  'JOIN calendar_rounds cr ON cr.id = s.round_id JOIN championships ch ON ch.id = s.championship_id JOIN categories c ON c.id = ch.category_id '
                  f"WHERE r.driver_id = ? AND s.status = 'completed'{extra}", tuple(params))
    by_cat = {}
    for r in rows:
        st = by_cat.setdefault(r['category'], {'starts': 0, 'wins': 0, 'poles': 0, 'podiums': 0, 'fastest_laps': 0, 'points': 0.0, 'dnfs': 0,
                                                'sprint_wins': 0, '_fin': [], '_grid': []})
        st['points'] += r['points']
        if r['code'] == 'Q' and r['position'] == 1: st['poles'] += 1
        if r['type'] == 'race':
            st['starts'] += 1
            if r['grid_position']: st['_grid'].append(r['grid_position'])
            if r['status'] == 'FIN':
                st['_fin'].append(r['position'])
                st['wins'] += r['position'] == 1
                st['podiums'] += r['position'] <= 3
            else:
                st['dnfs'] += 1
            st['fastest_laps'] += r['fastest_lap']
        elif r['type'] == 'sprint' and r['status'] == 'FIN' and r['position'] == 1:
            st['sprint_wins'] += 1
    for st in by_cat.values():
        fin, grid = st.pop('_fin'), st.pop('_grid')
        st['average_finish'] = round(sum(fin) / len(fin), 2) if fin else None
        st['average_grid'] = round(sum(grid) / len(grid), 2) if grid else None
    return by_cat
