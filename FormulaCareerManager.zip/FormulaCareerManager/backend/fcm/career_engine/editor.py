"""Editors: user-confirmed mappings (category car, round track/layout, skins) and grid edits.
Critical AC associations are never inferred automatically (spec section 5)."""
import csv
import io

from fcm.career_engine import repo
from fcm.career_engine.store import store
from fcm.database.db import jdump, now_ts
from fcm.shared import config
from fcm.shared.safefs import safe_id
from fcm.simulation.model import ATTRIBUTES, TRACK_KEYS, base_rating

EDITABLE_DRIVER = ('first_name', 'last_name', 'short_name', 'nationality', 'birth_date', 'potential', 'reputation', 'morale')


def set_championship_car(db, championship_id, car_id, auto_skins=True):
    if car_id:
        safe_id(car_id)
        if not store.app_db.one('SELECT 1 FROM ac_cars WHERE id = ?', (car_id,)): raise ValueError(f'El coche {car_id} no está en el catálogo escaneado')
    ch = repo.championship(db, championship_id)
    with db.transaction():
        db.update('championships', championship_id, {'ac_car_id': car_id or None})
        if car_id and auto_skins:
            skins = [r['id'] for r in store.app_db.all('SELECT id FROM ac_car_skins WHERE car_id = ? ORDER BY sort_order, id', (car_id,))]
            teams = [r['team_id'] for r in db.all('SELECT DISTINCT team_id FROM championship_entries WHERE championship_id = ? ORDER BY team_id', (championship_id,))]
            for i, team_id in enumerate(teams):
                skin = skins[i % len(skins)] if skins else None
                db.execute('UPDATE championship_entries SET skin = ? WHERE championship_id = ? AND team_id = ?', (skin, championship_id, team_id))
        repo.emit(db, 'CATEGORY_CAR_ASSIGNED', {'championship_id': championship_id, 'category': ch['category_code'], 'car_id': car_id}, season_id=ch['season_id'])
    return repo.championship(db, championship_id)


def set_player_mode(db, championship_id, mode):
    if mode not in ('play', 'simulate'): raise ValueError('El modo debe ser play o simulate')
    db.update('championships', championship_id, {'player_mode': mode})


def update_entry(db, entry_id, data):
    allowed = {k: data[k] for k in ('skin', 'number') if k in data}
    if 'skin' in allowed and allowed['skin']: safe_id(allowed['skin'])
    if allowed: db.update('championship_entries', entry_id, allowed)


def update_round(db, round_id, data):
    fields = {}
    if 'ac_track_id' in data:
        tid, lid = data.get('ac_track_id') or None, data.get('ac_layout_id') or ''
        if tid:
            safe_id(tid)
            if lid: safe_id(lid)
            if not store.app_db.one('SELECT 1 FROM ac_track_layouts WHERE track_id = ? AND id = ?', (tid, lid)): raise ValueError(f'El circuito/layout {tid}/{lid} no está en el catálogo')
        fields.update({'ac_track_id': tid, 'ac_layout_id': lid or None})
    for k in ('event_name', 'country', 'date'):
        if k in data: fields[k] = data[k]
    if 'length_override_m' in data: fields['length_override_m'] = float(data['length_override_m']) if data['length_override_m'] not in (None, '', 0) else None
    if 'sprint' in data: set_sprint(db, round_id, bool(data['sprint']))
    if fields:
        with db.transaction():
            db.update('calendar_rounds', round_id, fields)
            if 'ac_track_id' in fields: repo.emit(db, 'ROUND_TRACK_ASSIGNED', {'round_id': round_id, **fields}, round_id=round_id)
    if data.get('archetype'):
        r = db.one('SELECT track_profile_id FROM calendar_rounds WHERE id = ?', (round_id,))
        prof = config.load('track_archetypes')[data['archetype']]
        db.update('track_profiles', r['track_profile_id'], {'archetype': data['archetype'], **prof})
    return db.one('SELECT * FROM calendar_rounds WHERE id = ?', (round_id,))


def season_started(db, season_id):
    return bool(db.value("SELECT 1 FROM sessions s JOIN calendar_rounds cr ON cr.id = s.round_id WHERE cr.season_id = ? AND s.status IN ('completed', 'skipped', 'running') LIMIT 1",
                         (season_id,)))


def set_sprint(db, round_id, sprint):
    """Sprint weekends are chosen before the season starts; the weekend sessions are regenerated."""
    from fcm.career_engine import world_builder
    r = db.one('SELECT * FROM calendar_rounds WHERE id = ?', (round_id,))
    if bool(r['sprint']) == sprint: return
    if season_started(db, r['season_id']): raise ValueError('Los fines de semana sprint solo se pueden elegir antes de que empiece la temporada')
    season = db.one('SELECT * FROM seasons WHERE id = ?', (r['season_id'],))
    with db.transaction():
        db.update('calendar_rounds', round_id, {'sprint': int(sprint)})
        rr = db.one('SELECT * FROM calendar_rounds WHERE id = ?', (round_id,))
        for ch in db.all('SELECT DISTINCT s.championship_id FROM sessions s WHERE s.round_id = ?', (round_id,)):
            cat = repo.category_config(db, repo.championship(db, ch['championship_id'])['category_id'])['config']
            if 'sprint' not in cat['weekend_formats']: continue
            db.execute('DELETE FROM sessions WHERE round_id = ? AND championship_id = ?', (round_id, ch['championship_id']))
            world_builder.create_sessions(db, rr, ch['championship_id'], cat, season['seed'])
        repo.emit(db, 'SPRINT_WEEKEND_SET', {'round_id': round_id, 'sprint': sprint}, season_id=r['season_id'], round_id=round_id)


def update_profile(db, profile_id, data):
    fields = {k: float(data[k]) for k in (*TRACK_KEYS, 'overtaking_difficulty', 'wet_probability', 'length_m') if data.get(k) is not None}
    if fields: db.update('track_profiles', profile_id, fields)


def update_driver(db, driver_id, data):
    with db.transaction():
        d = {k: data[k] for k in EDITABLE_DRIVER if k in data}
        if d: db.update('drivers', driver_id, {**d, 'update_ts': now_ts()})
        attrs = data.get('attributes')
        if attrs:
            cur = db.one('SELECT * FROM driver_attributes WHERE driver_id = ?', (driver_id,))
            new = {a: max(30.0, min(99.5, float(attrs.get(a, cur[a])))) for a in ATTRIBUTES}
            w = config.load('progression')['attribute_weights']
            b = base_rating(new, w)
            db.update('driver_attributes', driver_id, {**new, 'base_rating': b, 'update_ts': now_ts()}, key='driver_id')
            db.insert('driver_rating_history', {'driver_id': driver_id, 'kind': 'manual', 'base_before': cur['base_rating'], 'base_after': b,
                                                'delta': round(b - cur['base_rating'], 4), 'reasons_json': jdump([{'label': 'Edición manual (editor)', 'value': round(b - cur['base_rating'], 4)}]),
                                                'attributes_json': jdump(new), 'create_ts': now_ts()})


def update_car(db, season_id, team_id, data):
    fields = {k: max(40.0, min(100.0, float(data[k]))) for k in (*repo.CAR_FIELDS, 'development_efficiency') if k in data}
    if not fields: return
    with db.transaction():
        db.execute(f"UPDATE car_performance SET {', '.join(f'{k} = ?' for k in fields)}, update_ts = ? WHERE season_id = ? AND team_id = ?",
                   (*fields.values(), now_ts(), season_id, team_id))
        from fcm.simulation.model import overall_strength
        car = repo.car(db, season_id, team_id)
        comps = {k: car[k] for k in repo.CAR_FIELDS}
        db.insert('team_performance_history', {'season_id': season_id, 'team_id': team_id, 'overall': overall_strength(comps, config.load('car_model')),
                                               'components_json': jdump(comps), 'reason': 'manual edit', 'create_ts': now_ts()})


def update_team(db, team_id, data):
    d = {k: data[k] for k in ('name', 'short_name', 'country', 'color') if k in data}
    if d: db.update('teams', team_id, d)


CSV_COLUMNS = ('category', 'team', 'team_short', 'team_color', 'team_strength', 'first_name', 'last_name', 'short_name', 'nationality', 'birth_date',
               'number', 'rating', 'potential', 'contract_end')


def csv_to_world(text, base_world):
    """Grid CSV (one row per driver) -> world JSON (teams/drivers replaced, calendar kept)."""
    world = {**base_world, 'categories': {}}
    for row in csv.DictReader(io.StringIO(text.lstrip('﻿'))):
        row = {k.strip().lower(): (v or '').strip() for k, v in row.items() if k}
        cat = (row.get('category') or 'F1').upper()
        teams = world['categories'].setdefault(cat, {'teams': []})['teams']
        team = next((t for t in teams if t['name'] == row['team']), None)
        if not team:
            team = {'name': row['team'], 'short_name': row.get('team_short') or row['team'][:3].upper(), 'color': row.get('team_color') or '#888888',
                    'strength': float(row.get('team_strength') or 88), 'drivers': []}
            teams.append(team)
        if row.get('first_name'):
            team['drivers'].append({k: row[k] for k in ('first_name', 'last_name', 'short_name', 'nationality', 'birth_date') if row.get(k)} |
                                   {k: float(row[k]) for k in ('rating', 'potential') if row.get(k)} |
                                   {k: int(row[k]) for k in ('number', 'contract_end') if row.get(k)})
    if 'F1' not in world['categories']: raise ValueError('El CSV debe contener filas de F1')
    return world
