@echo off
rem Runs from source (needs Python 3.10+). Builds the frontend if it is missing (needs Node.js).
cd /d "%~dp0"
if not exist frontend\dist\index.html (
  pushd frontend
  if not exist node_modules call npm install --no-audit --no-fund
  call npm run build
  popd
)
python backend\fcm\main.py %*
