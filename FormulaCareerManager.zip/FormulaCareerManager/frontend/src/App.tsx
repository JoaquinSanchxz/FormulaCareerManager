import { useEffect, useState } from 'react'
import { Any, api } from './api'
import { Icon, Logo, Toaster } from './ui'
import Home from './pages/Home'
import Hub from './pages/Hub'
import Calendar from './pages/Calendar'
import Weekend from './pages/Weekend'
import SessionView from './pages/SessionView'
import Standings from './pages/Standings'
import Drivers from './pages/Drivers'
import DriverProfile from './pages/DriverProfile'
import Teams from './pages/Teams'
import History from './pages/History'
import News from './pages/News'
import Content from './pages/Content'
import Settings from './pages/Settings'
import Diagnostics from './pages/Diagnostics'
import Team from './pages/Team'
import Market from './pages/Market'
import Inbox from './pages/Inbox'
import Records from './pages/Records'

const NAV = [
  { id: 'hub', label: 'Inicio', career: true, group: 'Temporada' },
  { id: 'weekend', label: 'Fin de semana', career: true, group: 'Temporada' },
  { id: 'calendar', label: 'Calendario', career: true, group: 'Temporada' },
  { id: 'standings', label: 'Clasificación', career: true, group: 'Temporada' },
  { id: 'team', label: 'Mi equipo', career: true, group: 'Gestión' },
  { id: 'market', label: 'Mercado y contratos', career: true, group: 'Gestión' },
  { id: 'inbox', label: 'Decisiones', career: true, group: 'Gestión' },
  { id: 'drivers', label: 'Pilotos', career: true, group: 'Mundo' },
  { id: 'teams', label: 'Equipos y coches', career: true, group: 'Mundo' },
  { id: 'news', label: 'Noticias', career: true, group: 'Mundo' },
  { id: 'history', label: 'Histórico', career: true, group: 'Mundo' },
  { id: 'records', label: 'Récords', career: true, group: 'Mundo' },
  { id: 'home', label: 'Partidas', career: false, group: 'Aplicación' },
  { id: 'content', label: 'Assetto Corsa', career: false, group: 'Aplicación' },
  { id: 'settings', label: 'Ajustes', career: false, group: 'Aplicación' },
  { id: 'diagnostics', label: '¿Listo para jugar?', career: false, group: 'Aplicación' }
]

const getTheme = () => { try { return new URLSearchParams(window.location.search).get('theme') || localStorage.getItem('fcm_theme') || 'light' } catch { return 'light' } }

function useHash() {
  const [hash, setHash] = useState(window.location.hash.slice(2) || '')
  useEffect(() => {
    const f = () => setHash(window.location.hash.slice(2))
    window.addEventListener('hashchange', f)
    return () => window.removeEventListener('hashchange', f)
  }, [])
  return hash
}

export default function App() {
  const hash = useHash()
  const [health, setHealth] = useState<Any>(null)
  const [acLive, setAcLive] = useState<Any>(null)
  const [theme, setTheme] = useState(getTheme)
  const [entered, setEntered] = useState(() => window.location.hash.length > 2)
  useEffect(() => { document.documentElement.dataset.theme = theme; try { localStorage.setItem('fcm_theme', theme) } catch { /* private mode */ } }, [theme])
  const refresh = () => api.get('/api/health').then(setHealth).catch(() => setHealth(null))
  useEffect(() => { refresh() }, [hash])
  useEffect(() => {
    const t = setInterval(() => {
      api.post('/api/heartbeat').catch(() => {})
      api.get('/api/ac/status').then(s => setAcLive(s.launcher)).catch(() => {})
    }, 5000)
    return () => clearInterval(t)
  }, [])
  const [page, ...args] = hash.split('/')
  const hasCareer = !!health?.career
  const current = page || (hasCareer ? 'hub' : 'home')
  const props = { onCareerChange: refresh }
  if (health && !entered) return <><Home menu onCareerChange={() => { refresh(); setEntered(true) }} /><Toaster /></>
  let view
  if (!health) view = <div className="pad muted">Conectando…</div>
  else if (!hasCareer && NAV.find(n => n.id === current)?.career) view = <Home {...props} />
  else if (current === 'hub') view = <Hub />
  else if (current === 'weekend') view = <Weekend roundId={args[0]} />
  else if (current === 'session') view = <SessionView id={args[0]} />
  else if (current === 'calendar') view = <Calendar />
  else if (current === 'standings') view = <Standings />
  else if (current === 'drivers') view = <Drivers />
  else if (current === 'driver') view = <DriverProfile id={args[0]} />
  else if (current === 'teams') view = <Teams />
  else if (current === 'history') view = <History />
  else if (current === 'team') view = <Team />
  else if (current === 'market') view = <Market />
  else if (current === 'inbox') view = <Inbox />
  else if (current === 'records') view = <Records />
  else if (current === 'news') view = <News />
  else if (current === 'content') view = <Content />
  else if (current === 'settings') view = <Settings />
  else if (current === 'diagnostics') view = <Diagnostics />
  else view = <Home {...props} />
  return (
    <div className="app">
      <aside className="side">
        <div className="brand"><Logo /><div><b>Formula Career<br />Manager</b><small>Assetto Corsa · v{health?.version ?? '…'}</small></div></div>
        {hasCareer ? <a className="side-cta" href="#/weekend"><Icon name="play" /><div>Continuar temporada<small>Ir a la próxima sesión</small></div></a>
          : <a className="side-cta" href="#/home"><Icon name="plus" /><div>Empezar<small>Crea o carga una trayectoria</small></div></a>}
        {['Temporada', 'Gestión', 'Mundo', 'Aplicación'].map(g => {
          const items = NAV.filter(n => n.group === g && (!n.career || hasCareer))
          return items.length > 0 && (
            <div key={g}>
              <div className="side-g">{g}</div>
              <nav>{items.map(n => (
                <a key={n.id} href={`#/${n.id}`} className={current === n.id || (current === 'driver' && n.id === 'drivers') || (current === 'session' && n.id === 'weekend') ? 'on' : ''}><Icon name={n.id} />{n.label}</a>
              ))}</nav>
            </div>
          )
        })}
        {acLive && acLive.status !== 'idle' && (
          <a className={`live ${acLive.status}`} href="#/weekend">
            <b>Assetto Corsa: {({ running: 'en sesión', importing: 'importando', finished: 'terminado', failed: 'error' } as Any)[acLive.status] ?? acLive.status}</b>
            {acLive.live?.available && <small>{acLive.live.status} · vuelta {acLive.live.completed_laps} · P{acLive.live.position}</small>}
            {acLive.context?.label && <small>{acLive.context.label}</small>}
          </a>
        )}
        <div className="side-f">{health?.career ? <span>Partida: <b>{health.career}</b></span> : <span>Sin partida cargada</span>}
          <button className="theme-t" title="Cambiar tema claro / oscuro" onClick={() => setTheme(theme === 'dark' ? 'light' : 'dark')}>{theme === 'dark' ? '☀ Claro' : '☾ Oscuro'}</button></div>
      </aside>
      <main className="main">{view}</main>
      <Toaster />
    </div>
  )
}
