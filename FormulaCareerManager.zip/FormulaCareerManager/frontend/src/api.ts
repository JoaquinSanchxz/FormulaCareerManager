/* eslint-disable @typescript-eslint/no-explicit-any */
export type Any = any

async function req(method: string, url: string, body?: unknown, raw?: BodyInit): Promise<Any> {
  const res = await fetch(url, { method, headers: raw ? {} : { 'Content-Type': 'application/json' }, body: raw ?? (body !== undefined ? JSON.stringify(body) : undefined) })
  const txt = await res.text()
  const data = txt ? JSON.parse(txt) : null
  if (!res.ok) throw new Error(data?.error || `HTTP ${res.status}`)
  return data
}

export const api = {
  get: (url: string) => req('GET', url),
  post: (url: string, body: unknown = {}) => req('POST', url, body),
  patch: (url: string, body: unknown) => req('PATCH', url, body),
  put: (url: string, body: unknown) => req('PUT', url, body),
  del: (url: string) => req('DELETE', url),
  upload: (url: string, file: File) => req('POST', url, undefined, file)
}

export function imgUrl(path?: string | null, acRoot?: string | null) {
  if (!path || !acRoot) return undefined
  const content = acRoot.replace(/[\\/]+$/, '') + '\\content'
  const rel = path.startsWith(content) ? path.slice(content.length + 1) : path
  return `/api/content/image?path=${encodeURIComponent(rel)}`
}
