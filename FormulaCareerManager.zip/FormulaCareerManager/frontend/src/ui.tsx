import { ReactNode, useCallback, useEffect, useState } from 'react'
import { Any } from './api'

export function useLoad<T = Any>(fn: () => Promise<T>, deps: unknown[] = []) {
  const [data, setData] = useState<T | null>(null)
  const [error, setError] = useState<string | null>(null)
  const [loading, setLoading] = useState(true)
  const reload = useCallback(() => {
    setLoading(true)
    fn().then(d => { setData(d); setError(null) }).catch(e => setError(String(e.message || e))).finally(() => setLoading(false))
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, deps)
  useEffect(() => { reload() }, [reload])
  return { data, error, loading, reload, setData }
}

export const nav = (path: string) => { window.location.hash = path }

export function Card({ title, right, desc, children, className = '' }: { title?: ReactNode, right?: ReactNode, desc?: ReactNode, children: ReactNode, className?: string }) {
  return (
    <section className={`card ${className}`}>
      {(title || right) && <header className="card-h"><h3>{title}</h3><div>{right}</div></header>}
      <div className="card-b">{desc && <p className="card-d">{desc}</p>}{children}</div>
    </section>
  )
}

export function Btn({ children, onClick, kind = '', disabled, title }: { children: ReactNode, onClick?: () => void | Promise<unknown>, kind?: string, disabled?: boolean, title?: string }) {
  const [busy, setBusy] = useState(false)
  const click = async () => {
    if (!onClick) return
    setBusy(true)
    try { await onClick() } catch (e: Any) { toast(e.message || String(e), 'err') } finally { setBusy(false) }
  }
  return <button className={`btn ${kind}`} disabled={disabled || busy} onClick={click} title={title}>{busy ? '…' : children}</button>
}

export function Stat({ label, value, sub }: { label: string, value: ReactNode, sub?: ReactNode }) {
  return <div className="stat"><div className="stat-l">{label}</div><div className="stat-v">{value ?? '—'}</div>{sub && <div className="stat-s">{sub}</div>}</div>
}

export const TeamDot = ({ color }: { color?: string }) => <span className="tdot" style={{ background: color || '#888' }} />

export function Err({ error }: { error?: string | null }) {
  return error ? <div className="alert err">{error}</div> : null
}

export function Loading({ loading }: { loading: boolean }) {
  return loading ? <div className="muted pad">Cargando…</div> : null
}

export function fmtLap(ms?: number | null) {
  if (!ms) return '—'
  const m = Math.floor(ms / 60000), s = (ms % 60000) / 1000
  return `${m}:${s.toFixed(3).padStart(6, '0')}`
}

export function fmtRace(ms?: number | null) {
  if (!ms) return '—'
  const h = Math.floor(ms / 3600000), m = Math.floor((ms % 3600000) / 60000), s = (ms % 60000) / 1000
  return `${h ? h + ':' : ''}${String(m).padStart(h ? 2 : 1, '0')}:${s.toFixed(3).padStart(6, '0')}`
}

export function fmtGap(r: Any, leaderLaps?: number) {
  if (r.status !== 'FIN') return STATUS_ES[r.status] ?? r.status
  if (r.position === 1) return r.total_time_ms ? fmtRace(r.total_time_ms) : fmtLap(r.best_lap_ms)
  if (r.gap_ms != null) return `+${(r.gap_ms / 1000).toFixed(3)}`
  if (leaderLaps && r.laps < leaderLaps) return `+${leaderLaps - r.laps} vuelta${leaderLaps - r.laps > 1 ? 's' : ''}`
  return '—'
}

export const n2 = (v?: number | null, d = 2) => v == null ? '—' : Number(v).toFixed(d)
export const signed = (v?: number | null, d = 2) => v == null ? '—' : `${v >= 0 ? '+' : ''}${Number(v).toFixed(d)}`

export function Bar({ value, min = 60, max = 100, color }: { value: number, min?: number, max?: number, color?: string }) {
  const pct = Math.max(0, Math.min(100, ((value - min) / (max - min)) * 100))
  return <div className="bar"><div style={{ width: `${pct}%`, background: color }} /><span>{n2(value, 0)}</span></div>
}

export function LineChart({ series, height = 180 }: { series: { name: string, color: string, points: { x: number, y: number, label?: string }[] }[], height?: number }) {
  const all = series.flatMap(s => s.points)
  if (all.length < 2) return <div className="muted pad">Sin datos suficientes todavía.</div>
  const w = 640, pad = 34
  const xs = all.map(p => p.x), ys = all.map(p => p.y)
  const x0 = Math.min(...xs), x1 = Math.max(...xs)
  let y0 = Math.min(...ys), y1 = Math.max(...ys)
  if (y1 - y0 < 0.5) { y0 -= 0.25; y1 += 0.25 }
  const sx = (x: number) => pad + ((x - x0) / Math.max(1, x1 - x0)) * (w - pad * 1.5)
  const sy = (y: number) => height - 22 - ((y - y0) / (y1 - y0)) * (height - 36)
  const ticks = [y0, (y0 + y1) / 2, y1]
  return (
    <svg className="chart" viewBox={`0 0 ${w} ${height}`} preserveAspectRatio="none">
      {ticks.map((t, i) => <g key={i}><line x1={pad} x2={w - 10} y1={sy(t)} y2={sy(t)} className="grid" /><text x={2} y={sy(t) + 4} className="axis">{t.toFixed(1)}</text></g>)}
      {series.map(s => (
        <g key={s.name}>
          <polyline fill="none" stroke={s.color} strokeWidth={2} points={s.points.map(p => `${sx(p.x)},${sy(p.y)}`).join(' ')} />
          {s.points.map((p, i) => <circle key={i} cx={sx(p.x)} cy={sy(p.y)} r={2.5} fill={s.color}><title>{`${p.label ?? ''} ${p.y.toFixed(2)}`}</title></circle>)}
        </g>
      ))}
    </svg>
  )
}

let toastFn: ((msg: string, kind?: string) => void) | null = null
export function toast(msg: string, kind = 'ok') { toastFn?.(msg, kind) }
export function Toaster() {
  const [items, setItems] = useState<{ id: number, msg: string, kind: string }[]>([])
  useEffect(() => {
    toastFn = (msg, kind = 'ok') => {
      const id = Date.now() + Math.random()
      setItems(x => [...x, { id, msg, kind }])
      setTimeout(() => setItems(x => x.filter(i => i.id !== id)), kind === 'err' ? 9000 : 4000)
    }
    return () => { toastFn = null }
  }, [])
  return <div className="toasts">{items.map(i => <div key={i.id} className={`toast ${i.kind}`}>{i.msg}</div>)}</div>
}

export function Tabs({ tabs, value, onChange }: { tabs: { id: string, label: string }[], value: string, onChange: (id: string) => void }) {
  return <div className="tabs">{tabs.map(t => <button key={t.id} className={t.id === value ? 'on' : ''} onClick={() => onChange(t.id)}>{t.label}</button>)}</div>
}

export const SESSION_TYPE_ES: Record<string, string> = { practice: 'Libres', qualifying: 'Clasificación', sprint: 'Sprint', race: 'Carrera' }

export function Logo({ className = 'logo' }: { className?: string }) {
  return (
    <svg className={className} viewBox="0 0 64 64" aria-label="Formula Career Manager">
      <defs>
        <linearGradient id="lg-a" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stopColor="#ff2d46" /><stop offset="1" stopColor="#ff8a1f" /></linearGradient>
      </defs>
      <rect width="64" height="64" rx="16" fill="url(#lg-a)" />
      <g transform="translate(40 40) skewX(-14)" fill="#fff" opacity=".9"><rect x="0.0" y="0.0" width="4.5" height="4.5" /><rect x="9.0" y="0.0" width="4.5" height="4.5" /><rect x="4.5" y="4.5" width="4.5" height="4.5" /><rect x="13.5" y="4.5" width="4.5" height="4.5" /><rect x="0.0" y="9.0" width="4.5" height="4.5" /><rect x="9.0" y="9.0" width="4.5" height="4.5" /><rect width="18" height="13.5" fill="none" stroke="#fff" strokeWidth=".8" /></g>
      <path d="M15 46 29 16h22l-3.6 7.2H34.2l-2.6 5.4h13.6l-3.4 7H28.3L23.4 46z" fill="#fff" />
      <path d="M8 50h20M6 55h14" stroke="#fff" strokeWidth="3" strokeLinecap="round" opacity=".7" />
    </svg>
  )
}

const ICONS: Record<string, string> = {
  hub: 'M3 12l9-8 9 8M5 10v10h5v-6h4v6h5V10',
  weekend: 'M5 21V4M5 4h11l-2 4 2 4H5',
  calendar: 'M4 6h16v14H4zM4 10h16M9 3v4M15 3v4',
  standings: 'M8 21h8M12 17v4M7 4h10v5a5 5 0 01-10 0zM7 6H4v2a3 3 0 003 3M17 6h3v2a3 3 0 01-3 3',
  drivers: 'M12 12a4 4 0 100-8 4 4 0 000 8zM4 21a8 8 0 0116 0',
  team: 'M14.7 6.3a4 4 0 00-5.4 5.4L3 18l3 3 6.3-6.3a4 4 0 005.4-5.4l-2.5 2.5-2.5-.5-.5-2.5z',
  market: 'M4 7h16v13H4zM9 7V5a3 3 0 016 0v2M9 13h6',
  inbox: 'M4 13l3-8h10l3 8v6H4zM4 13h5l1 2h4l1-2h5',
  teams: 'M3 15l2-5h14l2 5v3H3zM7 18v2M17 18v2M6 10l2-4h8l2 4',
  history: 'M3 12a9 9 0 109-9 9 9 0 00-7 3.3M3 4v4h4M12 7v5l3 2',
  records: 'M12 3l2.7 5.6 6.1.9-4.4 4.3 1 6.1L12 17l-5.4 2.9 1-6.1-4.4-4.3 6.1-.9z',
  news: 'M4 5h13v14H6a2 2 0 01-2-2zM17 9h3v8a2 2 0 01-2 2M8 9h5M8 13h5',
  content: 'M3 7l9-4 9 4-9 4zM3 7v10l9 4 9-4V7M12 11v10',
  settings: 'M12 15a3 3 0 100-6 3 3 0 000 6zM19.4 15a1.7 1.7 0 00.3 1.8l.1.1a2 2 0 11-2.8 2.8l-.1-.1a1.7 1.7 0 00-1.8-.3 1.7 1.7 0 00-1 1.5V21a2 2 0 01-4 0v-.1a1.7 1.7 0 00-1.1-1.5 1.7 1.7 0 00-1.8.3l-.1.1a2 2 0 11-2.8-2.8l.1-.1a1.7 1.7 0 00.3-1.8 1.7 1.7 0 00-1.5-1H3a2 2 0 010-4h.1a1.7 1.7 0 001.5-1.1 1.7 1.7 0 00-.3-1.8l-.1-.1a2 2 0 112.8-2.8l.1.1a1.7 1.7 0 001.8.3H9a1.7 1.7 0 001-1.5V3a2 2 0 014 0v.1a1.7 1.7 0 001 1.5 1.7 1.7 0 001.8-.3l.1-.1a2 2 0 112.8 2.8l-.1.1a1.7 1.7 0 00-.3 1.8V9a1.7 1.7 0 001.5 1H21a2 2 0 010 4h-.1a1.7 1.7 0 00-1.5 1z',
  diagnostics: 'M3 12h4l3-8 4 16 3-8h4',
  home: 'M4 4h6v6H4zM14 4h6v6h-6zM4 14h6v6H4zM14 14h6v6h-6z',
  play: 'M7 4l13 8-13 8z',
  plus: 'M12 5v14M5 12h14',
  user: 'M12 12a4 4 0 100-8 4 4 0 000 8zM4 21a8 8 0 0116 0',
  spark: 'M12 3v4M12 17v4M3 12h4M17 12h4M6 6l2.5 2.5M15.5 15.5L18 18M6 18l2.5-2.5M15.5 8.5L18 6',
  quiz: 'M9 9a3 3 0 115 2c-1 .7-2 1.3-2 3M12 18h.01M12 21a9 9 0 100-18 9 9 0 000 18z'
}

export function Icon({ name }: { name: string }) {
  return <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d={ICONS[name] ?? ICONS.hub} /></svg>
}

export const Help = ({ tip }: { tip: string }) => <span className="help" data-tip={tip}>?</span>

export function Field({ title, desc, children }: { title: ReactNode, desc?: ReactNode, children: ReactNode }) {
  return <div className="field field-r"><div><div className="field-t">{title}</div>{desc && <div className="field-d">{desc}</div>}</div><div>{children}</div></div>
}

export function Toggle({ checked, onChange, title, desc }: { checked: boolean, onChange: (v: boolean) => void, title: string, desc?: string }) {
  return <label className="toggle"><input type="checkbox" className="switch" checked={checked} onChange={e => onChange(e.target.checked)} /><div><b>{title}</b>{desc && <span>{desc}</span>}</div></label>
}

export function Seg({ options, value, onChange }: { options: [string, string][], value: string, onChange: (v: string) => void }) {
  return <div className="seg">{options.map(([v, l]) => <button key={v} type="button" className={v === value ? 'on' : ''} onClick={() => onChange(v)}>{l}</button>)}</div>
}

// ---------------------------------------------------------------------------------------------
// Traducciones de valores internos
// ---------------------------------------------------------------------------------------------
export const COUNTRY_ES: Record<string, string> = { AUS: 'Australia', CHN: 'China', JPN: 'Japón', USA: 'Estados Unidos', CAN: 'Canadá', MCO: 'Mónaco', ESP: 'España', AUT: 'Austria',
  GBR: 'Gran Bretaña', BEL: 'Bélgica', HUN: 'Hungría', NLD: 'Países Bajos', ITA: 'Italia', AZE: 'Azerbaiyán', MYS: 'Malasia', BHR: 'Baréin', SGP: 'Singapur', MEX: 'México',
  BRA: 'Brasil', QAT: 'Catar', ARE: 'Emiratos Árabes', SAU: 'Arabia Saudí', FRA: 'Francia', DEU: 'Alemania', FIN: 'Finlandia', DNK: 'Dinamarca', ARG: 'Argentina',
  NZL: 'Nueva Zelanda', CHE: 'Suiza', POL: 'Polonia', IND: 'India', THA: 'Tailandia', SWE: 'Suecia', NOR: 'Noruega', EST: 'Estonia', IRL: 'Irlanda', CZE: 'Chequia', COL: 'Colombia', PRT: 'Portugal' }
export const ARCH_ES: Record<string, string> = { balanced: 'Equilibrado', power: 'De potencia', high_downforce: 'De alta carga', street: 'Urbano', fast_flowing: 'Rápido y fluido', stop_start: 'Frenar y acelerar', tyre_limited: 'Duro con los neumáticos' }
export const ROLE_ES: Record<string, string> = { D1: 'Primer piloto', D2: 'Segundo piloto', D3: 'Tercer piloto', reserve: 'Reserva', junior: 'Junior' }
export const DNF_ES: Record<string, string> = { mechanical: 'avería', incident: 'accidente', DNS: 'no salió', DSQ: 'descalificado' }
export const STATUS_ES: Record<string, string> = { FIN: '', DNF: 'Abandono', DNS: 'No salió', DSQ: 'Descalificado' }

// ---------------------------------------------------------------------------------------------
// Tendencias y valoraciones (sin números internos)
// ---------------------------------------------------------------------------------------------
export function Trend({ v, small }: { v?: number | null, small?: boolean }) {
  const x = Number(v || 0)
  const [cls, ic, txt] = x > 1.2 ? ['pos', '▲▲', 'En racha'] : x > 0.35 ? ['pos', '▲', 'Al alza'] : x < -1.2 ? ['neg', '▼▼', 'En crisis'] : x < -0.35 ? ['neg', '▼', 'A la baja'] : ['muted', '●', 'Estable']
  return <span className={`trend ${cls}`}>{ic}{!small && <> {txt}</>}</span>
}
export const moraleLabel = (m?: number | null) => m == null ? '—' : m >= 78 ? 'Muy alta' : m >= 62 ? 'Buena' : m >= 45 ? 'Normal' : m >= 30 ? 'Baja' : 'Por los suelos'
export function Stars({ value, min = 60, max = 94 }: { value?: number | null, min?: number, max?: number }) {
  const n = Math.max(1, Math.min(5, Math.round(((Number(value || 0) - min) / (max - min)) * 4 + 1)))
  return <span className="stars" title="Potencial estimado por los ojeadores">{'★'.repeat(n)}<i>{'★'.repeat(5 - n)}</i></span>
}
export function Helmet({ color = '#888', size = 44 }: { color?: string, size?: number }) {
  return (
    <svg className="helmet" width={size} height={size} viewBox="0 0 64 64">
      <path d="M8 38c0-15 11-27 26-27 13 0 22 9 22 21v9c0 3-2 5-5 5H22l-6 6H11c-2 0-3-1-3-3z" fill={color} />
      <path d="M26 26h26c2 0 4 2 4 4v6H30c-3 0-5-2-5-5z" fill="#111827" opacity=".85" />
      <path d="M13 30c3-9 10-14 19-15" stroke="#fff" strokeWidth="3" strokeLinecap="round" fill="none" opacity=".55" />
      <path d="M16 46h36" stroke="#000" strokeWidth="2" opacity=".2" />
    </svg>
  )
}

// ---------------------------------------------------------------------------------------------
// Clima
// ---------------------------------------------------------------------------------------------
export const WEATHER_STATES: Record<string, string> = { clear: 'Despejado', few_clouds: 'Poco nuboso', scattered: 'Nubes y claros', broken: 'Nuboso', overcast: 'Cubierto',
  fog: 'Niebla', drizzle: 'Llovizna', light_rain: 'Lluvia débil', rain: 'Lluvia', heavy_rain: 'Lluvia fuerte', storm: 'Tormenta' }
const DROPS: Record<string, number> = { drizzle: 1, light_rain: 2, rain: 3, heavy_rain: 4, storm: 3 }
export function WeatherIcon({ state, night, size = 34 }: { state: string, night?: boolean, size?: number }) {
  const sun = night ? <path d="M30 8a13 13 0 1 0 14 17A11 11 0 0 1 30 8z" fill="#c7d2fe" /> : <g><circle cx="24" cy="22" r="10" fill="#fdb813" />{[0, 45, 90, 135, 180, 225, 270, 315].map(a => <line key={a} x1={24 + 13 * Math.cos(a * Math.PI / 180)} y1={22 + 13 * Math.sin(a * Math.PI / 180)} x2={24 + 18 * Math.cos(a * Math.PI / 180)} y2={22 + 18 * Math.sin(a * Math.PI / 180)} stroke="#fdb813" strokeWidth="3" strokeLinecap="round" />)}</g>
  const cloud = (dark: boolean, dy = 0) => <path d={`M18 ${46 + dy}h30a10 10 0 0 0 0-20 14 14 0 0 0-27-3 9 9 0 0 0-3 23z`} fill={dark ? '#8b98ae' : '#e3e9f3'} stroke={dark ? '#6b7890' : '#c5cfdd'} strokeWidth="1.5" />
  const drops = DROPS[state] ?? 0
  return (
    <svg className="wicon" width={size} height={size} viewBox="0 0 64 64">
      {['clear', 'few_clouds', 'scattered'].includes(state) && sun}
      {['few_clouds', 'scattered'].includes(state) && cloud(false, state === 'few_clouds' ? 6 : 2)}
      {['broken', 'overcast', 'drizzle', 'light_rain', 'rain', 'heavy_rain', 'storm'].includes(state) && cloud(state !== 'broken' && state !== 'drizzle', -6)}
      {state === 'fog' && [22, 32, 42, 52].map(y => <line key={y} x1="10" x2="54" y1={y} y2={y} stroke="#aab4c5" strokeWidth="4" strokeLinecap="round" />)}
      {Array.from({ length: drops }, (_, i) => <line key={i} x1={20 + i * 8} y1="46" x2={17 + i * 8} y2="56" stroke="#3b82f6" strokeWidth="3" strokeLinecap="round" />)}
      {state === 'storm' && <path d="M34 40l-7 11h6l-3 10 10-14h-6l4-7z" fill="#facc15" />}
    </svg>
  )
}
/** Weather report of a session: rain probability at the start, middle and end (a forecast, not what will surely happen). */
export function WeatherStrip({ f, compact }: { f: Any, compact?: boolean }) {
  if (!f?.parts) return null
  const main = [...f.parts].sort((a: Any, b: Any) => b.rain - a.rain)[0]
  return (
    <div className={`wstrip ${compact ? 'compact' : ''}`}>
      <div className="wmeta"><WeatherIcon state={main.rain >= 50 ? main.state : f.parts[0].state} night={f.night} size={compact ? 26 : 34} /><div><b>{f.night ? '🌙 ' : ''}{f.time}</b><span>≈{f.ambient}° · pista ≈{f.road}°</span></div></div>
      <div className="wline">{f.parts.map((p: Any) => (
        <div key={p.label} className={`wseg ${p.rain >= 60 ? 'w-rain' : p.rain >= 35 ? 'w-light_rain' : p.rain >= 15 ? 'w-drizzle' : `w-${p.state}`}`} title={`${p.label}: ${WEATHER_STATES[p.state] ?? p.state}, ${p.rain} % de probabilidad de lluvia`}>
          {!compact && <span className="wlab">{p.label}</span>}<WeatherIcon state={p.state} night={f.night} size={compact ? 18 : 22} /><span>💧{p.rain} %</span>
        </div>
      ))}</div>
    </div>
  )
}
