import { ReactNode } from 'react'
import { Any, api } from '../api'
import { Btn, Card, Err, Loading, useLoad } from '../ui'

const yn = (v: Any) => v ? <b className="pos">SÍ</b> : <b className="neg">NO</b>
const CM_STEPS = <ol><li>Abre <b>Content Manager</b> (gratis: assettocorsa.club/content-manager.html).</li><li>Ve a <b>Ajustes → Custom Shaders Patch</b>.</li><li>Pulsa <b>Instalar</b> (última versión) y reinicia Content Manager.</li></ol>

type Check = { state: 'ok' | 'bad' | 'warn' | 'opt', title: string, desc: ReactNode, fix?: ReactNode, action?: ReactNode }

function Row({ c }: { c: Check }) {
  return (
    <div className={`chk ${c.state}`}>
      <div className="st">{c.state === 'ok' ? '✓' : c.state === 'bad' ? '✕' : c.state === 'warn' ? '!' : '·'}</div>
      <div><b className="t">{c.title}</b><div className="d">{c.desc}</div>{c.state !== 'ok' && c.fix && <div className="fix">{c.fix}</div>}</div>
      <div>{c.state !== 'ok' && c.action}</div>
    </div>
  )
}

export default function Diagnostics() {
  const { data: d, error, loading, reload } = useLoad(() => api.get('/api/diagnostics'))
  const hub = useLoad(() => api.get('/api/career').catch(() => null))
  const setup = useLoad(() => api.get('/api/season/setup').catch(() => null))
  if (!d) return <div className="page"><h1>¿Listo para jugar?</h1><Loading loading={loading} /><Err error={error} /></div>
  const csp = d.ac.csp ?? {}
  const go = (href: string, label: string) => <a className="btn" href={href}>{label}</a>
  const checks: Check[] = [
    { state: d.ac.detected ? 'ok' : 'bad', title: 'Assetto Corsa encontrado', desc: d.ac.detected ? <span className="mono small">{d.ac.path}</span> : 'La aplicación necesita saber dónde está instalado Assetto Corsa.',
      fix: 'Ve a «Assetto Corsa» y pulsa «Detectar automáticamente» o pega la carpeta del juego (normalmente …\\steamapps\\common\\assettocorsa).', action: go('#/content', 'Configurar') },
    { state: d.content.cars > 0 && d.content.tracks > 0 ? 'ok' : 'bad', title: 'Coches y circuitos escaneados', desc: `${d.content.cars} coches · ${d.content.tracks} circuitos · ${d.content.layouts} trazados`,
      fix: 'Pulsa «Escanear contenido» para que la app vea tus coches y circuitos (también los de mods).', action: go('#/content', 'Escanear') },
    { state: csp.active ? 'ok' : 'bad', title: 'Custom Shaders Patch (CSP)', desc: csp.installed ? `Instalado ${csp.version ?? ''}${csp.build ? ` (build ${csp.build})` : ''}${csp.active ? '' : ' pero desactivado'}` : 'Mod gratuito que añade clima dinámico, lluvia y noche a Assetto Corsa. Obligatorio para jugar; para simular no hace falta.',
      fix: csp.installed ? 'Actívalo en Content Manager → Ajustes → Custom Shaders Patch (casilla «Activo»).' : CM_STEPS },
    { state: csp.weather ? 'ok' : 'bad', title: 'Weather FX activado', desc: 'Permite que el clima de cada sesión (sol, nubes, lluvia…) cambie durante la carrera.',
      fix: 'Content Manager → Ajustes → Custom Shaders Patch → Weather FX → activar.' },
    { state: csp.rain ? 'ok' : 'bad', title: 'Rain FX activado', desc: 'Lluvia real en pista: agua, charcos y menos agarre.',
      fix: 'Content Manager → Ajustes → Custom Shaders Patch → Rain FX → activar.' },
    { state: csp.night ? 'ok' : 'opt', title: 'Carreras nocturnas (recomendado)', desc: 'Singapur, Las Vegas, Catar y Abu Dabi se corren de noche. Sin esta función se usa la última hora con luz.',
      fix: 'Actualiza CSP a una versión reciente desde Content Manager.' },
    { state: d.ac.steam_running ? 'ok' : 'warn', title: 'Steam abierto', desc: 'Assetto Corsa solo arranca con Steam abierto. Basta con tenerlo abierto al pulsar JUGAR.', fix: 'Abre Steam antes de lanzar una sesión.' }
  ]
  if (hub.data) {
    const played = hub.data.championships.filter((c: Any) => c.player_mode === 'play')
    const noCar = played.filter((c: Any) => !c.ac_car_id)
    checks.push({ state: noCar.length ? 'bad' : 'ok', title: 'Coche asignado a tus categorías', desc: noCar.length ? `Sin coche de AC: ${noCar.map((c: Any) => c.category_code).join(', ')}` : played.map((c: Any) => `${c.category_code}: ${c.ac_car_id}`).join(' · ') || 'No juegas ninguna categoría (todo simulado).',
      fix: 'En «Assetto Corsa → Coches de la partida» elige qué coche de tu AC es el F1, el F2…', action: go('#/content', 'Asignar coche') })
    const rounds: Any[] = setup.data?.rounds ?? []
    const missing = rounds.filter(r => !r.ac_track_id && r.status !== 'completed')
    const next = hub.data.next_round
    checks.push({ state: next && !next.ac_track_id ? 'bad' : missing.length ? 'warn' : 'ok', title: 'Circuitos asignados en el calendario',
      desc: next && !next.ac_track_id ? `La próxima carrera (${next.event_name}) no tiene circuito de AC.` : missing.length ? `Faltan ${missing.length} rondas por asignar (no es urgente hasta que llegues a ellas).` : 'Todas las rondas tienen circuito.',
      fix: 'En «Calendario» pulsa «Asignar…» en cada ronda y elige el circuito de tu AC.', action: go('#/calendar', 'Ir al calendario') })
  }
  const required = checks.filter(c => c.state === 'bad')
  return (
    <div className="page">
      <h1>¿Listo para jugar?</h1>
      <p className="muted">Comprueba que todo está preparado para disputar sesiones en Assetto Corsa. Simular carreras funciona siempre, aunque falte algo de esta lista.</p>
      <div className={`ready ${required.length ? 'bad' : 'ok'}`}>
        <span className="big">{required.length ? '✕' : '✓'}</span>
        <div><b>{required.length ? `Falta${required.length > 1 ? 'n' : ''} ${required.length} paso${required.length > 1 ? 's' : ''} para poder jugar` : '¡Todo listo! Ya puedes jugar tus sesiones'}</b>
          <span>{required.length ? 'Sigue las indicaciones en rojo. Mientras tanto puedes simular.' : 'Ve a Fin de semana y pulsa ▶ JUGAR.'}</span></div>
        <div style={{ marginLeft: 'auto' }}><Btn onClick={() => { reload(); hub.reload(); setup.reload() }}>Volver a comprobar</Btn></div>
      </div>
      <div className="check-list">{checks.map(c => <Row key={c.title} c={c} />)}</div>
      <h4>Ahora mismo</h4>
      <div className="grid3">
        <div className="stat"><span className="stat-l">Assetto Corsa</span><span className="stat-v small">{d.ac.ac_running ? 'En ejecución' : 'Cerrado'}</span></div>
        <div className="stat"><span className="stat-l">Datos en vivo del juego</span><span className="stat-v small">{d.shared_memory.available ? `${d.shared_memory.track} · ${d.shared_memory.car_model}` : 'Sin conexión (AC cerrado)'}</span></div>
        <div className="stat"><span className="stat-l">Sesión lanzada</span><span className="stat-v small">{({ idle: 'Ninguna', running: 'En curso', importing: 'Importando resultado', finished: 'Terminada', failed: 'Error' } as Any)[d.launcher.status] ?? d.launcher.status}{d.launcher.context?.label ? ` · ${d.launcher.context.label}` : ''}</span></div>
      </div>
      <Card title="¿Algo no funciona?" desc="Descarga el informe de diagnóstico: un .zip con este informe, los registros (logs) de la app y los últimos race.ini, resultado y log de Assetto Corsa. No incluye tus partidas. Es lo que necesitas si quieres pedir ayuda.">
        <div className="actions" style={{ marginTop: 0 }}><a className="btn primary" href="/api/diagnostics/export">Descargar informe de diagnóstico</a></div>
        <details><summary>Detalles técnicos</summary>
          <table className="tbl compact"><tbody>
            <tr><td>Versión de la app</td><td>{d.app_version}</td></tr><tr><td>Python / sistema</td><td>{d.python} · {d.os}</td></tr>
            <tr><td>Carpeta de datos</td><td className="mono small">{d.data_dir}</td></tr><tr><td>Documentos de AC</td><td className="mono small">{d.ac.documents?.path} {d.ac.documents && yn(d.ac.documents.exists)}</td></tr>
            <tr><td>acs.exe</td><td>{yn(d.ac.validation?.checks?.acs_exe)}</td></tr><tr><td>Content Manager</td><td>{yn(d.ac.content_manager?.detected)}</td></tr>
            <tr><td>Partida / esquema</td><td>{d.career.loaded ?? '—'} / v{d.career.schema_version ?? '—'}</td></tr>
            {Object.entries(d.features).map(([k, v]) => <tr key={k}><td className="mono small">{k}</td><td className="small">{typeof v === 'boolean' ? yn(v) : String(v)}</td></tr>)}
          </tbody></table>
        </details>
      </Card>
    </div>
  )
}
