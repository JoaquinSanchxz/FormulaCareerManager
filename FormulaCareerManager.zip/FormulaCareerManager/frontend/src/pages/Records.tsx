import { useState } from 'react'
import { Any, api } from '../api'
import { Card, Err, Loading, Tabs, nav, useLoad } from '../ui'

const KINDS: [string, string][] = [['titles', 'Títulos'], ['wins', 'Victorias'], ['poles', 'Poles'], ['podiums', 'Podios'], ['fastest_laps', 'Vueltas rápidas'], ['starts', 'Salidas'], ['points', 'Puntos']]

export default function Records() {
  const { data, error, loading } = useLoad(() => api.get('/api/records'))
  const [cat, setCat] = useState('F1')
  const r = data?.[cat]
  return (
    <div className="page">
      <h1>Récords</h1>
      <Tabs tabs={Object.keys(data ?? {}).map(k => ({ id: k, label: k }))} value={cat} onChange={setCat} />
      <Loading loading={loading} /><Err error={error} />
      {r && (
        <>
          <Card title="Campeones">
            {r.champions.length === 0 ? <div className="muted">Aún no hay temporadas terminadas.</div> :
              <table className="tbl compact"><tbody>{r.champions.map((c: Any) => <tr key={c.year}><td>{c.year}</td><td><a className="link" onClick={() => nav(`/driver/${c.driver_id}`)}>{c.driver}</a></td><td>{c.points} pts</td><td className="muted">Constructores: {c.team}</td></tr>)}</tbody></table>}
          </Card>
          <div className="grid3">{KINDS.map(([k, l]) => (
            <Card key={k} title={l}>
              <table className="tbl compact"><tbody>{(r[k] ?? []).filter((x: Any) => x[k] > 0).map((x: Any, i: number) => <tr key={x.driver_id}><td>{i + 1}</td><td><a className="link" onClick={() => nav(`/driver/${x.driver_id}`)}>{x.first_name} {x.last_name}</a></td><td><b>{k === 'points' ? Math.round(x[k]) : x[k]}</b></td></tr>)}</tbody></table>
            </Card>
          ))}</div>
        </>
      )}
    </div>
  )
}
