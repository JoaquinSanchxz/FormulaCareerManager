import { useEffect, useState } from 'react'
import { Any, api } from '../api'
import { Btn, Card, Err, Help, Icon, Logo, Seg, nav, toast, useLoad } from '../ui'

export default function Home({ onCareerChange, menu }: { onCareerChange: () => void, menu?: boolean }) {
  const saves = useLoad(() => api.get('/api/saves'))
  const ac = useLoad(() => api.get('/api/ac/status'))
  const [creating, setCreating] = useState(false)
  useEffect(() => { if (saves.data?.saves.length === 0) setCreating(true) }, [saves.data])
  const open = async (id: string) => { await api.post(`/api/careers/${id}/open`); onCareerChange(); nav('/hub') }
  const del = async (id: string) => { if (!confirm(`¿Borrar la partida «${id}»? Se guardará una copia por si acaso.`)) return; await api.del(`/api/careers/${id}`); saves.reload() }
  const importFile = async (f?: File) => { if (!f) return; const r = await api.upload(`/api/careers/import?name=${encodeURIComponent(f.name)}`, f); toast(`Partida importada: ${r.id}`); saves.reload() }
  const list: Any[] = saves.data?.saves ?? []
  const saveCards = (
    <div className="saves">
      {list.map((s: Any) => (
        <div key={s.id} className="save" onClick={() => open(s.id)}>
          <h3>{s.name ?? s.id}</h3>
          <div className="meta"><span><b>{s.player ?? '—'}</b></span><span>Temporada <b>{s.season ?? '—'}</b></span></div>
          <div className="meta"><span>{s.next_round ? <>Próxima: <b>{s.next_round.replace(/^R\d+ /, '')}</b></> : 'Temporada completada'}</span></div>
          <div className="actions" onClick={e => e.stopPropagation()}><Btn kind="primary" onClick={() => open(s.id)}><Icon name="play" />Continuar</Btn><Btn kind="ghost danger" onClick={() => del(s.id)}>Borrar</Btn></div>
          <span className="save-date">{s.modified}</span>
        </div>
      ))}
    </div>
  )
  if (menu) return (
    <div className="menu-screen">
      <div className="menu-c">
        <div className="menu-brand"><Logo /><div><h1>Formula Career Manager</h1><p>Tu carrera en los monoplazas, en Assetto Corsa</p></div></div>
        {creating ? <div className="menu-card"><NewCareer onCancel={list.length ? () => setCreating(false) : undefined} onCreated={async id => { await open(id) }} /></div> : (
          <>
            <div className="menu-h"><h2>Elige tu partida</h2><Btn kind="primary" onClick={() => setCreating(true)}><Icon name="plus" />Nueva trayectoria</Btn></div>
            <Err error={saves.error} />
            {saveCards}
            <div className="menu-f">
              <label className="btn ghost">Importar partida<input type="file" accept=".fcm" hidden onChange={e => importFile(e.target.files?.[0])} /></label>
              <a className="btn ghost" href="#/content" onClick={onCareerChange}>Conectar Assetto Corsa</a>
            </div>
          </>
        )}
      </div>
    </div>
  )
  return (
    <div className="page">
      <h1>Partidas</h1>
      {ac.data && !ac.data.content.valid && <a className="alert warn" href="#/content" style={{ display: 'block' }}><b>Primer paso:</b> conecta la aplicación con tu Assetto Corsa. Mientras tanto puedes simular. →</a>}
      {creating ? <NewCareer onCancel={() => setCreating(false)} onCreated={async id => { await open(id) }} /> : (
        <Card title="Mis partidas" right={<><label className="btn ghost">Importar partida<input type="file" accept=".fcm" hidden onChange={e => importFile(e.target.files?.[0])} /></label> <Btn kind="primary" onClick={() => setCreating(true)}><Icon name="plus" />Nueva trayectoria</Btn></>}>
          <Err error={saves.error} />
          {saveCards}
        </Card>
      )}
    </div>
  )
}


const NATS = ['ESP', 'GBR', 'ITA', 'FRA', 'DEU', 'NLD', 'BRA', 'AUS', 'USA', 'MEX', 'JPN', 'CHN', 'FIN', 'DNK', 'CAN', 'ARG', 'BEL', 'NZL', 'MCO', 'CHE', 'AUT', 'POL', 'IND', 'THA']
export const RACE_LENGTHS: [string, string][] = [['laps5', '5 vueltas'], ['25', '25 %'], ['50', '50 %'], ['100', '100 % (real)']]

function NewCareer({ onCancel, onCreated }: { onCancel?: () => void, onCreated: (id: string) => Promise<void> }) {
  const tpl = useLoad(() => api.get('/api/templates/world'))
  const questions = useLoad(() => api.get('/api/personality/questions'))
  const [step, setStep] = useState<'mode' | 'existing' | 'new' | 'test'>('mode')
  const [f, setF] = useState<Any>({ name: 'Mi trayectoria', seed: '', categories: ['F1', 'F2', 'F3'], settings: { race_length: '25', session_length_pct: 50, practice_mode: 'skip' } })
  const [p, setP] = useState<Any>({ first_name: '', last_name: '', short_name: '', nationality: 'ESP', age: 19, rating: 72, potential: 88, category: 'F3', team_index: 0, slot: 0 })
  const [answers, setAnswers] = useState<Any>({})
  const [rec, setRec] = useState<Any>(null)
  const [error, setError] = useState<string | null>(null)
  const w = tpl.data
  const set = (k: string, v: Any) => setF((x: Any) => ({ ...x, [k]: v }))
  const setS = (k: string, v: Any) => setF((x: Any) => ({ ...x, settings: { ...x.settings, [k]: v } }))
  const upd = (k: string, v: Any) => setP((x: Any) => ({ ...x, [k]: v }))
  const teams = w?.categories?.[p.category]?.teams ?? []
  const team = teams[p.team_index]
  const create = async (player: Any) => {
    setError(null)
    const cats = Array.from(new Set([...f.categories, player.category]))
    const body = { ...f, categories: cats, seed: f.seed ? Number(f.seed) : undefined, settings: { ...f.settings, race_length: f.settings.race_length }, player }
    try { const r = await api.post('/api/careers', body); await onCreated(r.id) } catch (e: Any) { setError(e.message) }
  }
  const newPlayer = () => {
    if (!p.first_name || !p.last_name) return setError('Introduce nombre y apellido de tu piloto.')
    return create({ ...p, mode: 'new', age: Number(p.age), rating: Number(p.rating), potential: Number(p.potential), team_index: Number(p.team_index), slot: Number(p.slot) })
  }
  const runTest = async () => {
    const r = await api.post('/api/personality/evaluate', { answers, categories: ['F1', 'F2', 'F3'] })
    setRec(r)
    setP((x: Any) => ({ ...x, category: r.category, rating: r.rating, potential: r.potential, age: r.age, team_index: r.teams[0]?.team_index ?? 0, slot: 0,
      attribute_offsets: r.attribute_offsets, personality: r.personality, reputation: r.reputation }))
  }
  const common = (
    <>
      <h4>Partida</h4>
      <div className="grid3">
        <label>Nombre de la partida<input value={f.name} onChange={e => set('name', e.target.value)} /></label>
        <label>Duración de las carreras <Seg options={RACE_LENGTHS} value={f.settings.race_length} onChange={v => setS('race_length', v)} /></label>
        <label>Duración libres / clasificación (%) <input type="number" min={10} max={100} value={f.settings.session_length_pct} onChange={e => setS('session_length_pct', Number(e.target.value))} /></label>
      </div>
      <div className="row">
        <span className="muted small">Categorías del mundo <Help tip="Las categorías activas se simulan todas cada fin de semana. F2 y F3 alimentan a la F1 con ascensos de pilotos jóvenes." /></span>
        {['F1', 'F2', 'F3'].map(c => <label key={c} className="check"><input type="checkbox" disabled={c === 'F1'} checked={f.categories.includes(c)} onChange={e => set('categories', e.target.checked ? [...f.categories, c] : f.categories.filter((x: string) => x !== c))} /> {c}</label>)}
        <label>Semilla (opcional) <Help tip="Número que fija el azar de la partida. Con la misma semilla y las mismas decisiones, los resultados simulados se repiten. Déjalo vacío si no sabes qué es." /><input value={f.seed} placeholder="aleatoria" onChange={e => set('seed', e.target.value.replace(/\D/g, ''))} /></label>
      </div>
      <p className="muted small">100 % = regla F1: las vueltas mínimas que superan 305 km (Mónaco 260 km); F2 y F3 corren la mitad. Las categorías que no disputes se simulan.</p>
    </>
  )
  const seatPicker = (allowReplace: boolean) => (
    <div className="grid3">
      <label>Categoría<select value={p.category} onChange={e => { upd('category', e.target.value); upd('team_index', 0); upd('slot', 0) }}>{Object.keys(w?.categories ?? {}).map(c => <option key={c}>{c}</option>)}</select></label>
      <label>Equipo<select value={p.team_index} onChange={e => { upd('team_index', Number(e.target.value)); upd('slot', 0) }}>{teams.map((t: Any, i: number) => <option key={i} value={i}>{t.name} (coche {t.strength})</option>)}</select></label>
      <label>{allowReplace ? 'Sustituyes a' : 'Piloto'}<select value={p.slot} onChange={e => upd('slot', Number(e.target.value))}>
        {(team?.drivers ?? []).map((d: Any, i: number) => <option key={i} value={i}>{d.first_name} {d.last_name} · media {d.rating}</option>)}</select></label>
    </div>
  )
  return (
    <Card title="Nueva trayectoria" right={onCancel && <Btn kind="ghost" onClick={onCancel}>Cancelar</Btn>}>
      <Err error={error || tpl.error} />
      {step === 'mode' && (
        <div className="grid3">
          <div className="choice" onClick={() => setStep('existing')}><div className="ic"><Icon name="user" /></div><h3>Ser un piloto real</h3><p className="muted">Toma el control de cualquier piloto actual de F1, F2 o F3 con su equipo, contrato y valoración.</p></div>
          <div className="choice" onClick={() => setStep('new')}><div className="ic"><Icon name="plus" /></div><h3>Crear mi piloto</h3><p className="muted">Un piloto nuevo que entra en la parrilla: eliges tú el asiento que ocupa.</p></div>
          <div className="choice" onClick={() => setStep('test')}><div className="ic"><Icon name="quiz" /></div><h3>Crear mi piloto con test</h3><p className="muted">Responde un test de personalidad y trayectoria: te recomendamos categoría y escudería.</p></div>
        </div>
      )}
      {step === 'existing' && w && (
        <>
          <h4>Elige piloto</h4>
          {seatPicker(false)}
          {common}
          <div className="actions"><Btn kind="ghost" onClick={() => setStep('mode')}>Atrás</Btn><Btn kind="primary" onClick={() => create({ mode: 'existing', category: p.category, team_index: p.team_index, slot: p.slot })}>Empezar como {team?.drivers?.[p.slot]?.first_name} {team?.drivers?.[p.slot]?.last_name}</Btn></div>
        </>
      )}
      {step === 'test' && !rec && (
        <>
          <h4>Test de personalidad y trayectoria</h4>
          {(questions.data ?? []).map((q: Any) => (
            <div key={q.id} className="question"><b>{q.text}</b>
              <div className="row">{q.options.map((o: Any) => <label key={o.id} className="check"><input type="radio" name={q.id} checked={answers[q.id] === o.id} onChange={() => setAnswers({ ...answers, [q.id]: o.id })} /> {o.text}</label>)}</div>
            </div>
          ))}
          <div className="actions"><Btn kind="ghost" onClick={() => setStep('mode')}>Atrás</Btn><Btn kind="primary" disabled={Object.keys(answers).length < (questions.data?.length ?? 99)} onClick={runTest}>Ver mi perfil</Btn></div>
        </>
      )}
      {(step === 'new' || (step === 'test' && rec)) && w && (
        <>
          {rec && (
            <div className="alert ok">
              <b>Tu perfil:</b> encajas en <b>{rec.category}</b> · media inicial {rec.rating} · potencial {rec.potential} · estilo {rec.personality}.
              <div className="small">Equipos recomendados: {rec.teams.map((t: Any) => <a key={t.team_index} className="link" onClick={() => { upd('team_index', t.team_index); upd('slot', 0) }}>{t.name}</a>).reduce((a: Any, b: Any) => [a, ' · ', b])}</div>
            </div>
          )}
          <h4>Tu piloto</h4>
          <div className="grid4">
            <label>Nombre<input value={p.first_name} onChange={e => upd('first_name', e.target.value)} /></label>
            <label>Apellido<input value={p.last_name} onChange={e => upd('last_name', e.target.value)} /></label>
            <label>Abreviatura<input maxLength={3} value={p.short_name} placeholder="AUTO" onChange={e => upd('short_name', e.target.value.toUpperCase())} /></label>
            <label>Nacionalidad<select value={p.nationality} onChange={e => upd('nationality', e.target.value)}>{NATS.map(n => <option key={n}>{n}</option>)}</select></label>
            <label>Edad<input type="number" min={16} max={40} value={p.age} onChange={e => upd('age', e.target.value)} disabled={!!rec} /></label>
            <label>Media inicial<input type="number" min={50} max={90} value={p.rating} onChange={e => upd('rating', e.target.value)} disabled={!!rec} /></label>
            <label>Potencial<input type="number" min={50} max={99} value={p.potential} onChange={e => upd('potential', e.target.value)} disabled={!!rec} /></label>
          </div>
          <h4>Asiento</h4>
          {seatPicker(true)}
          {common}
          <div className="actions"><Btn kind="ghost" onClick={() => { setRec(null); setStep('mode') }}>Atrás</Btn><Btn kind="primary" onClick={newPlayer}>Crear trayectoria</Btn></div>
        </>
      )}
    </Card>
  )
}
