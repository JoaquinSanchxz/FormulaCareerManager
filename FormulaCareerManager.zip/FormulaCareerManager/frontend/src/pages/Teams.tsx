import { useState } from 'react'
import { Any, api } from '../api'
import { Bar, Btn, Card, Err, LineChart, Loading, Tabs, TeamDot, nav, toast, useLoad } from '../ui'
import { useChampionship } from './Standings'

const COMPS: [string, string][] = [['power', 'Potencia'], ['energy_recovery', 'Recuperación energía'], ['low_speed_downforce', 'Curvas lentas'], ['medium_speed_downforce', 'Curvas medias'],
  ['high_speed_downforce', 'Curvas rápidas'], ['drag_efficiency', 'Velocidad punta'], ['traction', 'Tracción'], ['mechanical_grip', 'Agarre mecánico'], ['braking', 'Frenada'],
  ['weight', 'Peso'], ['tyre_usage', 'Uso neumáticos'], ['cooling', 'Refrigeración'], ['reliability', 'Fiabilidad']]

export default function Teams() {
  const { chs, cur, setSel } = useChampionship()
  const data = useLoad(() => cur ? api.get(`/api/teams?championship_id=${cur}`) : Promise.resolve(null), [cur])
  const [open, setOpen] = useState<number | null>(null)
  const [edit, setEdit] = useState<Any>(null)
  const teams = data.data?.teams ?? []
  const t = teams.find((x: Any) => x.id === open) ?? teams[0]
  const saveCar = async () => { await api.patch(`/api/teams/${t.id}`, { car: Object.fromEntries(Object.entries(edit).map(([k, v]) => [k, Number(v)])) }); toast('Coche actualizado'); setEdit(null); data.reload() }
  return (
    <div className="page">
      <h1>Equipos y coches</h1>
      <Tabs tabs={(chs.data ?? []).map((c: Any) => ({ id: String(c.id), label: c.category_code }))} value={cur ?? ''} onChange={setSel} />
      <Loading loading={data.loading} /><Err error={data.error} />
      <div className="cols">
        <Card title="¿Quién tiene el mejor coche?" right={data.data?.next_round && <span className="muted small">Próxima carrera: {data.data.next_round.event_name}</span>}>
          <table className="tbl"><thead><tr><th>#</th><th>Equipo</th><th style={{ width: '32%' }}>Coche</th><th>En la próxima</th><th>Pilotos</th></tr></thead>
            <tbody>{teams.map((x: Any) => (
              <tr key={x.id} className={x.id === t?.id ? 'hl' : ''} onClick={() => { setOpen(x.id); setEdit(null) }} style={{ cursor: 'pointer' }}>
                <td>{x.overall_rank}</td><td><TeamDot color={x.color} /><b>{x.name}</b></td><td><Bar value={x.overall} min={78} max={100} color={x.color} /></td>
                <td>{x.next_track_rank ? `${x.next_track_rank}.º` : '—'}</td>
                <td className="small">{x.drivers.map((d: Any) => <a key={d.id} className="link" onClick={e => { e.stopPropagation(); nav(`/driver/${d.id}`) }}>{d.last_name} </a>)}</td>
              </tr>
            ))}</tbody>
          </table>
        </Card>
        {t && (
          <div>
            <Card title={<><TeamDot color={t.color} />{t.name}</>} right={edit ? <Btn kind="primary" onClick={saveCar}>Guardar</Btn> : <Btn kind="ghost" onClick={() => setEdit({ ...t.car })}>Editar coche</Btn>}>
              {COMPS.map(([k, l]) => (
                <div key={k} className="attr"><span>{l}</span>{edit ? <input type="number" step="0.1" value={edit[k]} onChange={e => setEdit({ ...edit, [k]: e.target.value })} /> : <Bar value={t.car[k]} min={70} max={100} color={t.color} />}</div>
              ))}
              <p className="muted small">Cada circuito premia cosas distintas: un coche fuerte en curvas lentas brillará en Mónaco; uno con mucha velocidad punta, en Monza.</p>
            </Card>
            <Card title="Evolución del coche">
              <LineChart series={[{ name: t.name, color: t.color || 'var(--accent)', points: t.history.map((h: Any, i: number) => ({ x: i, y: h.overall, label: `${h.year}${h.round_no ? ` · ronda ${h.round_no}` : ''}` })) }]} />
            </Card>
          </div>
        )}
      </div>
    </div>
  )
}
