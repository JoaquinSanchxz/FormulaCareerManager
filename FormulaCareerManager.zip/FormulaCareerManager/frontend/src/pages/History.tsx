import { Any, api } from '../api'
import { Card, Err, Loading, TeamDot, nav, useLoad } from '../ui'

export default function History() {
  const { data, error, loading } = useLoad(() => api.get('/api/history'))
  return (
    <div className="page">
      <h1>Histórico</h1>
      <Loading loading={loading} /><Err error={error} />
      {[...(data ?? [])].reverse().map((s: Any) => (
        <Card key={s.id} title={`Temporada ${s.year}`} right={<span className="tag">{s.status === 'finished' ? 'Finalizada' : 'En curso'}</span>}>
          <div className="row">
            {s.championships.map((c: Any) => (
              <div key={c.id} className="champ">
                <div className="eyebrow">{c.category_code}</div>
                {c.leader?.points ? <div><b>{s.status === 'finished' ? '🏆 ' : 'Líder: '}{c.leader.name}</b> · {c.leader.points} pts</div> : <div className="muted">Aún no ha empezado</div>}
                {c.constructor_leader?.points > 0 && <div className="muted small"><TeamDot color={c.constructor_leader.team_color} />{c.constructor_leader.team_name} · {c.constructor_leader.points} pts</div>}
              </div>
            ))}
          </div>
          <table className="tbl compact"><tbody>{s.rounds.map((r: Any) => (
            <tr key={r.id}><td className="muted">{r.round_no}</td><td><a className="link" onClick={() => nav(`/weekend/${r.id}`)}>{r.event_name}</a></td><td>{r.categories.join(' · ')}</td><td>{r.winner ? `🏆 ${r.winner}` : r.status === 'completed' ? '' : <span className="muted">Por disputar</span>}</td></tr>
          ))}</tbody></table>
        </Card>
      ))}
    </div>
  )
}
