import { useState } from 'react'
import { Any, api } from '../api'
import { ARCH_ES, Btn, COUNTRY_ES, Card, Err, Loading, nav, toast, useLoad } from '../ui'

const ARCH = ['balanced', 'power', 'high_downforce', 'street', 'fast_flowing', 'stop_start', 'tyre_limited']

export default function Calendar() {
  const cal = useLoad(() => api.get('/api/season/setup'))
  const tracks = useLoad(() => api.get('/api/content/tracks'))
  const [edit, setEdit] = useState<number | null>(null)
  const save = async (id: number, body: Any) => { await api.patch(`/api/rounds/${id}`, body); toast('Ronda actualizada'); cal.reload() }
  const layouts = (tracks.data ?? []).flatMap((t: Any) => t.layouts.map((l: Any) => ({ key: `${t.id}|${l.id}`, label: `${l.name || t.name}${l.id ? ` [${l.id}]` : ''} · ${t.id}${l.length_m ? ` · ${(l.length_m / 1000).toFixed(3)} km` : ''}${l.pitboxes ? ` · ${l.pitboxes} boxes` : ''}` })))
  const started = cal.data?.started
  const rounds = cal.data?.rounds ?? []
  return (
    <div className="page">
      <h1>Calendario {cal.data?.season?.year}</h1>
      <p className="muted">Elige para cada carrera qué circuito de tu Assetto Corsa se usa. El número de vueltas se calcula con la longitud real del circuito.</p>
      {!started && <div className="alert warn">Pretemporada: marca qué fines de semana tendrán <b>carrera sprint</b>. Cuando empiece la temporada ya no podrás cambiarlo. Sprints elegidos: <b>{rounds.filter((r: Any) => r.sprint).length}</b></div>}
      <Loading loading={cal.loading} /><Err error={cal.error} />
      {layouts.length === 0 && <div className="alert warn">Todavía no se han leído tus circuitos. Ve a <a href="#/content">Assetto Corsa</a> y pulsa «Escanear contenido».</div>}
      <Card>
        <div className="scroll-x">
          <table className="tbl compact">
            <thead><tr><th>#</th><th>Gran Premio</th><th>Sprint</th><th>Circuito en Assetto Corsa</th><th>Longitud (m)</th><th>Tipo de circuito</th><th /></tr></thead>
            <tbody>
              {rounds.map((r: Any) => (
                <tr key={r.id} className={r.status === 'completed' ? 'dim' : ''}>
                  <td className="muted">{r.round_no}</td>
                  <td className="cal-gp"><b>{r.event_name}</b>{r.summer_break_after ? <span className="tag">parón de verano</span> : null}
                    <div className="muted small">{[COUNTRY_ES[r.country] ?? r.country, r.date, r.start_time && `${r.night ? '🌙 ' : ''}${r.start_time}`].filter(Boolean).join(' · ')}</div>
                    <div>{r.categories.map((c: string) => <span key={c} className="tag cat">{c}</span>)}</div></td>
                  <td><input type="checkbox" disabled={started || !r.categories.includes('F1')} checked={!!r.sprint} onChange={e => save(r.id, { sprint: e.target.checked }).catch(err => toast(err.message, 'err'))} /></td>
                  <td>{edit === r.id ? (
                    <select autoFocus defaultValue={r.ac_track_id ? `${r.ac_track_id}|${r.ac_layout_id ?? ''}` : ''} onChange={e => { const [t, l] = e.target.value.split('|'); save(r.id, { ac_track_id: t || null, ac_layout_id: l || '' }); setEdit(null) }} onBlur={() => setEdit(null)}>
                      <option value="">— sin elegir —</option>{layouts.map((l: Any) => <option key={l.key} value={l.key}>{l.label}</option>)}
                    </select>
                  ) : <a onClick={() => setEdit(r.id)} className="link">{r.ac_track_id ? (r.ac_layout?.name ?? `${r.ac_track_id}${r.ac_layout_id ? '/' + r.ac_layout_id : ''}`) : <span className="warn-t">Elegir…</span>}</a>}</td>
                  <td className="small">
                    <input className="num cal-num" type="number" step="1" placeholder={r.official_length_m ? String(Math.round(r.official_length_m)) : 'm'} defaultValue={r.length_override_m ?? ''}
                      onBlur={e => { const v = e.target.value; if (String(r.length_override_m ?? '') !== v) save(r.id, { length_override_m: v ? Number(v) : null }) }} title="Déjalo vacío para usar la longitud real" />
                    <div className="muted">{r.official_length_m ? `real ${(r.official_length_m / 1000).toFixed(3)} km` : ''}{r.ac_layout?.length_m ? ` · en AC ${(r.ac_layout.length_m / 1000).toFixed(3)} km` : ''}</div>
                  </td>
                  <td><select className="cal-sel" value={r.archetype ?? 'balanced'} onChange={e => save(r.id, { archetype: e.target.value })}>{ARCH.map(a => <option key={a} value={a}>{ARCH_ES[a]}</option>)}</select></td>
                  <td className="right">{r.status === 'completed' ? <span className="small">🏆 {r.winner ?? ''} </span> : r.status === 'in_progress' ? <span className="chip next">En curso</span> : null} <Btn kind="ghost" onClick={() => nav(`/weekend/${r.id}`)}>Abrir</Btn></td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </Card>
    </div>
  )
}
