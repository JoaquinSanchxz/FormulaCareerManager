import { useState } from 'react'
import { Any, api } from '../api'
import { Err, Helmet, Tabs, useLoad } from '../ui'

const KIND: Record<string, [string, string]> = { carrera: ['🏁', 'Carrera'], clasificacion: ['⏱️', 'Clasificación'], campeonato: ['🏆', 'Campeonato'], hito: ['⭐', 'Hito'],
  mercado: ['🤝', 'Mercado'], tecnica: ['🔧', 'Técnica'], equipo: ['🏭', 'Equipos'], lesion: ['🚑', 'Parte médico'], temporada: ['📅', 'Temporada'], reglamento: ['📜', 'Reglamento'],
  jugador: ['✉️', 'Para ti'], general: ['📰', 'Actualidad'] }
const SECTIONS: [string, string, string[]][] = [['all', 'Todas', []], ['pista', 'En pista', ['carrera', 'clasificacion', 'hito', 'campeonato']], ['mercado', 'Mercado', ['mercado', 'jugador']],
  ['tecnica', 'Técnica y equipos', ['tecnica', 'equipo', 'reglamento', 'lesion']]]

export function NewsItem({ n, compact }: { n: Any, compact?: boolean }) {
  const [ic, label] = KIND[n.kind] ?? KIND.general
  return (
    <div className={`nitem ${compact ? 'compact' : ''}`} style={{ borderLeftColor: n.team_color || 'var(--line)' }}>
      <span className="nic">{ic}</span>
      <div>
        <div className="nkind">{label}{n.event_name ? ` · ${n.event_name}` : ''}</div>
        <b>{n.headline}</b>
        {n.body && !compact && <p>{n.body}</p>}
      </div>
    </div>
  )
}

export default function News() {
  const [tab, setTab] = useState('all')
  const news = useLoad(() => api.get('/api/news?limit=200'))
  const kinds = SECTIONS.find(s => s[0] === tab)?.[2] ?? []
  const list: Any[] = (news.data ?? []).filter((n: Any) => !kinds.length || kinds.includes(n.kind))
  const top = list.find(n => ['carrera', 'campeonato'].includes(n.kind)) ?? list[0]
  const rest = list.filter(n => n !== top)
  return (
    <div className="page">
      <h1>Noticias</h1>
      <Tabs tabs={SECTIONS.map(([id, label]) => ({ id, label }))} value={tab} onChange={setTab} />
      <Err error={news.error} />
      {!list.length && <div className="muted pad">Todavía no hay noticias.</div>}
      {top && (
        <div className="ntop" style={{ background: `linear-gradient(120deg, ${top.team_color || '#e8102e'}, #1f1650 75%)` }}>
          <div>
            <div className="nkind">{(KIND[top.kind] ?? KIND.general)[1]}{top.event_name ? ` · ${top.event_name}` : ''}</div>
            <h2>{top.headline}</h2>
            {top.body && <p>{top.body}</p>}
          </div>
          {top.driver_id ? <Helmet color={top.team_color} size={120} /> : <span className="ntop-ic">{(KIND[top.kind] ?? KIND.general)[0]}</span>}
        </div>
      )}
      <div className="ngrid">{rest.map(n => <NewsItem key={n.id} n={n} />)}</div>
    </div>
  )
}
