import { useEffect, useState } from 'react'
import { Any, api } from '../api'
import { Btn, Card, Err, Field, Help, Seg, Tabs, Toggle, toast, useLoad } from '../ui'

const REALISM: [string, string, string][] = [
  ['driver_progression', 'Progresión de pilotos', 'Los pilotos mejoran o empeoran poco a poco según edad, rendimiento y potencial.'],
  ['development', 'Desarrollo del coche', 'Los equipos investigan y fabrican mejoras durante la temporada.'],
  ['driver_market', 'Mercado de pilotos', 'Fichajes, renovaciones y cambios de equipo entre temporadas y en el parón de verano.'],
  ['contracts', 'Contratos', 'Salarios, duración, rol y cláusulas de los pilotos.'],
  ['generated_rookies', 'Nuevos pilotos', 'Cuando alguien se retira, entran pilotos jóvenes inventados en la categoría más baja.'],
  ['failures', 'Averías y desgaste', 'Motores y componentes se desgastan; puede haber averías y penalizaciones de parrilla.'],
  ['finances', 'Finanzas', 'Presupuesto, patrocinadores, premios y costes de cada equipo.'],
  ['regulation_changes', 'Cambios de reglamento', 'Cada cierto tiempo cambia el reglamento y los equipos deben adaptarse.'],
  ['academies', 'Academias', 'Los equipos de F1 tienen jóvenes promesas en F2/F3 con prioridad para subir.'],
  ['random_events', 'Eventos y decisiones', 'Situaciones del equipo en las que tendrás que elegir (problemas técnicos, patrocinio…).'],
  ['injuries', 'Lesiones', 'Tras accidentes graves un piloto puede perderse carreras (lo cubre el reserva).'],
  ['super_license', 'Superlicencia', 'Para subir a F1 hacen falta los puntos de superlicencia, como en la realidad.']]
const LEVELS: [string, string][] = [['easy', 'Fácil'], ['normal', 'Normal'], ['hard', 'Difícil']]
const CONFIGS: Record<string, string> = {
  ai_mapping: 'Cómo se traduce la media de cada piloto al nivel de la IA de Assetto Corsa (AI_LEVEL y agresividad). Es lo primero que conviene ajustar si la IA va demasiado rápida o lenta.',
  car_performance_mapping: 'Cómo se traduce el rendimiento de cada coche a lastre, restrictor y nivel de IA dentro de AC.',
  ac_session: 'Horarios, clima (estados, probabilidades de lluvia por clima) y opciones que se escriben en race.ini.',
  simulation: 'Motor de simulación: ritmo, neumáticos, lluvia, abandonos, safety car y estrategias.',
  progression: 'Velocidad de progresión de los pilotos, forma, moral y efecto de la edad.',
  categories: 'Formatos de fin de semana, distancias y parrillas de F1, F2 y F3.',
  points_systems: 'Puntos por posición de cada tipo de carrera.',
  market: 'Mercado de fichajes, valor de mercado, ofertas y traspasos de verano.',
  finance: 'Presupuestos, salarios, premios y costes.',
  development: 'I+D: coste, duración y ganancias de las mejoras.',
  components: 'Desgaste de motor y componentes, averías y penalizaciones.',
  regulations: 'Reglamentos y cambios programados.',
  events: 'Eventos del equipo y sus probabilidades.',
  car_model: 'Cómo se combinan los componentes del coche con el perfil de cada circuito.',
  track_archetypes: 'Perfiles de circuito (potencia, carga, tracción, adelantamientos…).',
  physics: 'Física avanzada experimental (modifica copias del coche). Desactivada por defecto.',
  app: 'Opciones internas de la aplicación.'
}

export default function Settings() {
  const health = useLoad(() => api.get('/api/health'))
  const [tab, setTab] = useState('career')
  const has = !!health.data?.career
  return (
    <div className="page">
      <h1>Ajustes</h1>
      <p className="muted">Todo lo que cambies aquí se aplica a partir de la próxima sesión. Pasa el ratón por los <Help tip="Así: cada ajuste tiene una explicación corta." /> para ver más detalles.</p>
      <Tabs tabs={[...(has ? [{ id: 'career', label: 'Mi partida' }, { id: 'saves', label: 'Guardados y copias' }] : []), { id: 'config', label: 'Avanzado' }]}
        value={has ? tab : 'config'} onChange={setTab} />
      {!has && <div className="alert info">Carga o crea una partida para ver sus ajustes. Aquí abajo solo está la configuración avanzada.</div>}
      {tab === 'career' && has && <CareerSettings />}
      {tab === 'saves' && has && <Saves career={health.data.career} />}
      {(tab === 'config' || !has) && <ConfigEditor />}
    </div>
  )
}

function CareerSettings() {
  const hub = useLoad(() => api.get('/api/career'))
  const [s, setS] = useState<Any>(null)
  const [dirty, setDirty] = useState(false)
  useEffect(() => { if (hub.data) setS(structuredClone(hub.data.career)) }, [hub.data])
  if (!s) return <Err error={hub.error} />
  const upd = (group: string, k: string, v: Any) => { setS({ ...s, [group]: { ...s[group], [k]: v } }); setDirty(true) }
  const save = async () => { await api.patch('/api/career/settings', { settings: s.settings, realism: s.realism, difficulty: s.difficulty }); setDirty(false); toast('Ajustes guardados') }
  const ai = Number(s.difficulty.driving_ai || 0)
  return (
    <>
      <Card title="Carreras y sesiones" desc="Cuánto duran las sesiones que juegas en Assetto Corsa. Las que se simulan usan la misma duración, y los puntos son siempre los reales.">
        <Field title="Duración de las carreras" desc="100 % = distancia real: las vueltas justas para superar 305 km en F1 (Mónaco 260 km) y la mitad en F2/F3. 5 vueltas es ideal para probar.">
          <Seg options={[['laps5', '5 vueltas'], ['25', '25 %'], ['50', '50 %'], ['100', '100 %']]} value={String(s.settings.race_length ?? s.settings.race_length_pct ?? 25)} onChange={v => upd('settings', 'race_length', v)} />
        </Field>
        <Field title={<>Duración de libres y clasificación <b className="pos">{s.settings.session_length_pct} %</b></>} desc="Porcentaje del tiempo real de cada sesión (por ejemplo, Q1 de 18 min al 50 % dura 9 min).">
          <input type="range" min={10} max={100} step={5} value={s.settings.session_length_pct} onChange={e => upd('settings', 'session_length_pct', Number(e.target.value))} style={{ width: '100%' }} />
        </Field>
        <Field title="Tus entrenamientos libres" desc="Los libres no dan puntos. Puedes saltarlos para ir directo a la clasificación o simularlos.">
          <Seg options={[['skip', 'Saltarlos'], ['simulate', 'Simularlos']]} value={s.settings.practice_mode} onChange={v => upd('settings', 'practice_mode', v)} />
        </Field>
      </Card>
      <Card title="Gestión del equipo">
        <Toggle checked={!!s.settings.delegate_team_management} onChange={v => upd('settings', 'delegate_team_management', v)} title="Solo quiero pilotar: el equipo se gestiona solo"
          desc="La IA del equipo decide I+D, fabricación e instalación de piezas, motores e instalaciones. Tú solo corres y negocias tus contratos." />
      </Card>
      <Card title="Dificultad" desc="Cada sistema tiene su propia dificultad, así puedes, por ejemplo, tener una IA rápida en pista con una economía sencilla.">
        <Field title={<>Trayectoria <Help tip="Afecta a cuánto te valoran los equipos al ofrecerte contratos y a lo exigentes que son tus objetivos." /></>} desc="Interés de los equipos por ti y exigencia de los objetivos.">
          <Seg options={LEVELS} value={s.difficulty.career} onChange={v => upd('difficulty', 'career', v)} />
        </Field>
        <Field title={<>Economía <Help tip="Fácil: +15 % de presupuesto para todos los equipos. Difícil: −15 %." /></>} desc="Presupuestos de los equipos.">
          <Seg options={LEVELS} value={s.difficulty.economy} onChange={v => upd('difficulty', 'economy', v)} />
        </Field>
        <Field title={<>Desarrollo <Help tip="Fácil: las mejoras dan un 15 % más de rendimiento. Difícil: un 15 % menos." /></>} desc="Cuánto rinden las mejoras que diseña tu equipo.">
          <Seg options={LEVELS} value={s.difficulty.development} onChange={v => upd('difficulty', 'development', v)} />
        </Field>
        <Field title={<>IA en pista: <b className={ai > 0 ? 'neg' : ai < 0 ? 'pos' : ''}>{ai > 0 ? `+${ai}` : ai}</b> <Help tip="Hace más rápidos o más lentos a todos los rivales dentro de Assetto Corsa. Si los rivales te sacan mucho tiempo, bájalo; si vas sobrado, súbelo." /></>}
          desc="Solo afecta a las sesiones que juegas en Assetto Corsa. 0 = calibración por defecto.">
          <input type="range" min={-10} max={10} step={0.5} value={ai} onChange={e => upd('difficulty', 'driving_ai', Number(e.target.value))} style={{ width: '100%' }} />
          <div className="muted small" style={{ display: 'flex', justifyContent: 'space-between' }}><span>Más fácil</span><span>Más difícil</span></div>
        </Field>
      </Card>
      <Card title="Realismo" desc="Activa o desactiva sistemas completos del mundo. Desactivar alguno simplifica la trayectoria.">
        <div className="grid2">{REALISM.map(([k, l, d]) => <Toggle key={k} checked={!!s.realism[k]} onChange={v => upd('realism', k, v)} title={l} desc={d} />)}</div>
      </Card>
      {dirty && <div className="savebar"><span>Tienes cambios sin guardar</span><div className="actions" style={{ margin: 0 }}><Btn kind="ghost" onClick={() => { setS(structuredClone(hub.data.career)); setDirty(false) }}>Descartar</Btn><Btn kind="primary" onClick={save}>Guardar cambios</Btn></div></div>}
    </>
  )
}

function Saves({ career }: { career: string }) {
  const auto = useLoad(() => api.get(`/api/autosaves?career=${career}`))
  const restore = async (file: string) => { if (!confirm(`¿Volver a este punto (${file})? El estado actual se guarda antes en una copia.`)) return; await api.post('/api/autosaves/restore', { file }); toast('Restaurado'); window.location.hash = '/hub' }
  return (
    <Card title="Guardados y copias" right={<><a className="btn" href="/api/careers/current/export">Exportar partida (.fcm)</a> <Btn onClick={async () => { await api.post('/api/careers/current/backup'); auto.reload(); toast('Copia creada') }}>Hacer copia ahora</Btn></>}
      desc="La partida se guarda sola: antes y después de cada sesión, al avanzar y antes de cerrar la temporada. Si algo sale mal puedes volver a cualquiera de estos puntos. «Exportar» crea un fichero para llevar la partida a otro PC.">
      {auto.data?.length === 0 && <div className="muted">Todavía no hay guardados automáticos.</div>}
      <table className="tbl compact"><thead><tr><th>Fecha</th><th>Momento</th><th>Fichero</th><th /></tr></thead>
        <tbody>{auto.data?.map((a: Any) => <tr key={a.file}><td>{a.modified}</td><td>{a.tag}</td><td className="mono small muted">{a.file}</td><td className="right"><Btn kind="ghost" onClick={() => restore(a.file)}>Volver a este punto</Btn></td></tr>)}</tbody></table>
    </Card>
  )
}

function ConfigEditor() {
  const cfg = useLoad(() => api.get('/api/config'))
  const [name, setName] = useState('ai_mapping')
  const [text, setText] = useState('')
  const [error, setError] = useState<string | null>(null)
  useEffect(() => { if (cfg.data?.[name]) setText(JSON.stringify(cfg.data[name], null, 2)) }, [cfg.data, name])
  const save = async () => {
    setError(null)
    try { await api.put(`/api/config/${name}`, JSON.parse(text)); toast('Guardado en tu carpeta de usuario'); cfg.reload() } catch (e: Any) { setError(e.message) }
  }
  return (
    <Card title="Configuración avanzada" right={<Btn kind="primary" onClick={save}>Guardar</Btn>}
      desc="Para usuarios avanzados. Todos los números del juego están en ficheros JSON editables. Tus cambios se guardan aparte (en tu carpeta de usuario) y nunca borran los valores originales.">
      <div className="alert info">Consejo: si la IA de Assetto Corsa va demasiado rápida o lenta, antes de tocar nada prueba el ajuste <b>IA en pista</b> de «Mi partida». Si no basta, ajusta <code>ai_mapping</code>.</div>
      <label>Fichero<select value={name} onChange={e => setName(e.target.value)}>{Object.keys(cfg.data ?? {}).map(n => <option key={n} value={n}>{n}</option>)}</select></label>
      {CONFIGS[name] && <p className="field-d">{CONFIGS[name]}</p>}
      <Err error={error || cfg.error} />
      <textarea className="code" rows={26} value={text} onChange={e => setText(e.target.value)} spellCheck={false} />
    </Card>
  )
}
