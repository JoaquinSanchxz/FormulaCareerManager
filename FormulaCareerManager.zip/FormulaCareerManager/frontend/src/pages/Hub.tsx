import { useState } from 'react'
import { Any, api } from '../api'
import { ARCH_ES, Btn, COUNTRY_ES, Card, Err, Helmet, Icon, Loading, Stat, TeamDot, Trend, WeatherStrip, moraleLabel, n2, nav, toast, useLoad } from '../ui'
import { NewsItem } from './News'
import { EventInfo } from './Weekend'

export default function Hub() {
  const { data: d, error, loading, reload } = useLoad(() => api.get('/api/career'))
  const [info, setInfo] = useState(false)
  if (!d) return <div className="page"><Loading loading={loading} /><Err error={error} /></div>
  const p = d.player
  const nr = d.next_round
  const race = nr?.sessions?.filter((s: Any) => s.code === 'R' && s.player_session)[0] ?? nr?.sessions?.find((s: Any) => s.code === 'R')
  const m = d.management
  const finish = async () => {
    if (!confirm('¿Cerrar la temporada? Los pilotos envejecen, hay retiradas y fichajes, y empieza la siguiente temporada.')) return
    const r = await api.post('/api/season/finish')
    toast(`Temporada ${r.finished} cerrada. ¡Bienvenido a ${r.new_season}!`)
    reload()
  }
  const alerts = m ? [
    m.pending_events > 0 && { href: '#/inbox', cls: 'warn', t: `Tienes ${m.pending_events === 1 ? 'una decisión pendiente' : `${m.pending_events} decisiones pendientes`} en el equipo` },
    m.open_offers > 0 && { href: '#/market', cls: 'ok', t: m.open_offers === 1 ? 'Un equipo te ha hecho una oferta' : `${m.open_offers} equipos te han hecho ofertas` },
    !m.delegated && m.projects === 0 && { href: '#/team', cls: 'warn', t: 'Tu equipo no está desarrollando ninguna mejora' },
    !m.delegated && m.parts_ready > 0 && { href: '#/team', cls: 'warn', t: 'Hay piezas nuevas listas para montar' },
    !m.delegated && m.worn > 0 && { href: '#/team', cls: 'warn', t: 'El motor está muy gastado' }].filter(Boolean) as Any[] : []
  return (
    <div className="page">
      <div className="hero" style={{ borderColor: d.entry?.team_color }}>
        <div className="who">
          <Helmet color={d.entry?.team_color} size={78} />
          <div>
            <div className="eyebrow">Temporada {d.season.year}</div>
            <h1>{p.first_name} {p.last_name}</h1>
            <div className="muted"><TeamDot color={d.entry?.team_color} />{d.entry ? `${d.entry.team_name} · ${d.entry.category_code} · #${d.entry.number}` : 'Sin asiento esta temporada'}</div>
          </div>
        </div>
        <div className="hero-stats">
          <Stat label="Mundial" value={d.standing ? `${d.standing.position}.º` : '—'} sub={d.standing ? `${d.standing.points} puntos` : ''} />
          <Stat label="Media" value={n2(p.base_rating, 0)} sub={<Trend v={p.form} />} />
          <Stat label="Moral" value={<span className="small">{moraleLabel(p.morale)}</span>} />
          <Stat label="Tu coche" value={d.car_rank ? `${d.car_rank.rank}.º` : '—'} sub={d.car_rank ? `de ${d.car_rank.of} equipos` : ''} />
          <Stat label="Constructores" value={d.team_standing ? `${d.team_standing.position}.º` : '—'} sub={d.team_standing ? `${d.team_standing.points} puntos` : ''} />
        </div>
      </div>
      {d.preseason && <a className="alert info" href="#/calendar" style={{ display: 'block' }}>Pretemporada: elige en el Calendario qué fines de semana tendrán carrera sprint.</a>}
      {alerts.length > 0 && <div className="grid3">{alerts.map(a => <a key={a.t} className={`alert ${a.cls}`} href={a.href}>{a.t} →</a>)}</div>}
      {info && nr && <EventInfo r={nr} onClose={() => setInfo(false)} />}
      <div className="cols">
        <div>
          {d.season_complete ? (
            <Card title="Temporada completada">
              <p>Se han disputado todas las carreras. Es hora de mirar al año que viene.</p>
              <Btn kind="primary" onClick={finish}>Pasar a {d.season.year + 1}</Btn>
            </Card>
          ) : nr && (
            <div className="next-race" onClick={() => nav(`/weekend/${nr.id}`)}>
              <div className="nr-top">
                <div>
                  <div className="eyebrow">Ronda {nr.round_no} · {nr.date}</div>
                  <h2>{nr.event_name}</h2>
                  <button className="ev-tag light" onClick={e => { e.stopPropagation(); setInfo(true) }}>ℹ Ficha del Gran Premio</button>
                  <div className="muted">{COUNTRY_ES[nr.country] ?? nr.country}{nr.circuit ? ` · ${nr.circuit}` : ''}{nr.sprint ? ' · fin de semana sprint' : ''}</div>
                </div>
                <div className="nr-badges">
                  {nr.car_rank_here && <div className="stat"><span className="stat-l">Tu coche aquí</span><span className="stat-v">{nr.car_rank_here}.º</span></div>}
                  <div className="stat"><span className="stat-l">Circuito</span><span className="stat-v small">{ARCH_ES[nr.archetype] ?? nr.archetype}</span></div>
                </div>
              </div>
              {race?.forecast && <div className="nr-w"><span className="muted small">Previsión del tiempo para la carrera</span><WeatherStrip f={race.forecast} /></div>}
              <div className="actions"><Btn kind="primary"><Icon name="play" />Ir al fin de semana</Btn>{!nr.ac_track_id && <span className="warn-t small">Falta elegir el circuito de Assetto Corsa en el Calendario</span>}</div>
            </div>
          )}
          <Card title="Tus últimos resultados">
            {d.recent.length === 0 ? <div className="muted">Todavía no has corrido ninguna carrera.</div> : (
              <div className="results-row">{d.recent.map((r: Any, i: number) => (
                <div key={i} className={`res ${r.status !== 'FIN' ? 'dnf' : r.position === 1 ? 'p1' : r.position <= 3 ? 'pod' : r.points ? 'pts' : ''}`}>
                  <b>{r.status === 'FIN' ? r.position : 'AB'}</b><span>{r.event_name.replace(/^Gran Premio (de (los |la )?|del )/, '')}</span><small>{r.session_name === 'Gran Premio' ? 'Carrera' : r.session_name.replace('Carrera sprint', 'Sprint')}{r.points ? ` · +${r.points}` : ''}</small>
                </div>
              ))}</div>
            )}
          </Card>
        </div>
        <Card title="Últimas noticias" right={<a className="link small" href="#/news">Ver todas</a>}>
          {d.news.map((n: Any) => <NewsItem key={n.id} n={n} compact />)}
        </Card>
      </div>
    </div>
  )
}

