import { useEffect, useState } from 'react'
import { Any, api } from '../api'
import { ARCH_ES, Btn, COUNTRY_ES, Err, Helmet, Icon, Loading, STATUS_ES, WeatherStrip, nav, toast, useLoad } from '../ui'

export const TYRE_COLOR: Record<string, string> = { S: '#ff3b30', M: '#ffd000', H: '#f0f0f0', I: '#3ec33e', W: '#2f7bff' }
export const TYRE_LETTER: Record<string, string> = { S: 'B', M: 'M', H: 'D', I: 'I', W: 'LL' }
const LIVE_ES: Record<string, string> = { off: 'Cargando', replay: 'Repetición', live: 'En pista', pause: 'En pausa' }
const SESSION_IC: Record<string, string> = { practice: '🛞', qualifying: '⏱️', sprint: '⚡', race: '🏁' }
const pos = (r: Any) => r.status === 'FIN' ? `${r.position}.º` : STATUS_ES[r.status] ?? r.status
const format = (s: Any) => {
  const f = s.format
  if (f.stages_min) { const p = s.code === 'SQ' ? 'SQ' : 'Q'; return `${p}1 ${f.stages_min[0]} min · ${p}2 ${f.stages_min[1]} min · ${p}3 ${f.stages_min[2]} min` }
  const base = f.laps ? `${f.laps} vueltas · ${Math.round(f.distance_km)} km` : `${f.duration_min} minutos`
  return base + (s.grid_rule?.reverse_top ? ` · parrilla invertida de los ${s.grid_rule.reverse_top} primeros` : '')
}

export default function Weekend({ roundId }: { roundId?: string }) {
  const hub = useLoad(() => roundId ? Promise.resolve(null) : api.get('/api/career'), [roundId])
  const rid = roundId ?? hub.data?.next_round?.id
  const rnd = useLoad(() => rid ? api.get(`/api/rounds/${rid}`) : Promise.resolve(null), [rid])
  const [preview, setPreview] = useState<Any>(null)
  const [strategy, setStrategy] = useState<number | null>(null)
  const [info, setInfo] = useState(false)
  const [live, setLive] = useState<Any>(null)
  useEffect(() => {
    const poll = () => api.get('/api/ac/status').then(s => {
      setLive((prev: Any) => {
        if (prev?.status === 'running' || prev?.status === 'importing') {
          if (s.launcher.status === 'finished') { toast('¡Sesión terminada! Resultado guardado.'); rnd.reload() }
          if (s.launcher.status === 'failed') { toast(s.launcher.error, 'err'); rnd.reload() }
        }
        return s.launcher
      })
    }).catch(() => {})
    poll()
    const t = setInterval(poll, 2000)
    return () => clearInterval(t)
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [rid])
  if (!roundId && hub.data && !hub.data.next_round) return <div className="page"><h1>Temporada completada</h1><p>Ciérrala desde <a className="link" href="#/hub">Inicio</a> para pasar al año siguiente.</p></div>
  const r = rnd.data
  if (!r) return <div className="page"><Loading loading={rnd.loading || hub.loading} /><Err error={rnd.error || hub.error} /></div>
  const act = async (s: Any, action: string) => {
    if (action === 'play') {
      await api.post(`/api/sessions/${s.id}/play`)
      toast('Assetto Corsa arrancando. Corre la sesión y sal al menú al terminar.')
      setPreview(null)
    } else {
      await api.post(`/api/sessions/${s.id}/${action}`)
      if (action === 'simulate') toast(`${s.name} (${s.category_code}) simulada`)
    }
    rnd.reload()
  }
  const advance = async () => {
    const res = await api.post('/api/weekend/advance', { stop_at_player: true })
    toast(res.stopped_at ? 'Todo al día: te toca a ti.' : `${res.simulated.length} sesiones simuladas.`)
    rnd.reload()
    if (!res.stopped_at) hub.reload()
  }
  const busy = live && ['running', 'importing'].includes(live.status)
  const byCat: Record<string, Any[]> = {}
  r.sessions.forEach((s: Any) => { (byCat[s.category_code] ||= []).push(s) })
  const img = r.ac_layout?.preview_url
  return (
    <div className="page">
      <div className="hero wk-hero" style={img ? { backgroundImage: `linear-gradient(100deg, rgba(17, 27, 61, .96) 35%, rgba(31, 22, 80, .55)), url(${img})` } : undefined}>
        <div>
          <div className="eyebrow">Ronda {r.round_no} · {r.date}</div>
          <h1>{r.event_name}</h1>
          <button className="ev-tag" onClick={() => setInfo(true)}>ℹ Ficha del Gran Premio</button>
          <div className="muted">{COUNTRY_ES[r.country] ?? r.country}{r.circuit ? ` · ${r.circuit}` : ''}</div>
          {!r.ac_track_id && <div className="warn-t small" style={{ marginTop: 6 }}>Aún no has elegido el circuito de Assetto Corsa · <a className="link" href="#/calendar">elegir</a></div>}
        </div>
        <div className="hero-stats">
          {r.ac_layout?.outline_url && <img className="outline" src={r.ac_layout.outline_url} alt="" />}
          {r.car_rank_here && <div className="stat"><div className="stat-l">Tu coche aquí</div><div className="stat-v">{r.car_rank_here}.º</div></div>}
          <div className="stat"><div className="stat-l">Circuito</div><div className="stat-v small">{ARCH_ES[r.archetype] ?? r.archetype}</div></div>
          <div className="stat"><div className="stat-l">Adelantar</div><div className="stat-v small">{r.overtaking_difficulty > 0.7 ? 'Muy difícil' : r.overtaking_difficulty > 0.45 ? 'Normal' : 'Fácil'}</div></div>
        </div>
      </div>
      {busy && (
        <div className="alert live-box">
          <b>🏎️ Estás en pista</b> — {live.context?.label}. Cuando termines, sal al menú o cierra Assetto Corsa y el resultado se guardará solo.
          {live.live?.available && <div className="small">{LIVE_ES[live.live.status] ?? live.live.status} · vuelta {live.live.completed_laps}{live.live.number_of_laps ? `/${live.live.number_of_laps}` : ''} · posición {live.live.position}</div>}
        </div>
      )}
      {live?.status === 'failed' && (
        <div className="alert err">
          {live.error}
          {live.context?.session_id && <div className="actions"><Btn onClick={async () => { await api.post(`/api/sessions/${live.context.session_id}/import-latest`); await api.post('/api/ac/reset'); toast('Resultado recuperado'); rnd.reload() }}>Recuperar el resultado</Btn> <Btn kind="ghost" onClick={async () => { await api.post('/api/ac/reset'); rnd.reload() }}>Descartar</Btn></div>}
        </div>
      )}
      {live?.status === 'finished' && live.summary && (
        <div className="alert ok">Sesión guardada: {live.context?.label}. <a className="link" href={`#/session/${live.context?.session_id}`}>Ver resultado</a> <Btn kind="ghost" onClick={async () => { await api.post('/api/ac/reset'); setLive(null) }}>Cerrar</Btn></div>
      )}
      <div className="actions"><Btn kind="primary" disabled={busy} onClick={advance}><Icon name="play" />Simular hasta mi próxima sesión</Btn></div>
      {Object.entries(byCat).map(([cat, list]) => (
        <div key={cat}>
          <h4>{cat}</h4>
          <div className="sessions-grid">
            {list.map(s => {
              const done = s.status === 'completed' || s.status === 'skipped'
              const mine = s.player_session
              return (
                <div key={s.id} className={`sess ${done ? 'done' : s.can_run ? 'now' : ''}`}>
                  <div className="sess-h">
                    <span className="sess-ic">{SESSION_IC[s.type]}</span>
                    <div><b>{s.name}</b><small>{format(s)}</small></div>
                    <span className={`chip ${done ? 'ok' : s.status === 'running' ? 'live' : s.can_run ? 'next' : ''}`}>
                      {({ pending: s.stage ? `${s.code === 'SQ' ? 'SQ' : 'Q'}${s.stage} hecha` : s.can_run ? 'Ahora' : 'Pendiente', running: 'En pista', completed: s.mode === 'played' ? 'Corrida' : 'Simulada', skipped: 'Saltada' } as Any)[s.status]}
                    </span>
                  </div>
                  {!done && s.forecast && <WeatherStrip f={s.forecast} compact />}
                  {done && (s.winner || s.player_result) && (
                    <div className="sess-res">
                      {s.winner && <span>{s.type === 'race' || s.type === 'sprint' ? '🏆' : '⏱️'} <b>{s.winner.first_name} {s.winner.last_name}</b></span>}
                      {s.player_result && <span className="you">Tú: <b>{pos(s.player_result)}</b>{s.player_result.points ? ` · +${s.player_result.points} pts` : ''}</span>}
                    </div>
                  )}
                  {s.strategy?.compounds && !done && <div className="small">Tu estrategia: {s.strategy.compounds.map((c: string, i: number) => <span key={i} className="tchip" style={{ background: TYRE_COLOR[c] }}>{TYRE_LETTER[c]}</span>)}</div>}
                  <div className="actions">
                    {s.status === 'pending' && s.can_run && mine && s.player_mode === 'play' && <Btn kind="primary play" disabled={busy} onClick={async () => setPreview(await api.get(`/api/sessions/${s.id}/preview`))}>▶ Jugar{s.format.stages_min ? ` ${s.code === 'SQ' ? 'SQ' : 'Q'}${s.format.stage}` : ''}</Btn>}
                    {['race', 'sprint'].includes(s.type) && s.status === 'pending' && mine && <Btn kind="ghost" disabled={busy} onClick={() => setStrategy(s.id)}>Estrategia</Btn>}
                    {s.status === 'pending' && s.can_run && <Btn disabled={busy} onClick={() => act(s, 'simulate')}>{s.stage ? 'Simular el resto' : 'Simular'}</Btn>}
                    {s.status === 'pending' && s.can_run && s.type === 'practice' && <Btn kind="ghost" disabled={busy} onClick={() => act(s, 'skip')}>Saltar</Btn>}
                    {s.status === 'running' && !busy && <Btn kind="ghost" onClick={async () => { await api.post(`/api/sessions/${s.id}/reset`); rnd.reload() }}>Desbloquear</Btn>}
                    {s.status === 'completed' && <Btn kind="ghost" onClick={() => nav(`/session/${s.id}`)}>Ver resultados</Btn>}
                  </div>
                </div>
              )
            })}
          </div>
        </div>
      ))}
      {preview && <Preview p={preview} onClose={() => setPreview(null)} onPlay={() => act(preview.session, 'play')} />}
      {strategy && <Strategy id={strategy} onClose={() => { setStrategy(null); rnd.reload() }} />}
      {info && <EventInfo r={r} onClose={() => setInfo(false)} />}
    </div>
  )
}

function Preview({ p, onClose, onPlay }: { p: Any, onClose: () => void, onPlay: () => Promise<void> }) {
  const warnings = p.warnings.filter((w: string) => !w.startsWith('Clima:'))
  return (
    <div className="modal" onClick={onClose}>
      <div className="modal-c" style={{ width: 'min(820px, 100%)' }} onClick={e => e.stopPropagation()}>
        <header className="card-h"><h3>{p.session.event_name} · {p.session.name}{p.stage_label ? ` · ${p.stage_label}` : ''}</h3><Btn kind="ghost" onClick={onClose}>✕</Btn></header>
        <div className="card-b">
          {p.errors.map((e: string) => <div key={e} className="alert err">{e}</div>)}
          {warnings.map((e: string) => <div key={e} className="alert warn">{e}</div>)}
          {p.forecast && <WeatherStrip f={{ ...p.forecast, time: p.conditions?.time_used ?? p.forecast.time }} />}
          <p className="muted">{p.format.laps ? `${p.format.laps} vueltas` : `${p.format.duration_min} minutos`} · {p.field.length} coches en pista
            {p.setup?.TYRES != null || p.setup?.FUEL ? ' · saldrás con los neumáticos y el combustible de tu estrategia' : ''}</p>
          <div className="grid-list">{p.field.map((f: Any) => (
            <div key={f.driver_id} className={`gl ${f.is_player ? 'me' : ''}`}><span className="gp">{f.grid_position ?? '—'}</span><Helmet color={f.team_color} size={26} /><div><b>{f.name}</b><small>{f.team_name}</small></div></div>
          ))}</div>
          <div className="actions">
            <Btn kind="primary play" disabled={p.errors.length > 0} onClick={onPlay}>▶ Salir a pista</Btn>
            <span className="muted small">Steam debe estar abierto.</span>
          </div>
        </div>
      </div>
    </div>
  )
}

function Strategy({ id, onClose }: { id: number, onClose: () => void }) {
  const { data: d, error } = useLoad(() => api.get(`/api/sessions/${id}/strategy`), [id])
  const [st, setSt] = useState<Any>(null)
  const [err, setErr] = useState<string | null>(null)
  const cur = st ?? d?.strategy ?? d?.suggestion
  if (!d) return <div className="modal"><div className="modal-c"><div className="card-b"><Err error={error} /></div></div></div>
  const laps = d.format.laps
  const setComp = (i: number, c: string) => setSt({ ...cur, compounds: cur.compounds.map((x: string, j: number) => j === i ? c : x) })
  const setPit = (i: number, v: number) => setSt({ ...cur, pit_laps: cur.pit_laps.map((x: number, j: number) => j === i ? v : x) })
  const addStop = () => { const n = cur.compounds.length + 1; setSt({ ...cur, compounds: [...cur.compounds, 'H'], pit_laps: Array.from({ length: n - 1 }, (_, k) => Math.round(laps * (k + 1) / n)) }) }
  const delStop = () => { if (cur.compounds.length > 1) setSt({ ...cur, compounds: cur.compounds.slice(0, -1), pit_laps: cur.pit_laps.slice(0, -1) }) }
  const save = async () => { setErr(null); try { await api.put(`/api/sessions/${id}/strategy`, cur); toast('Estrategia guardada'); onClose() } catch (e: Any) { setErr(e.message) } }
  const stints = cur.compounds.map((c: string, i: number) => { const a = i === 0 ? 0 : cur.pit_laps[i - 1]; const b = i < cur.pit_laps.length ? cur.pit_laps[i] : laps; return { c, laps: b - a } })
  return (
    <div className="modal" onClick={onClose}>
      <div className="modal-c" style={{ width: 'min(760px, 100%)' }} onClick={e => e.stopPropagation()}>
        <header className="card-h"><h3>Estrategia · {d.session.name}</h3><Btn kind="ghost" onClick={onClose}>✕</Btn></header>
        <div className="card-b">
          <WeatherStrip f={d.forecast} />
          <p className="muted small">{laps} vueltas. Es una previsión: el tiempo real puede cambiar.{d.two_compounds_required && ' En seco tienes que usar al menos dos compuestos distintos.'}</p>
          <div className="stints">{stints.map((x: Any, i: number) => <div key={i} style={{ flex: Math.max(1, x.laps), background: TYRE_COLOR[x.c] }} title={`${d.tyres[x.c]?.name} · ${x.laps} vueltas`}>{TYRE_LETTER[x.c]} · {x.laps}</div>)}</div>
          <table className="tbl compact"><tbody>{cur.compounds.map((c: string, i: number) => (
            <tr key={i}><td>Tramo {i + 1}</td>
              <td>{(['S', 'M', 'H', 'I', 'W'] as string[]).map(k => <button key={k} className={`tyre ${c === k ? 'on' : ''}`} style={{ borderColor: k === 'H' ? '#9aa4b5' : TYRE_COLOR[k] }} onClick={() => setComp(i, k)}>{d.tyres[k].name}</button>)}</td>
              <td>{i < cur.pit_laps.length && <label>Parar en la vuelta<input type="number" min={1} max={laps - 1} value={cur.pit_laps[i]} onChange={e => setPit(i, Number(e.target.value))} /></label>}</td></tr>
          ))}</tbody></table>
          <div className="actions"><Btn kind="ghost" onClick={addStop}>+ Parada</Btn><Btn kind="ghost" onClick={delStop}>− Parada</Btn><Btn kind="ghost" onClick={() => setSt(d.suggestion)}>La que recomienda el equipo</Btn></div>
          <label>Combustible al salir (litros, opcional){d.car_fuel?.max ? ` · depósito de ${d.car_fuel.max} L` : ''}<input type="number" min={0} value={cur.fuel_liters ?? ''} placeholder="el del reglaje" onChange={e => setSt({ ...cur, fuel_liters: e.target.value ? Number(e.target.value) : null })} /></label>
          <p className="muted small">Blando: más rápido pero dura menos. Duro: más lento pero aguanta. Intermedio para pista húmeda y lluvia extrema para mucha agua. Si cambia el tiempo, el equipo te llamará a boxes.</p>
          <Err error={err} />
          <div className="actions"><Btn kind="primary" onClick={save}>Guardar estrategia</Btn></div>
        </div>
      </div>
    </div>
  )
}

const TRAITS: [string, string][] = [['power_importance', 'Potencia del motor'], ['high_speed_importance', 'Curvas rápidas'], ['medium_speed_importance', 'Curvas medias'],
  ['low_speed_importance', 'Curvas lentas'], ['traction_importance', 'Tracción'], ['braking_importance', 'Frenadas'], ['tyre_importance', 'Desgaste de neumáticos'], ['overtaking_difficulty', 'Dificultad para adelantar']]

/** Ficha del Gran Premio: circuito, formato, previsión por sesión, lo que exige al coche e historial en la partida. */
export function EventInfo({ r, onClose }: { r: Any, onClose: () => void }) {
  const race = r.sessions.find((s: Any) => s.type === 'race' && s.player_session) ?? r.sessions.find((s: Any) => s.type === 'race')
  const mine = r.sessions.filter((s: Any) => s.player_session)
  const img = r.ac_layout?.preview_url
  return (
    <div className="modal" onClick={onClose}>
      <div className="modal-c ev" style={{ width: 'min(920px, 100%)' }} onClick={e => e.stopPropagation()}>
        <div className="ev-top" style={img ? { backgroundImage: `linear-gradient(100deg, rgba(17, 27, 61, .95) 40%, rgba(31, 22, 80, .5)), url(${img})` } : undefined}>
          <div>
            <div className="eyebrow">Ronda {r.round_no} · {r.date}{r.sprint ? ' · fin de semana sprint' : ''}{r.night ? ' · carrera nocturna' : ''}</div>
            <h2>{r.event_name}</h2>
            <div className="muted">{COUNTRY_ES[r.country] ?? r.country}{r.circuit ? ` · ${r.circuit}` : ''}</div>
          </div>
          {r.ac_layout?.outline_url && <img className="outline" src={r.ac_layout.outline_url} alt="" />}
          <Btn kind="ghost" onClick={onClose}>✕</Btn>
        </div>
        <div className="card-b">
          <div className="ev-stats">
            <div className="stat"><span className="stat-l">Longitud</span><span className="stat-v small">{r.official_length_m ? `${(r.official_length_m / 1000).toFixed(3).replace('.', ',')} km` : '—'}</span></div>
            {race && <div className="stat"><span className="stat-l">Carrera</span><span className="stat-v small">{race.format.laps} vueltas · {Math.round(race.format.distance_km)} km</span></div>}
            <div className="stat"><span className="stat-l">Salida</span><span className="stat-v small">{r.start_time ?? '—'} (hora local)</span></div>
            <div className="stat"><span className="stat-l">Tipo</span><span className="stat-v small">{ARCH_ES[r.archetype] ?? r.archetype}</span></div>
            {r.car_rank_here && <div className="stat"><span className="stat-l">Tu coche aquí</span><span className="stat-v small">{r.car_rank_here}.º de {r.car_rank_of}</span></div>}
            <div className="stat"><span className="stat-l">Tu mejor resultado</span><span className="stat-v small">{r.player_best ? `${r.player_best}.º` : 'Primera vez'}</span></div>
          </div>
          <div className="cols">
            <div>
              <h4>Qué exige el circuito</h4>
              {TRAITS.map(([k, l]) => <div key={k} className="attr"><span>{l}</span><div className="bar"><div style={{ width: `${Math.round((r[k] ?? 0.5) * 100)}%` }} /></div></div>)}
            </div>
            <div>
              <h4>Previsión del tiempo</h4>
              <div className="ev-fc">{mine.filter((s: Any) => s.forecast).map((s: Any) => <div key={s.id}><b>{s.name}</b><WeatherStrip f={s.forecast} compact /></div>)}
                {!mine.some((s: Any) => s.forecast) && <div className="muted">Sesiones ya disputadas.</div>}</div>
              <h4>Ganadores en tu trayectoria</h4>
              {r.history?.length ? r.history.map((h: Any, i: number) => <div key={i} className="who ev-h"><Helmet color={h.team_color} size={26} /><div><b>{h.winner}</b><small>{h.date.slice(0, 4)} · {h.team}</small></div></div>)
                : <div className="muted small">Aún no se ha corrido aquí en esta partida.</div>}
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}
