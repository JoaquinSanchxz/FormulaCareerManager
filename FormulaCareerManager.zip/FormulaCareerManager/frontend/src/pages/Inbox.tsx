import { Any, api } from '../api'
import { Btn, Card, Err, Loading, toast, useLoad } from '../ui'

const TYPE_ES: Record<string, string> = { technical: '🔧 Técnica', financial: '💶 Finanzas', driver: '🧑 Piloto', team: '🏭 Equipo', contract: '📝 Contrato', regulatory: '📜 Reglamento', sponsor: '🤝 Patrocinio', facility: '🏗️ Instalaciones', random_world: '🌍 Actualidad' }

export default function Inbox() {
  const { data, error, loading, reload } = useLoad(() => api.get('/api/inbox'))
  const pending = (data ?? []).filter((e: Any) => e.status === 'pending')
  const past = (data ?? []).filter((e: Any) => e.status !== 'pending')
  const choose = async (id: number, choice: number) => { await api.post(`/api/game-events/${id}/resolve`, { choice }); toast('Decisión aplicada'); reload() }
  return (
    <div className="page">
      <h1>Decisiones del equipo</h1>
      <p className="muted">Situaciones en las que el equipo necesita tu opinión. Si no decides antes de la próxima carrera, decidirán ellos.</p>
      <Loading loading={loading} /><Err error={error} />
      {pending.length === 0 && <div className="muted pad">Todo en orden: no hay nada que decidir ahora mismo.</div>}
      {pending.map((e: Any) => (
        <Card key={e.id} title={e.title} right={<span className="tag">{TYPE_ES[e.type] ?? e.type}</span>}>
          <p>{e.body}</p>
          <div className="actions">{e.choices.map((c: Any, i: number) => <Btn key={i} kind={i === 0 ? 'primary' : ''} onClick={() => choose(e.id, i)}>{c.label}</Btn>)}</div>
        </Card>
      ))}
      {past.length > 0 && (
        <Card title="Decisiones anteriores">
          <table className="tbl compact"><tbody>{past.map((e: Any) => <tr key={e.id}><td className="muted">Ronda {e.round_no}</td><td><b>{e.title}</b></td>
            <td className="small">{e.choices[e.choice]?.label}{e.status === 'auto' ? ' (lo decidió el equipo)' : ''}</td></tr>)}</tbody></table>
        </Card>
      )}
    </div>
  )
}
