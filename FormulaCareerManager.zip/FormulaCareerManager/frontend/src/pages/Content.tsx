import { useState } from 'react'
import { Any, api, imgUrl } from '../api'
import { Btn, Card, Err, Tabs, TeamDot, toast, useLoad } from '../ui'

export default function Content() {
  const st = useLoad(() => api.get('/api/ac/status'))
  const health = useLoad(() => api.get('/api/health'))
  const [path, setPath] = useState('')
  const [tab, setTab] = useState('mapping')
  const [q, setQ] = useState('')
  const cars = useLoad(() => api.get(`/api/content/cars${q ? `?q=${encodeURIComponent(q)}` : ''}`), [q])
  const tracks = useLoad(() => api.get(`/api/content/tracks${q ? `?q=${encodeURIComponent(q)}` : ''}`), [q])
  const c = st.data?.content
  const root = c?.ac_root
  const detect = async () => { const r = await api.post('/api/ac/detect'); toast(r.found ? `Detectado: ${r.path}` : 'No encontrado automáticamente. Indica la carpeta manualmente.', r.found ? 'ok' : 'err'); st.reload() }
  const setRoot = async () => { await api.post('/api/ac/path', { path }); toast('Ruta guardada'); st.reload() }
  const scan = async () => { const r = await api.post('/api/ac/scan'); toast(`Escaneado: ${r.last_scan.cars} coches, ${r.last_scan.tracks} circuitos`); st.reload(); cars.reload(); tracks.reload() }
  const chs = useLoad(() => health.data?.career ? api.get('/api/championships') : Promise.resolve(null), [health.data?.career])
  const setup = useLoad(() => health.data?.career ? api.get('/api/season/setup') : Promise.resolve(null), [health.data?.career])
  const carsOk = !!chs.data?.length && chs.data.filter((x: Any) => x.player_mode === 'play').every((x: Any) => x.ac_car_id)
  const tracksLeft = (setup.data?.rounds ?? []).filter((r: Any) => !r.ac_track_id).length
  const steps = [
    { done: !!c?.valid, t: 'Localiza Assetto Corsa', d: c?.valid ? 'Carpeta encontrada' : 'Detecta o pega la carpeta' },
    { done: !!c?.last_scan?.cars, t: 'Escanea tu contenido', d: c?.last_scan ? `${c.last_scan.cars} coches · ${c.last_scan.tracks} circuitos` : 'Busca coches y circuitos' },
    { done: carsOk, t: 'Elige el coche de cada categoría', d: health.data?.career ? (carsOk ? 'Coches asignados' : 'Pestaña «Coches de la partida»') : 'Necesita una partida' },
    { done: !!setup.data && tracksLeft === 0, t: 'Asigna los circuitos', d: health.data?.career ? (tracksLeft ? <a className="link" href="#/calendar">{tracksLeft} rondas en el Calendario</a> : 'Calendario completo') : 'Necesita una partida' }]
  const firstTodo = steps.findIndex(x => !x.done)
  return (
    <div className="page">
      <h1>Assetto Corsa</h1>
      <p className="muted">Conecta la aplicación con tu Assetto Corsa en cuatro pasos. No se modifica ningún fichero de tus coches ni circuitos: solo se leen.</p>
      <div className="steps">{steps.map((x, i) => <div key={i} className={`step ${x.done ? 'done' : i === firstTodo ? 'todo' : ''}`}><span className="n">{x.done ? '✓' : i + 1}</span><div><b>{x.t}</b><span>{x.d}</span></div></div>)}</div>
      <Card title="1 · 2  Instalación y escaneo" desc="Pulsa «Detectar automáticamente»: la app busca en Steam y sus bibliotecas. Si no la encuentra, pega la ruta de la carpeta del juego (la que contiene acs.exe) y pulsa «Usar esta carpeta». Después, «Escanear contenido» lee tus coches y circuitos, incluidos los mods. Vuelve a escanear cuando instales contenido nuevo.">
        <Err error={st.error} />
        {c && (c.valid ? <div className="alert ok">Assetto Corsa detectado en <b>{root}</b></div> : <div className="alert warn">No configurado{c.validation ? `: faltan ${c.validation.missing.join(', ')}` : ''}.</div>)}
        <div className="row">
          <Btn onClick={detect}>Detectar automáticamente</Btn>
          <input className="grow" placeholder="C:\Program Files (x86)\Steam\steamapps\common\assettocorsa" value={path} onChange={e => setPath(e.target.value)} />
          <Btn onClick={setRoot} disabled={!path}>Usar esta carpeta</Btn>
          <Btn kind="primary" onClick={scan} disabled={!c?.valid}>Escanear contenido</Btn>
        </div>
        {c?.last_scan && <div className="muted small">Último escaneo {c.last_scan.create_ts}: {c.last_scan.cars} coches · {c.last_scan.tracks} circuitos · {c.last_scan.layouts} layouts · {c.last_scan.duration_ms} ms{c.last_scan.warnings.length ? ` · ${c.last_scan.warnings.length} avisos` : ''}</div>}
        {c?.last_scan?.warnings.length > 0 && <details><summary className="small">Ver avisos</summary><ul className="small">{c.last_scan.warnings.map((w: string) => <li key={w}>{w}</li>)}</ul></details>}
      </Card>
      <Tabs tabs={[...(health.data?.career ? [{ id: 'mapping', label: '3 · Coches de la partida' }] : []), { id: 'cars', label: `Mis coches (${cars.data?.length ?? 0})` }, { id: 'tracks', label: `Mis circuitos (${tracks.data?.length ?? 0})` }]} value={health.data?.career ? tab : (tab === 'mapping' ? 'cars' : tab)} onChange={setTab} />
      {(tab === 'cars' || tab === 'tracks') && <input className="search" placeholder="Buscar…" value={q} onChange={e => setQ(e.target.value)} />}
      {tab === 'mapping' && health.data?.career && <><Mapping cars={cars.data ?? []} root={root} /><Physics /></>}
      {tab === 'cars' && (
        <Card>
          <table className="tbl compact"><thead><tr><th /><th>Coche</th><th>Carpeta</th><th>Año</th><th>Clase</th><th>Skins</th><th>Física</th><th>Tags</th></tr></thead>
            <tbody>{cars.data?.map((x: Any) => (
              <tr key={x.id}><td>{x.preview_path && <img className="thumb" src={imgUrl(x.preview_path, root)} loading="lazy" onError={e => { e.currentTarget.style.display = 'none' }} />}</td><td><b>{x.name}</b><div className="muted small">{x.brand}</div></td><td className="mono small">{x.id}</td><td>{x.year ?? ''}</td><td>{x.class ?? ''}</td>
                <td>{x.skin_count}</td><td>{x.has_data_acd ? 'data.acd' : x.has_data_folder ? 'data/' : <span className="warn-t">falta</span>}</td><td className="small">{x.tags.slice(0, 5).join(', ')}</td></tr>
            ))}</tbody></table>
        </Card>
      )}
      {tab === 'tracks' && (
        <Card>
          <table className="tbl compact"><thead><tr><th /><th>Circuito</th><th>Carpeta</th><th>Layout</th><th>País</th><th>Longitud</th><th>Boxes</th><th>Datos</th></tr></thead>
            <tbody>{tracks.data?.flatMap((t: Any) => t.layouts.map((l: Any) => (
              <tr key={t.id + l.id}><td>{l.preview_path && <img className="thumb" src={imgUrl(l.preview_path, root)} loading="lazy" onError={e => { e.currentTarget.style.display = 'none' }} />}</td><td><b>{l.name || t.name}</b></td><td className="mono small">{t.id}</td><td className="mono small">{l.id || '(único)'}</td><td>{l.country ?? ''}</td>
                <td>{l.length_m ? `${(l.length_m / 1000).toFixed(3)} km` : '—'}</td><td>{l.pitboxes ?? '—'}</td><td>{l.has_data ? '✓' : <span className="warn-t">no</span>}</td></tr>
            )))}</tbody></table>
        </Card>
      )}
    </div>
  )
}

function Mapping({ cars, root }: { cars: Any[], root?: string }) {
  const chs = useLoad(() => api.get('/api/championships'))
  const [sel, setSel] = useState<number | null>(null)
  const ch = chs.data?.find((x: Any) => x.id === sel) ?? chs.data?.[0]
  const entries = useLoad(() => ch ? api.get(`/api/drivers?championship_id=${ch.id}`) : Promise.resolve([]), [ch?.id])
  const car = useLoad(() => ch?.ac_car_id ? api.get(`/api/content/cars/${ch.ac_car_id}`) : Promise.resolve(null), [ch?.ac_car_id])
  const assign = async (car_id: string) => {
    if (car_id && !confirm(`¿Asignar "${car_id}" a ${ch.category_code}? Se repartirán skins por equipo (podrás cambiarlas).`)) return
    await api.patch(`/api/championships/${ch.id}`, { ac_car_id: car_id || null })
    toast('Coche asignado'); chs.reload(); entries.reload()
  }
  const setSkin = async (entry_id: number, skin: string) => { await api.patch(`/api/entries/${entry_id}`, { skin }); entries.reload() }
  const setMode = async (mode: string) => { await api.patch(`/api/championships/${ch.id}`, { player_mode: mode }); chs.reload() }
  if (!ch) return null
  const skins: Any[] = car.data?.skins ?? []
  return (
    <Card title="Coche de Assetto Corsa por categoría" desc="Elige qué coche de tu Assetto Corsa hace de F1, cuál de F2… Todos los pilotos de la categoría usarán ese coche; la app reparte una skin (decoración) por equipo y aquí puedes cambiarla. «Modo del jugador» decide si esa categoría la juegas tú o se simula." right={<Tabs tabs={(chs.data ?? []).map((c: Any) => ({ id: String(c.id), label: c.category_code }))} value={String(ch.id)} onChange={v => setSel(Number(v))} />}>
      <div className="row">
        <label className="grow">{ch.category_code} → modelo AC
          <select value={ch.ac_car_id ?? ''} onChange={e => assign(e.target.value)}>
            <option value="">— sin asignar —</option>
            {cars.map((c: Any) => <option key={c.id} value={c.id}>{c.name} · {c.id} ({c.skin_count} skins)</option>)}
          </select>
        </label>
        <label>Modo del jugador<select value={ch.player_mode} onChange={e => setMode(e.target.value)}><option value="play">Jugar mis sesiones</option><option value="simulate">Simular</option></select></label>
      </div>
      {ch.ac_car_id && (
        <table className="tbl compact"><thead><tr><th>Equipo</th><th>#</th><th>Piloto</th><th>Skin</th><th /></tr></thead>
          <tbody>{entries.data?.map((e: Any) => {
            const sk = skins.find(s => s.id === e.skin)
            return (
              <tr key={e.entry_id}><td><TeamDot color={e.team_color} />{e.team_name}</td><td>{e.number}</td><td>{e.first_name} {e.last_name}</td>
                <td><select value={e.skin ?? ''} onChange={x => setSkin(e.entry_id, x.target.value)}><option value="">—</option>{skins.map(s => <option key={s.id} value={s.id}>{s.name}{s.team ? ` (${s.team})` : ''}</option>)}</select></td>
                <td>{sk?.preview_path && <img className="thumb" src={imgUrl(sk.preview_path, root)} loading="lazy" onError={e => { e.currentTarget.style.display = 'none' }} />}</td></tr>
            )
          })}</tbody></table>
      )}
    </Card>
  )
}

function Physics() {
  const ph = useLoad(() => api.get('/api/physics'))
  if (!ph.data) return null
  const cfg = ph.data.config
  const toggle = async () => { await api.put('/api/config/physics', { ...cfg, enabled: !cfg.enabled }); toast(cfg.enabled ? 'Física avanzada desactivada' : 'Física avanzada activada'); ph.reload() }
  const cleanup = async () => { if (!confirm('¿Eliminar todas las copias gestionadas fcm_* creadas por el Career Manager? Tus coches originales no se tocan.')) return; const r = await api.post('/api/physics/cleanup'); toast(`${r.removed} copias eliminadas`); ph.reload() }
  return (
    <Card title="Coches distintos por equipo (experimental)" right={<><Btn kind={cfg.enabled ? '' : 'primary'} onClick={toggle}>{cfg.enabled ? 'Desactivar' : 'Activar'}</Btn> <Btn kind="ghost danger" onClick={cleanup}>Eliminar copias gestionadas</Btn></>}>
      <p className="muted small">Experimental. Si la activas, cada equipo tendrá su propia versión del coche con más o menos potencia, carga aerodinámica y peso según su desarrollo. Tus coches originales nunca se tocan. Solo funciona con coches cuya carpeta <code>data</code> no esté empaquetada.</p>
      <table className="tbl compact"><tbody>{ph.data.cars.map((c: Any) => <tr key={c.category}><td>{c.category}</td><td className="mono small">{c.car_id}</td><td>{c.supported ? <b className="pos">compatible</b> : <span className="warn-t">no compatible</span>}</td></tr>)}</tbody></table>
      {ph.data.managed.length > 0 && <div className="muted small">{ph.data.managed.length} copias gestionadas existentes.</div>}
    </Card>
  )
}
