import { useState } from 'react'
import { Any, api } from '../api'
import { Card, Err, Helmet, Loading, ROLE_ES, Stars, Tabs, Trend, n2, nav, useLoad } from '../ui'
import { useChampionship } from './Standings'

export default function Drivers() {
  const { chs, cur, setSel } = useChampionship()
  const [sort, setSort] = useState('team')
  const list = useLoad(() => cur ? api.get(`/api/drivers?championship_id=${cur}`) : Promise.resolve(null), [cur])
  const rows = [...(list.data ?? [])].sort((a: Any, b: Any) => sort === 'rating' ? b.base_rating - a.base_rating : sort === 'potential' ? b.potential - a.potential : sort === 'form' ? b.form - a.form : 0)
  return (
    <div className="page">
      <h1>Pilotos</h1>
      <Tabs tabs={(chs.data ?? []).map((c: Any) => ({ id: String(c.id), label: c.category_code }))} value={cur ?? ''} onChange={setSel} />
      <Loading loading={list.loading} /><Err error={list.error} />
      <Card right={<select value={sort} onChange={e => setSort(e.target.value)}><option value="team">Por equipo</option><option value="rating">Por media</option><option value="potential">Por potencial</option><option value="form">Por forma</option></select>}>
        <table className="tbl">
          <thead><tr><th>#</th><th>Piloto</th><th>Edad</th><th>Equipo</th><th>Media</th><th>Forma</th><th>Potencial</th><th>Ritmo</th><th>Clasif.</th><th>Carrera</th><th>Regularidad</th></tr></thead>
          <tbody>{rows.map((d: Any) => (
            <tr key={d.driver_id ?? d.id} className={d.is_player ? 'hl' : ''} onClick={() => nav(`/driver/${d.driver_id ?? d.id}`)} style={{ cursor: 'pointer' }}>
              <td className="muted">{d.number}</td>
              <td><div className="who"><Helmet color={d.team_color} size={30} /><div><b>{d.first_name} {d.last_name}</b><small>{ROLE_ES[d.role] ?? d.role}</small></div></div></td><td>{d.age}</td>
              <td>{d.team_name}</td><td><span className="rating">{n2(d.base_rating, 0)}</span></td><td><Trend v={d.form} /></td><td><Stars value={d.potential} /></td>
              <td>{n2(d.pace, 0)}</td><td>{n2(d.qualifying, 0)}</td><td>{n2(d.racecraft, 0)}</td><td>{n2(d.consistency, 0)}</td>
            </tr>
          ))}</tbody>
        </table>
      </Card>
    </div>
  )
}
