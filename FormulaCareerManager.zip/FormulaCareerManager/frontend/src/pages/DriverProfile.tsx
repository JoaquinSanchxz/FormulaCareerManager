import { useState } from 'react'
import { Any, api } from '../api'
import { Bar, Btn, COUNTRY_ES, Card, Err, Helmet, LineChart, Loading, ROLE_ES, Stars, Stat, TeamDot, Trend, moraleLabel, n2, toast, useLoad } from '../ui'

const ATTRS: [string, string][] = [['pace', 'Ritmo'], ['qualifying', 'Clasificación'], ['racecraft', 'Carrera'], ['awareness', 'Atención'], ['consistency', 'Regularidad'],
  ['tyre_management', 'Gestión de neumáticos'], ['wet_skill', 'En mojado'], ['starts', 'Salidas'], ['defending', 'Defensa'], ['overtaking', 'Adelantamientos'],
  ['adaptability', 'Adaptación'], ['experience', 'Experiencia']]
const INFO: [string, string][] = [['first_name', 'Nombre'], ['last_name', 'Apellido'], ['short_name', 'Abreviatura'], ['nationality', 'Nacionalidad'], ['birth_date', 'Fecha de nacimiento'], ['potential', 'Potencial']]

export default function DriverProfile({ id }: { id?: string }) {
  const { data, error, loading, reload } = useLoad(() => api.get(`/api/drivers/${id}`), [id])
  const [editing, setEditing] = useState(false)
  if (!data) return <div className="page"><Loading loading={loading} /><Err error={error} /></div>
  const d = data.driver
  const hist = data.history
  const color = data.entry?.team_color
  const season = Object.entries(data.season_stats ?? {}) as [string, Any][]
  const career = Object.entries(data.career_stats ?? {}) as [string, Any][]
  const tm = data.teammate
  return (
    <div className="page">
      <div className="hero" style={{ borderColor: color }}>
        <div className="who">
          <Helmet color={color} size={84} />
          <div>
            <div className="eyebrow">{COUNTRY_ES[d.nationality] ?? d.nationality} · {d.age} años{d.is_player ? ' · Tú' : ''}{d.retired ? ' · Retirado' : ''}</div>
            <h1>{d.first_name} {d.last_name}</h1>
            <div className="muted"><TeamDot color={color} />{data.entry ? `${data.entry.team_name} · ${data.entry.category_code} · #${data.entry.number} · ${ROLE_ES[data.entry.role] ?? data.entry.role}` : 'Sin equipo'}</div>
          </div>
        </div>
        <div className="hero-stats">
          <Stat label="Media" value={n2(d.base_rating, 0)} sub={<Trend v={d.form} />} />
          <Stat label="Moral" value={<span className="small">{moraleLabel(d.morale)}</span>} />
          <Stat label="Potencial" value={<Stars value={d.potential} />} sub="según los ojeadores" />
          <Stat label="Valor" value={d.market_value ? `${d.market_value >= 10 ? d.market_value.toFixed(0) : d.market_value.toFixed(1)} M€` : '—'} />
        </div>
      </div>
      <div className="cols">
        <div>
          <Card title="Evolución de la media">
            <LineChart series={[{ name: 'media', color: color || 'var(--accent)', points: hist.map((h: Any, i: number) => ({ x: i, y: h.base_after, label: h.year ? `${h.year}${h.round_no ? ` · R${h.round_no}` : ''}` : '' })) }]} />
          </Card>
          <Card title="Últimas carreras">
            {data.recent.length === 0 ? <div className="muted">Sin carreras todavía.</div> : (
              <div className="results-row">{data.recent.map((r: Any, i: number) => (
                <div key={i} className={`res ${r.status !== 'FIN' ? 'dnf' : r.position === 1 ? 'p1' : r.position <= 3 ? 'pod' : ''}`}>
                  <b>{r.status === 'FIN' ? r.position : 'AB'}</b><span>{r.event_name.replace(/^Gran Premio (de (los |la )?|del )/, '')}</span><small>{r.code === 'Q' ? 'Clasificación' : r.code === 'S' ? 'Sprint' : r.code === 'SQ' ? 'Clas. sprint' : 'Carrera'}</small>
                </div>
              ))}</div>
            )}
          </Card>
          <Card title="Estadísticas">
            <div className="scroll-x"><table className="tbl compact"><thead><tr><th /><th>Carreras</th><th>Victorias</th><th>Poles</th><th>Podios</th><th>Vueltas rápidas</th><th>Puntos</th><th>Abandonos</th><th>Posición media</th></tr></thead>
              <tbody>
                {season.map(([c, s]) => <tr key={'s' + c}><td>Esta temporada · {c}</td><td>{s.starts}</td><td>{s.wins}</td><td>{s.poles}</td><td>{s.podiums}</td><td>{s.fastest_laps}</td><td>{s.points}</td><td>{s.dnfs}</td><td>{s.average_finish ?? '—'}</td></tr>)}
                {career.map(([c, s]) => <tr key={'c' + c}><td><b>Trayectoria · {c}</b></td><td>{s.starts}</td><td>{s.wins}</td><td>{s.poles}</td><td>{s.podiums}</td><td>{s.fastest_laps}</td><td>{s.points}</td><td>{s.dnfs}</td><td>{s.average_finish ?? '—'}</td></tr>)}
              </tbody></table></div>
          </Card>
        </div>
        <div>
          <Card title="Habilidades" right={<Btn kind="ghost" onClick={() => setEditing(!editing)}>{editing ? 'Cerrar' : 'Editar'}</Btn>}>
            {editing ? <AttrEditor d={d} onSaved={() => { setEditing(false); reload() }} /> : ATTRS.map(([k, l]) => <div key={k} className="attr"><span>{l}</span><Bar value={d[k]} color={color} /></div>)}
          </Card>
          {tm && (
            <Card title={`Duelo con ${tm.teammate_name}`}>
              <div className="duel">
                <div><span>Clasificación</span><b>{tm.qualifying[0]} – {tm.qualifying[1]}</b></div>
                <div><span>Carrera</span><b>{tm.race[0]} – {tm.race[1]}</b></div>
              </div>
            </Card>
          )}
          <Card title="Contrato">
            {data.contract ? <div className="duel"><div><span>Equipo</span><b>{data.contract.team_name}</b></div><div><span>Rol</span><b>{ROLE_ES[data.contract.role] ?? data.contract.role}</b></div><div><span>Hasta</span><b>{data.contract.end_season}</b></div></div> : <div className="muted">Sin contrato</div>}
          </Card>
        </div>
      </div>
    </div>
  )
}

function AttrEditor({ d, onSaved }: { d: Any, onSaved: () => void }) {
  const [a, setA] = useState<Any>(Object.fromEntries(ATTRS.map(([k]) => [k, d[k]])))
  const [info, setInfo] = useState<Any>(Object.fromEntries(INFO.map(([k]) => [k, d[k]])))
  const save = async () => {
    await api.patch(`/api/drivers/${d.id ?? d.driver_id}`, { ...info, potential: Number(info.potential), attributes: Object.fromEntries(Object.entries(a).map(([k, v]) => [k, Number(v)])) })
    toast('Piloto actualizado')
    onSaved()
  }
  return (
    <div>
      <div className="grid3">{INFO.map(([k, l]) => <label key={k}>{l}<input value={info[k] ?? ''} onChange={e => setInfo({ ...info, [k]: e.target.value })} /></label>)}</div>
      <div className="grid3">{ATTRS.map(([k, l]) => <label key={k}>{l}<input type="number" step="0.1" value={a[k]} onChange={e => setA({ ...a, [k]: e.target.value })} /></label>)}</div>
      <div className="actions"><Btn kind="primary" onClick={save}>Guardar</Btn></div>
    </div>
  )
}
