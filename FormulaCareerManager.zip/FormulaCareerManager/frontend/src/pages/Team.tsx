import { useEffect, useState } from 'react'
import { Any, api } from '../api'
import { Bar, Btn, Card, Err, Loading, Stat, Tabs, TeamDot, toast, useLoad } from '../ui'

const COMP_ES: Record<string, string> = { power: 'Potencia', energy_recovery: 'Recuperación de energía', low_speed_downforce: 'Carga baja', medium_speed_downforce: 'Carga media',
  high_speed_downforce: 'Carga alta', drag_efficiency: 'Resistencia al aire', traction: 'Tracción', mechanical_grip: 'Agarre mecánico', braking: 'Frenada', weight: 'Peso',
  tyre_usage: 'Neumáticos', cooling: 'Refrigeración', reliability: 'Fiabilidad' }
const FAC_ES: Record<string, string> = { factory: 'Fábrica', wind_tunnel: 'Túnel de viento', cfd: 'Simulación aerodinámica', simulator: 'Simulador', quality_control: 'Control de calidad', powertrain: 'Departamento de motor', personnel: 'Personal' }
const OUT_ES: Record<string, string> = { underperformed: 'Algo peor de lo esperado', expected: 'Como se esperaba', overperformed: 'Mejor de lo esperado', failed: 'Fallido', abandoned: 'Abandonado' }
export const PART_ES: Record<string, string> = { front_wing: 'Alerón delantero', rear_wing: 'Alerón trasero', floor: 'Fondo', diffuser: 'Difusor', sidepods: 'Pontones', cooling: 'Refrigeración',
  suspension: 'Suspensión', brakes: 'Frenos', weight_reduction: 'Aligeramiento', power_unit: 'Unidad de potencia', ers: 'Sistema híbrido', gearbox: 'Caja de cambios', reliability_pack: 'Paquete de fiabilidad',
  chassis: 'Chasis', engine: 'Motor' }
const SIZE_ES: Record<string, string> = { minor: 'Pequeña evolución', standard: 'Evolución normal', major: 'Gran paso adelante' }
const RISK_ES: Record<string, string> = { low: 'Bajo', medium: 'Medio', high: 'Alto' }
const KIND_ES: Record<string, string> = { ICE: 'Motor de combustión', TURBO: 'Turbo', ERS: 'Sistema híbrido', ES: 'Batería', CE: 'Centralita', GEARBOX: 'Caja de cambios' }
const TX_ES: Record<string, string> = { academy: 'Academia', components: 'Componentes de motor', damage: 'Reparaciones', development: 'Desarrollo', driver_salary: 'Salarios de pilotos', event: 'Imprevistos',
  facility_upgrade: 'Obras en instalaciones', facility_upkeep: 'Mantenimiento de instalaciones', fine: 'Multas', manufacturing: 'Fabricación', operating: 'Gastos de operación', owner_funding: 'Aportación de los dueños',
  prize: 'Premios', refund: 'Reembolsos', sponsor: 'Patrocinio', staff: 'Personal', transfer: 'Traspasos', budget: 'Presupuesto' }
const gainLevel = (g?: number | null) => g == null ? '—' : g >= 0.8 ? 'Grande' : g >= 0.35 ? 'Media' : 'Pequeña'
export const money = (v?: number | null) => {
  if (v == null) return '—'
  const a = Math.abs(v), sign = v < 0 ? '-' : ''
  return a < 1 ? `${sign}${Math.round(a * 1000)} mil €` : `${sign}${a >= 10 ? a.toFixed(1) : a.toFixed(2)} M€`.replace('.', ',')
}

export default function Team() {
  const { data: d, error, loading, reload } = useLoad(() => api.get('/api/team'))
  const [tab, setTab] = useState('summary')
  if (!d) return <div className="page"><Loading loading={loading} /><Err error={error} /></div>
  const f = d.finance.finance
  const cc = d.finance.cost_cap
  return (
    <div className="page">
      <div className="hero small" style={{ borderColor: d.team.color }}>
        <div>
          <div className="eyebrow">{d.team.code} · {d.season.year}{d.delegated ? ' · gestión delegada en el equipo' : ''}</div>
          <h1><TeamDot color={d.team.color} />{d.team.name}</h1>
          <div className="muted">Objetivo de la temporada: {d.objective ? <b>terminar {d.objective.position}.º en constructores</b> : '—'}</div>
        </div>
        <div className="hero-stats">
          <Stat label="Caja" value={money(f?.cash)} />
          <Stat label="Presupuesto" value={money(f?.season_budget)} />
          {cc?.enabled && <Stat label="Límite de gasto" value={money(d.cost_cap_headroom)} sub="margen disponible" />}
          <Stat label="Proyectos" value={`${d.development.active}/${d.development.capacity}`} sub="en marcha" />
        </div>
      </div>
      <Tabs tabs={[{ id: 'summary', label: 'Rendimiento' }, { id: 'dev', label: 'I+D y fabricación' }, { id: 'facilities', label: 'Instalaciones' },
        { id: 'components', label: 'Motor y fiabilidad' }, { id: 'finance', label: 'Finanzas' }, { id: 'regs', label: 'Reglamento' }]} value={tab} onChange={setTab} />
      {tab === 'summary' && <Summary d={d} />}
      {tab === 'dev' && <Development d={d} reload={reload} />}
      {tab === 'facilities' && <Facilities d={d} reload={reload} />}
      {tab === 'components' && <Components d={d} reload={reload} />}
      {tab === 'finance' && <Finances d={d} />}
      {tab === 'regs' && <Regs d={d} />}
    </div>
  )
}

function Summary({ d }: { d: Any }) {
  return (
    <div className="cols">
      <Card title="Tu coche">
        {Object.keys(COMP_ES).map(k => (
          <div key={k} className="attr"><span>{COMP_ES[k]}</span><Bar value={d.current_car[k]} min={70} max={100} color={d.team.color} />
            <span className="small pos" style={{ width: 24 }}>{d.current_car[k] - d.base_car[k] > 0.05 ? '▲' : ''}</span></div>
        ))}
        <p className="muted small">▲ = mejorado con piezas nuevas esta temporada.</p>
      </Card>
      <Card title="Cómo está la parrilla">
        {(() => {
          const best = Math.max(...d.field.map((x: Any) => x.overall))
          const next = [...d.field].sort((a: Any, b: Any) => b.next_track - a.next_track)
          return <table className="tbl compact"><thead><tr><th>#</th><th>Equipo</th><th style={{ width: '32%' }}>Coche</th><th>Próxima carrera</th></tr></thead>
            <tbody>{d.field.map((x: Any, i: number) => <tr key={x.team_id} className={x.team_id === d.team.team_id ? 'hl' : ''}><td>{i + 1}</td><td className="nowrap">{x.name}</td>
              <td><div className="bar"><div style={{ width: `${Math.max(8, 100 - (best - x.overall) * 9)}%` }} /></div></td><td>{next.indexOf(x) + 1}.º</td></tr>)}</tbody>
          </table>
        })()}
      </Card>
    </div>
  )
}

function Development({ d, reload }: { d: Any, reload: () => void }) {
  const dev = d.development
  const [form, setForm] = useState<Any>({ part: 'floor', size: 'standard', target_year: d.season.year })
  const [pv, setPv] = useState<Any>(null)
  useEffect(() => { if (d.is_player_team) api.post('/api/development/preview', form).then(setPv).catch(e => setPv({ reasons: [e.message] })) }, [form, d.is_player_team])
  const start = async () => { await api.post('/api/development/projects', form); toast('Proyecto iniciado'); reload() }
  const drivers = d.components.drivers
  const canAct = d.is_player_team && !d.delegated
  return (
    <div>
      {!canAct && <div className="alert warn">{d.delegated ? 'La gestión está delegada en el equipo (Ajustes → Partida).' : 'Sólo puedes gestionar tu propio equipo.'}</div>}
      <div className="cols">
        <Card title="Nuevo proyecto de I+D">
          <div className="grid3">
            <label>Pieza<select value={form.part} onChange={e => setForm({ ...form, part: e.target.value })}>{Object.entries(dev.catalog).map(([k, p]: Any) => <option key={k} value={k}>{PART_ES[k] ?? k} · {dev.departments[p.department]}</option>)}</select></label>
            <label>Alcance<select value={form.size} onChange={e => setForm({ ...form, size: e.target.value })}>{Object.keys(dev.sizes).map(k => <option key={k} value={k}>{SIZE_ES[k] ?? k}</option>)}</select></label>
            <label>Objetivo<select value={form.target_year} onChange={e => setForm({ ...form, target_year: Number(e.target.value) })}><option value={d.season.year}>Coche {d.season.year}</option><option value={d.season.year + 1}>Coche {d.season.year + 1}</option></select></label>
          </div>
          {pv && (
            <div>
              <div className="row">
                <Stat label="Coste" value={money(pv.cost)} /><Stat label="Duración" value={pv.rounds ? `${pv.rounds} rondas` : '—'} />
                <Stat label="Mejora prevista" value={<span className="small">{gainLevel(pv.expected_gain)}</span>} /><Stat label="Riesgo" value={<span className="small">{RISK_ES[pv.risk] ?? pv.risk}</span>} />
              </div>
              {pv.components && <div className="muted small">Mejora: {Object.keys(pv.components).map(k => COMP_ES[k]).join(', ')}</div>}
              {pv.reasons?.map((r: string) => <div key={r} className="alert warn small">{r}</div>)}
              <div className="actions"><Btn kind="primary" disabled={!canAct || !pv.can_start} onClick={start}>Iniciar diseño</Btn></div>
              <p className="muted small">El resultado puede salir mejor o peor de lo esperado. Cuando el diseño esté listo, hay que fabricar la pieza y montarla en el coche.</p>
            </div>
          )}
        </Card>
        <Card title={`Banco para ${d.season.year + 1}`}>
          {Object.keys(dev.next_season_bank).length === 0 ? <div className="muted">Sin desarrollo para el coche siguiente todavía.</div> :
            Object.entries(dev.next_season_bank).map(([k, v]: Any) => <div key={k} className="attr"><span>{COMP_ES[k]}</span><b className="pos">{gainLevel(v)}</b></div>)}
          <p className="muted small">Lo que inviertas en el coche del año que viene no lo tendrás para el de este año.</p>
        </Card>
      </div>
      <Card title="Proyectos">
        <table className="tbl compact"><thead><tr><th>Pieza</th><th>Departamento</th><th>Tipo</th><th>Para</th><th>Coste</th><th>Estado</th></tr></thead>
          <tbody>{dev.projects.map((p: Any) => <tr key={p.id}><td><b>{PART_ES[p.part] ?? p.part}</b></td><td>{dev.departments[p.department]}</td><td>{SIZE_ES[p.size] ?? p.size}</td><td>Coche {p.target_year}</td><td>{money(p.cost)}</td>
            <td>{p.status === 'design' ? `En diseño · ${p.rounds_left} carrera${p.rounds_left === 1 ? '' : 's'}` : OUT_ES[p.outcome] ?? p.status}</td></tr>)}</tbody></table>
      </Card>
      <Card title="Piezas diseñadas: fabricación e instalación">
        <table className="tbl compact"><thead><tr><th>Pieza</th><th>Versión</th><th>Mejora</th><th>En almacén</th><th>Fabricándose</th><th>Montadas</th><th /></tr></thead>
          <tbody>{dev.parts.map((p: Any) => {
            const comps = JSON.parse(p.components_json)
            return (
              <tr key={p.id}><td><b>{PART_ES[p.part] ?? p.part}</b></td><td>{p.spec_no}</td><td className="small">{Object.keys(comps).map(k => COMP_ES[k]).join(', ')}</td>
                <td>{p.available}</td><td>{p.in_production ? `${p.in_production} (${p.production_rounds} carr.)` : ''}</td><td>{p.installed}</td>
                <td className="right">
                  {canAct && <><Btn kind="ghost" onClick={async () => { await api.post(`/api/development/parts/${p.id}/manufacture`, { quantity: 1 }); toast('Fabricando 1'); reload() }}>Fabricar 1 ({money(p.manufacture_cost)})</Btn>
                    <Btn kind="ghost" onClick={async () => { await api.post(`/api/development/parts/${p.id}/manufacture`, { quantity: 2 }); toast('Fabricando 2'); reload() }}>Fabricar 2</Btn>
                    {p.available > 0 && drivers.map((dr: Any) => <Btn key={dr.driver_id} onClick={async () => { await api.post(`/api/development/parts/${p.id}/install`, { driver_id: dr.driver_id }); toast('Instalada'); reload() }}>Instalar a {dr.last_name}</Btn>)}</>}
                </td></tr>
            )
          })}</tbody></table>
        <h4>Montado actualmente</h4>
        <table className="tbl compact"><tbody>{dev.installations.map((i: Any) => <tr key={i.id}><td>{i.first_name} {i.last_name}</td><td>{PART_ES[i.part] ?? i.part} v{i.spec_no}</td><td className="muted">desde la ronda {i.round_no}</td></tr>)}</tbody></table>
      </Card>
    </div>
  )
}

function Facilities({ d, reload }: { d: Any, reload: () => void }) {
  const fc = d.facility_costs
  const tier = String(Math.min(3, d.team.tier))
  const canAct = d.is_player_team && !d.delegated
  return (
    <Card title="Instalaciones">
      <table className="tbl"><thead><tr><th>Instalación</th><th>Nivel</th><th>Efecto</th><th /></tr></thead>
        <tbody>{d.development.facilities.map((f: Any) => (
          <tr key={f.kind}><td><b>{FAC_ES[f.kind] ?? f.kind}</b></td><td>{'■'.repeat(f.level)}{'□'.repeat(fc.max_level - f.level)} {f.level}/{fc.max_level}</td>
            <td className="small muted">{f.kind === 'personnel' ? 'capacidad de proyectos simultáneos' : f.kind === 'quality_control' ? 'precisión (menos fallos), fiabilidad' : f.kind === 'factory' ? 'coste y tiempo de fabricación, chasis' : 'velocidad y ganancia del desarrollo'}</td>
            <td className="right">{f.upgrade_rounds_left ? `Mejorando · ${f.upgrade_rounds_left} rondas` : f.level < fc.max_level && canAct &&
              <Btn onClick={async () => { await api.post(`/api/facilities/${f.kind}/upgrade`); toast('Mejora iniciada'); reload() }}>Mejorar · {money(fc.upgrade_cost[tier][f.level])} · {fc.upgrade_rounds[f.level]} carreras</Btn>}</td></tr>
        ))}</tbody></table>
      <p className="muted small">Las obras en instalaciones no cuentan para el límite de gasto.</p>
    </Card>
  )
}

function Components({ d, reload }: { d: Any, reload: () => void }) {
  const c = d.components
  const canAct = d.is_player_team && !d.delegated
  if (!c.drivers.length || !Object.keys(c.limits).length) return <Card><div className="muted">Esta categoría no gestiona componentes de motor.</div></Card>
  return (
    <div>
      {c.drivers.map((dr: Any) => (
        <Card key={dr.driver_id} title={`${dr.first_name} ${dr.last_name}`}>
          <table className="tbl compact"><thead><tr><th>Elemento</th><th>Usados / permitidos</th><th>Montado</th><th>Desgaste</th><th /></tr></thead>
            <tbody>{Object.keys(c.kinds).map(k => {
              const pc = dr.fitted[k]
              const used = dr.used[k]
              return (
                <tr key={k}><td><b>{KIND_ES[k] ?? k}</b></td><td className={used > (c.limits[k] ?? 99) ? 'neg' : ''}>{used} / {c.limits[k] ?? '∞'}</td><td>{pc ? `n.º ${pc.serial}` : <span className="neg">sin montar</span>}</td>
                  <td>{pc && <Bar value={pc.wear * 100} min={0} max={120} color={pc.wear > 0.9 ? 'var(--err)' : pc.wear > 0.7 ? 'var(--warn)' : 'var(--ok)'} />}</td>
                  <td className="right">{canAct && <Btn kind="ghost" onClick={async () => {
                    if (used >= (c.limits[k] ?? 99) && !confirm(`Montar un elemento nuevo supera el cupo: habrá penalización en parrilla. ¿Seguir?`)) return
                    const r = await api.post('/api/components/fit', { driver_id: dr.driver_id, kind: k }); toast(r.penalty ? `Montado · penalización de ${r.penalty} puestos` : 'Montado'); reload()
                  }}>Montar nuevo</Btn>}</td></tr>
              )
            })}</tbody></table>
        </Card>
      ))}
      <div className="cols">
        <Card title="Penalizaciones">{c.penalties.length === 0 ? <div className="muted">Ninguna.</div> :
          <table className="tbl compact"><tbody>{c.penalties.map((p: Any) => <tr key={p.id}><td>{p.event_name}</td><td>{p.value} puestos</td><td>{p.applied ? 'Cumplida' : 'Pendiente'}</td></tr>)}</tbody></table>}</Card>
        <Card title="Daños recientes">{c.damage.length === 0 ? <div className="muted">Sin daños.</div> :
          <table className="tbl compact"><tbody>{c.damage.map((x: Any) => <tr key={x.id}><td>{x.event_name}</td><td>{PART_ES[x.component] ?? x.component}</td><td>{x.severity > 0.6 ? 'Grave' : x.severity > 0.3 ? 'Moderado' : 'Leve'}</td><td>{money(x.cost)}</td></tr>)}</tbody></table>}</Card>
      </div>
    </div>
  )
}

function Finances({ d }: { d: Any }) {
  const fin = d.finance
  return (
    <div className="cols">
      <div>
        <Card title="Ingresos y gastos">
          <table className="tbl compact"><tbody>{fin.by_type.map((t: Any) => <tr key={t.type}><td>{TX_ES[t.type] ?? t.type}</td><td className={t.total >= 0 ? 'pos' : 'neg'}>{money(t.total)}</td></tr>)}</tbody></table>
        </Card>
        <Card title="Patrocinadores">
          <table className="tbl compact"><tbody>{fin.sponsors.map((s: Any) => <tr key={s.id}><td><b>{s.name}</b></td><td>{money(s.base_payment)}/temp.</td>
            <td className="small">+{money(s.race_bonus)} por acabar entre los {s.race_objective} primeros · +{money(s.season_bonus)} si el equipo termina {s.season_objective}.º</td></tr>)}</tbody></table>
        </Card>
      </div>
      <Card title="Movimientos">
        <div className="scroll-y" style={{ maxHeight: 600 }}>
          <table className="tbl compact"><tbody>{fin.ledger.map((t: Any) => <tr key={t.id}><td className="muted">{t.round_no ? `Ronda ${t.round_no}` : '—'}</td><td>{TX_ES[t.type] ?? t.type}</td><td className="small">{t.description}</td>
            <td className={t.amount >= 0 ? 'pos' : 'neg'}>{money(t.amount)}</td></tr>)}</tbody></table>
        </div>
      </Card>
    </div>
  )
}

function Regs({ d }: { d: Any }) {
  const r = d.regulations
  return (
    <Card title="Reglamento">
      {r.next_year_major && <div className="alert warn">El año que viene cambia el reglamento: invertir en el coche nuevo será clave.</div>}
      {r.regulations.map((x: Any) => (
        <div key={x.id}>
          <h4>{x.code} · {x.name}</h4>
          <div className="small">Elementos de motor permitidos por temporada: {Object.entries(x.data.component_limits || {}).map(([k, v]) => `${KIND_ES[k] ?? k} ${v}`).join(' · ') || '—'}</div>
          <div className="small muted">Si se supera el cupo: {x.data.grid_penalty_first} puestos la primera vez y {x.data.grid_penalty_next} las siguientes.</div>
        </div>
      ))}
    </Card>
  )
}
