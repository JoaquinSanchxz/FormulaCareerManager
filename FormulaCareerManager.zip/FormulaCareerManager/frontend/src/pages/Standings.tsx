import { useState } from 'react'
import { Any, api } from '../api'
import { Card, Err, Helmet, Loading, Tabs, TeamDot, nav, useLoad } from '../ui'

export function useChampionship() {
  const chs = useLoad(() => api.get('/api/championships'))
  const [sel, setSel] = useState<string | null>(null)
  const cur = sel ?? (chs.data?.[0] ? String(chs.data[0].id) : null)
  return { chs, cur, setSel }
}

export default function Standings() {
  const { chs, cur, setSel } = useChampionship()
  const [tab, setTab] = useState('drivers')
  const st = useLoad(() => cur ? api.get(`/api/standings?championship_id=${cur}`) : Promise.resolve(null), [cur])
  const rounds = st.data ? Array.from(new Set(st.data.drivers.flatMap((d: Any) => Object.keys(d.rounds).map(Number)))).sort((a: Any, b: Any) => a - b) as number[] : []
  return (
    <div className="page">
      <h1>Clasificación</h1>
      <Tabs tabs={(chs.data ?? []).map((c: Any) => ({ id: String(c.id), label: c.category_code }))} value={cur ?? ''} onChange={setSel} />
      <Tabs tabs={[{ id: 'drivers', label: 'Pilotos' }, { id: 'constructors', label: 'Constructores' }]} value={tab} onChange={setTab} />
      <Loading loading={st.loading} /><Err error={st.error} />
      {st.data && tab === 'drivers' && st.data.drivers.length >= 3 && (
        <div className="leaders">{st.data.drivers.slice(0, 3).map((d: Any, i: number) => (
          <div key={d.driver_id} className={`leader l${i + 1}`} style={{ borderColor: d.team_color }} onClick={() => nav(`/driver/${d.driver_id}`)}>
            <span className="lp">{i + 1}</span><Helmet color={d.team_color} size={52} /><div><b>{d.name}</b><small>{d.team_short}</small></div><span className="lpts">{d.points}<small> pts</small></span>
          </div>
        ))}</div>
      )}
      {st.data && tab === 'drivers' && (
        <Card>
          <div className="scroll-x">
            <table className="tbl compact">
              <thead><tr><th>Pos</th><th>Piloto</th><th>Equipo</th><th>Puntos</th><th title="Victorias">Vic.</th><th title="Podios">Pod.</th><th title="Poles">Poles</th><th title="Vueltas rápidas">VR</th><th title="Abandonos">Ab.</th>{rounds.map(r => <th key={r} className="rcol">R{r}</th>)}</tr></thead>
              <tbody>{st.data.drivers.map((d: Any) => (
                <tr key={d.driver_id} className={d.is_player ? 'hl' : ''}>
                  <td><b>{d.position}</b></td><td><a className="link" onClick={() => nav(`/driver/${d.driver_id}`)}>{d.name}</a></td>
                  <td><TeamDot color={d.team_color} />{d.team_short}</td><td><b>{d.points}</b></td><td>{d.wins}</td><td>{d.podiums}</td><td>{d.poles}</td><td>{d.fastest_laps}</td><td>{d.dnfs}</td>
                  {rounds.map(r => { const x = d.rounds[r]; const v = x?.race; return <td key={r} className={`rcol ${v === 1 ? 'p1' : v === 2 || v === 3 ? 'pod' : typeof v === 'string' ? 'dnf' : ''}`}>{v === 'DNF' ? 'Ab' : v ?? ''}{x?.sprint ? <sup>{x.sprint === 'DNF' ? 'Ab' : x.sprint}</sup> : null}</td> })}
                </tr>
              ))}</tbody>
            </table>
          </div>
        </Card>
      )}
      {st.data && tab === 'constructors' && (
        <Card>
          <table className="tbl"><thead><tr><th>Pos</th><th>Equipo</th><th>Puntos</th><th>Victorias</th><th>Podios</th></tr></thead>
            <tbody>{st.data.constructors.map((t: Any) => <tr key={t.team_id}><td><b>{t.position}</b></td><td><TeamDot color={t.team_color} />{t.team_name}</td><td><b>{t.points}</b></td><td>{t.wins}</td><td>{t.podiums}</td></tr>)}</tbody>
          </table>
        </Card>
      )}
    </div>
  )
}
