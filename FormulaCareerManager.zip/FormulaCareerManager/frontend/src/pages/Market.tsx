import { useState } from 'react'
import { Any, api } from '../api'
import { Btn, Card, Err, Loading, ROLE_ES, Stars, Stat, Tabs, TeamDot, n2, nav, toast, useLoad } from '../ui'

const interestES = (v: number) => v > 1.5 ? ['pos', 'Muy interesados'] : v > 0.3 ? ['pos', 'Interesados'] : v > -0.5 ? ['muted', 'Tienen dudas'] : ['neg', 'Sin interés']
const repES = (v: number) => v >= 80 ? 'Estrella' : v >= 60 ? 'Muy respetado' : v >= 40 ? 'Conocido' : v >= 20 ? 'Prometedor' : 'Desconocido'
import { money } from './Team'

export default function Market() {
  const { data: d, error, loading, reload } = useLoad(() => api.get('/api/market'))
  const [tab, setTab] = useState('offers')
  const [neg, setNeg] = useState<Any>(null)
  const [answer, setAnswer] = useState<Any>(null)
  if (!d) return <div className="page"><Loading loading={loading} /><Err error={error} /></div>
  const openOffers = d.offers.filter((o: Any) => o.status === 'open')
  const offers = d.offers.filter((o: Any) => o.status !== 'expired').slice(0, 12)
  const send = async () => {
    const r = await api.post('/api/market/negotiate', neg)
    setAnswer(r)
    toast(r.status === 'accepted' ? 'Acuerdo cerrado' : r.status === 'countered' ? 'Contraoferta recibida' : 'Propuesta rechazada', r.status === 'rejected' ? 'err' : 'ok')
    reload()
  }
  return (
    <div className="page">
      <h1>Mercado y contratos</h1>
      <div className="row">
        <Stat label="Tu media" value={n2(d.player.base_rating, 0)} /><Stat label="Reputación" value={<span className="small">{repES(d.player.reputation)}</span>} />
        <Stat label="Contrato" value={d.contract ? `hasta ${d.contract.end_season}` : '—'} sub={d.contract ? `${ROLE_ES[d.contract.role] ?? d.contract.role} · ${money(d.contract.salary)}/año` : ''} />
        <Stat label="Superlicencia" value={<span className="small">{d.super_license.eligible ? 'Sí' : 'Todavía no'}</span>} />
        <Stat label="Valor de mercado" value={money(d.player.market_value)} sub={d.summer_open ? 'mercado de verano abierto' : 'el mercado abre al final de temporada'} />
      </div>
      {d.future_contracts.map((c: Any) => <div key={c.id} className="alert ok">Has firmado con <b>{c.team_name}</b> para {c.start_season}–{c.end_season} como {(ROLE_ES[c.role] ?? c.role).toLowerCase()} ({money(c.salary)}/año).</div>)}
      <Tabs tabs={[{ id: 'offers', label: `Ofertas (${openOffers.length})` }, { id: 'teams', label: 'Negociar' }, { id: 'contracts', label: 'La parrilla' }, { id: 'academies', label: 'Academias' }]} value={tab} onChange={setTab} />
      {tab === 'offers' && (
        <Card>
          {offers.length === 0 && <div className="muted">Aún no hay ofertas. Los equipos se mueven a mitad y a final de temporada: sigue sumando buenos resultados.</div>}
          <table className="tbl"><tbody>{offers.map((o: Any) => (
            <tr key={o.id} className={o.status === 'open' ? 'next' : 'dim'}>
              <td><TeamDot color={o.team_color} /><b>{o.team_name}</b> <span className="muted small">{o.category_code} · {o.origin === 'ai' ? 'te buscan ellos' : 'tu propuesta'}</span></td>
              <td>{ROLE_ES[o.role] ?? o.role}</td><td>{money(o.salary)}/año</td><td>{o.years} año{o.years === 1 ? '' : 's'}</td><td className="small">{o.status === 'open' ? (d.summer_open ? 'Cambiarías de equipo en el parón de verano' : 'Cambiarías de equipo al final de temporada') : o.effective === 'summer' ? 'En el parón de verano' : 'Al final de temporada'}</td><td className="small">{o.bonus_per_win > 0 ? `prima por victoria ${money(o.bonus_per_win)}` : ''}</td>
              <td>{({ open: 'abierta', accepted: 'aceptada', rejected: 'rechazada', expired: 'caducada', countered: 'contraoferta' } as Any)[o.status] ?? o.status}</td>
              <td className="right">{o.status === 'open' && <><Btn kind="primary" onClick={async () => { await api.post(`/api/offers/${o.id}/accept`); toast('Contrato firmado'); reload() }}>Aceptar</Btn> <Btn kind="ghost" onClick={async () => { await api.post(`/api/offers/${o.id}/reject`); reload() }}>Rechazar</Btn></>}</td>
            </tr>
          ))}</tbody></table>
        </Card>
      )}
      {tab === 'teams' && (
        <div className="cols">
          <Card title="Equipos de tu categoría y de la superior">
            <table className="tbl compact"><thead><tr><th>Equipo</th><th>¿Te quieren?</th><th>Sueldo que te pagarían</th><th>Pilotos (contrato hasta)</th><th /></tr></thead>
              <tbody>{d.teams.map((t: Any) => (
                <tr key={t.team_id}><td><b>{t.name}</b> <span className="muted small">{t.code}</span></td><td className={interestES(t.interest)[0]}>{interestES(t.interest)[1]}</td><td>{money(t.valuation)}/año</td>
                  <td className="small">{t.drivers.map((x: Any) => <span key={x.driver_id}><a className="link" onClick={() => nav(`/driver/${x.driver_id}`)}>{x.name}</a> ({x.contract_end ?? '—'}) </span>)}</td>
                  <td className="right"><Btn kind="ghost" onClick={() => { setNeg({ team_id: t.team_id, team: t.name, role: 'D2', salary: t.valuation, years: 2, bonus_per_win: 0 }); setAnswer(null) }}>Negociar</Btn></td></tr>
              ))}</tbody></table>
          </Card>
          <Card title={neg ? `Propuesta a ${neg.team}` : 'Propuesta'}>
            {!neg ? <div className="muted">Elige un equipo para hacerle una propuesta. El contrato empezaría la próxima temporada.</div> : (
              <div>
                <div className="grid4">
                  <label>Rol<select value={neg.role} onChange={e => setNeg({ ...neg, role: e.target.value })}><option value="D1">Primer piloto</option><option value="D2">Segundo piloto</option></select></label>
                  <label>Sueldo (millones al año)<input type="number" step="0.1" value={neg.salary} onChange={e => setNeg({ ...neg, salary: Number(e.target.value) })} /></label>
                  <label>Años<input type="number" min={1} max={5} value={neg.years} onChange={e => setNeg({ ...neg, years: Number(e.target.value) })} /></label>
                  <label>Prima por victoria (millones)<input type="number" step="0.05" value={neg.bonus_per_win} onChange={e => setNeg({ ...neg, bonus_per_win: Number(e.target.value) })} /></label>
                </div>
                <div className="actions"><Btn kind="primary" onClick={send}>Enviar propuesta</Btn></div>
                {answer && (
                  <div className={`alert ${answer.status === 'accepted' ? 'ok' : answer.status === 'countered' ? 'warn' : 'err'}`}>
                    <b>{answer.status === 'accepted' ? '¡Aceptada!' : answer.status === 'countered' ? 'Te hacen una contraoferta' : 'Rechazada'}</b>
                    <ul>{answer.reasons.map((r: string) => <li key={r}>{r}</li>)}</ul>
                    {answer.counter && <div>Proponen: {ROLE_ES[answer.counter.role] ?? answer.counter.role} · {money(answer.counter.salary)}/año · {answer.counter.years} año{answer.counter.years === 1 ? '' : 's'}. La tienes en Ofertas.</div>}
                  </div>
                )}
              </div>
            )}
          </Card>
        </div>
      )}
      {tab === 'contracts' && (
        <Card>
          <table className="tbl compact"><thead><tr><th>Equipo</th><th>Piloto</th><th>Media</th><th>Valor de mercado</th><th>Rol</th><th>Sueldo</th><th>Hasta</th><th>Cláusula</th></tr></thead>
            <tbody>{d.contracts.map((c: Any) => <tr key={c.id}><td>{c.team_name}</td><td><a className="link" onClick={() => nav(`/driver/${c.driver_id}`)}>{c.first_name} {c.last_name}</a></td>
              <td>{n2(c.base_rating, 0)}</td><td>{money(c.market_value)}</td><td>{ROLE_ES[c.role] ?? c.role}</td><td>{money(c.salary)}</td><td>{c.end_season}</td><td>{money(c.release_clause)}</td></tr>)}</tbody></table>
        </Card>
      )}
      {tab === 'academies' && (
        <div className="grid3">{d.academies.map((a: Any) => (
          <Card key={a.id} title={<><TeamDot color={a.color} />{a.name}</>}>
            {a.members.length === 0 ? <div className="muted">Sin miembros</div> : a.members.map((m: Any) => <div key={m.id} className="news"><a className="link" onClick={() => nav(`/driver/${m.driver_id}`)}>{m.first_name} {m.last_name}</a> <span className="muted small">media {n2(m.base_rating, 0)} · <Stars value={m.potential} /></span></div>)}
            <div className="muted small">Sus pilotos tienen preferencia para subir al equipo.</div>
          </Card>
        ))}</div>
      )}
    </div>
  )
}
