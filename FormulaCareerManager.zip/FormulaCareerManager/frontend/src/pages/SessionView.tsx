import { Any, api } from '../api'
import { Card, DNF_ES, Err, Helmet, Loading, fmtGap, fmtLap, nav, signed, useLoad } from '../ui'
import { TYRE_COLOR, TYRE_LETTER } from './Weekend'

export default function SessionView({ id }: { id?: string }) {
  const { data, error, loading } = useLoad(() => api.get(`/api/sessions/${id}`), [id])
  const tele = useLoad(() => api.get(`/api/sessions/${id}/telemetry`), [id])
  if (!data) return <div className="page"><Loading loading={loading} /><Err error={error} /></div>
  const s = data.session
  const isRace = ['race', 'sprint'].includes(s.type)
  const ko = s.type === 'qualifying' && data.results.some((r: Any) => r.q_stage)
  const p = s.code === 'SQ' ? 'SQ' : 'Q'
  const leaderLaps = data.results[0]?.laps
  return (
    <div className="page">
      <a className="link" onClick={() => nav(`/weekend/${s.round_id}`)}>← {s.event_name}</a>
      <h1>{s.event_name}</h1>
      <p className="muted">{s.name}{s.laps ? ` · ${s.laps} vueltas` : ''}{s.weather === 'wet' ? ' · 🌧 en mojado' : ''} · {s.mode === 'played' ? 'disputada por ti en Assetto Corsa' : 'simulada'}</p>
      {isRace && data.results.length >= 3 && <div className="podium">{[1, 0, 2].map(i => { const r = data.results[i]; return r && <div key={i} className={`pod-${i + 1}`}><Helmet color={r.team_color} size={i === 0 ? 70 : 54} /><b>{r.first_name} {r.last_name}</b><span>{r.team_name}</span><div className="step">{i + 1}</div></div> })}</div>}
      <Card>
        <table className="tbl">
          <thead><tr><th>Pos</th><th>#</th><th>Piloto</th><th>Equipo</th>{isRace && <th>Salida</th>}{isRace && <th>Vueltas</th>}{ko ? <><th>{p}1</th><th>{p}2</th><th>{p}3</th></> : <th>{isRace ? 'Tiempo / gap' : 'Mejor vuelta'}</th>}{isRace && <th>Mejor vuelta</th>}{isRace && <th>Paradas</th>}{isRace && <th>Neumáticos</th>}{isRace && <th>Puntos</th>}</tr></thead>
          <tbody>
            {data.results.map((r: Any) => (
              <tr key={r.driver_id} className={r.is_player ? 'hl' : ''}>
                <td><b>{r.position}</b></td><td>{r.number}</td>
                <td><a className="link" onClick={() => nav(`/driver/${r.driver_id}`)}>{r.first_name} {r.last_name}</a>{r.fastest_lap ? <span className="tag purple">VR</span> : null}</td>
                <td><span className="tdot" style={{ background: r.team_color }} />{r.team_name}</td>
                {isRace && <td>{r.grid_position}{r.grid_position && r.status === 'FIN' ? <span className={`delta ${r.grid_position - r.position >= 0 ? 'up' : 'down'}`}>{signed(r.grid_position - r.position, 0)}</span> : null}</td>}
                {isRace && <td>{r.laps}</td>}
                {ko ? <><td className={r.q_stage === 1 ? 'b' : ''}>{fmtLap(r.q1_ms)}</td><td className={r.q_stage === 2 ? 'b' : ''}>{r.q_stage >= 2 ? fmtLap(r.q2_ms) : ''}</td><td>{r.q_stage === 3 ? fmtLap(r.q3_ms) : ''}</td></> :
                  <td>{isRace ? fmtGap(r, leaderLaps) : (r.position === 1 ? fmtLap(r.best_lap_ms) : r.gap_ms != null ? `+${(r.gap_ms / 1000).toFixed(3)}` : fmtLap(r.best_lap_ms))}{r.status !== 'FIN' && r.dnf_reason ? <span className="muted small"> ({DNF_ES[r.dnf_reason] ?? r.dnf_reason})</span> : null}</td>}
                {isRace && <td>{fmtLap(r.best_lap_ms)}</td>}
                {isRace && <td>{r.pit_stops ?? '—'}</td>}
                {isRace && <td>{(r.strategy ?? '').split('-').filter(Boolean).map((c: string, i: number) => <span key={i} className="tchip" style={{ background: TYRE_COLOR[c] }} title={c}>{TYRE_LETTER[c] ?? c}</span>)}</td>}
                {isRace && <td><b>{r.points || ''}</b></td>}
              </tr>
            ))}
          </tbody>
        </table>
      </Card>
      {tele.data?.summary && (
        <Card title="Tus vueltas">
          <div className="muted small">Paradas en boxes: {tele.data.summary.pit_stops ?? '—'}</div>
          <table className="tbl compact"><thead><tr><th>Vuelta</th><th>Vel. máx</th><th>Acelerador medio</th><th>Freno medio</th><th>Combustible</th></tr></thead>
            <tbody>{tele.data.laps.map((l: Any) => <tr key={l.id}><td>{l.lap}</td><td>{l.max_speed} km/h</td><td>{Math.round(l.avg_gas * 100)}%</td><td>{Math.round(l.avg_brake * 100)}%</td><td>{l.fuel_used} L</td></tr>)}</tbody></table>
        </Card>
      )}
    </div>
  )
}
