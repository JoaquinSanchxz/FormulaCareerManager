# Gestión: finanzas, I+D, fabricación, fiabilidad, mercado, reglamento, eventos

Código: `backend/fcm/management/*`. Configuración: `finance.json`, `development.json`, `components.json`, `market.json`,
`regulations.json`, `events.json`, `physics.json`. Tests: `test_management.py`, `test_physics.py`.
Todas las cifras de dinero son **ficticias** (millones, "M") y configurables; no se usan cifras reales.

Tu piloto pertenece a un equipo y **tú tomas las decisiones técnicas de ese equipo** (pantalla *Mi equipo*).
Si prefieres una trayectoria solo de piloto: *Ajustes → Partida → Delegar la gestión técnica* (la IA del equipo decide por ti).

## Finanzas (`finance.py`)
- **Libro mayor**: cada operación es una fila de `transactions` (tipo, importe, descripción, referencia, si cuenta para el cost cap).
  La caja es un saldo materializado; la fuente de verdad es el ledger.
- Temporada: presupuesto = base por nivel + reputación × factor (× dificultad económica del jugador). Aportación de los accionistas al inicio,
  patrocinadores (pago base por ronda, bonus por objetivo de carrera y de temporada).
- Por ronda: costes operativos, personal, mantenimiento de instalaciones, salarios de pilotos (incluidos los reservas).
- Fin de temporada: premios según la clasificación de constructores, objetivos de los patrocinadores, **cost cap** (multa + penalización de desarrollo del 10 % la temporada siguiente).
- Cost cap configurable por categoría con gastos excluidos (salarios, instalaciones, patrocinio, premios, academia, fichajes…).

## I+D → diseño → fabricación → instalación (`development.py`)
- Departamentos: Aerodinámica, Chasis, Motor (powertrain), Fiabilidad. 13 piezas (alerón delantero/trasero, suelo, difusor, pontones, refrigeración,
  suspensión, frenos, reducción de peso, unidad de potencia, ERS, caja de cambios, paquete de fiabilidad) y 3 alcances (menor/estándar/mayor).
- Proyecto: coste, duración (rondas), ganancia esperada, riesgo. La ganancia depende de la eficiencia de desarrollo, de las instalaciones del departamento,
  de rendimientos decrecientes cerca del techo (92→100) y de la dificultad de desarrollo del jugador.
- Resultado incierto: `failed` / `underperformed` / `expected` / `overperformed` (control de calidad reduce fallos y varianza). Los eventos extremos son poco frecuentes.
- **Una mejora terminada no está montada**: se fabrica (1 o 2 unidades, coste y rondas) y se instala **por piloto** → los compañeros pueden llevar coches distintos.
- Coche en sesión = coche base de la temporada + ganancias de las piezas instaladas en ESE piloto.
- **Coche siguiente**: los proyectos con objetivo el año siguiente van a un banco que se suma al coche nuevo; compiten por dinero, cost cap y capacidad.
- Capacidad de diseño simultáneo = 2 + nivel de personal/2.

## Instalaciones
Fábrica, túnel de viento, CFD, simulador, control de calidad, powertrain, personal (niveles 1–5): velocidad, ganancia, precisión, fiabilidad,
capacidad, coste/tiempo de fabricación. Mejoras con coste (excluido del cost cap) y duración en rondas.

## Fiabilidad, componentes, daños y penalizaciones (`components.py`)
- F1: ICE, TURBO, ERS, ES, CE, GEARBOX por piloto. Desgaste por uso (tipo de sesión, vueltas), fiabilidad del coche y vida del elemento.
- Probabilidad de fallo = base × peso × e^(5·(desgaste−0.8)) × (1.15 − fiabilidad/100): contextual, no RNG puro.
- En sesiones simuladas un fallo se decide antes de la carrera (vuelta concreta) → DNF "mechanical: ICE". El elemento queda roto y se sustituye.
- Cupo por reglamento (4 ICE, 4 TURBO, 3 ERS/ES/CE, 5 cajas). Superarlo: 10 puestos la primera vez, 5 las siguientes, fondo de parrilla si >15.
  La IA prefiere montar elementos extra en circuitos donde es fácil adelantar.
- Daños: accidentes simulados → alerón, suelo, suspensión, caja… con coste de reparación. En sesiones jugadas, daño del coche del jugador leído
  de la shared memory (`carDamage[5]`) durante la sesión.

## Mercado (`market.py`)
- Salarios por nivel/rating/reputación. Reputación separada del rating (rendimiento frente a lo esperado, victorias, podios).
- **Ofertas al jugador** a mitad y final de temporada, con interés calculado frente al piloto sustituible (preferencia por contratos que expiran).
- **Negociación**: propones rol, salario, años y bonus; el equipo acepta, contraoferta o rechaza con razones explícitas
  (interés, valoración salarial, rol frente al compañero, duración, presupuesto, cláusula de rescisión, superlicencia).
- Contratos futuros firmados se respetan al cambiar de temporada. Si cambias de equipo con contrato vigente, el nuevo equipo paga la cláusula.
- **Academias**: cada equipo de F1 tiene academia (jóvenes de F2/F3 con más potencial): coste anual, +5 % de desarrollo, prioridad en ascensos.
- **Superlicencia** (configurable): puntos por posición final en F1/F2/F3 en las últimas 3 temporadas; necesaria para debutar en F1.
- **Reservas**: cada equipo de F1 ficha un reserva (agente libre o piloto de una categoría inferior).
- **Lesiones** (opcional, desactivadas por defecto): tras accidentes simulados; las cubre el reserva.
- Mercado de fin de temporada: renovaciones, retiradas, ascensos F3→F2→F1, rookies generados. Cada fichaje guarda los candidatos y sus puntuaciones.

## Valor de mercado y fichajes a mitad de temporada (`transfers.py`)
- **Valor de mercado** (M€) recalculado cada ronda: exponencial sobre media efectiva (base + forma) frente a un pivote por categoría,
  ajustado por edad/potencial (jóvenes con margen valen más), reputación, contrato restante y racha reciente. `market.json → market_value`.
- Ofertas de mitad de temporada hasta 2 rondas antes del parón de verano. Si aceptas antes del parón, el cambio se ejecuta en el **parón de verano**
  (contrato `pending`); si aceptas después, a **final de temporada**.
- En el parón: se ejecutan los traspasos pendientes y los equipos IA pueden sustituir a pilotos que rinden muy por debajo (máx. 3 movimientos,
  probabilidad y mejora mínima configurables en `market.json → midseason`). El equipo que pierde un piloto **busca reemplazo antes** de que se vaya:
  reserva, agente libre o piloto de otra categoría (superlicencia para F1), valorando rating, potencial, racha y forma; cascada si deja otro hueco.
- Pilotos inventados solo al generar rookies, y solo en la categoría más baja; las vacantes superiores se cubren ascendiendo.

## Reglamento (`regulations.py`)
RegulationSet por temporada y categoría: límites de componentes, penalizaciones, sistema de puntos opcional, cost cap opcional.
Cambio reglamentario importante cada 5 temporadas (el primero tras 3), **anunciado un año antes**: los coches convergen (factor 0.35),
no se arrastran las mejoras actuales y el banco del coche siguiente vale ×1.6. La IA reparte más recursos al año siguiente.
Entre temporadas, un ajuste reglamentario devuelve la media de la parrilla a su nivel base: se mantiene el orden relativo sin inflación a largo plazo.

## IA de los equipos
Cada equipo tiene estrategia (equilibrada, agresiva, conservadora), tolerancia al riesgo y reparto actual/siguiente. Decide qué desarrollar
(sus áreas más débiles frente a la parrilla, ponderadas por los próximos circuitos), tamaño del proyecto, fabricación, instalación, motores e instalaciones.
Nunca usa la posición del jugador (sin rubber-banding).

## Eventos (`events.py`, `events.json`)
Técnicos, financieros, de patrocinio, instalaciones, equipo y piloto, con condiciones, probabilidad, cooldown, opciones y efectos.
Los tuyos esperan decisión en *Decisiones* (si no decides antes de la siguiente ronda, el equipo elige); los de la IA se resuelven solos.

## Récords, hitos y telemetría
Campeones, líderes históricos (títulos, victorias, poles, podios, VR, salidas, puntos). Hitos reales (primera victoria, 10ª, 100 salidas…) generan noticias.
Telemetría opcional del jugador vía shared memory (velocidad máxima, uso de acelerador/freno, combustible, desgaste por vuelta) en una **base de datos separada**
(`saves/telemetry/<partida>.sqlite`); en la partida solo se guardan paradas en boxes detectadas y daño máximo.

## Física avanzada (experimental, desactivada)
Ver `CAR_PERFORMANCE.md`: copias gestionadas por piloto con BASE + modificadores; solo coches con `data/` desempaquetado.
