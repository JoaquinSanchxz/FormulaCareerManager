# Desarrollo

## Entorno

```
pip install -r backend/requirements-dev.txt
cd frontend && npm install
```
- Backend desde código: `python backend/fcm/main.py [--port N] [--no-browser] [--browser]`
- UI en caliente: `npm run dev` (Vite en :5173 con proxy a :47820)
- Variables útiles: `FCM_DATA_DIR` (carpeta de datos), `FCM_AC_DOCUMENTS` (Documents/Assetto Corsa alternativo),
  `FCM_ACS_COMMAND` (JSON con comando que sustituye a acs.exe; **solo tests**).

## Tests

`python -m pytest -q backend/tests` (≈10 s):

| Fichero | Cubre |
|---|---|
| `test_rating.py` | progresión, forma, límites, edad, fin de temporada (ejemplos §73, §97–99) |
| `test_progression_100_seasons.py` | 100 temporadas (§74) con métricas (`-s` para verlas) |
| `test_ac_integration.py` | validación de instalación, VDF de Steam, escáner, JSON tolerante, rutas seguras, race.ini, parser de race_out |
| `test_career_flow.py` | creación, temporada simulada, puntos, clasificación, estadísticas, cambio de temporada, cerrar/reabrir |
| `test_mvp_e2e.py` | flujo MVP §86 completo con el launcher real y un `acs.exe` falso (`tests/fake_ac.py`) |
| `test_management.py` | ledger y cost cap, I+D → fabricación → instalación por piloto, capacidad, cupo de motores y penalizaciones, desgaste, salarios y negociación, contrato futuro y cambio de equipo, eventos, 4 temporadas sin inflación con cambio reglamentario y récords |
| `test_physics.py` | copias gestionadas: original intacto, BASE + modificadores no acumulativos, coches empaquetados rechazados, limpieza segura |

## Añadir una categoría

1. `data/config/categories.json`: nueva clave (tier, formatos de fin de semana, distancias, velocidad base).
2. `data/config/points_systems.json`: sistema de puntos.
3. Plantilla/importación: equipos en `categories.<CÓDIGO>.teams`.

## Añadir una migración

`backend/fcm/database/migrations/career/002_descripcion.sql`. Se aplica automáticamente al abrir cada partida.

## Añadir un endpoint

`backend/fcm/api/routes.py` con `@route('GET', '/api/...')`. Sin SQL en el handler: lógica en `career_engine/*`.

## Estilo

Código compacto y consistente; configuración en JSON, no números mágicos en el código; funciones puras para los modelos.
