# Base de datos

SQLite, dos tipos de fichero, ambos con migraciones SQL versionadas (`backend/fcm/database/migrations/<tipo>/NNN_nombre.sql`,
tabla `schema_migrations`, aplicadas en transacción al abrir):

## `app.sqlite` (global del usuario)

| Tabla | Contenido |
|---|---|
| `settings` | clave → JSON (ruta de AC, última partida…) |
| `scan_runs` | historial de escaneos con avisos |
| `ac_cars`, `ac_car_skins` | catálogo de coches instalados y sus skins (`installed_content`) |
| `ac_tracks`, `ac_track_layouts` | circuitos y layouts (longitud, boxes, país, previews) |
| `ac_weathers` | climas disponibles |

## `<partida>.fcm` (una por trayectoria)

| Área | Tablas |
|---|---|
| Partida | `career` (semilla, jugador, temporada actual, dificultad/realismo/ajustes JSON) |
| Estructura | `categories` (config de formato por partida), `seasons`, `championships` (coche AC por categoría y temporada, modo jugador) |
| Mundo | `teams`, `drivers`, `driver_attributes` (atributos + base_rating), `contracts`, `championship_entries` (dorsal, skin, rol) |
| Coches | `car_performance` (componentes por temporada y equipo), `team_performance_history` |
| Calendario | `track_profiles`, `calendar_rounds` (circuito/layout AC), `sessions` (formato, parrilla, semilla, estado) |
| Sesión | `session_entries` (índice CAR_n, AI_LEVEL, agresividad, lastre, restrictor, desglose de traducción) |
| Resultados | `results` (jugados y simulados, `source`), `laps`, `raw_results` (JSON bruto + race.ini usado) |
| Rendimiento | `driver_performance` (esperado vs real, compañero, puntuación, confianza), `driver_rating_history` (cada cambio + razones) |
| Histórico | `standings_snapshots` (por ronda), `snapshots` (estado antes de cada ronda) |
| Eventos | `domain_events` (event sourcing), `news` |

Convenciones: timestamps `create_ts` / `update_ts` (UTC ISO), columnas sin prefijo de tabla, JSON en columnas `*_json`.
Las clasificaciones se **derivan** de `results` (nunca se recalcula destructivamente el pasado); los snapshots guardan la foto por ronda.

Guardado/export/import: el `.fcm` es la partida completa. Autosave = copia con la API de backup de SQLite en `saves/autosave`
(antes/después de cada sesión, al avanzar, antes y después de cerrar temporada; se conservan las últimas N).

### Migración `002_management.sql` (fases 5–8)

| Área | Tablas |
|---|---|
| Finanzas | `team_finances` (caja, presupuesto, cost cap gastado), `transactions` (ledger), `sponsors` |
| Desarrollo | `development_projects`, `parts` (specs diseñadas), `manufacturing_orders`, `part_installations` (por piloto), `next_season_bank`, `facilities`, `team_ai` |
| Fiabilidad | `power_components` (ICE/TURBO/ERS/ES/CE/GEARBOX por piloto con desgaste), `penalties`, `damage_reports` |
| Mercado | `offers` (ofertas y negociaciones con razones), `academies`, `academy_members`, `injuries` |
| Mundo | `regulations` (RegulationSet por temporada/categoría), `game_events` (eventos con decisiones) |
| Telemetría | `player_telemetry` (resumen); las vueltas detalladas van a `saves/telemetry/<partida>.sqlite` (BD separada) |

Las migraciones se aplican solas al abrir partidas antiguas.
