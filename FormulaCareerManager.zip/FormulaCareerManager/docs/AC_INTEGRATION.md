# Integración Assetto Corsa ↔ Career Manager (AC Bridge)

Regla: no se usa ninguna función de AC sin verificar la fuente. Lo no verificable queda configurable y marcado.

## 1. Detección de la instalación (`ac_integration/detect.py`)

Orden de búsqueda:
1. Ruta guardada por el usuario (`settings.ac_root`).
2. Registro: `HKLM\...\Uninstall\Steam App 244210\InstallLocation` (244210 = app id de AC).
3. Steam: `HKCU\Software\Valve\Steam\SteamPath`, `HKLM\SOFTWARE\WOW6432Node\Valve\Steam\InstallPath`.
4. Bibliotecas adicionales en `<steam>\steamapps\libraryfolders.vdf` (formato antiguo y nuevo) → `<lib>\steamapps\common\assettocorsa`.
5. Rutas típicas en todas las unidades (`X:\SteamLibrary\…`, `X:\Steam\…`, `X:\Games\…`).
6. Selector manual.

Validación: existe `acs.exe`, `content\cars` y `content\tracks`. La ruta se guarda y no se vuelve a pedir.
Extras: CSP (`dwrite.dll` + `extension\`, versión en `extension\config\data_manifest.ini`), Content Manager (`%LOCALAPPDATA%\AcTools Content Manager`),
Steam/acs.exe en ejecución (`tasklist`). Carpeta Documentos real vía `SHGetKnownFolderPath(FOLDERID_Documents)` (soporta OneDrive).

## 2. Escáner (`scanner.py`) — solo lectura

| Dato | Fuente |
|---|---|
| Coche: nombre, marca, año, clase, tags, specs, país, autor | `content/cars/<id>/ui/ui_car.json` |
| Física empaquetada / desempaquetada | existencia de `data.acd` / `data/` |
| Skins | `skins/<skin>/ui_skin.json` (`skinname, drivername, team, number, country, priority`), `preview.jpg`, `livery.png` |
| Circuito un layout | `content/tracks/<id>/ui/ui_track.json` (+ `preview.png`, `outline.png`), datos en `<id>/data` |
| Circuito multi-layout | `content/tracks/<id>/ui/<layout>/ui_track.json`, datos en `<id>/<layout>/data` |
| Longitud / boxes / país | `length` (texto libre: "5.3 km", "5793m", "2 mi" → metros), `pitboxes` |
| Clima | `content/weather/<id>/weather.ini` |

Los JSON de mods suelen estar rotos (BOM, saltos de línea dentro de strings, comas finales, comentarios, cp1252):
`lenient_json.py` los repara. Sin UI json se infieren layouts por `models_<layout>.ini`. Nada se asocia automáticamente
a categorías/rondas: el usuario confirma coche por categoría y circuito por ronda.

## 3. Generación de la sesión (`race_ini.py`)

Se escribe `Documents\Assetto Corsa\cfg\race.ini`. Claves verificadas contra el escritor de Content Manager
(gro-ove/actools, `AcTools/Processes/Game.Properties.cs`):

- `[RACE]` TRACK, CONFIG_TRACK, MODEL, MODEL_CONFIG, SKIN, CARS, AI_LEVEL, FIXED_SETUP, PENALTIES, JUMP_START_PENALTY, DRIFT_MODE, RACE_LAPS
- `[CAR_0]` jugador: `MODEL=-`, SKIN, SETUP, BALLAST, RESTRICTOR, DRIVER_NAME, NATIONALITY, NATION_CODE
- `[CAR_n]` IA: MODEL, SKIN, **AI_LEVEL (0–100 por coche)**, **AI_AGGRESSION (por coche)**, DRIVER_NAME, BALLAST, RESTRICTOR…
- `[SESSION_0]` NAME, TYPE (1 práctica, 2 clasificación, 3 carrera), DURATION_MINUTES, SPAWN_SET (PIT / START), LAPS, STARTING_POSITION
- `[LIGHTING] SUN_ANGLE = 16·(segundos − 46800)/3600` (fórmula de CM), `[WEATHER] NAME`, `[TEMPERATURE]`, `[WIND]`, `[GROOVE]`, `[DYNAMIC_TRACK]`, `[AUTOSPAWN] ACTIVE=1`

Parrilla: coches `CAR_1..N` en orden de parrilla y posición del jugador en `STARTING_POSITION`.
Todos los ids (coche, skin, pista, layout) pasan `safe_id` (sin separadores ni `..`), la escritura es atómica y el
`race.ini` original se respalda en `backups/race_ini` y se restaura al terminar.

## 4. Lanzamiento y fin de sesión (`launcher.py`)

1. Validaciones (`sessions.prepare_play`): AC configurado, coche asignado y escaneado, pista/layout escaneados, boxes ≥ coches, jugador inscrito.
2. Autosave "before_…".
3. `acs.exe` con `cwd = raíz de AC` (mismo método que Content Manager). Steam debe estar en ejecución.
4. Hilo en segundo plano espera la salida del proceso; durante la sesión se lee la **shared memory** para el estado en vivo.
5. Se acepta `Documents\Assetto Corsa\out\race_out.json` solo si su fecha es posterior al lanzamiento.
6. Importación → puntos → evidencia de rendimiento → autosave "after_…".
7. Si no hay resultado (AC se cerró enseguida, Steam cerrado, sesión abortada) la sesión vuelve a *pendiente* con un mensaje claro.
   Fallback manual: *Importar race_out.json manualmente*.

## 5. Resultados (`results.py`)

`race_out.json`: `players[{name, car, skin}]`, `sessions[{name, type, lapsCount, laps[{car, lap, time, sectors, cuts, tyre}], lapstotal, bestLaps, raceResult}]`
(estructura contrastada con el lector de *simresults*). El índice `car` = sección `CAR_n` de race.ini → mapeo exacto a pilotos
(se valida además el nombre; discrepancias = aviso).

## 6. Qué datos son fiables y cuáles necesitan fallback

| Dato | Estado | Fuente / fallback |
|---|---|---|
| Orden final de carrera | **Fiable** | `raceResult` (si falta: vueltas + tiempo total) |
| Vueltas, tiempos por vuelta, sectores, cortes, compuesto | **Fiable** | `laps[]` |
| Mejor vuelta / vuelta rápida | **Fiable** | calculada de vueltas sin cortes; `bestLaps` como respaldo |
| Tiempo total, gap | **Fiable** | suma de vueltas |
| Posición de salida | **Fiable** | la genera el Career Manager |
| DNS | Inferido | 0 vueltas |
| DNF | **Inferido** | menos vueltas que el líder y tiempo total + 1,5 vueltas < tiempo del líder (distingue doblado de retirado) |
| Causa del DNF | No disponible | se trata como "desconocida" (confianza de evidencia reducida) |
| Paradas en boxes | No en race_out | **jugador**: transiciones de `isInPit` en shared memory durante la carrera; IA: `NULL` |
| Daños | No en race_out | **jugador**: máximo de `carDamage[5]` (SPageFilePhysics) durante la sesión → costes de reparación; IA: no disponible |
| Telemetría por vuelta | No en race_out | jugador: velocidad máxima, acelerador/freno medios, combustible y desgaste (BD separada) |
| Penalizaciones | Parcial | los cortes (`cuts`) sí; sanciones de tiempo no |
| Estado en vivo (vuelta, posición, pausa, tiempos) | **Fiable con AC abierto** | shared memory `acpmf_graphics/static` (solo lectura, `OpenFileMappingW`) |
| Lluvia | No en AC vanilla | solo simulación; las sesiones jugadas se generan en seco |
| AI_AGGRESSION por coche | Verificar en tu instalación | escala configurable en `ai_mapping.json` (`output_scale`) |

## 7b. Hora, clima y estrategia
- **Requisito para jugar**: CSP activo con WeatherFX controlado por el launcher (`WEATHERFX_LAUNCHER_CONTROLLED` en `data_manifest.ini [FEATURES]`,
  `weather_fx.ini` activo) y Rain FX (`rain_fx.ini` activo). Sin eso JUGAR muestra el error y la sesión solo puede simularse.
- Hora = hora real de salida del GP (`calendar_rounds.start_time`) con desfase por sesión (`ac_session.json → session_times`). El jugador **no** puede
  cambiar hora ni clima; solo la estrategia.
- **Clima dinámico** (`simulation/weather.py`, `ac_session.json → weather_states / weather / climates`): cada sesión tiene un *plan* = estados
  (despejado … cubierto, niebla, llovizna, lluvia débil, lluvia, lluvia fuerte, tormenta) a lo largo del progreso de la sesión (0–1), generado con una
  cadena de Markov sembrada. Cada ronda puede tener un sistema de lluvia (`rain_chance` del clima, compartido por F1/F2/F3 ese fin de semana);
  sin él solo hay chubascos aislados raros. El plan es estable una vez generado y el mismo en simulación y en AC.
- **En AC**: el Career Manager escribe su propio controlador de WeatherFX en `<AC>\extension\weather-controllers\fcm\` (`manifest.ini` +
  `controller.lua` con el plan) y lo selecciona con `[LIGHTING] __CM_WEATHER_CONTROLLER=fcm`, `__CM_WEATHER_TYPE=<estado inicial>`. El Lua avanza el
  plan por vueltas del líder (carreras) o por tiempo de conducción (libres/clasificación; cada fase Q1/Q2/Q3 recibe su tramo del plan), hace
  transiciones suaves (`currentType`/`upcomingType`/`transition`) y acumula charcos (`rainWater`). API verificada en el SDK Lua de CSP
  (`acc-lua-sdk`: `common/ac_weatherconditions.lua`, `common/ac_enums.lua`) y en el controlador `base` de `acc-extension-config`. No se modifica nada de CSP.
- **En simulación**: humedad de pista vuelta a vuelta (sube rápido con la lluvia y seca despacio); ritmo, errores y abandonos escalan con la humedad;
  slicks en mojado penalizan mucho (`tyres.wet_penalty`); cada piloto cambia a intermedios/lluvia/slicks cuando lo que gana en las próximas vueltas
  compensa la parada (con un factor de riesgo propio), así que hay quien acierta y quien no.
- **Noche**: si CSP declara `CONDITIONS_24H` en `data_manifest.ini [FEATURES]`, `SUN_ANGLE` se escribe sin límite (p. ej. 20:00 → 112). Sin CSP se limita a 08:00–18:00.
- **Estrategia**: compuestos por stint (S/M/H/I/W) y vueltas de parada (F1 en seco obliga a 2 compuestos de slick). Neumático de salida y combustible se escriben en
  `Documents\Assetto Corsa\setups\<coche>\<pista>\fcm_strategy.ini` (`[FUEL] VALUE`, `[TYRES] VALUE=<índice en data/tyres.ini>`) y se cargan con `[CAR_0] SETUP`.
- **Q1/Q2/Q3**: cada fase se lanza como una clasificación de AC con los coches que siguen vivos; si te eliminan, el resto se simula.

## 7. Limitaciones conocidas y a validar en tu PC

- La correspondencia `AI_LEVEL` ↔ rating de carrera **debe calibrarse** con tu coche/circuito (`ai_mapping.json`).
- `STARTING_POSITION` + orden de `CAR_n` define la parrilla; verifica en tu primera carrera que la IA sale en el orden mostrado en la vista previa.
- Prácticas con IA en una sesión única TYPE=1: soportado por AC en modo fin de semana; si tu versión solo te pone a ti en pista, simúlalas.
- Por defecto no se modifican físicas: el rendimiento del coche se traduce a lastre/restrictor/nivel IA (§77). El módulo de física avanzada
  (experimental) genera copias gestionadas y nunca toca el coche original (ver CAR_PERFORMANCE.md).
- La escala de `carDamage` depende del coche: calibra `components.json → ac_damage_scale`.
