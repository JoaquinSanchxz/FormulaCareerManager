# Arquitectura

## Stack definitivo y justificación

| Capa | Elección | Por qué |
|---|---|---|
| Backend / dominio | **Python 3.12, solo librería estándar** (`sqlite3`, `http.server`, `ctypes`, `winreg`, `subprocess`) | La integración con AC es más simple en Python (shared memory vía `ctypes`, registro de Windows, procesos). Sin dependencias de runtime → empaquetado robusto. |
| Base de datos | **SQLite** con migraciones SQL versionadas | Offline, un fichero por partida (guardar/exportar = copiar). |
| UI | **React 18 + TypeScript + Vite** | Pedido en la especificación. CSS propio (identidad visual propia, sin librerías visuales). |
| Contenedor de escritorio | Servidor local `127.0.0.1` + ventana **Edge/Chrome `--app`** con perfil propio | **Tauri no es viable aquí**: requiere toolchain Rust (no disponible). Electron añade ~150 MB. Edge (WebView2/Chromium) viene con Windows 10/11, así que la ventana de app nativa existe en cualquier PC sin instalar nada. Fallback: navegador por defecto. |
| Empaquetado | **PyInstaller onedir** | `dist/FormulaCareerManager/FormulaCareerManager.exe`, sin Python en destino. Onefile descartado: se comprobó que el antivirus/EDR corporativo lo borra a los pocos segundos. |

La vida del proceso: si la ventana `--app` se cierra y no hay una sesión de AC en curso, el servidor termina.
En modo navegador, se apaga tras `idle_shutdown_s` sin latido (`/api/heartbeat` cada 5 s). Nunca se apaga con AC en marcha.

## Estructura de carpetas

```
FormulaCareerManager/
├─ backend/
│  ├─ fcm/
│  │  ├─ main.py               entrada: servidor + ventana
│  │  ├─ api/                  http.py (servidor JSON + estáticos), routes.py (REST, sin SQL)
│  │  ├─ ac_integration/       AC BRIDGE: detect, scanner, catalog, race_ini, launcher, results, shared_memory, diagnostics
│  │  ├─ career_engine/        dominio: store (partidas), world_builder, sessions, championship, rating, progression,
│  │  │                        translator (Performance/AI translator), weekend, editor, queries, repo
│  │  ├─ simulation/           model.py (fuerzas coche/pista/piloto), engine.py (simulador vuelta a vuelta)
│  │  ├─ management/           finance, development (I+D/fabricación/instalaciones/IA), components (fiabilidad/penalizaciones/daños),
│  │  │                        market (contratos/ofertas/academias/superlicencia), regulations, events, records, lifecycle, team_view
│  │  ├─ database/             db.py + migrations/app/*.sql + migrations/career/*.sql
│  │  └─ shared/               paths, log (categorías), config (data-driven), rng (sembrado), safefs, lenient_json
│  ├─ tests/                   pytest (+ fake_ac.py: instalación AC y acs.exe falsos SOLO para tests)
├─ frontend/                   React/TS (src/pages/*), build → frontend/dist
├─ data/
│  ├─ config/                  TODOS los parámetros de balance (JSON)
│  ├─ templates/               mundo ficticio por defecto + pool de nombres
│  └─ schemas/                 world.schema.json (importación de parrilla)
├─ docs/                       esta documentación
├─ FormulaCareerManager.spec   PyInstaller
├─ build.bat / run_dev.bat
```

(Equivalente a la propuesta `/apps /packages` de la especificación, adaptada a un único backend Python:
`ac_integration` = ac-bridge/ac-integration, `career_engine` + `simulation` = domain/career-engine/simulation,
`database` = database, `shared` = shared, `frontend` = desktop/ui.)

## Capas y dependencias

```
frontend (React) ──HTTP JSON──► api/routes ──► career_engine (servicios) ──► database / simulation / ac_integration
                                                  ▲
                              simulation.model / rating.py / translator.py = funciones puras (sin BD, testeables)
```

- El dominio **no depende de la UI**. Los handlers HTTP solo validan y delegan; todo el SQL vive en servicios/`repo`/`queries`.
- Funciones puras: `rating.py` (evidencia, forma, rating, fin de temporada), `simulation/engine.py`, `simulation/model.py`,
  `translator.py`, `race_ini.py`, `results.py`. Son las que cubren los tests de modelo.

## Servicios de dominio (mapeo con la especificación §88)

| Especificación | Implementación |
|---|---|
| CareerService | `store.py` (partidas, autosave, export/import), `world_builder.py` (creación) |
| ChampionshipService | `championship.py` (puntos, clasificaciones, estadísticas, snapshots) |
| SessionService / ResultService | `sessions.py` (parrilla, simular, preparar/lanzar AC, importar) |
| DriverDevelopmentService | `rating.py` + `progression.complete_championship_weekend / finish_season` |
| CarPerformanceService | `simulation/model.py` + `management/development.driver_car` + `lifecycle.next_season_cars` + `ac_integration/physics.py` |
| MarketService | `management/market.py` (ofertas, negociación, academias, superlicencia, reservas, mercado de fin de temporada) |
| FinanceService | `management/finance.py` (ledger, patrocinadores, premios, cost cap) |
| DevelopmentService | `management/development.py` (I+D, fabricación, instalación por piloto, instalaciones, IA) |
| SimulationService | `simulation/engine.py` |
| ACIntegrationService / ContentScannerService | `ac_integration/*` |

## Event sourcing y auditoría

Tabla `domain_events` (append-only): `CAREER_CREATED, SESSION_FINISHED, RESULT_IMPORTED, RATING_UPDATED, ROUND_COMPLETED,
UPGRADE_COMPLETED, UPGRADE_FAILED, CONTRACT_DECISION, CONTRACT_SIGNED (con candidatos y puntuaciones), DRIVER_PROMOTED,
ROOKIE_GENERATED, DRIVER_RETIRED, CHAMPION_CROWNED, SEASON_FINISHED, SEASON_STARTED, CATEGORY_CAR_ASSIGNED, ROUND_TRACK_ASSIGNED`.
Las noticias se generan solo desde eventos reales. Cada cambio de rating guarda sus razones (`driver_rating_history.reasons_json`).
Antes de cada ronda se guarda un snapshot (`snapshots`: ratings, coches, contratos).

## Determinismo

`career.seed` → `derive_seed(seed, claves…)` (SHA-256, 63 bits) para temporada, sesión, clima, desarrollo, mercado.
Misma semilla + mismas decisiones = mismos resultados simulados.

## Configuración data-driven

`data/config/*.json`, sobrescribibles por el usuario (`%APPDATA%/FormulaCareerManager/config/<nombre>.json`, merge profundo)
desde **Ajustes → Configuración**: `progression` (rating/forma/moral/edad/retiradas/rookies), `simulation`, `ai_mapping`,
`car_performance_mapping`, `car_model`, `track_archetypes`, `categories` (formatos de fin de semana, distancias),
`points_systems`, `ac_session` (secciones de race.ini), `app`.

## Logging

`logs/fcm.log` rotativo, categorías `AC, SESSION, DATABASE, CAREER, SIMULATION, DRIVER, CAR, API, ERROR…`.
**Diagnóstico → Exportar informe** genera un zip con informe, logs, race.ini, race_out.json y log.txt de AC.

## Decisiones técnicas (resumen)

- Una sesión de AC por lanzamiento (no "race weekend" multi-sesión): importación inequívoca y reintentos sencillos.
- El `race.ini` del usuario se respalda antes y se **restaura** al terminar.
- Sesiones "running" huérfanas (app cerrada con AC abierto) se recuperan al reabrir la partida; además, importación manual de `race_out.json`.
- Clasificación en formato único (AC no tiene Q1/Q2/Q3 nativo); el formato es configurable por categoría.
- La lluvia solo se simula (AC vanilla no tiene lluvia); las sesiones jugadas son en seco.
