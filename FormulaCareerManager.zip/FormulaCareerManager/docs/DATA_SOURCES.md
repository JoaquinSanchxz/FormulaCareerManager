# Fuentes de datos de la plantilla `real_2026`

Plantilla por defecto: `data/templates/real_2026.json` (parrillas, ratings, calendario). Se puede editar o sustituir por JSON/CSV propio.

## Ratings
- **F1**: medias y sub-ratings (experiencia, racecraft, awareness, pace) de EA Sports F1 25 *2026 Season Pack* (actualización de junio de 2026),
  publicadas en la web oficial de EA y en ClutchPoints (ratings de lanzamiento). Los 12 atributos del juego se derivan con `attrs_from_ea`
  (se conservan pace/racecraft/awareness/experience y el resto se deriva; la base coincide con la media EA).
- **F2 y F3**: EA no publica ratings. **Estimados** a partir de trayectoria, resultados 2025–2026 (clasificaciones FIA F2/F3, Formula Scout),
  edad y academia. Rango F2 ≈ 68–80, F3 ≈ 60–74.
- **Fuerza de coche**: estimada según el rendimiento 2026 de cada equipo.

## Parrillas y calendario
- Wikipedia: *2026 Formula One World Championship*, *2026 FIA Formula 2 Championship*, *2026 FIA Formula 3 Championship*.
- Calendario F1 2026 de 23 rondas (GP de Arabia Saudí cancelado; GP de Bahréin disputado en Sepang), horarios locales de salida,
  carreras nocturnas (Singapur, Las Vegas, Catar, Abu Dabi), 6 sprints (China, Miami, Canadá, Gran Bretaña, Países Bajos, Singapur),
  parón de verano tras Hungría. F2 14 rondas, F3 9 rondas.
- Ajustes F3: Maccagnani en VAR #14 (Yamakoshi pasó a F2), Ho de vuelta en Rodin #19, Benavides en AIX #26.

## Formatos y distancias
- F1: FP1 + Q1/Q2/Q3 (18/15/12 min, eliminados 6 + 6) + carrera de vueltas mínimas que superan 305 km (Mónaco 260 km). Sprint: SQ1/SQ2/SQ3 (12/10/8) + sprint 100 km.
- F2/F3: formato real (libres, clasificación única 30 min, sprint con parrilla invertida top 10/12, carrera principal).
  Distancias usadas: principal 152,5 km (mitad de F1, lo pedido), sprint 101,7 km.
- Puntos F1 2025+: 25-18-15-12-10-8-6-4-2-1 (sin punto por vuelta rápida); sprint 8-7-6-5-4-3-2-1.

## Assetto Corsa
- Claves de `race.ini` y setups: código fuente de Content Manager (gro-ove/actools).
- Funciones CSP (noche, lluvia): `extension/config/data_manifest.ini [FEATURES]` de la instalación de CSP (ver AC_INTEGRATION.md §7b).
