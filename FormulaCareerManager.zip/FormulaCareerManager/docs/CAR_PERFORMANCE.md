# Rendimiento del coche

## Componentes (`car_performance`, por equipo y temporada)

power, energy_recovery, low/medium/high_speed_downforce, drag_efficiency, traction, mechanical_grip, braking, weight,
tyre_usage, cooling, reliability (+ development_efficiency, que no suma a la fuerza).
`overall_strength` **nunca se guarda como entrada**: siempre se deriva con `car_model.json → overall_weights`.

## Perfil de pista (`track_profiles`)

Importancias 0–1: power, drag, low/medium/high speed, traction, braking, tyre + `overtaking_difficulty`, `wet_probability`.
Cada ronda tiene su perfil (arquetipos en `track_archetypes.json`: balanced, power, high_downforce, street, fast_flowing,
stop_start, tyre_limited), editable por ronda.

Fuerza en pista: `Σ comp · peso`, donde `peso(comp) = always_weights + Σ_importancias imp · share` (`car_model.json → track_mapping`).
Así un coche peor en global puede ser mejor en Monza (power/drag) y peor en Mónaco (low speed/traction).
La UI muestra el ranking global y el **ranking esperado en la próxima pista**.

## Evolución

- **En temporada**: proyectos de I+D → piezas → fabricación → instalación por piloto (ver `MANAGEMENT.md`). El coche de cada piloto =
  coche base + piezas instaladas en él. Sin rubber-banding: la posición del jugador no es una entrada.
- **Nueva temporada** (`lifecycle.next_season_cars`): `nuevo = base + 0.5·(mejoras instaladas) + (media − x)·0.3 + N(0, 0.8) + (eff − 75)·0.04 + banco I+D siguiente`;
  después un ajuste reglamentario devuelve la media de la parrilla a su nivel de la primera temporada (sin inflación, se conserva el orden).
  Cambio reglamentario importante: convergencia fuerte (factor 0.35), sin arrastre de mejoras, banco ×1.6.

## Performance Translator (a Assetto Corsa)

Todos los equipos comparten normalmente el mismo modelo de AC, así que la diferencia de coche se emula (fase 1, sin tocar físicas):

| Entrada | Parámetro AC | Config |
|---|---|---|
| Déficit vs el mejor coche en esa pista | `BALLAST` kg (1.5/punto, máx 30) y `RESTRICTOR` % (0.6/punto, máx 8), zona muerta 0.3 | `car_performance_mapping.json` |
| Fuerza del coche vs media del campo | ± `AI_LEVEL` (0.25/punto) | `ai_mapping.json → car_to_ai_level` |
| Rating de carrera/clasificación del piloto (+forma, moral) | `AI_LEVEL` por curva calibrable | `ai_mapping.json → ai_level_points` |
| racecraft / awareness | `AI_AGGRESSION` | `ai_mapping.json → aggression` |

Cada inscripción guarda el desglose de la traducción (`session_entries.translation_json`) y la vista previa de la sesión lo muestra.

## Calibración recomendada

1. Corre una carrera corta con 5 niveles de IA conocidos y compara ritmo real: ajusta `ai_level_points`.
2. Prueba lastre/restrictor en tu coche: ¿cuántas décimas por kg? Ajusta `ballast_kg_per_point` / `restrictor_pct_per_point`
   para que 1 punto de coche ≈ la diferencia de tiempo del simulador (`laptime_per_point` = 0.13%/punto de fuerza).
3. Todos los overrides se guardan en tu carpeta de usuario (Ajustes → Configuración).

## Física avanzada (§16–18) — experimental, desactivada por defecto (`physics.json`)

Contenido AC → *Física avanzada* → Activar. Antes de cada sesión jugada se generan copias gestionadas **por piloto**
(`content/cars/fcm_<coche>__<equipo><dorsal>/`, marcador `fcm_managed.json`):
- ficheros grandes (kn5, dds) con **enlaces duros** (sin espacio extra); el resto copiado; tu coche original nunca se modifica
- física base inmutable guardada una vez en `%APPDATA%/FormulaCareerManager/physics_base/<coche>/`
- siempre `BASE + MODIFICADORES` (nunca acumulativo): `power.lut` par × (1 + potencia%), `aero.ini` `CL_GAIN`/`CD_GAIN`, `car.ini` `TOTALMASS`
- modificadores = componentes del coche del piloto frente a la media (0.4 %/punto, máx ±3 %; peso 1.5 kg/punto, máx ±15 kg)
- con física activa, lastre/restrictor se anulan y el ajuste de IA por coche se reduce a la mitad (sin doble conteo)
- solo coches con `data/` desempaquetado; con `data.acd` se sigue usando lastre/restrictor/IA
- *Eliminar copias gestionadas* borra solo carpetas con el marcador
Validar en tu PC antes de usarlo en serio (§77).
