# Modelo de rating de pilotos

Código: `backend/fcm/career_engine/rating.py`. Parámetros: `data/config/progression.json`. Tests: `test_rating.py`, `test_progression_100_seasons.py`.

## Magnitudes separadas

| Magnitud | Escala | Velocidad | Uso |
|---|---|---|---|
| Atributos (12) | 30–99.5 | lenta | pace, qualifying, racecraft, awareness, consistency, tyre_management, wet_skill, starts, defending, overtaking, adaptability, experience |
| **Base rating** | media ponderada de atributos (`attribute_weights`) | lenta, con límites | talento permanente |
| **Forma** | −3…+3 | rápida, decae a 0 | rendimiento inmediato (1–5 carreras) |
| **Moral** | 5…100 (neutral 60) | media | efecto limitado ±0.5 |
| **Potencial** | techo estimado | converge con la edad | no es destino garantizado |
| Rendimiento efectivo | base + forma + efecto_moral | — | simulación y traducción a IA |

## 1. Evidencia por sesión (qualifying, sprint, race)

Para cada sesión se calcula la **fuerza esperada** de cada coche sin ruido:
`perf = w_car · coche_en_pista + w_driver · piloto_efectivo` (`simulation.json`).

Posición esperada (probabilística, no por ordenación): `E[pos_i] = 1 + Σ_j σ((perf_j − perf_i)/s)` con s = `expected_sigma`.

- Término de posición: `P = (E[pos] − pos_real)/(N−1) · position_scale`
- Término compañero (mismo coche):
  - clasificación: `T = clamp((Δ% real − Δ% esperado)·k_q, ±cap)`, con Δ% esperado = diferencia de fuerza × `laptime_per_point`
  - carrera: `T = clamp(((pos_c − pos) − (E_c − E))/(N−1)·k_r, ±cap)`
- `raw = 0.6·P + 0.4·T` (solo P si no hay compañero comparable)
- Saturación: `score = S·tanh(raw/S)` (S=2.5) → una actuación irreal no produce valores extremos.
- Confianza: jugador humano 1.0, IA de AC 0.5 (su resultado depende de AI_LEVEL), simulado 0.8.
  DNF mecánico = 0 (no es evidencia), accidente 0.6, causa desconocida 0.4 (y posición = N).

Esto implementa "no sobrevalorar posiciones": P18→P10 con un coche rápido puede ser neutro; P8 con un Williams puede ser excelente.

## 2. Fin de semana (escala A + B)

`score_w = Σ w_t·c_t·score_t / Σ w_t·c_t` (pesos qualifying 0.35, sprint 0.2, race 0.45), `conf = Σ w_t·c_t / Σ w_t`.

**Forma**: `form' = clamp(form·0.7 + score_w·0.7·conf, −3, 3)` → decae hacia 0 (regresión a la media).
**Moral**: `m' = clamp(m + 3·score_w·conf + (60 − m)·0.08)`.

**Base rating** (lento):
```
inmediato = score_w · conf · rate(0.04) · dev_rate · f_edad(±) · f_potencial · (0.6 si negativo)
trend     = EMA(score_w·conf, α=0.2)
tendencia = trend · 0.03 · n/(n+5) · dev_rate · f_edad · f_potencial          (n = fines de semana de la temporada)
Δ = inmediato + tendencia
límites: |Δ| ≤ 0.08 por carrera; |Σ últimas 5| ≤ 0.30; |Σ temporada| ≤ 1.5 (2.2 si ≤ 22 años)
```
- `f_edad` positivo: 17–20 → 1.6, 23 → 1.25, 26 → 1.0, 31 → 0.8, 33 → 0.5, 35 → 0.3, 38+ → 0.15 (interpolado)
- `f_edad` negativo: ≤25 → 0.8, 30 → 1.0, 34 → 1.2, 37 → 1.4
- `f_potencial` = clamp(0.3 + (pot − base)/8, 0.3, 1.5); si base ≥ potencial → 0.1
- La negatividad se amortigua (×0.6): una mala carrera tiene más ruido externo que una buena.

El Δ se reparte entre grupos de atributos (clasificación → pace/qualifying; carrera → pace, racecraft, consistency,
tyre_management, overtaking, defending, awareness, starts) de forma que la media ponderada se mueve exactamente Δ.

## 3. Fin de temporada (escala C)

```
deriva = curva_edad(edad) [17:+1.1, 21:+0.65, 25:+0.2, 27:+0.05, 30:0, 34:−0.4, 36:−0.7, 38:−1.1, 41:−1.6]
si deriva > 0: deriva · dev_rate · min(1, f_potencial)
cambio = clamp(deriva + N(0, 0.35) + 0.15·media_temporada, ±1.5), sin superar potencial + 1
experiencia += 0.6; potencial converge hacia base un 25%/año desde los 26; forma ×0.5
```
Ruido sembrado → hay "late bloomers" y caídas tempranas; nada es determinista.

Retiradas: `p = 0.06 + 0.07·(edad − 34)` (+0.15 si rating < 72; forzada a 42). Rookies: potencial N(83, 5.5), base = potencial − U(5, 14).

## 4. Ejemplos (verificados en tests)

| Caso | Resultado del modelo | Test |
|---|---|---|
| §97 base 86.40, forma +0.2; Q P3 (esp. P8), R P2 (esp. P7) | base 86.40 → **86.43**, forma +0.2 → **+0.93** (spec: ~86.45 / +1.1) | `test_exceptional_weekend_example_97` |
| §98 10 fines de semana así | base 86.40 → **86.80** (spec: ~87.05) | `test_ten_excellent_races_example_98` |
| §99 piloto 90: accidente, P11, P13 | base 90 → **89.92**, forma **−1.91** (spec: 89.92 / −1.7) | `test_bad_streak_example_99` |
| 1 carrera terrible | |Δbase| ≤ 0.08, forma < −0.8 | `test_one_terrible_race_is_mostly_form` |
| mala racha y vuelta a la normalidad | forma vuelve a ~0 sin subir base | `test_form_regresses_to_zero_without_base_gain` |
| rookie 19 años supera al compañero toda la temporada | +0.8…+2.2 | `test_rookie_outperforming_for_season_develops` |
| 35 años ligeramente por encima | +0…+0.25 | `test_veteran_slightly_outperforming_little_growth` |

## 5. Test de 100 temporadas (§74)

`pytest -s backend/tests/test_progression_100_seasons.py` simula 100 temporadas × 22 carreras con el simulador real,
retiradas y relevo. Métricas de una ejecución (semilla 2026):

```
media parrilla primeras 10: 82.7  últimas 10: 80.8  (rango 80.0–84.0) · máximo histórico 90.8 · % ≥95 al final: 0
Δ máx por carrera 0.08 · rookie primer año: media +0.65, máx +1.69 · |forma| media 0.50
peor temporada de veterano −2.18, media veterano −0.81
```
Asserts: sin explosión (<99.5), sin deriva (>4 puntos), <25% élite, rookies < +3.5/año, forma reactiva, veteranos no se hunden.
