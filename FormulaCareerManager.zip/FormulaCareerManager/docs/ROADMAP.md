# Roadmap y estado

## MVP (§86) — ✅ completo

1 detectar AC · 2 escanear · 3 configurar campeonato · 4 crear trayectoria · 5 elegir coche F1 · 6 asignar 22 pilotos ·
7 generar carrera · 8 lanzar AC · 9 terminar · 10 importar resultado automáticamente · 11 puntos · 12 campeonato ·
13 guardar · 14 cerrar · 15 reabrir · 16 continuar en el mismo estado.

> Validado contra una instalación de AC simulada y un `acs.exe` falso (el PC de desarrollo no tiene AC). En tu PC real, verifica en la primera
> carrera: orden de parrilla (STARTING_POSITION), AI_AGGRESSION y calibración de AI_LEVEL (AC_INTEGRATION.md §7).

## Fases

| Fase | Estado | Contenido |
|---|---|---|
| 1 AC Integration | ✅ | detección, escáner, catálogo, mapeos, race.ini, lanzamiento, fin de sesión, importación, SQLite, shared memory, diagnóstico |
| 2 Championship Core | ✅ | pilotos, equipos, calendario (F1/F2/F3 compartiendo fin de semana), formatos, puntos, clasificaciones, estadísticas, histórico, partidas |
| 3 Driver Performance | ✅ | atributos, base/forma/moral/potencial, esperado vs real, compañero, edad, progresión/regresión, auditoría, traductor IA, test 100 temporadas |
| 4 Car Performance | ✅ | componentes, perfiles de pista, fuerza por circuito, traductor lastre/restrictor/IA, física avanzada experimental |
| 5 Management | ✅ | ledger, presupuestos, patrocinadores, premios, cost cap, I+D por departamentos, diseño → fabricación → instalación por piloto, instalaciones, fiabilidad/desgaste, daños con coste, componentes de motor y penalizaciones |
| 6 Driver Market | ✅ | contratos, salarios, ofertas, negociación con razones, cláusulas, academias, reservas, superlicencia, ascensos, retiradas, rookies, lesiones opcionales |
| 7 World Simulation | ✅ | IA de equipos (estrategia, riesgo, reparto actual/siguiente), reglamentos con cambios anunciados, coche del año siguiente, eventos con decisiones, sin rubber-banding |
| 9 Realismo de temporada | ✅ | parrilla real 2026 (ratings EA F1), Q1/Q2/Q3 eliminatoria jugable por fases, sprints elegibles en pretemporada, puntos F1 actuales, duración 5 vueltas/25/50/100 % (regla 305 km), formatos reales F2/F3, hora real del GP y clima aleatorio, estrategia de neumáticos/combustible, valor de mercado dinámico, fichajes en el parón de verano, jugar como piloto real o crear piloto (test de personalidad) |
| 8 Polish | ✅ | noticias desde eventos, hitos, récords, gráficas de rating y coche, telemetría del jugador, animaciones ligeras, UI en español |

## Limitaciones conocidas (dependen de Assetto Corsa)

- `race_out.json` no trae paradas, daños ni causa del abandono: se obtienen del jugador vía shared memory; para la IA en sesiones jugadas no están disponibles.
- Jugar requiere CSP con WeatherFX y RainFX (clima dinámico con controlador propio). La noche requiere además la función CONDITIONS_24H de CSP.
- El controlador de clima se ha escrito contra el SDK Lua de CSP sin una instalación real de AC en el PC de desarrollo: validar en la primera sesión con lluvia.
- En sesión jugada solo el neumático de salida y el combustible se envían a AC (setup `fcm_strategy.ini`, requiere `data/` legible del coche); las paradas las haces tú.
- La física avanzada solo funciona con coches con `data/` desempaquetado; los `data.acd` nunca se tocan.

## Posibles ampliaciones

- App Python/Lua dentro de AC (CSP) para registrar paradas y daños de todos los coches.
- Importación opcional de datos reales desde internet (módulo aparte; la app funciona sin conexión).
