# Formula Career Manager

Modo trayectoria de monoplazas (**F1 · F2 · F3**) para **Assetto Corsa** en PC.

La aplicación lleva todo el mundo de la competición: pilotos y equipos, calendario, resultados, clasificaciones, fichajes, desarrollo del coche y economía.
Assetto Corsa se encarga de la conducción. Tú pulsas **▶ Jugar**, corres la sesión y el resultado se importa solo. No hay que editar INIs ni copiar resultados a mano.

```
CAREER MANAGER ──genera race.ini──► ASSETTO CORSA (acs.exe) ──race_out.json──► CAREER MANAGER actualiza el mundo
```

## Características

- **Parrilla real 2026**: equipos y pilotos actuales de F1, F2 y F3. Las medias de F1 salen de EA Sports F1; las de F2 y F3 son estimaciones.
  Solo aparecen pilotos inventados cuando alguien se retira, y siempre en la categoría más baja.
- **Tres formas de empezar**: ser un piloto real, crear el tuyo eligiendo asiento o crearlo con un test de personalidad que recomienda categoría y equipo.
- **Fines de semana realistas**:
  - F1 con libres, clasificación eliminatoria Q1/Q2/Q3 y carrera. Los fines de semana sprint se eligen en pretemporada.
  - F2 y F3 con su formato real.
  - Puntuación de la F1 actual.
- **Duración de carrera configurable**: 5 vueltas, 25 %, 50 % o 100 %. El 100 % aplica la regla de 305 km sobre la longitud real del circuito (Mónaco, 260 km); F2 y F3 corren la mitad.
- **Clima dinámico**: cambia durante la sesión y se ve como un parte meteorológico con probabilidades de lluvia. Las carreras usan la hora real del GP, incluidas las nocturnas.
- **Estrategia**: blandos, medios, duros, intermedios y lluvia extrema, paradas y combustible. Con lluvia los equipos cambian de neumático cuando les compensa.
- **Progresión creíble**: la media de cada piloto cambia despacio y la forma y la moral más rápido. Se tienen en cuenta el compañero, la edad y el potencial.
- **Mercado**: valor de mercado dinámico, ofertas y negociación, fichajes en el parón de verano y a final de temporada, academias y ascensos F3 → F2 → F1.
- **Gestión del equipo**: I+D, fabricación e instalación de piezas por piloto, instalaciones, motores y penalizaciones, finanzas y límite de gasto, y decisiones del equipo.
  Si solo quieres pilotar, la gestión se puede delegar.
- **Noticias con tono de prensa**, récords e histórico de todas tus temporadas.
- **Funciona sin conexión**. Tema claro u oscuro. Todo en castellano.

## Requisitos para jugar

- Windows 10/11 y **Assetto Corsa** (Steam). Steam tiene que estar abierto al lanzar una sesión.
- **Custom Shaders Patch (CSP)** con **Weather FX** y **Rain FX** activados, para el clima dinámico, la lluvia y la noche.
  Se instala gratis desde [Content Manager](https://assettocorsa.club/content-manager.html) → Ajustes → Custom Shaders Patch.
- Para **simular** no hace falta nada de esto: se puede jugar una trayectoria entera simulando.

## Instalación

No hace falta Python ni Node en el PC donde se juega.

1. Genera la versión portable con `build.bat` (ver [Desarrollo](#desarrollo)) o usa una ya generada.
2. Copia la carpeta `dist/FormulaCareerManager/` (o descomprime `FormulaCareerManager.zip`) donde quieras.
3. Ejecuta `FormulaCareerManager.exe`. Se abre en una ventana propia (Edge o Chrome en modo aplicación).

## Primeros pasos

1. En el **menú principal** crea una trayectoria nueva o continúa una existente.
2. **Assetto Corsa** → *Detectar automáticamente* (o pega la carpeta del juego) → *Escanear contenido*.
3. **Assetto Corsa → Coches de la partida**: elige qué coche de tu AC hace de F1, F2 y F3. La app reparte una skin por equipo.
4. **Calendario**: elige el circuito de tu AC para cada Gran Premio. En pretemporada, marca también los fines de semana sprint.
5. **¿Listo para jugar?** comprueba que todo está preparado y te dice cómo arreglar lo que falte.
6. **Fin de semana** → *Simular hasta mi próxima sesión* → **▶ Jugar** → *Salir a pista*. Al terminar, sal al menú de AC: el resultado se guarda solo.

Las partidas se guardan en `%APPDATA%\FormulaCareerManager`: ficheros `.fcm`, guardados automáticos, registros y ajustes.
Para usarla en modo portable, crea un fichero vacío `portable.txt` junto al `.exe` y los datos irán a `userdata\`.

## Desarrollo

Requisitos solo para desarrollar: **Python 3.10+** y **Node.js 18+**. En ejecución, el backend usa únicamente la biblioteca estándar de Python.

| Acción | Comando |
|---|---|
| Ejecutar desde el código | `run_dev.bat` (compila el frontend si falta) |
| Frontend con recarga en caliente | `cd frontend && npm install && npm run dev` (redirige `/api` a 127.0.0.1:47820) |
| Tests | `python -m pip install -r backend/requirements-dev.txt` y `python -m pytest -q backend/tests` |
| Test de 100 temporadas con métricas | `python -m pytest -s backend/tests/test_progression_100_seasons.py` |
| Generar la versión portable | `build.bat` → `dist/FormulaCareerManager/` + `dist/FormulaCareerManager.zip` |

### Estructura

```
backend/fcm/          Servidor local (Python, solo stdlib)
  ac_integration/     Detección de AC, escáner de contenido, race.ini, lanzamiento, resultados, CSP
  career_engine/      Mundo, sesiones, campeonato, progresión de pilotos, noticias
  management/         Finanzas, I+D, componentes, mercado, fichajes, reglamento, eventos
  simulation/         Simulador vuelta a vuelta y clima
  database/           SQLite y migraciones
backend/tests/        Tests (pytest)
frontend/src/         Interfaz (React + TypeScript + Vite)
data/config/          Todos los parámetros del juego en JSON (balance, puntos, clima, IA…)
data/templates/       Mundo inicial (parrilla y calendario 2026)
docs/                 Documentación técnica
```

Los parámetros de balance (progresión, simulación, economía, clima, IA de AC…) están en `data/config/*.json`.
Desde la app se pueden sobrescribir en *Ajustes → Avanzado* sin tocar los originales.

## Documentación

- [ARCHITECTURE](docs/ARCHITECTURE.md): arquitectura, stack y decisiones
- [AC_INTEGRATION](docs/AC_INTEGRATION.md): integración con Assetto Corsa y CSP, qué datos son fiables y cuáles tienen alternativa
- [DATABASE](docs/DATABASE.md): esquema SQLite y migraciones
- [RATING_MODEL](docs/RATING_MODEL.md): modelo de media, forma, moral y potencial
- [CAR_PERFORMANCE](docs/CAR_PERFORMANCE.md): rendimiento del coche y perfiles de circuito
- [MANAGEMENT](docs/MANAGEMENT.md): finanzas, I+D, mercado, reglamento y eventos
- [DEVELOPMENT](docs/DEVELOPMENT.md): cómo extender, calibrar y testear
- [DATA_SOURCES](docs/DATA_SOURCES.md): origen de parrillas, medias y calendario
- [ROADMAP](docs/ROADMAP.md): estado y siguientes pasos

## Estado

Primera versión (0.1). Todo el ciclo de una trayectoria funciona y está probado simulando: varias temporadas con F1, F2 y F3, cierre de temporada, mercado y noticias.
La integración con Assetto Corsa está probada con una instalación simulada. En una instalación real conviene revisar en las primeras sesiones:

- el orden de la parrilla;
- el nivel de la IA (se calibra en `ai_mapping.json`);
- el clima dinámico de CSP.

## Aviso

Proyecto de aficionado, sin relación con la FIA, Formula One Group, Electronic Arts ni Kunos Simulazioni.
Los nombres de pilotos, equipos y competiciones pertenecen a sus respectivos propietarios y se usan solo como referencia.
No incluye contenido de Assetto Corsa: usa los coches y circuitos que tengas instalados.
