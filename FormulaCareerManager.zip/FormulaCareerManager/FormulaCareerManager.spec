# PyInstaller spec: portable folder dist/FormulaCareerManager/ (FormulaCareerManager.exe + _internal). No Python needed on the target PC.
# onedir is used instead of onefile: onefile self-extracting exes are frequently quarantined by antivirus/EDR.
# Build with build.bat (it builds the frontend first).
from pathlib import Path

root = Path(SPECPATH)

a = Analysis(
    [str(root / 'backend' / 'fcm' / 'main.py')],
    pathex=[str(root / 'backend')],
    datas=[
        (str(root / 'data' / 'config'), 'data/config'),
        (str(root / 'data' / 'templates'), 'data/templates'),
        (str(root / 'data' / 'schemas'), 'data/schemas'),
        (str(root / 'frontend' / 'dist'), 'frontend/dist'),
        (str(root / 'backend' / 'fcm' / 'database' / 'migrations'), 'fcm/database/migrations'),
    ],
    hiddenimports=['fcm.api.routes', 'fcm.api.http'],
    excludes=['tkinter', 'unittest', 'pydoc', 'pytest'],
    noarchive=False,
)
pyz = PYZ(a.pure)
exe = EXE(
    pyz, a.scripts, [],
    exclude_binaries=True,
    name='FormulaCareerManager',
    icon=str(root / 'assets' / 'icon.ico'),
    console=False,
    upx=False,
)
coll = COLLECT(exe, a.binaries, a.datas, upx=False, name='FormulaCareerManager')
